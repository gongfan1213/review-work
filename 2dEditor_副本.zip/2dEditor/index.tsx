import React, { useCallback, useEffect, useState } from 'react'
import { navigate, type PageProps } from 'gatsby'
import * as classes from './index.module.scss'
import App from './App'
import { useLocation } from '@reach/router'

export default function MememakerPage(props: PageProps) {
  const location = useLocation()
  return (
    <div className={classes.root}>
      <App location={location} />
    </div>
  )
}
