import { CanvasEventEmitter } from '../utils/event/notifier';
import { createContext, useContext } from 'react';
import { fabric as FabricType } from 'fabric';
import Editor from '../core';
import { ProjectModel } from '../components/SelectDialog/model/ProjectModel';


export const FabricContext = createContext<typeof FabricType | null>(null);
export const EventContext = createContext<CanvasEventEmitter | null>(null);
export const CanvasEditorContext = createContext<Editor | undefined>(undefined);
export const AllRight_state = createContext<any>(null);
export const CanvasContext = createContext<any>(null);
export const ProjectContext = createContext<ProjectModel | null>(null);
export const SearchContext = createContext<any>(null);
export const ShowUiContainerState = createContext<any>(null);

export const useFabric = () => useContext(FabricContext);
export const useEvent = () => useContext(EventContext);
export const useCanvasEditor = () => useContext(CanvasEditorContext);
export const useAllRight = () => useContext(AllRight_state);
export const useCanvas = () => useContext(CanvasContext);
export const useProjectData = () => useContext(ProjectContext);
export const useSearchContext = () => useContext(SearchContext);
export const useShowUiContainerState = () => useContext(ShowUiContainerState);