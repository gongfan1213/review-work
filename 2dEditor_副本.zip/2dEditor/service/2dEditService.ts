import { post } from 'src/services';
import {
  MaterialCreateRequestModel,
  MaterialDeleteRequestModel,
  MaterialEditData,
  MaterialEditDataList,
  ProjecDeleteRequestModel,
  ProjecDetailtRequestModel,
  ProjectDownUrlRequestModel,
  ProjectDownUrlResponseModel,
  ProjectModel,
  ProjectModelList,
  ProjectUpdateRequestModel,
  RemoveImageBackgroundRequestModel,
  RemoveImageBackgroundResponseModel,
  StartCreate_taskRequestModel,
  TaskStatus_RequestModel,
  StartCreate_taskRequestModel_post,
  TaskStatus_RequestModel_post,
  HistoryLists_RequestModel,
  HistoryLists_RequestModel_post,
  GetWorksList_RequestModel,
  GetWorksList_RequestModel_post,
  getCollectOfficialt_RequestModel,
  getCollectOfficialt_RequestModel_post,
  getLikeWorks_RequestModel,
  getLikeWorks_RequestModel_post,
  getFficialMaterialStatus_RequestModel,
  getFficialMaterialStatus_post,
  CreateScalerImageRequestModel,
  CreateScalerImageResponseModel,
  GetScalerImageRequestModel,
  GetScalerImageResponseModel,
  EndScalerImageRequestModel,
  EndScalerImageResponseModel,
  PopArtify_taskRequestModel,
  PopArtify_taskRequestModel_post,
  ProjectCreateRequestModel,
  ProjectCavasUpdateRequestModel,
  PublishRequestModel,
  PublishResponseModel,
  getTextImageCreate_task,
  getTextImageCreate_task_post,
  getTextImageTaskStatus,
  getTextImageTaskStatus_post,
  delete_history,
  delete_history_post,
  GetPetPortraitCreateTaskReqModal,
  GetPetPortraitTaskStatusResModal,
  CreateModelTrainTaskReqModal,
  GetModelTrainTaskStatusResModal,
  RotaryParams,
} from '../components/SelectDialog/model/ProjectModel';
import { CusPageRequestModel, CusResponseModel } from '../common/netUtil';
import navigate from 'src/common/route';
import { CanvasCategory } from '../cons/2dEditorCons';
import { getRotaryParams } from '../common/cavasUtil';

export async function createProject(data: ProjectCreateRequestModel) {
  try {
    const resp = await post<ProjectModel>('/web/editor/project/create_project', data);
    return resp;
  } catch {
    return null;
  }
}

export async function updateProject(data: ProjectUpdateRequestModel) {
  try {
    const resp = await post<ProjectModel>('/web/editor/project/update_project', data);
    return resp;
  } catch {
    return null;
  }
}

export async function updateProjectCavas(data: ProjectCavasUpdateRequestModel, isThread?: boolean) {
  try {
    var resp = await post<ProjectModel>('/web/editor/canvas/update_canvas', data, undefined, isThread);
    return resp;
  } catch {
    return null;
  }
}

export async function getProjectDetail(data: ProjecDetailtRequestModel) {
  try {
    const resp = await post<ProjectModel>('/web/editor/project/get_project_detail', data);

    if (resp && resp.data && resp.data.canvases && resp.data.canvases.length > 0) {
      // 兼容旧数据，旋转体
      var rotary_params: RotaryParams = JSON.parse(resp.data.canvases[0].print_param).rotary_params;
      if (!rotary_params && resp.data.project_info.category == CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL) {
        resp.data.canvases[0].print_param = JSON.stringify({
          ...JSON.parse(resp.data.canvases[0].print_param),
          rotary_params: getRotaryParams(resp.data.canvases[0].base_map_width, resp.data.canvases[0].base_map_height),
        });
      }
    }
    return resp;
  } catch {
    return null;
  }
}

export async function getProjectList(data: CusPageRequestModel) {
  try {
    const resp = await post<ProjectModelList>('/web/editor/project/get_project_list', data);
    return resp;
  } catch {
    return null;
  }
}

export async function deleteProjectList(data: ProjecDeleteRequestModel) {
  try {
    const resp = await post<CusResponseModel>('/web/editor/project/delete_project', data);
    return resp;
  } catch {
    return null;
  }
}

export async function getUserMaterialList(data: CusPageRequestModel) {
  try {
    const resp = await post<MaterialEditDataList>('/web/editor/uploads/get_material_list', data);
    return resp;
  } catch {
    return null;
  }
}

export async function createUserMaterial(data: MaterialCreateRequestModel) {
  try {
    const resp = await post<MaterialEditData>('/web/editor/uploads/create_material', data);
    return resp;
  } catch {
    return null;
  }
}

export async function deleteUserMateria(data: MaterialDeleteRequestModel) {
  try {
    const resp = await post<CusResponseModel>('/web/editor/uploads/delete_material', data);
    return resp;
  } catch {
    return null;
  }
}

export async function getProjectImgDownUrl(data: ProjectDownUrlRequestModel) {
  try {
    const resp = await post<ProjectDownUrlResponseModel>('/web/editor/cloudstor/get_download_url', data);
    return resp;
  } catch {
    return null;
  }
}

// #regiom remove background API;
export async function removeImageBackground(data: RemoveImageBackgroundRequestModel) {
  try {
    const resp = await post<RemoveImageBackgroundResponseModel>('/web/aihub/aitools/remove_bg', data);
    return resp;
  } catch {
    return null;
  }
}
export async function createRemoveBGImage(data: CreateScalerImageRequestModel) {
  try {
    const resp = await post<CreateScalerImageResponseModel>('/web/aihub/removebg/create_task', data);
    return resp;
  } catch {
    return null;
  }
}
export async function getRemoveBGImage(data: GetScalerImageRequestModel) {
  try {
    const resp = await post<GetScalerImageResponseModel>('/web/aihub/removebg/get_task_status', data);
    return resp;
  } catch {
    return null;
  }
}
export async function endRemoveBGImage(data: EndScalerImageRequestModel) {
  try {
    const resp = await post<EndScalerImageResponseModel>('/web/aihub/removebg/stop_task', data);
    return resp;
  } catch {
    return null;
  }
}
// #endregiom remove background API;

export async function createUpscalerImage(data: CreateScalerImageRequestModel) {
  try {
    const resp = await post<CreateScalerImageResponseModel>('/web/aihub/upscale/create_task', data);
    return resp;
  } catch {
    return null;
  }
}

export async function getUpscalerImage(data: GetScalerImageRequestModel) {
  try {
    const resp = await post<GetScalerImageResponseModel>('/web/aihub/upscale/get_task_status', data);
    return resp;
  } catch {
    return null;
  }
}

export async function endUpscalerImage(data: EndScalerImageRequestModel) {
  try {
    const resp = await post<EndScalerImageResponseModel>('/web/aihub/upscale/stop_task', data);
    return resp;
  } catch {
    return null;
  }
}

export async function StartCreate_task(data: StartCreate_taskRequestModel) {
  try {
    const resp = await post<StartCreate_taskRequestModel_post>('/web/aihub/faceswap/create_task', data);
    return resp;
  } catch {
    return;
  }
}

export async function PopArtify_task(data: PopArtify_taskRequestModel) {
  try {
    const resp = await post<PopArtify_taskRequestModel_post>('/web/aihub/styletransfer/create_task', data);
    return resp;
  } catch {
    return null;
  }
}

export async function getTaskStatus(data: TaskStatus_RequestModel) {
  try {
    const resp = await post<TaskStatus_RequestModel_post>('/web/aihub/faceswap/get_task_status', data);
    return resp;
  } catch (e) {
    return;
  }
}

export async function getHistoryList(data: HistoryLists_RequestModel) {
  try {
    const resp = await post<HistoryLists_RequestModel_post>('/web/aihub/common/get_history_list', data);
    return resp;
  } catch {
    return null;
  }
}

// 删除AI历史记录
export async function deleteHistory(data: delete_history) {
  try {
    const resp = await post<delete_history_post>('/web/aihub/common/delete_history', data);
    return resp;
  } catch {
    return null;
  }
}

//获取模版列表
export async function getWorksList(data: GetWorksList_RequestModel) {
  try {
    const resp = await post<GetWorksList_RequestModel_post>('/web/editor/works/get_works_list', data);
    return resp;
  } catch {
    return null;
  }
}

//获取模版JSON文件
export async function getJsonUrl(data: { works_id: string }) {
  try {
    const resp = await post<{ download_url: string }>('/web/editor/works/get_template_file', data);
    return resp;
  } catch {
    return null;
  }
}

// 字体和元素的收藏与取消收藏
export async function getCollectOfficialt(data: getCollectOfficialt_RequestModel, isLike: boolean) {
  try {
    const resp = await post<getCollectOfficialt_RequestModel_post>(
      isLike
        ? '/web/editor/material/collect_official_material'
        : '/web/editor/material/cancel_collect_official_material',
      data,
    );
    return resp;
  } catch {
    return null;
  }
}

// 模版的收藏与取消收藏
export async function getLikeWorks(data: getLikeWorks_RequestModel, isLike: boolean) {
  try {
    const resp = await post<getLikeWorks_RequestModel_post>(
      isLike ? '/web/editor/works/like_works' : '/web/editor/works/cancel_like_works',
      data,
    );
    return resp;
  } catch {
    return null;
  }
}

// 获取字体和元素的收藏状态
export async function getFficialMaterialStatus(data: getFficialMaterialStatus_RequestModel) {
  try {
    const resp = await post<getFficialMaterialStatus_post>('/web/editor/material/get_official_material_status', data);
    return resp;
  } catch {
    return null;
  }
}

// Publish;
export async function publish(data: PublishRequestModel) {
  try {
    const resp = await post<PublishResponseModel>('/web/editor/works/publish_works', data);
    return resp;
  } catch {
    return null;
  }
}

export async function getTextImageCreatetask(data: getTextImageCreate_task) {
  try {
    const resp = await post<getTextImageCreate_task_post>('/web/aihub/text2image/create_task', data);
    return resp;
  } catch (e) {
    throw e;
  }
}

export async function getTextImageTaskstatus(data: getTextImageTaskStatus) {
  try {
    const resp = await post<getTextImageTaskStatus_post>('/web/aihub/text2image/get_task_status', data);
    return resp;
  } catch (e) {
    throw e;
  }
}

// 创建宠物肖像任务
export async function petPortraitCreateTask(data: GetPetPortraitCreateTaskReqModal) {
  try {
    const resp = await post<{ task_id: string }>('/web/aihub/petportrait/create_task', data);
    return resp;
  } catch {
    return null;
  }
}

// 获取宠物肖像进度及结果
export async function petPortraitGetTaskStatus(data: { task_id: string }) {
  try {
    const resp = await post<GetPetPortraitTaskStatusResModal>('/web/aihub/petportrait/get_task_status', data);
    return resp;
  } catch {
    return null;
  }
}

// 停止宠物肖像任务
export async function petPortraitStopTask(data: { task_id: string }) {
  try {
    const resp = await post<{ task_id: string }>('/web/aihub/petportrait/stop_task', data);
    return resp;
  } catch {
    return null;
  }
}

// 创建模型训练任务
export async function createModelTrainTask(data: CreateModelTrainTaskReqModal) {
  try {
    const resp = await post<{ task_id: string }>('/web/aihub/train/create_task', data);
    return resp;
  } catch {
    return null;
  }
}

// 获取模型训任务列表
export async function getModelTrainTaskList(data: { pagination: { page: number; page_size: number } }) {
  try {
    const resp = await post<{ list: any[]; total: number }>('/web/aihub/train/get_task_list', data);
    return resp;
  } catch {
    return null;
  }
}

// 获取模型训练进度及结果
export async function getModelTrainTaskStatus(data: { task_id: string }) {
  try {
    const resp = await post<GetModelTrainTaskStatusResModal>('/web/aihub/train/get_task_status', data);
    return resp;
  } catch {
    return null;
  }
}

// 获取模型训练上传Token
export async function getModelTrainUploadToken(data: { dataset_num: number }) {
  try {
    const resp = await post<{ dataset_id: string; thumb_token: string; upload_token: string[] }>(
      '/web/aihub/train/get_upload_token',
      data,
    );
    return resp;
  } catch {
    return null;
  }
}

// 停止模型训练任务
export async function stopModelTrainTask(data: { task_id: string }) {
  try {
    const resp = await post<{ task_id: string }>('/web/aihub/train/stop_task', data);
    return resp;
  } catch {
    return null;
  }
}

// 删除训练模型记录(训练任务)
export async function deleteModelTrainTask(data: { ids: number[] }) {
  try {
    const resp = await post('/web/aihub/train/delete_history', data);
    return resp;
  } catch {
    return null;
  }
}
// 获取用户总积分
export async function getAiCredit(data: { need_detail: boolean }) {
  try {
    const resp = await post('/web/aicredit/get_ai_credit', data);
    return resp;
  } catch {
    return null;
  }
}

// 获取ai模块消耗积分
export async function getAiCreditConsumeInfo() {
  try {
    const resp = await post('/web/aicredit/get_ai_credit_consume_info');
    return resp;
  } catch {
    return null;
  }
}

// 获取风格迁移任务进度
export async function GetTaskStatus(data: { task_id: string }) {
  try {
    const resp = await post('/web/aihub/styletransfer/get_task_status', data);
    return resp;
  } catch {
    return null;
  }
}
