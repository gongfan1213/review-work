import { ACTION_MAGICK } from "../cons/2dEditorCons";

onmessage = async function (e) {
  const { url, options } = e.data;
  try {
    const res = await fetch(url, options)
    const data = await res.json(); // 假设响应是 JSON
    const ret = {
      status: res.status,
      statusText: res.statusText,
      data: data,
    };
    this.self.postMessage(ret);
  } catch (e) {
    this.self.postMessage(e);
  }
};

