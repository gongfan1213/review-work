/*
 * @Description: 自定义事件的类型
 */

// 选择模式
export enum SelectMode {
  EMPTY = '',
  ONE = 'one',
  MULTI = 'multiple',
}

export enum SelectOneType {
  EMPTY = '',
  GROUP = 'group',
  POLYGON = 'polygon',
}

// 选择事件（用于广播）
export enum SelectEvent {
  ONE = 'selectOne',
  MULTI = 'selectMultiple',
  CANCEL = 'selectCancel',
}


//2d编辑器入口来源from与type值映射关系
export enum From2dEditorType {
  NewProject = '1', //from:New Project/Projects
  Replace = '2',  //from:Replace
  RecentProjects = '3', //from:2dStudio-->Recent Projects
  CustomizeDesign = '4', //from:details-->AI Tools-->Customize this design
  MyCreated = '5', //from:My Projects-->Created
  HomeNewProject = '6', //from:Home--> + New Project
  AiTool = '7', //from:AiTool
  CreateDesign = '8', //from:2dStudio-->Create a new design
  MyPublished = '9', //from:2dStudio-->Create a new design
  CreateProjectAuto = '10', //进入编辑器自动创建默认项目
}
