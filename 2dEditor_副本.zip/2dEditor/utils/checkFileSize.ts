import { EditorToastType, editorToastShow } from 'src/templates/2dEditor/components/Toast/index';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
export function checkFileSize(item: any) {
  const { getTranslation } = useCustomTranslation()
  // 获取文件扩展名并转换为小写
  const fileExtension = item?.name.split('.').pop()?.toLowerCase();
  // 获取文件大小
  const fileSize = item.size;
  // 定义文件大小限制，避免重复创建对象
  const SVG_SIZE_LIMIT = 5 * 1024 * 1024; // SVG文件大小限制为5MB
  const DEFAULT_SIZE_LIMIT = 50 * 1024 * 1024; // 其他支持的文件类型大小限制为50MB

  // 根据文件扩展名获取对应的大小限制
  const limit = fileExtension === 'svg' ? SVG_SIZE_LIMIT : DEFAULT_SIZE_LIMIT;

  // 判断文件是否超过大小限制
  if (fileSize > limit) {
    // 如果文件超过大小限制，显示错误提示并终止方法执行
    editorToastShow({
      tips: fileExtension === 'svg' ?
      getTranslation(TranslationsKeys.SVG_SIZE_LIMIT_EXCEEDED)
      : getTranslation(TranslationsKeys.PNG_SIZE_LIMIT_EXCEEDED),
      type: EditorToastType.error,
    });
    return false; // 返回false表示文件超过大小限制
  }
  return true; // 返回true表示文件未超过大小限制
}