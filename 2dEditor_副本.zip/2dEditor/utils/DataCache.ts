import { useState, useEffect } from 'react';

class DataCache {
  private static instance: DataCache;
  private data: Record<string, any>;

  private constructor() {
    this.data = {};
  }

  public static getInstance(): DataCache {
    if (!DataCache.instance) {
      DataCache.instance = new DataCache();
    }
    return DataCache.instance;
  }

  public setItem(key: string, value: any): void {
    this.data[key] = value;
  }

  public getItem(key: string): any {
    return this.data[key];
  }

  public removeItem(key: string): void {
    delete this.data[key];
  }

  public clear(): void {
    this.data = {};
  }

}

const useDataCache = () => {
  const cache = DataCache.getInstance();
  const [_, forceUpdate] = useState({});

  useEffect(() => {
  
  }, []);

  const setCacheItem = (key: string, value: any) => {
    cache.setItem(key, value);
    forceUpdate({});
  };

  const getCacheItem = (key: string) => {
    return cache.getItem(key);
  };

  const removeCacheItem = (key: string) => {
    cache.removeItem(key);
    forceUpdate({});
  };

  const clearPageCache = () => {
    cache.clear();
    forceUpdate({});
  };

  const cacheHasMore = (key: string) => {
    return getCacheItem(key)?.['hasMore'];
  }

  const cachePageSize = (key:string) => {
    return getCacheItem(key)?.['pageSize'];
  }

  const cacheData = (key:string) => {
    return getCacheItem(key)?.['pageData'];
  }

  return { setCacheItem, getCacheItem, removeCacheItem, clearPageCache, cacheHasMore, cachePageSize, cacheData };
}

export default useDataCache;