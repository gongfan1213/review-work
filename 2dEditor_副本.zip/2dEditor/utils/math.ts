/**
 * 获取多边形顶点坐标
 * @param edges 变数
 * @param radius 半径
 * @returns 坐标数组
 */
const getPolygonVertices = (edges: number, radius: number) => {
  const vertices = [];
  const interiorAngle = (Math.PI * 2) / edges;
  let rotationAdjustment = -Math.PI / 2;
  if (edges % 2 === 0) {
    rotationAdjustment += interiorAngle / 2;
  }
  for (let i = 0; i < edges; i++) {
    // 画圆取顶点坐标
    const rad = i * interiorAngle + rotationAdjustment;
    vertices.push({
      x: Math.cos(rad) * radius,
      y: Math.sin(rad) * radius,
    });
  }
  return vertices;
};

/**
 * 求直角三角形斜边长度;
 * @param baseLine 基底长度;
 * @param perpendicularLine 垂直线长度;
 * @returns 斜边长度;
 */
const getHypotenuse = (baseLine: number, perpendicularLine: number) => {
  const bSquare = baseLine ** 2;
  const pSquare = perpendicularLine ** 2;
  const sum = bSquare + pSquare;
  const hypotenuse = Math.sqrt(sum);
  return hypotenuse;
};
/**
 * 求直角三角形对边长度;
 * @param hypotenuse 斜边长度;
 * @param angleInDegrees 角度;
 * @returns 对边长度;
 */
function getOppositeSide(hypotenuse: number, angleInDegrees: number) {
  // 将角度从度转换为弧度
  var angleInRadians = angleInDegrees * (Math.PI / 180);

  // 使用正弦函数计算对边长度
  var oppositeSide = hypotenuse * Math.sin(angleInRadians);

  return oppositeSide;
}
/**
 * 求平面坐标系的角度;
 * @param downPointer 鼠标落下点;
 * @param movePointer 鼠标移动点
 * @returns angle;
 */
const getPlaneAngle = (downPointer: any, movePointer: any) => {
  var angle =
    (Math.atan2(movePointer.y - downPointer.y, movePointer.x - downPointer.x) *
      180) /
    Math.PI;
  return angle;
};


export {
  getPolygonVertices,
  getHypotenuse,
  getOppositeSide,
  getPlaneAngle,
};
