/*
 * @Description: 工具文件
 */

import { isLogined } from 'src/common/storage'
import TemplatesUtilsFn from 'src/templates/utils'
import { Modal } from 'src/components/MakeUI'

import {
  CanvasesInfo,
  ProjectCreateRequestModel,
  ProjectInfo,
  ProjectModel,
} from '../components/SelectDialog/model/ProjectModel'
import {
  PrintLayerModel,
  PrintModel,
  PrintQuality,
} from 'src/templates/2dEditor/components/MainUi/MainUiRightComponent/PrintLayer/model/PrintLayerModel'
import StringUtil from 'src/common/utils/stringUtil'
import { createProject } from '../service/2dEditService'
import { removeLocalStorage, setLocalStorage } from 'src/common/storage'
import { openToast } from 'src/state/reducers/toast'
import { CanvasCategory, CanvasParams, CustomPcAction, FabricObjectType } from '../cons/2dEditorCons';
import { isPc, loginFromWeb, sendCommandToPc } from 'src/common/jsbridge'
import navigate from 'src/common/route'
import { From2dEditorType } from 'src/templates/2dEditor/utils/event/types'
import { reach } from 'yup'
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
// const useClipboard = () => {}
const useFileDialog = () => { }
const useBase64 = () => { }

interface Font {
  type: string;
  fontFamily: string;
}

/**
 * @description: 选择文件
 * @param {Object} options accept = '', capture = '', multiple = false
 * @return {Promise}
 */
export const selectFiles = (options: {
  accept?: string;
  capture?: string;
  multiple?: boolean;
}) => {
  options = { accept: "image/*", multiple: false, ...options };
  // 创建input[type="file"]
  const input = document.createElement("input");
  input.type = "file";
  // 获取选择的文件
  input.id = "upFile";
  // 设置文件类型
  input.accept = options.accept;
  // 设置是否多选
  if (options.multiple) {
    input.multiple = "multiple";
  }
  return new Promise((resolve) => {
    input.onchange = function () {
      resolve(this.files);
    };
    // 触发选择
    input.click();
  });
};

/**
 * @description: 图片文件转字符串
 * @param {Blob|File} file 文件
 * @return {String}
 */
export function getImgStr(file: File | Blob): Promise<FileReader['result']> {
  // 将文件转为base64

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  })
}

/**
 * @description: 根据json模板下载字体文件
 * @param {String} str
 * @return {Promise}
 */
export async function downFontByJSON(str: string): Promise<void[]> {
  try {
    const skipFonts = ['arial', 'Microsoft YaHei'];
    const parsedData = JSON.parse(str);

    function extractTextObjects(item: any): any[] {
      if (item.type === 'group' && item.objects) {
        return item.objects.flatMap(extractTextObjects); // 递归提取组内的文本对象
      } else if (item.type === 'text' || item.type === 'textbox') {
        return [item]; // 返回文本对象
      }
      return []; // 非文本对象返回空数组
    }

    const fontLoadPromises: Promise<void>[] = parsedData.objects
      .flatMap(extractTextObjects)
      .filter((item: any) => {
        const isNotSkippedFont = !skipFonts.includes(item.fontFamily);
        return isNotSkippedFont;
      })
      .map((item: any) => {
        // 确保 item._fontUrl 是已定义的字符串
        if (typeof item._fontUrl === 'string') {
          const fontName = item.fontFamily;
          console.log(`downFontByJSON =====Loading font:=== ${fontName}`, item._fontUrl);
          let fontFace = new FontFace(fontName, `url(${item._fontUrl})`);
          (document.fonts as any).add(fontFace);
          return fontFace.load();
        }
        // 如果 _fontUrl 不是字符串，返回一个立即解决的 Promise
        return Promise.resolve();
      });

    return Promise.all(fontLoadPromises);
  } catch (error) {
    console.error("Error parsing JSON string:", error);
    return Promise.reject(error);
  }
}

/**
 * @description: 创建图片元素
 * @param {String} str 图片地址或者base64图片
 * @return {Promise} element 图片元素
 */
export function insertImgFile(str: string) {
  return new Promise((resolve) => {
    const imgEl = document.createElement('img');
    imgEl.src = str;
    // 插入页面
    document.body.appendChild(imgEl);
    imgEl.onload = () => {
      resolve(imgEl);
    };
  });
}

/**
 * Copying text to the clipboard
 * @param source Copy source
 * @param options Copy options
 * @returns Promise that resolves when the text is copied successfully, or rejects when the copy fails.
 */
export const clipboardText = async (
  source: string,
  options?: Parameters<typeof useClipboard>[0]
) => {
  const { getTranslation } = useCustomTranslation();
  try {
    await useClipboard({ source, ...options });
    openToast({
      message: getTranslation(TranslationsKeys.COPY_SUCCESS_CHINESE),
      severity: 'success',
    })
  } catch (error) {
    openToast({
      message: getTranslation(TranslationsKeys.COPY_FAILED_CHINESE),
      severity: 'error',
    })
    throw error;
  }
};

export const useClipboard = async ({ source, ...options }: { source: string }) => {
  try {
    return navigator.clipboard.writeText(source);
  } catch (error) {
    throw error;
  }
};

// 将静态数组重复n次，传入需要重复的数组与次数
export function repeatObject(obj: any, times: any) {
  return Array(times).fill(null).map(() => ({ ...obj }));
}

// 是否滚到到最右侧，触发最右侧加载,true为触底
export function isScrolledToRight(element: any, differenceDistance = 0) {
  if (!element) return false;
  // 元素的总宽度
  const totalWidth = element.scrollWidth;
  // 元素的可视区域宽度
  const viewportWidth = element.clientWidth;
  // 元素向右滚动过的像素数
  const scrollPosition = element.scrollLeft;
  // console.log("-------->>>>", scrollPosition + viewportWidth, '222222', totalWidth, '33333', element);
  // 判断是否滚动到最右侧，考虑到一个差距值
  // return scrollPosition + viewportWidth + differenceDistance >= totalWidth;
  // 判断是否滚动超过总宽度的一半，就返回true
  return (scrollPosition + viewportWidth + differenceDistance / 2) >= totalWidth / 2;
}

// 数据添加与转化
export function appendListToDataA(dataA: any, dataB: any) {
  // console.log('dataA', dataA, 'dataB', dataB);
  // 遍历数据a
  for (let i = 0; i < dataA.length; i++) {
    // 找到与数据b的label相同的项
    if (dataA[i].label === dataB.label) {
      // 将数据b的list逐项添加到对应项的list后面
      dataA[i].list.push(...dataB.list);
      break; // 可以选择终止循环，如果确定只有一个匹配的项
    }
  }
  return dataA;
}
// 更新缓存内的数据
export function replaceGraphicData(dataA: any, dataB: any, active?: any) {
  // 遍历数据A
  dataA.forEach((itemA: any) => {
    if (active) {
      // 检查数据B的pageData对象中是否有Graphic属性
      if (dataB.pageData[active]) {
        // 遍历Graphic对象的data数组
        dataB.pageData[active].data.forEach((itemB: any, index: number) => {
          // 如果找到相同label的元素，则替换list属性
          if (itemB.label === itemA.label) {
            dataB.pageData[active].data[index].list = itemA.list;
          }
        });
      }
    } else {
      if (dataB.pageData) {
        dataB.pageData.forEach((itemB: any, index: number) => {
          // 如果找到相同label的元素，则替换list属性
          if (itemB.label === itemA.label) {
            dataB.pageData[index].list = itemA.list;
          }
        });
      }
    }
  });

  // 返回修改后的数据B
  return dataB;
}

// AiTools与Apps的映射关系，需要id和title对应上
// export const titleMapping: any = {
//   'Royal Portrait': '1',
//   'Master Landscape': '2',
//   'Master Portrait': '3',
//   'Pop Art Maker': '4',
//   'AI Product Designer': '5',
//   'Pet Poratrait': '6',
// };

// 更新缓存内的数据
const handleLink2dEditor = (projectId: string, type: string, projectData?: any, AiTitle?: any, hasChangePageForPc?: boolean) => {
  console.log('projectId', projectId, 'type', type, 'projectData', projectData, 'AiTitle', AiTitle);

  if (isLogined()) {
    if (projectData) {
      setLocalStorage('projectData', JSON.stringify(projectData))
    } else {
      removeLocalStorage('projectData')
    }
    const queryParams = [];
    if (projectId) {
      queryParams.push(`project_id=${projectId}`);
    }
    if (type) {
      queryParams.push(`type=${type}`);
    }
    if (AiTitle) {
      queryParams.push(`AiTitle=${AiTitle}`);
    }
    const url = `/apps/2dEditor/${queryParams.length > 0 ? '?' + queryParams.join('&') : ''}`;
    if (isPc()) {
      let flag = beforeHomeToCreatedByTool(projectData, type, '2dStudio', AiTitle, hasChangePageForPc)
      if (flag) return
    };
    if (typeof window !== 'undefined') {
      window.open(url, '_blank');
      // 删除旧窗口的AiTitle
      window?.sessionStorage?.removeItem('AiTitle')
      window?.sessionStorage?.removeItem('AiToolsAllData')
      window?.sessionStorage?.removeItem('sessionAiModeIntegralData')
    }
  } else {
    if (TemplatesUtilsFn.redirectLogin()) return
  }
}

const beforeHomeToCreatedByTool = (project: any, type: string, target: any, AiTitle: string, hasChangePageForPc: boolean | undefined) => {
  if (isPc()) {
    if (!isLogined()) {
      loginFromWeb()
      return true
    } else {
      console.log('=====jumoCreateDesign=========555,', hasChangePageForPc)
      if (hasChangePageForPc) {
        const queryParams = [];
        if (project) {
          var project_id = project.project_info.project_id;
          queryParams.push(`project_id=${project_id}`);
        }
        if (type) {
          queryParams.push(`type=${type}`);
        }
        if (AiTitle) {
          queryParams.push(`AiTitle=${encodeURIComponent(AiTitle)}`);
        }
        const url = `/apps/2dEditor/${queryParams.length > 0 ? '?' + queryParams.join('&') : ''}`;
        // const targetUrl = `https://${domain}/apps/2dEditor/?key=${type}&target=${target}&AiTitle=${encodeURIComponent(AiTitle)}&project_id=${project_id}`
        const targetUrl = `https://${window.location.host}${url}`
        console.log('触发-通信-webTopc-->', targetUrl)
        sendCommandToPc(CustomPcAction.command_switchPage, {
          target: target,
          target_url: targetUrl,
          // project_id: project_id,
        })
      } else {
        navigate('/apps/2dEditor/?popover=off', {
          state: {
            EditorParmas: {
              key: '2dStudio',
              data: { ...project, project_id: project_id, type: From2dEditorType.AiTool, AiTitle: AiTitle, },
            },
          },
        })
      }
    }
    return true
  }
};

//创建项目错误提示
const handleError = (project: any, fn: any, t: any, close?: () => void) => {
  const { getTranslation } = useCustomTranslation();
  if (project && project?.code === 0 && project!.data) {
    return project!.data
  } else if (project?.code === 181301 || project?.code === 181302) {
    // 181301 项目数超过最大限制
    // 181302 画布数超过最大限制
    Modal.confirm({
      title: '',
      content: t(
        'str_my_projects',
        'You can create up to 20 projects.',
      ),
      okText: t('btn_make', 'Manage Projects'),
      cancelText: t('Cancel'),
      closable: true,
      onOk: async (callBack: () => void) => {
        callBack()
        if (typeof window !== 'undefined') {
          const urlParams = new URLSearchParams(window.location.search);
          const type = urlParams.get('type');
          if (type === '1' || type === '2') {
            window.open('/?MyProject=7', '_blank');
          } else {
            close?.()
            navigate('/?MyProject=7')
          }
        }
      },
      onCancel: async (callBack: () => void) => {
        callBack()
      },
    })
    return false
  } else {
    fn(
      openToast({
        message:
          project?.msg ??
          getTranslation(TranslationsKeys.SOMETHING_WRONG_TRY),
        severity: 'error',
      }),
    )
    return false
  }
}

//创建项目数据整理
const createProjectRequest = (
  canvasData: any,
  isReplace?: boolean,
) => {
  console.log('++++++++create+++++++++canvasData++++++++++', canvasData);
  let newScenes = canvasData?.scenes && Array.isArray(canvasData?.scenes) && canvasData?.scenes?.length ? canvasData?.scenes.map((item: any) => {
    let scenesImgs: string[] = []
    item.scenesImg?.data?.forEach((element: any) => {
      scenesImgs.push(element?.attributes?.url)
    })
    return scenesImgs
  }) : []

  let canvasInfo: CanvasesInfo
  const printLayerModel: PrintLayerModel = {
    printModel: PrintModel.printModel1,
    imgQuality: PrintQuality.printQuality2,
    printLayerData: [],
  }

  printLayerModel.format_size_w = canvasData?.baseMapWidth || 0
  printLayerModel.format_size_h = canvasData?.baseMapHeight || 0
  printLayerModel.cavas_map =
    canvasData?.baseMapCavas?.data?.attributes?.url || ''
  let modelPath: string = canvasData?.modelUrl?.data?.attributes?.url || ''

  let cutData = {
    cutX: canvasData?.cutX || 0,
    cutY: canvasData?.cutY || 0,
    cutWidth: canvasData?.cutWidth || 0,
    cutHeight: canvasData?.cutHeight || 0,
  }
  if (canvasData.rotary_params) {
    printLayerModel.rotary_params = canvasData.rotary_params;
  }
  console.log('========createProjectRequest=======222222====', printLayerModel, canvasData.rotary_params);

  let extraData = {
    cutData: modelPath.length > 0 ? JSON.stringify(cutData) : '',
    appCavas: canvasData?.appCavas?.data?.attributes?.url || '',
    pcCavas: canvasData?.pcCavas?.data?.attributes?.url || '',
    canvasShape: canvasData?.canvasShape,
    bleedingLine: canvasData?.bleedingLine,
  }

  const params: CanvasesInfo = {
    canvas_name: canvasData?.title || '',
    is_standard_product: canvasData?.isEditCanvas ? 2 : 1,
    category: canvasData?.categoryType?.data?.attributes?.categoryKey,
    sub_category: canvasData?.categorySubType?.data?.attributes?.categorySubKey,
    scenes: JSON.stringify(newScenes),
    base_map: canvasData?.baseMapBg?.data?.attributes?.url || '',
    base_map_width: canvasData?.width || 0,
    base_map_height: canvasData?.height || 0,
    model_link: modelPath,
    print_param: JSON.stringify(printLayerModel),
    extra: JSON.stringify(extraData)
  }

  canvasInfo = params
  const canvasesInfo: CanvasesInfo[] = [canvasInfo]
  const projectInfo: ProjectInfo = {
    project_name: canvasData?.title || '',
    category: canvasData?.categoryType?.data?.attributes?.categoryKey,
    sub_category: canvasData?.categorySubType?.data?.attributes?.categorySubKey,
    is_standard_product: canvasData?.isEditCanvas ? 2 : 1,
  }
  const projectCreateRequestModel: ProjectCreateRequestModel = {
    project_info: projectInfo,
    canvases: canvasesInfo,
  }
  if (isReplace) {
    projectCreateRequestModel.canvasesIndex = 0
    return projectCreateRequestModel
  } else {
    return createProject(projectCreateRequestModel).then((resp) => {
      return resp
    })
  }
}

const handleSave = (data: any) => {
  console.log(data, '+++++++AiToll+++++++data++++++++');
  let values = data?.options?.[0] || {}
  if (!data?.options?.[0]?.baseMapWidth || !data?.options?.[0]?.baseMapHeight) return
  const canvasData: any = {}
  if (data?.categoryType?.data?.attributes?.categoryKey === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL) {
    let circle: number =
      Number(values?.baseMapWidth) >= Number(values?.baseMapHeight)
        ? Number(values?.baseMapWidth)
        : Number(values?.baseMapHeight)
    canvasData.width = Math.floor(Math.PI * StringUtil.mmToPixel(circle, CanvasParams.canvas_dpi_def))
    canvasData.height = Number(StringUtil.mmToPixel(values?.cupHeight, CanvasParams.canvas_dpi_def))
  } else {
    canvasData.width = Number(values?.baseMapWidth)
    canvasData.height = Number(values?.baseMapHeight)
  }
  let widthHeight: any = {}
  let bleedingSite: any = {}
  if (values?.defaultUnit === 'mm') {
    widthHeight = StringUtil.scaleToWidth(
      Number(canvasData?.width) || 0,
      Number(canvasData?.height) || 0,
      CanvasParams.canvas_dpi_def,
    )
    bleedingSite =
      values?.bleedingLine &&
      StringUtil.mmToPixelBleedingLine(values?.bleedingLine, CanvasParams.canvas_dpi_def)
  } else if (values?.defaultUnit === 'In') {
    widthHeight = StringUtil.inchToPixelwh(
      Number(canvasData?.width) || 0,
      Number(canvasData?.height) || 0,
      CanvasParams.canvas_dpi_def,
    )
    bleedingSite.top =
      values?.bleedingLine &&
      StringUtil.inchToPixelBleedingLine(values?.bleedingLine, CanvasParams.canvas_dpi_def)
  } else if (values?.defaultUnit === 'px') {
    widthHeight = {
      width: Number(canvasData?.width) || 0,
      height: Number(canvasData?.height) || 0,
    }
  }

  const newProjectModel = {
    ...data,
    ...values,
    ...widthHeight,
    is_standard_product: values?.isEditCanvas ? 2 : 1,
  }
  if (
    values?.bleedingLine &&
    typeof values?.bleedingLine === 'object' &&
    Object.values(bleedingSite)?.length
  ) {
    newProjectModel.bleedingLine = bleedingSite
  }
  return newProjectModel
}

const aiToolsProject = (payload: any, dispatch: any, t: any, hasChangePageForPc?: boolean) => {
  if (!payload?.category?.data?.attributes || !dispatch || !t) return
  handleLink2dEditor(
    payload?.category?.attributes?.id,
    From2dEditorType.CreateProjectAuto,
    null,
    payload?.title,
    hasChangePageForPc
  )
  // const projectRequest = createProjectRequest(
  //   handleSave(payload?.category?.data?.attributes)
  // )
  // if (projectRequest instanceof Promise) {
  //   projectRequest.then((newProjectModle: any) => {
  //     const result: any = handleError(newProjectModle, dispatch, t)
  //     if (result) {
  //       result.canvasesIndex = 0
  //       handleLink2dEditor(
  //         payload?.category?.attributes?.id,
  //         From2dEditorType.AiTool,
  //         result,
  //         payload?.title,
  //         hasChangePageForPc
  //       )
  //     } else {
  //       const params = {
  //         type: From2dEditorType.AiTool,
  //       }
  //       const queryString = new URLSearchParams(params).toString()
  //       history.pushState({}, '', `/apps/2dEditor/?${queryString}`)
  //     }
  //   })
  // }
}

const handleThemes = (data: any) => {
  const arr: any = []
  if (Array.isArray(data) && data.length) {
    data.forEach((item: any) => {
      arr.push(...item?.itemTitle)
    })
  }
  return arr
}

const homeFilterData = (
  totalData: any, //数据
  positions: string, //展示位置
  isChoice?: boolean, //是否是精选
  isAll?: boolean, //是否有All选项
  allUrl?: any //All选项的url
) => {
  if (totalData && positions) {
    const newData: any = []
    Array.isArray(totalData) && totalData.length && totalData?.forEach((key: any) => {
      const flag = key?.attributes?.positions?.data?.filter((val: any) => val?.attributes?.site === positions)
      let item = { ...key?.attributes }
      if (key?.attributes?.name === 'Themes') { //Themes三级变二级
        const newSubTitle = handleThemes(key?.attributes?.subTitle)
        item.subTitle = newSubTitle
      }
      if (flag?.length) {
        if (isChoice) {
          let el: any = isAll ? {
            ...item,
            subTitle: [
              { 'subName': 'All', 'id': 0, subIcon: allUrl || null },
              ...item?.subTitle?.filter((el: any) => { return el?.isSubChoice || el?.isItemChoice })
            ]
          } : {
            ...item,
            subTitle: item?.subTitle?.filter((el: any) => { return el?.isSubChoice || el?.isItemChoice })
          }
          newData.push(el)
        } else {
          let el: any = isAll ? {
            ...item,
            subTitle: [
              { 'subName': 'All', 'id': 0, subIcon: allUrl || null },
              ...item?.subTitle
            ]
          } : {
            ...item,
            subTitle: item?.subTitle
          }
          newData.push(el)
        }
      }
    })
    return newData
  }
}

export {
  createProjectRequest,
  handleError,
  handleLink2dEditor,
  aiToolsProject,
  homeFilterData
}

