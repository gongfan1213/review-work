import { compressorImage1, convertToBase64, dataURLtoFile, getImgCompress, jsonToZipFile } from 'src/common/utils';
import {
  CanvasesResInfo,
  ProjectCavasItemUpdateRequestModel,
  ProjectCavasUpdateRequestModel,
  ProjectCreateRequestModel,
  ProjectInfo,
  ProjectMaterialModel,
  ProjectModel,
  ProjectUpdateRequestModel,
  RotaryParams,
} from '../components/SelectDialog/model/ProjectModel';
import Editor from '../core';
import { UploadResultData, upload, upload2dEditFile } from 'src/hooks/useUpload';
import {
  createProject,
  getProjectDetail,
  getProjectImgDownUrl,
  updateProjectCavas,
  updateProject,
} from '../service/2dEditService';
import { CanvasEventEmitter } from './event/notifier';
import {
  ACTION_MAGICK,
  CanvasCategory,
  CanvasSubCategory,
  CanvasParams,
  CustomKey,
  EventNameCons,
  PROJECT_STANDARD_TYPE,
  ProjectSaveState,
  WorkspaceID,
} from '../cons/2dEditorCons';
import { ImportSource } from '../core/plugin/ImagePlugin/types/common';
import { get, GetUpTokenFileTypeEnum } from 'src/services';
import { v4 as uuid } from 'uuid';
import axios from 'axios';
import JSZip from 'jszip';
import React from 'react';
import greenlet from 'greenlet';
import {
  PrintLayerModel,
  PrintQuality,
} from '../components/MainUi/MainUiRightComponent/PrintLayer/model/PrintLayerModel';
// @ts-ignore
// import IMagickWorker from 'src/templates/2dEditor/core/worker/imagick.worker';
import StringUtil from 'src/common/utils/stringUtil';
import eventBus from '../core/eventbus';
import { CanvasSizeModel } from '../core/model/CanvasModel';
import { getRotaryParams } from '../common/cavasUtil';

interface ImageObject {
  type: string;
  src: string;
  [key: string]: any;
}

// 节流函数
function throttle(func: Function, limit: number) {
  let inThrottle: boolean;
  return function (this: any) {
    const args = arguments;
    const context = this;
    if (!inThrottle) {
      func.apply(context, args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

class ProjectManager extends React.Component {
  private static instance: ProjectManager;
  private initStrTemp: string;
  private isJsonUpLoadAgain: boolean = false;
  private intervalId: NodeJS.Timeout | null = null;
  private detailIntervalId: NodeJS.Timeout | null = null;
  private canvasEditor: Editor | undefined = undefined;
  private event: CanvasEventEmitter | null = null;
  private uploadImageQueue: ImageObject[] = [];
  private UPDATE_KEY: string = 'updateToken:';
  private PROJECT_JSON_NAME: string = 'project.json';
  private projectModel: ProjectModel | null = null;
  private md5List: string[] = [];
  private isLoadingProject: boolean = false;
  private isUpdatingProject: boolean = false;
  // private stringifyWorker: Worker;
  private stringifyTaskThread: (data: any) => Promise<any>;
  public mockMaterialData: any = [];
  public mockBlankData: any = [];

  private constructor() {
    super({});
    // 私有构造函数确保不直接实例化
    this.initStrTemp = '';
    this.isJsonUpLoadAgain = false;
    this.md5List = [];
    this.setChangeProjectState = this.setChangeProjectState.bind(this);
    this.removeObjsAction = this.removeObjsAction.bind(this);
    this.changeEditorSaveState = this.changeEditorSaveState.bind(this);

    this.stringifyTaskThread = greenlet(async (data) => {
      const result = JSON.stringify(data);
      return result; // 返回计算结果
    });
    // let worker = new IMagickWorker();
    // worker.postMessage({
    //   action: ACTION_MAGICK.ACTION_TYPE_INIT,
    // });
    // worker.onmessage = function (e: { data: any; }) {
    //   worker.terminate();
    //   worker = null;
    // };
  }

  componentWillUnmount() {
    this.event?.off(EventNameCons.Event2dObjectRemove, this.removeObjsAction);
    this.event?.off(EventNameCons.EventProjectChangeState, this.setChangeProjectState);
    eventBus.off(EventNameCons.ChangeEditorSaveState, this.changeEditorSaveState);
  }

  public static getInstance(): ProjectManager {
    // 获取类的单例实例
    if (!ProjectManager.instance) {
      ProjectManager.instance = new ProjectManager();
    }
    return ProjectManager.instance;
  }

  public init(canvasEditor: Editor, event: CanvasEventEmitter, projectModel: ProjectModel) {
    this.canvasEditor = canvasEditor;
    this.event = event;
    this.projectModel = projectModel;
    this.event.on(EventNameCons.Event2dObjectRemove, this.removeObjsAction);
    this.event.on(EventNameCons.EventProjectChangeState, this.setChangeProjectState);
    eventBus.on(EventNameCons.ChangeEditorSaveState, this.changeEditorSaveState);
  }

  public unInit() {
    this.initStrTemp = '';
    this.isJsonUpLoadAgain = false;
    this.md5List = [];
    this.updateCanvasSizeDisable();
  }

  public start(): void {
    this.stop();

    if (this.intervalId === null) {
      const throttledExecuteTask = throttle(this.executeTask.bind(this), 5000);
      this.intervalId = setInterval(throttledExecuteTask, 5000);
    }

    // 每隔50分钟调用getProjectDetail方法
    if (this.detailIntervalId === null) {
      this.detailIntervalId = setInterval(
        () => {
          this.getProjectDetailInterval();
        },
        50 * 60 * 1000,
      ); // 50分钟
    }
  }

  private getProjectDetailInterval() {
    if (!this.projectModel) return;
    getProjectDetail({ project_id: this.projectModel?.project_info.project_id }).then((resp) => {
      if (!resp) return;
      var projectModelRet: ProjectModel = resp['data'];
      projectModelRet.canvasesIndex = this.projectModel?.canvasesIndex || 0;
      this.projectModel = projectModelRet;
      this.event?.emitEvent(EventNameCons.EventUpdateDetailProject, projectModelRet);
    });
  }

  public stop(): void {
    console.log('==task====stop ... = ');
    if (this.intervalId !== null) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    // 停止调用getProjectDetail方法
    if (this.detailIntervalId !== null) {
      clearInterval(this.detailIntervalId);
      this.detailIntervalId = null;
    }
  }

  public atOnceSave(): void {
    this.executeTask();
  }

  private async executeTask(): Promise<void> {
    console.log('===executeTask ... = ');
    const dataJson = this.canvasEditor?.getJson();
    !this.isUpdatingProject &&
      this.event?.emitEvent(EventNameCons.EventProjectSaveState, ProjectSaveState.SaveStateSaved);

    Array.isArray(dataJson?.objects) &&
      dataJson?.objects?.length &&
      dataJson.objects.forEach((obj: any) => {
        if (obj.cropPath) {
          delete obj.cropPath.canvas;
          delete obj.cropPath._cacheCanvas;
          delete obj.cropPath._cacheContext;
          delete obj.cropPath.canvas;
        }
      });

    // 将对象发送到Web Worker进行序列化
    this.stringifyTaskThread(dataJson).then((dataJsonStr) => {
      if (dataJson && this.initStrTemp !== dataJsonStr) {
        console.log(
          ' this.isLoadingProject===',
          this.isLoadingProject,
          ' this.isUpdatingProject=',
          this.isUpdatingProject,
        );
        if (this.isLoadingProject || dataJson.objects.length === 0) return;
        if (this.isUpdatingProject) {
          ///还在上传图片中，等下次上传
          // console.log('===上传中 = ');
          return;
        }
        this.event?.emitEvent(EventNameCons.EventProjectSaveState, ProjectSaveState.SaveStateSaving);
        this.isUpdatingProject = true;
        this.isJsonUpLoadAgain = false;
        ///内容修改，开始上传
        const layerData = dataJson;
        this.uploadImageQueue = this.findImagesToUpload(layerData.objects);
        this.processUploadQueue(layerData, JSON.parse(dataJsonStr));
        // console.log('===上传中 = ', dataJsonStr);
        // ///获取缩略图 getThumbnail
        this.canvasEditor?.preview1(this.projectModel).then((data: any) => {
          console.log(
            '===获取缩略图 = ' +
            this.projectModel!.canvases![this.projectModel!.canvasesIndex]?.thumb_file.upload_url +
            ' ==' +
            this.projectModel?.canvases[this.projectModel.canvasesIndex].thumb_file.download_url,
          );
          if (!data || !data.dataUrl) return;
          const filename = 'thumbnail.png'; // 你可以根据需要设置文件名
          const file = dataURLtoFile(data.dataUrl, filename);
          if (file) {
            // 压缩
            console.log(`compressorImage1==start==:`, new Date().toISOString());
            compressorImage1(file, 0, 0, 1, 200)
              .then((blob) => {
                console.log(`compressorImage1==end=======:`, new Date().toISOString());
                this.event?.emitEvent(
                  EventNameCons.EventUpdateProjectThumbnail,
                  blob,
                  this.projectModel?.project_info.project_id,
                );
                var fileRet: File = new File([blob], file.name, { type: blob.type, lastModified: Date.now() });
                const uploadUrl =
                  this.projectModel?.canvases![this.projectModel!.canvasesIndex]?.thumb_file?.upload_url;
                if (uploadUrl) {
                  /// 上传缩略图
                  upload(uploadUrl, fileRet)
                    .then((uploadSuccess) => {
                      // 上传成功的处理
                    })
                    .catch((error) => {
                      console.error('Upload thumbnail error:', error);
                    });
                  /// 上传信息
                  var projectParamModel: PrintLayerModel;
                  if (this.projectModel && this.projectModel.canvases[this.projectModel.canvasesIndex].print_param) {
                    projectParamModel = JSON.parse(
                      this.projectModel.canvases[this.projectModel.canvasesIndex].print_param,
                    );
                    if (!projectParamModel.format_size_w_non) {
                      const width = this.projectModel.canvases[this.projectModel.canvasesIndex].base_map_width;
                      const height = this.projectModel.canvases[this.projectModel.canvasesIndex].base_map_height;
                      var retSizeMM = StringUtil.pixelsToMM(width, height, PrintQuality.printQuality1);
                      projectParamModel.format_size_w_non = retSizeMM.widthMM;
                      projectParamModel.format_size_h_non = retSizeMM.heightMM;
                    }

                    projectParamModel = {
                      ...projectParamModel,
                      thumbnail_x: data.minX,
                      thumbnail_y: data.minY,
                    };
                    var extraData = this.projectModel!.canvases[this.projectModel!.canvasesIndex].extra;

                    let canvasModel: CanvasSizeModel = this.canvasEditor?.getCanvasSize();
                    console.log('format_size_w_non===printLayerModel==thumbnail_x===', data, canvasModel);
                    if (extraData) {
                      extraData = {
                        ...JSON.parse(extraData),
                        hasLayerPrint:
                          layerData.objects.filter(
                            (obj: any) => !(obj.id as string).includes(WorkspaceID.WorkspaceCavas),
                          ).length > 0,
                      };
                    }
                    var itemRequest: ProjectCavasItemUpdateRequestModel = {
                      canvas_id: this.projectModel!.canvases[this.projectModel!.canvasesIndex].canvas_id,
                      print_param: JSON.stringify(projectParamModel),
                      extra: JSON.stringify(extraData),
                      base_map_width: canvasModel.width,
                      base_map_height: canvasModel.height,
                    };

                    var request: ProjectCavasUpdateRequestModel = {
                      project_id: this.projectModel!.project_info.project_id,
                      canvases: [itemRequest],
                    };
                    updateProjectCavas(request, true);
                  }
                }
              })
              .catch((error) => {
                console.error('Error compressing image:', error);
              });
          } else {
            console.error('Failed to convert data URL to file');
          }
        });
        console.log('===上传中 = ', this.projectModel!.project_info);
        const canvaObjects = this.canvasEditor?.canvas
          ?.getObjects()
          .filter((item: any) => !item.id?.includes(WorkspaceID.WorkspaceCavas));
        // @ts-ignore
        if (this.projectModel!.project_info?.is_edited !== 1 && canvaObjects?.length > 0) {
          const params = {
            project_id: this.projectModel!.project_info.project_id,
            is_edited: 1,
          };
          updateProject(params).then((resp) => {
            console.log('updateProject ret:', resp);
          });
        }
      }
    });
  }

  public editPageCheckSave(): boolean {
    var jsonStr = JSON.stringify(this.canvasEditor?.getJson());
    if (jsonStr == undefined || this.initStrTemp === JSON.stringify(this.canvasEditor?.getJson())) {
      return true;
    }
    return false;
  }

  private findImagesToUpload(objects: any[]): ImageObject[] {
    const imagesToUpload: ImageObject[] = [];
    var addMaterials: string[] = [];
    const checkAndAddImage = (obj: any, index: number) => {
      if (
        obj.type === 'image' &&
        obj.src &&
        !obj.src.startsWith(this.UPDATE_KEY) &&
        !obj.id?.includes(WorkspaceID.WorkspaceCavas)
      ) {
        if (obj[CustomKey.skip_upload] === true) {
          this.isJsonUpLoadAgain = true;
        } else if (obj.key_prefix) {
          console.log(`已上传图片=导入==:`);
          // let key = md5(obj.src).toString();
          // console.log(`已上传图片=导入==:` + obj.key_prefix, " key=", key, new Date().toISOString());
          if (!this.md5List.includes(obj.key_prefix)) {
            this.md5List.push(obj.key_prefix);
            addMaterials.push(obj.key_prefix);
          }
          obj.src = `${this.UPDATE_KEY}${obj.key_prefix}`;
        } else if (obj.src.startsWith('http')) {
        } else if (obj.src) {
          imagesToUpload.push(obj);
        }
      }
      if (obj.type === 'group' && obj.objects) {
        obj.objects.forEach(checkAndAddImage);
      }
    };
    objects.forEach(checkAndAddImage);

    if (addMaterials.length > 0) {
      // 更新project 上的图片add_materials
      var request: ProjectCavasUpdateRequestModel = {
        project_id: this.projectModel!.project_info.project_id,
        canvases: [
          {
            canvas_id: this.projectModel!.canvases[this.projectModel!.canvasesIndex].canvas_id,
            add_materials: addMaterials,
          },
        ],
      };
      updateProjectCavas(request);
    }
    return imagesToUpload;
  }

  private processUploadQueue(data: any, jsonDataTemp: string): void {
    if (
      this.uploadImageQueue.length === 0 &&
      this.projectModel?.canvases![this.projectModel!.canvasesIndex]?.project_file?.upload_url
    ) {
      console.log(
        '===所有图片上传完成 ===' + ' projectid =' + this.projectModel.project_info.project_id,
        ' downurl==' + this.projectModel!.canvases![this.projectModel!.canvasesIndex]!.project_file.download_url,
      );
      this.stringifyTaskThread(data).then((dataJsonStr) => {
        this.stringifyTaskThread(jsonDataTemp).then((jsonDataTempStr) => {
          jsonToZipFile(dataJsonStr, this.PROJECT_JSON_NAME, 'project.zip').then((zipFile: File) => {
            const uploadUrl = this.projectModel!.canvases![this.projectModel!.canvasesIndex]!.project_file?.upload_url;
            upload(uploadUrl, zipFile)
              .then((uploadSuccess) => {
                console.log('Upload project.json success:==uploadUrl=', uploadUrl);
                this.isUpdatingProject = false;
                this.event?.emitEvent(EventNameCons.EventProjectSaveState, ProjectSaveState.SaveStateSaved);

                if (!this.isJsonUpLoadAgain) {
                  this.initStrTemp = jsonDataTempStr;
                }
              })
              .catch((error) => {
                this.isUpdatingProject = false;
                this.event?.emitEvent(EventNameCons.EventProjectSaveState, ProjectSaveState.SaveStateSaved);
                // this.initStrTemp = '';
                this.isJsonUpLoadAgain = true;
                console.error('Upload ret error:', error);
                this.getProjectDetailInterval();
              });
          });
        });
      });
      return;
    }
    // console.log(`要上传图片===:` + this.uploadImageQueue.length);
    const imageObject = this.uploadImageQueue.shift();
    if (imageObject) {
      this.uploadImage(imageObject)
        .then((resp: UploadResultData | null) => {
          console.log('imageObject=======uploadImage end', resp);
          if (resp) {
            //保存
            this.md5List.push(resp!.key_prefix);
            // 替换上传内容
            const updatedSrc = `${this.UPDATE_KEY}${resp!.key_prefix}`;

            this.updateImageObjectSrc(data.objects, imageObject, resp!.key_prefix, updatedSrc);
            this.updateImageObjectSrc((jsonDataTemp as any).objects, imageObject, resp!.key_prefix);

            // 替换canvasEditor cavas里面的设置key_prefix的值，用于模版图片/官方元素/个人元素的上传，上传后新增key_prefix字段，用于判断是否上传过
            this.updateSourceImageObjectKey(imageObject.id, resp!.key_prefix);
            // 更新project 上的图片add_materials
            var request: ProjectCavasUpdateRequestModel = {
              project_id: this.projectModel!.project_info.project_id,
              canvases: [
                {
                  canvas_id: this.projectModel!.canvases[this.projectModel!.canvasesIndex].canvas_id,
                  add_materials: [resp.key_prefix],
                },
              ],
            };
            updateProjectCavas(request);
          } else {
            // 上传失败不替换内容，继续处理队列中的下一个任务,initStrTemp置为空，下次再上传
            // this.initStrTemp = "";
            this.isJsonUpLoadAgain = true;
          }
          this.processUploadQueue(data, jsonDataTemp);
        })
        .catch((error) => {
          // this.initStrTemp = "";
          console.log('imageObject=======uploadImage error');
          this.isJsonUpLoadAgain = true;
          this.processUploadQueue(data, jsonDataTemp);
        });
    }
  }

  private updateSourceImageObjectKey(id: string, key_prefix: string): void {
    const updateSrc = (obj: any) => {
      if (obj.id === id) {
        obj.key_prefix = key_prefix;
      }
      if (obj.type === 'group' && obj._objects) {
        obj._objects.forEach(updateSrc);
      }
    };
    this.canvasEditor!.canvas.getObjects().forEach(updateSrc);
  }

  public loadProjectFirst(projectModel: ProjectModel, retCallBack: Function) {
    this.event?.emitEvent(EventNameCons.EventProjectChangeState, true);

    ProjectManager.getInstance()
      .getProjectJson(projectModel, 0)
      .then((json: string | undefined) => {
        if (json) {
          this.canvasEditor?.clear(true);
          this.canvasEditor?.stopSaveHistory();
          this.canvasEditor?.insertSvgFile(json, () => {
            console.log('=====loadProjectFirst=-=======111111==', new Date().toISOString());
            // 解决历史旋转体画布，重新创建底图
            this.canvasEditor?.updateWorkspace();
            // 这里updateWorkspace异步，添加延迟保存
            setTimeout(() => {
              const dataJson = this.canvasEditor?.getJson();
              this.stringifyTaskThread(dataJson).then((dataJsonStr) => {
                console.log('=====loadProjectFirst=-=======33333==', new Date().toISOString());
                this.initStrTemp = dataJsonStr;
                this.canvasEditor?.clearHistory();
                this.canvasEditor?.startSaveHistory(true);
              });
            }, 300);
          });
        }
        this.event?.emitEvent(EventNameCons.EventProjectChangeState, false);
        retCallBack();
      });
  }

  private updateImageObjectSrc(objects: any[], targetImageObject: ImageObject, key_prefix: string, newSrc?: string) {
    const updateSrc = (obj: any) => {
      if (obj.id === targetImageObject.id) {
        if (newSrc) {
          obj.src = newSrc;
        }
        if (key_prefix) {
          obj.key_prefix = key_prefix;
        }
      }
      if (obj.type === 'group' && obj.objects) {
        obj.objects.forEach(updateSrc);
      }
    };
    objects.forEach(updateSrc);
  }

  private uploadImage(imageObject: ImageObject): Promise<UploadResultData | null> {
    const file = dataURLtoFile(imageObject.src, uuid() + '.' + (imageObject.fileType || 'png'));
    return upload2dEditFile(
      file!,
      imageObject.source === ImportSource.Local
        ? GetUpTokenFileTypeEnum.Edit2dLocal
        : GetUpTokenFileTypeEnum.Edit2dCloud,
      this.projectModel?.project_info.project_id,
      this.projectModel?.canvases![this.projectModel!.canvasesIndex]?.canvas_id,
    )
      .then((resp) => {
        if (resp && resp.key_prefix) {
          return resp; // 上传成功，返回 key_prefix
        } else {
          return null; // 上传失败，
        }
      })
      .catch((error) => {
        console.error(error);
        return null; // 上传失败
      });
  }

  public changeProject(rproject_id: string, retCallBack: Function) {
    getProjectDetail({ project_id: rproject_id }).then((resp) => {
      if (resp && resp.data) {
        this.event?.emitEvent(EventNameCons.EventProjectChangeState, true);
        var projectData: ProjectModel = resp.data;
        this.getProjectJson(projectData, 0).then(async (json: string | undefined) => {
          if (!json) {
            // @ts-ignore
            const tempCanvas = new fabric.StaticCanvas(null, {
              width: projectData?.canvases[0].base_map_width || 0,
              height: projectData?.canvases[0].base_map_height || 0,
            });
            await this.canvasEditor?.initWorkCanvas(tempCanvas, {
              width: projectData?.canvases[0].base_map_width || 0,
              height: projectData?.canvases[0].base_map_height || 0,
              url: projectData?.canvases[0].base_map || '',
              cavas_map: JSON.parse(projectData?.canvases[0].print_param)?.cavas_map || '',
              is_standard_product: projectData?.project_info.is_standard_product,
              canvasShape: JSON.parse(projectData?.canvases[0]?.extra || '')?.canvasShape || '',
              bleedingLine: JSON.parse(projectData?.canvases[0]?.extra || '')?.bleedingLine || null,
            });
            json = this.canvasEditor?.getJsonCanvas(tempCanvas);
          }
          // console.log('changeProject json ret======' + json);

          retCallBack(json ? true : false);
          if (json) {
            this.canvasEditor?.clear(true);
            // this.event?.emitEvent(EventNameCons.EventUpdateDetailProject, resp.data)
            this.canvasEditor?.insertSvgFile(json, () => {
              this.canvasEditor?.updateWorkspace({
                width: projectData?.canvases[0].base_map_width || 0,
                height: projectData?.canvases[0].base_map_height || 0,
                url: projectData?.canvases[0].base_map || '',
                cavas_map: JSON.parse(projectData?.canvases[0].print_param)?.cavas_map || '',
                is_standard_product: projectData?.project_info.is_standard_product,
                canvasShape: JSON.parse(projectData?.canvases[0]?.extra || '')?.canvasShape || '',
                bleedingLine: JSON.parse(projectData?.canvases[0]?.extra || '')?.bleedingLine || null,
                params: JSON.parse(projectData?.canvases[projectData?.canvasesIndex]?.print_param || '{}'),
                category: projectData?.project_info.category,
              });
              resp.data.canvasesIndex = 0;
              this.event?.emitEvent(EventNameCons.EventUpdateDetailProjectDataOnly, resp.data);
              this.event?.emitEvent(EventNameCons.EventProjectChangeState, false);
              this.canvasEditor?.clearHistory();
            });
            this.initStrTemp = json;
            this.updateCanvasSizeDisable();
          }
        });
      } else {
        retCallBack(false);
      }
    });
  }

  public changeProjectCanvas(projectSource: ProjectModel, retCallBack: Function) {
    this.event?.emitEvent(EventNameCons.EventProjectChangeState, true);
    var projectData: ProjectModel = { ...projectSource };
    this.getProjectJson(projectData, 0).then(async (json: string | undefined) => {
      if (!json) {
        // @ts-ignore
        const tempCanvas = new fabric.StaticCanvas(null, {
          width: projectData?.canvases[0].base_map_width || 0,
          height: projectData?.canvases[0].base_map_height || 0,
        });

        await this.canvasEditor?.initWorkCanvas(tempCanvas, {
          width: projectData?.canvases[0].base_map_width || 0,
          height: projectData?.canvases[0].base_map_height || 0,
          url: projectData?.canvases[0].base_map || '',
          cavas_map: JSON.parse(projectData?.canvases[0].print_param)?.cavas_map || '',
          is_standard_product: projectData?.project_info.is_standard_product,
          canvasShape: JSON.parse(projectData?.canvases[0]?.extra || '')?.canvasShape || '',
          bleedingLine: JSON.parse(projectData?.canvases[0]?.extra || '')?.bleedingLine || null,
        });
        json = this.canvasEditor?.getJsonCanvas(tempCanvas);
      }
      retCallBack(json ? true : false);
      if (json) {
        this.canvasEditor?.clear(true);
        this.event?.emitEvent(EventNameCons.EventUpdateDetailProject, projectData);
        this.canvasEditor?.insertSvgFile(json);
        this.event?.emitEvent(EventNameCons.EventProjectChangeState, false);
        this.initStrTemp = json;
      }
    });
  }

  public isFilterTextureEffect(projectModel: ProjectModel) {
    const canvas = projectModel.canvases[projectModel.canvasesIndex];
    const isCylindrical = canvas.category === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL;
    const isSticker =
      canvas.sub_category === CanvasSubCategory.CANVAS_CATEGORY_ACCESSORY_STICKER_S ||
      canvas.sub_category === CanvasSubCategory.CANVAS_CATEGORY_ACCESSORY_STICKER_M;
    const print_param = JSON.parse(canvas.print_param);
    return (isCylindrical && print_param?.rotary_params?.hasHandle) || isSticker;
  }

  /**
   * erchuangProject，二创项目
   * @param projectName 项目名称
   * @param retCallBack 回调函数
   */
  public erchuangProject(
    projectName: string,
    parents_works_id: string,
    category: number,
    sub_category: number,
    is_standard_product: number,
    retCallBack: Function,
  ) {
    var projectInfo: ProjectInfo = {
      project_name: projectName,
      parents_works_id: parents_works_id,
      category: category,
      sub_category: sub_category,
      is_standard_product: is_standard_product,
    };

    var projectCreateRequestModel: ProjectCreateRequestModel = {
      project_info: projectInfo,
    };

    createProject(projectCreateRequestModel).then((resp) => {
      retCallBack(resp);
      // if (resp && resp.data) {
      //   var projectRet: ProjectModel = resp!.data;
      //   retCallBack(projectRet, resp!.code);
      // } else {
      //   retCallBack(null, resp?.code);
      // }
    });
  }

  public chageProjectCategory(
    projectCreateRequestModel: ProjectCreateRequestModel,
    projectSource?: ProjectModel | null,
  ): Promise<ProjectModel | null> {
    projectSource = projectSource ? projectSource : this.projectModel;
    var projectModelNew: ProjectModel = JSON.parse(JSON.stringify(projectSource));
    projectModelNew.project_info.category = projectCreateRequestModel.project_info.category;
    projectModelNew.project_info.sub_category = projectCreateRequestModel.project_info.sub_category;
    projectModelNew.project_info.is_standard_product = projectCreateRequestModel.project_info.is_standard_product;

    var itemRequests: ProjectCavasItemUpdateRequestModel[] = [];
    var model_link = projectCreateRequestModel.canvases![0].model_link;
    projectModelNew.canvases.forEach((canvas, index) => {
      canvas.category = projectCreateRequestModel.project_info.category;
      canvas.sub_category = projectCreateRequestModel.project_info.sub_category;
      canvas.is_standard_product = projectCreateRequestModel.project_info.is_standard_product;
      canvas.scenes = projectCreateRequestModel.canvases![0].scenes;
      canvas.materials = projectCreateRequestModel.canvases![0].materials;
      canvas.base_map = projectCreateRequestModel.canvases![0].base_map;
      canvas.base_map_width = projectCreateRequestModel.canvases![0].base_map_width;
      canvas.base_map_height = projectCreateRequestModel.canvases![0].base_map_height;
      canvas.print_param = projectCreateRequestModel.canvases![0].print_param;
      canvas.model_link = model_link;
      canvas.extra = projectCreateRequestModel.canvases![0].extra;

      //旋转体属性设置

      console.log('====projectCreateRequestModel====', projectCreateRequestModel);
      let print_param = JSON.parse(canvas.print_param);
      if (
        projectModelNew.project_info.category == CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL &&
        !print_param.rotary_params
      ) {
        canvas.print_param = JSON.stringify({
          ...print_param,
          rotary_params: getRotaryParams(
            canvas.base_map_width,
            canvas.base_map_height,
            print_param.rotary_params.handleHeight,
          ),
        });
      }

      itemRequests.push({
        canvas_id: canvas.canvas_id,
        category: projectCreateRequestModel.project_info.category,
        sub_category: projectCreateRequestModel.project_info.sub_category,
        is_standard_product: projectCreateRequestModel.project_info.is_standard_product,
        scenes: projectCreateRequestModel.canvases![0].scenes,
        materials: projectCreateRequestModel.canvases![0].materials,
        base_map: projectCreateRequestModel.canvases![0].base_map,
        base_map_width: projectCreateRequestModel.canvases![0].base_map_width,
        base_map_height: projectCreateRequestModel.canvases![0].base_map_height,
        print_param: projectCreateRequestModel.canvases![0].print_param,
        model_link: model_link.length == 0 ? ' ' : model_link,
        extra: projectCreateRequestModel.canvases![0].extra,
      });
    });
    var request: ProjectCavasUpdateRequestModel = {
      project_id: projectModelNew!.project_info.project_id,
      canvases: itemRequests,
    };
    projectModelNew.canvasesIndex = 0;
    return updateProjectCavas(request).then((resp) => {
      if (resp?.data) {
        this.projectModel = projectModelNew;
        this.updateCanvasSizeDisable();
        return projectModelNew;
      } else {
        return null;
      }
    });
  }

  public updateCanvasSizeDisable() {
    eventBus.emit(EventNameCons.EventCanvasSizeDisable);
  }

  public updateProjectData(projectModel: ProjectModel, isClear?: boolean) {
    this.projectModel = projectModel;
    if (isClear) {
      this.unInit();
    }
  }

  public getProjectJson(projectModel: ProjectModel, canvasesIndex: number): Promise<string | undefined> {
    return axios({
      method: 'get',
      url: projectModel.canvases[canvasesIndex].project_file.download_url,
      responseType: 'arraybuffer',
    })
      .then((response) => {
        const zip = new JSZip();
        return zip.loadAsync(response.data);
      })
      .then((zip) => {
        if (zip.files[this.PROJECT_JSON_NAME]) {
          return zip.files[this.PROJECT_JSON_NAME].async('string');
        } else {
          throw new Error('Project JSON file not found in the zip.');
        }
      })
      .then((jsonStr) => {
        return this.fillingJson(jsonStr, projectModel, canvasesIndex);
      })
      .catch((error) => {
        if (error.response) {
          // 请求已发出，但服务器响应的状态码不在 2xx 范围内
          console.log('Error status=====:', error.response.status);
          if (error.response.status === 404) {
            return '';
          }
        } else {
          console.log('Error====:', error.message);
          throw error; // 抛出除了404之外的错误
        }
      });
  }

  private async fillingJson(json: string, projectModel: ProjectModel, canvasesIndex: number): Promise<string> {
    console.log('-1-1-1--1' + projectModel);
    const data = JSON.parse(json);
    /// 切换项目品类之后统一替换背景图
    if (projectModel?.project_info.is_standard_product == PROJECT_STANDARD_TYPE.PROJECT_STANDARD) {
      data.objects.forEach((obj: any) => {
        if (obj.id === WorkspaceID.WorkspaceCavas) {
          var cavas_map = JSON.parse(projectModel.canvases[0].print_param).cavas_map;
          if (obj.src !== cavas_map) {
            obj.src = cavas_map;
          }
        }
        if (obj.id === WorkspaceID.WorkspaceBG) {
          var bg_map = projectModel.canvases[0].base_map;
          console.log('projectModel-------projectModel' + projectModel.project_info);
          console.log('fillingJson stringify===src===' + obj.src + ' bg_map=' + bg_map);
          if (obj.src !== bg_map) {
            obj.src = bg_map;
          }
        }
      });
    }

    const imagesToUpdate = this.findImagesToUpdate(data.objects);
    var materialMap: Map<string, string> = new Map<string, string>();
    var imgKeys: string[] = [];
    var md5ListTemp: string[] = [];

    //填充download_url
    if (projectModel.canvases[canvasesIndex].material_list) {
      projectModel.canvases[canvasesIndex].material_list!.forEach((material: ProjectMaterialModel) => {
        materialMap.set(material.key_prefix, material.download_url);
      });
    }

    ///获取遗漏token
    imagesToUpdate.forEach((imageObject, index) => {
      const imageKey = imageObject.src.substring(this.UPDATE_KEY.length);
      if (!materialMap.has(imageKey)) {
        imgKeys.push(imageKey);
      }
    });

    if (imgKeys.length > 0) {
      const resp = await getProjectImgDownUrl({
        project_id: projectModel.project_info.project_id,
        canvas_id: projectModel.canvases[canvasesIndex].canvas_id,
        key_prefix: imgKeys,
      });
      if (resp && resp.data) {
        resp.data.download_url.forEach((url: string, index: number) => {
          materialMap.set(imgKeys[index], url);
        });
      }
    }

    // 创建一个包含所有下载任务的 promise 数组
    const downloadPromises = imagesToUpdate.map((imageObject) => {
      const imageKey = imageObject.src.substring(this.UPDATE_KEY.length);
      if (materialMap.has(imageKey)) {
        return convertToBase64(materialMap.get(imageKey)!).then((base64) => {
          console.log('下载图片完成======', new Date().toISOString());
          md5ListTemp.push(imageKey);
          this.updateImageObjectSrc(data.objects, imageObject, imageKey, base64);
        });
      } else {
        return '';
      }
    });

    // 使用Promise.all等待所有下载任务完成
    return Promise.all(downloadPromises).then(() => {
      console.log('所有图片下载完成======', new Date().toISOString());
      // 清空操作
      this.projectModel = projectModel;
      this.unInit();
      this.md5List = md5ListTemp;
      // 所有图片都已下载并替换 src，返回更新后的 JSON 字符串
      return JSON.stringify(data);
    });
  }

  private findImagesToUpdate(objects: any[]): ImageObject[] {
    const imagesToUpdate: ImageObject[] = [];
    const checkAndUpdateImage = (obj: any) => {
      if (obj.type === 'image' && obj.src && obj.src.startsWith(this.UPDATE_KEY)) {
        imagesToUpdate.push(obj);
      }
      if (obj.type === 'group' && obj.objects) {
        obj.objects.forEach(checkAndUpdateImage);
      }
    };
    objects.forEach(checkAndUpdateImage);
    return imagesToUpdate;
  }

  public getMaterials(data: ProjectModel): string[] {
    if (!data) return [];
    const materials: string[] = JSON.parse(data.canvases[data.canvasesIndex].materials!);
    return materials;
  }

  private setChangeProjectState(state: boolean) {
    this.isLoadingProject = state;
  }

  private removeObjsAction = (object: fabric.Object) => {
    if (this.isLoadingProject) return;
    this.canvasEditor?.removeLoadingElement(object);
    var imgRemoveList: string[] = [];
    const retImgSrc = (obj: fabric.Object) => {
      if (obj.type === 'image') {
        if ((obj as any).key_prefix) {
          var key = (obj as any).key_prefix;
          imgRemoveList.push(key);
          if (this.md5List.includes(key)) {
            this.md5List = this.md5List.filter((item) => item !== key);
          }
        }
      }
      if (obj.type === 'group' && (obj as any).objects) {
        (obj as any).objects.forEach(retImgSrc);
      }
    };
    retImgSrc(object);
    if (imgRemoveList.length == 0) return;
    var request: ProjectCavasUpdateRequestModel = {
      project_id: this.projectModel!.project_info.project_id,
      canvases: [
        {
          canvas_id: this.projectModel!.canvases[this.projectModel!.canvasesIndex]?.canvas_id,
          del_materials: imgRemoveList,
        },
      ],
    };
    updateProjectCavas(request, true);
  };

  private changeEditorSaveState(open: boolean, endSave?: boolean) {
    console.log('history===changeEditorSaveState===', open, endSave);
    if (open) {
      this.canvasEditor?.startSaveHistory(endSave !== undefined ? endSave : true);
      this.setChangeProjectState(false);
    } else {
      this.canvasEditor?.stopSaveHistory();
      this.setChangeProjectState(true);
    }
  }

  public async fetchSonClass(callBack: Function) {
    if (typeof window === 'undefined') return;
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      // cms接口地址
      content_type: 'make-2d-ankermake-materials',
      populate: [
        'categoryImg',
        'options',
        'options.categorySubImg',
        'options.baseMapBg',
        'options.baseMapCavas',
        'options.appCavas',
        'options.pcCavas',
        'options.modelUrl',
        'options.productColor',
        'options.baseMaterialX',
        'options.baseMaterialY',
        'options.baseMapWidth',
        'options.baseMapHeight',
        'options.scenes',
        'options.scenes.scenesImg',
        'options.categorySubType',
        'categoryType',
        'options.bleedingLine',
      ],
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'], // 按weight降序排列
    });
    const data = json.data?.data;
    if (data) {
      this.mockMaterialData = [];
      this.mockBlankData = [];
      !!data &&
        Array.isArray(data) &&
        data.length &&
        {} &&
        data.forEach((item: any) => {
          if (item?.attributes?.productType === 'Ankermake Material') {
            this.mockMaterialData.push(item);
          } else {
            this.mockBlankData.push(item);
          }
        });
    }
    console.log('======this.mockMaterialData====', this.mockMaterialData);
    callBack(data, [...this.mockMaterialData], this.mockBlankData);
  }

  public getProjectData(): ProjectModel | null {
    return this.projectModel;
  }
}

export default ProjectManager;
