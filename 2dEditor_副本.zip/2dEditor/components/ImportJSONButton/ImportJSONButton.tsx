import { Button } from '@mui/material';
import { useCanvasEditor, useProjectData } from '../../hooks/context'
import React from 'react'
import { selectFiles } from '../../utils/utils';
import { ACTION_MAGICK, WorkspaceID } from '../../cons/2dEditorCons';
import { AddJsonTempID } from '../../core/plugin/HistoryPlugin/types';
import IMagickWorker from '../../core/worker/imagick.worker'
import { post } from 'src/services';
import { CyRetData } from '../SelectDialog/model/CategoryModel';

function ImportJSONButton() {
  const canvasEditor = useCanvasEditor();
  const projectModel = useProjectData();
  return (
    <div>
      {(window.location.hostname === 'localhost' ||
        window.location.hostname === 'playground-ci.mkitreal.com') && (
          <>
            <button
              style={{
                color: '#ffffff',
                background: '#61bc65',
                border: '1px solid #61bc65',
                fontSize: '14px',
                padding: '7px 12px 4px 12px',
                borderRadius: '4px',
                marginRight: '14px',
              }}
              onClick={() => {
                initImage()
              }}
            >
              init
            </button>
            <button
              style={{
                color: '#ffffff',
                background: '#61bc65',
                border: '1px solid #61bc65',
                fontSize: '14px',
                padding: '7px 12px 4px 12px',
                borderRadius: '4px',
                marginRight: '14px',
              }}
              onClick={() => {
                // setDistort()
                setDistortCylinder();
              }}
            >
              posi
            </button>
          </>
        )}
      <button
        style={{
          color: '#ffffff',
          background: '#61bc65',
          border: '1px solid #61bc65',
          fontSize: '14px',
          padding: '7px 12px 4px 12px',
          borderRadius: '4px',
          marginRight: '14px',
        }}
        onClick={() => {
          importJson();
        }}>
        导入文件
      </button>
    </div>
  )

  async function nojsTest() {
    try {
      const resp = await post<any>('http://10.1.121.4:3000/api/data1', { "project_id": projectModel?.project_info.project_id })
      return resp
    } catch {
      return null
    }
  }


  function importJson() {
    selectFiles({ accept: '.json' }).then((files) => {
      const [file] = files;
      const reader = new FileReader();
      reader.readAsText(file, 'UTF-8');
      reader.onload = () => {
        const _uuid = AddJsonTempID.ID;
        const allObjects = canvasEditor?.canvas.getObjects().map((item: any) => item.toJSON(["selectable", "evented", "id"]));

        console.log('=======allObjects===', allObjects);
        const currentObjects = allObjects.filter((item: any) => item.id.includes(WorkspaceID.WorkspaceCavas));
        console.log('=======currentObjects===', reader.result);

        if (typeof reader.result === 'string') {
          // 解析 JSON 字符串为对象
          const resultObject = JSON.parse(reader.result);
          const newObjects = resultObject.objects;
          console.log('=======newObjects ===', newObjects);
          const result = { objects: [...currentObjects, ...newObjects] };
          canvasEditor?.insertSvgFile(result);
        }
      };
    });
  }

  function initImage() {
    var selectImg = canvasEditor?.canvas.getActiveObject();
    if (selectImg) {
      selectImg.set({
        left: 0,
        top: 0,
        scaleX: 1,
        scaleY: 1,
      });
      // 更新 canvas 以显示更改
      canvasEditor?.canvas.renderAll();
    }
  }

  function setDistort() {
    console.log('selectImg====start ====');
    var selectImg = canvasEditor?.canvas.getActiveObject();
    if (selectImg) {
      console.log('selectImg====start ====');
      let worker = new IMagickWorker();
      ///得到图片数据dataUrl，传入worker里面
      worker.onmessage = function (e) {
        // 使用处理后的图像数据
        console.log('selectImg====getData ====');

        const base64 = e.data;
        // 创建一个新的 Image 对象
        const img = new Image();
        img.onload = function () {
          // 图像加载完成后，将其添加到 canvas 中
          const fabricImage = new fabric.Image(img);
          canvasEditor?.canvas.add(fabricImage);
          canvasEditor?.canvas.renderAll();
        };
        // 设置图像的 src 为 base64 编码的数据
        img.src = base64;
        worker.terminate();
        worker = null;
      };
      ///四个角，原始坐标-》目标坐标
      // iphone15 323 645, （392，782）339，59
      //  const params = [
      //     0, 0, 0, 0,       // 左上角坐标不变（源坐标 (0, 0) -> 目标坐标 (10, 0)）
      //     1169, 0, 1169 - 104, 200,   // 右上角坐标向内倾斜（源坐标 (303, 0) -> 目标坐标 (216, 30)）
      //     0, 1654, 0, 1654,    // 左下角坐标不变（源坐标 (0, 597) -> 目标坐标 (0, 597)）
      //     1169, 1654, 1169 - 104, 1654 - 200  // 右下角坐标向内倾斜（源坐标 (303, 597) -> 目标坐标 (230, 607)）
      //   ];
      const params = [
        0, 0, 0, 0,
        276, 0, 236, 10,
        0, 197, 0, 197,
        276, 197, 236, 184,
      ]
      worker.postMessage({
        action: ACTION_MAGICK.ACTION_TYPE_DISTORT,
        data: {
          dataUrl: selectImg.toDataURL(), // 原始图像数据
          params: params // 透视变换参数,
        }
      });
    }
  }

  function setDistortCylinder() {
    var selectImg = canvasEditor?.canvas.getActiveObject();
    if (selectImg) {
      // 获取选中图像的宽度和高度
      const originalWidth = selectImg.getScaledWidth();
      const originalHeight = selectImg.getScaledHeight();
      // 瓶子左侧是cyCutLeft 0，中间是originalWidth! / 4，右侧是originalWidth! / 2
      const cyCutLeft = originalWidth! / 2;
      const cyCutTop = 0;
      const cyCutWidth = originalWidth! / 2;
      const cyCutHeight = originalHeight;
      // 创建新的图像对象，并设置裁剪区域
      const newImg = new fabric.Image(selectImg.getElement(), {
        left: 0, // 通常设置为0，除非你需要在画布上移动图像
        top: 0, // 通常设置为0，除非你需要在画布上移动图像
        width: cyCutWidth,
        height: cyCutHeight,
        cropX: cyCutLeft, // 设置裁剪区域的起始X坐标
        cropY: cyCutTop, // 设置裁剪区域的起始Y坐标
      });

      let worker = new IMagickWorker();
      ///得到图片数据dataUrl，传入worker里面
      worker.onmessage = function (e) {
        // 使用处理后的图像数据
        const base64 = e.data;
        // 创建一个新的 Image 对象
        const img = new Image();
        img.onload = function () {
          // 图像加载完成后，将其添加到 canvas 中
          const fabricImage = new fabric.Image(img);
          canvasEditor?.canvas.add(fabricImage);
          canvasEditor?.canvas.renderAll();
        };
        // 设置图像的 src 为 base64 编码的数据
        img.src = base64;
        worker.terminate();
        worker = null;
      };
      ///四个角，原始坐标-》目标坐标
      console.log('selectImg====start ====', newImg.width, newImg.height);
      const width = newImg.width!;
      const height = newImg.height!;

      const offset = 100;
      const offsetH = 20;
      // 源图像的四个角点
      const srcPoints = [
        // 源图像坐标点    目标图像坐标点
        0, 0, offset - 4, 0,        // 左上角
        width, 0, width - offset + 4, 0, // 右上角
        0, height, offset, height - offsetH,    // 左下角
        width, height, width - offset, height - offsetH  // 右下角
      ];
      // 控制点数组，需要根据图像尺寸和所需效果进行调整
      const amplitude = 20; // 波浪的振幅
      const length = width * 2; // 波浪的波长，设置为图片宽度的两倍
      console.log('selectImg====srcPoints ====', srcPoints);

      var retData: CyRetData = {
        cyCutLeft: cyCutLeft, cyCutTop: cyCutTop, cyCutWidth: cyCutWidth,
        cyCutHeight: cyCutHeight, srcPoints: srcPoints, amplitude: amplitude, length: length
      }

      console.log('selectImg====Ret ====', JSON.stringify(retData));

      const params = srcPoints;
      worker.postMessage({
        action: ACTION_MAGICK.ACTION_TYPE_DISTORT_CYLINDER,
        data: {
          dataUrl: newImg.toDataURL(), // 原始图像数据
          params: params, // 透视变换参数,
          amplitude: amplitude,
          length: length,
        }
      });
    }
  }

  function setDistortArc() {
    var selectImg = canvasEditor?.canvas.getActiveObject();
    if (selectImg) {
      let worker = new IMagickWorker();
      ///得到图片数据dataUrl，传入worker里面
      worker.onmessage = function (e) {
        // 使用处理后的图像数据
        const base64 = e.data;
        // 创建一个新的 Image 对象
        const img = new Image();
        img.onload = function () {
          // 图像加载完成后，将其添加到 canvas 中
          const fabricImage = new fabric.Image(img);
          canvasEditor?.canvas.add(fabricImage);
          canvasEditor?.canvas.renderAll();
        };
        // 设置图像的 src 为 base64 编码的数据
        img.src = base64;
        worker.terminate();
        worker = null;
      };
      ///四个角，原始坐标-》目标坐标
      const params = 120;

      worker.postMessage({
        action: ACTION_MAGICK.ACTION_TYPE_DISTORT_ARC,
        data: {
          dataUrl: selectImg.toDataURL(), // 原始图像数据
          params: params // 透视变换参数,
        }
      });
    }
  }

}

export default ImportJSONButton