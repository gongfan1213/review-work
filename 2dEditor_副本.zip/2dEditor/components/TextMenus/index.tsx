import React, { useState, useEffect, useRef } from "react";
import './index.scss'
import SideTable from '../SideTable'
import font_icon from '../../../../images/2dEditor/font_icon.png'
import { useFabric, useCanvasEditor } from '../../hooks/context';
import { get } from 'src/services';
import Loading from 'src/components/Loading';
import { Button } from 'src/components/MakeUI'
import useDataCache from "../../utils/DataCache";
import { useEvent } from 'src/templates/2dEditor/hooks/context';
import { getFficialMaterialStatus } from "../../service/2dEditService";
import DataCache from 'src/templates/2dEditor/components/MainUi/MainUiLeft/MainUiLeftUpload/cache';
import empty_data_icon from 'src/images/empty_upload.png';
import { appendListToDataA, replaceGraphicData } from 'src/templates/2dEditor/utils/utils'
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

function TextMenus(props: any) {
  const { getCacheItem, setCacheItem, cacheData, cacheHasMore, cachePageSize } = useDataCache();
  const canvasEditor = useCanvasEditor()
  const { getTranslation } = useCustomTranslation();
  const [sideData, setSideData] = useState<any>([]);
  const [isNetLoading, setNetLoading] = useState(false)
  const [isLoading, setLoading] = useState(false)
  const event = useEvent();
  const refdata = useRef<any>();
  const pageIndex = useRef(2);
  const SeeAllref = useRef(null)
  const PAGE_SIZE = 20;
  const [isSeeAll, setIsSeeAll] = useState<any>('')
  const [hasMore, setHasMore] = useState(false)
  const [hasLoading, setHasLoading] = useState(false)//加载更多模块的loading
  const [seeAllData, setSeeAllData] = useState<any>([]);
  const [RefreshLoading, setRefreshLoading] = useState<any>([])
  const [ListLoading, setListLoading] = useState(false)//加载更多模块的loading
  const [ListMore, setListMore] = useState(false)
  const List_PAGE_SIZE = 5;
  const currentIndex = useRef(0);
  const interface_loading = useRef(false)
  const [AllTypeData, setAllTypeData] = useState<any>([])
  const [isError, setIsError] = useState(false)
  const refRightState = useRef<Boolean>(false)

  // 拖拽属性
  const dragOption = {
    left: 0,
    top: 0,
  };

  // headline;
  const addHeadline = (option?: any) => {
    canvasEditor?.addText('Headline', {
      ...option,
      fontSize: 36,
    });
  };

  // paragraph;
  const addParagraph = (option?: any) => {
    const paragraph = 'This is a sample paragraph. Use it to add multiple lines of text for your poster, greeting card, or other design projects which require more information.';
    canvasEditor?.addText(paragraph, {
      ...option,
      fontSize: 18,
      width: 350,
    });
  };

  // 获取tags展示数组
  const getTags = (data: []) => {
    return data?.map((item: any) => item.attributes.tag_name);
  }

  // 获取收藏状态
  const getStatus = async (ids: number[]) => {
    // 2字体模块 3元素模块
    const res = await getFficialMaterialStatus({
      ids: ids,
      type: 2
    });
    return res;
  }

  // 数据的转化
  const DataChange = async (AllData: any, datas: any[]) => {
    let Ids: any[] = [];
    const result = Object.entries(AllData).map(([key, value]: [any, any]) => {

      const matchingClass = datas?.find((item: any) => {
        return item.class_name === key
      });
      //抽离出所有的id，用于调接口获取最新的收藏状态
      AllData[matchingClass?.class_name]?.data?.map((_: any) => {
        Ids.push(_?.id)
      })
      return {
        label: key,
        id: matchingClass?.id || null,
        total: AllData[matchingClass?.class_name]?.meta?.pagination?.total,
        list: value?.data?.map((item: any) => ({
          image: item?.attributes?.font_image?.data?.attributes?.formats?.thumbnail?.url ||
            item?.attributes?.font_image?.data?.attributes?.url,
          canvas_image: item?.attributes?.font_image?.data?.attributes?.url,
          font_file: item?.attributes?.font_file?.data?.attributes?.url,
          rules: {
            title: item?.attributes?.title,
            username: item?.attributes?.author,
            CategoryList: getTags(item?.attributes?.tags?.data || []),
            id: item?.id || null,
          },
        })),
      };
    });
    if (Ids.length > 0) {
      const status = await getStatus(Ids); // 在所有 Ids 都获取后调用getStatus
      // 遍历 result，将 like_status 设置为 status 对象中对应的值
      result?.forEach((item: any) => {
        item?.list?.forEach((subItem: any) => {
          if (status && subItem && subItem.rules) {
            // @ts-ignore
            subItem.rules.like_status = status?.data?.status_map?.[subItem.rules.id];
          }
        });
      });
    }
    return result;
  }

  const ChuDataChange = (AllData: any, datas: any[]) => {
    let Ids: any[] = [];
    const result = Object.entries(AllData).map(([key, value]: [any, any]) => {

      const matchingClass = datas?.find((item: any) => {
        return item.class_name === key
      });
      //抽离出所有的id，用于调接口获取最新的收藏状态
      AllData[matchingClass?.class_name]?.data?.map((_: any) => {
        Ids.push(_?.id)
      })
      return {
        label: key,
        id: matchingClass?.id || null,
        total: AllData[matchingClass?.class_name]?.meta?.pagination?.total,
        list: value?.data?.map((item: any) => ({
          image: item?.attributes?.font_image?.data?.attributes?.formats?.thumbnail?.url ||
            item?.attributes?.font_image?.data?.attributes?.url,
          canvas_image: item?.attributes?.font_image?.data?.attributes?.url,
          font_file: item?.attributes?.font_file?.data?.attributes?.url,
          rules: {
            title: item?.attributes?.title,
            username: item?.attributes?.author,
            CategoryList: getTags(item?.attributes?.tags?.data || []),
            id: item?.id || null,
          },
        })),
      };
    });
    return result;
  }

  const GetCollectionStatus = async (AllData: any) => {
    let Ids: any[] = [];

    AllData?.map((item: any) => {
      item?.list?.map((subItem: any) => {
        subItem?.rules?.id && Ids.push(subItem?.rules?.id)
      })
    })

    if (Ids.length > 0) {
      const status = await getStatus(Ids); // 在所有 Ids 都获取后调用getStatus
      // 遍历 result，将 like_status 设置为 status 对象中对应的值
      const newData = AllData?.map((item: any) => {
        item.list = item?.list?.map((subItem: any) => {
          if (status && subItem && subItem.rules) {
            // @ts-ignore
            subItem.rules.like_status = status?.data?.status_map[subItem.rules.id] || null;
          }
          return subItem;
        });
        return item;
      });
      // console.log("newData", newData);
      return newData;
    }
  }

  const onDragend = (type: any) => {
    // todo 拖拽优化 this.canvas.editor.dragAddItem(event, item);
    switch (type) {
      case 'text':
        addHeadline(dragOption);
        break;
      case 'textBox':
        (dragOption);
        break;
      default:
    }
  };

  // 页面获取全部子项数据
  const fetchData = async (datas: any) => {
    // SSR 时返回空数组
    if (typeof window === 'undefined') return [];
    setLoading(false)
    interface_loading.current = true
    let ItemId = '';
    const promises = datas.map((item: any) => {
      ItemId = item?.id;
      return get<{ data: any }>(
        '/web/cms-proxy/common/content',
        {
          // cms接口地址
          content_type: 'make-2d-text-groups',
          populate: ['font_file', 'font_image', 'tags'],
          filters: {
            group_class: {
              text_group_class: {
                $eq: item?.label
              }
            }
          },
          pagination: {
            page: 1,
            pageSize: PAGE_SIZE,
          },
        },
      ).then((result) => {
        const newData = { [item?.class_name]: result.data || [] };
        const processedData = ChuDataChange(newData, datas);
        if (Array.isArray(processedData)) { // 检查 processedData 是否是数组
          setSideData((prevData: any) => {
            // console.log("--------prevData", prevData);
            // 确保 prevData 是数组
            prevData = Array.isArray(prevData) ? prevData : [];
            // 创建一个新的数组，用于存储更新后的数据
            let newData = [...prevData];

            processedData.forEach((newItem: any) => {
              // 在旧数据中找到与新数据具有相同 id 的项的索引
              const index = prevData.findIndex((oldItem: any) => oldItem.id === newItem.id);
              // 如果找到了匹配的项，就用新数据替换旧数据
              if (index !== -1) {
                newData[index] = newItem;
              }
            });
            // 返回更新后的数据
            // console.log("newData--第一次设置------<", newData);
            return newData;
          });
        }
        return processedData;
      })
    });
    const results = await Promise.all(promises);
    // 数据转化，铺平
    let flatArray = results.flatMap(innerArray => innerArray);
    if (datas && flatArray.length > 0) {
      currentIndex.current = currentIndex.current + 5;
    }
    GetCollectionStatus(flatArray).then(result => {
      let newAllData: any[]

      setSideData((prevData: any) => {
        newAllData = [...prevData];
        // 确保 prevData 是数组
        prevData = Array.isArray(prevData) ? prevData : [];
        // 创建一个新的数组，用于存储更新后的数据
        result?.forEach((newItem: any) => {
          // 在旧数据中找到与新数据具有相同 id 的项的索引
          const index = prevData.findIndex((oldItem: any) => oldItem.id === newItem.id);
          // 如果找到了匹配的项，就用新数据替换旧数据
          if (index !== -1) {
            newAllData[index] = newItem;
          }
        });
        const cacheData = getCacheItem('textMenu') || {};
        // console.log("result--=------", newAllData);
        setCacheItem('textMenu', {
          ...cacheData,
          'pageData': newAllData
        })
        // 当前数据大于缓存数据时，且返回的数据大于List_PAGE_SIZE条数时，加载更多
        setListMore(datas.length >= List_PAGE_SIZE)
        // console.log("datas.length >= List_PAGE_SIZE", datas.length >= List_PAGE_SIZE);

        setListLoading(false)
        return newAllData;
      });
      // 获取收藏状态成功后，再去除刷新的loading状态  
      setRefreshLoading((prevIds: any) => prevIds.filter((id: string) => id !== ItemId));
    })
    setLoading(false)
    interface_loading.current = false
  };

  // 获取所有小类
  const fetchSonClass = async () => {
    if (typeof window === 'undefined') return;
    setIsError(false)
    setListLoading(true)
    interface_loading.current = true
    const cacheData = getCacheItem('textMenu');

    // 一进入页面时，判断AllTypeData内是否存在数据，如果没有就调接口，如果存在就直接取值
    const hasLabel = cacheData?.FontTypeData?.some((_: any) => {
      if (cacheData?.FontTypeData.length > 0) {
        // console.log("---cacheData?.FontTypeData----", cacheData?.FontTypeData);

        const newData = cacheData?.FontTypeData.slice(currentIndex.current, currentIndex.current + 5);
        setSideData(newData);
        fetchData(newData);
        return true;
      }
      return false;
    });
    // 如果AllTypeData内不存在label，那么就调接口获取数据
    if (hasLabel) return;
    try {
      const json = await get<{ data: any }>(
        '/web/cms-proxy/common/content',
        {
          // cms接口地址
          content_type: 'make-2d-text-group-classes',
          pagination: {
            page: 1,
            pageSize: 10000,
          },
        },
      );
      let data = [] as any;
      json.data?.data?.map((_: any) => {
        data.push({ label: _?.attributes?.text_group_class, id: _?.id, class_name: _?.attributes?.text_group_class, });
      });
      setAllTypeData((oldData: any) => {
        setCacheItem('textMenu', {
          ...getCacheItem('textMenu') || {},
          'FontTypeData': data,
        });
        return data;
      });
      console.log("data", data);

      const newData = data.slice(currentIndex.current, currentIndex.current + 5);
      setSideData(newData);
      fetchData(newData);
    } catch (error) {
      console.log('fetchSonClass方法错误');
      setListLoading(false);
      interface_loading.current = false;
      setIsError(true)
      return;
    }
  };

  //  首页加载更多数据
  const fetchListMore = () => {
    // 需要处理
    if (interface_loading.current === true) {
      // 延迟一秒再跑一次
      // setTimeout(fetchListMore, 1000);
      return;
    }
    const cachePageData = getCacheItem('textMenu') || {};
    // 只有所有数据大于缓存数据时才加载更多
    if (AllTypeData?.length <= cachePageData?.pageData?.length) {
      setListMore(false);
      return
    }

    if (isSeeAll === true) return;
    // 存放五项数据，超出高度就加载后面五项
    const newData1 = AllTypeData?.slice(currentIndex.current, currentIndex.current + 5);
    // 率先展示小类，然后再调接口填充值
    setSideData((item: any) => {
      fetchData(newData1)
      return [...item, ...newData1]
    });
  }

  const CardClick = async (data: any) => {
    console.log('datadatadatadatadata=====', data);

    setNetLoading(true);
    try {
      await canvasEditor?.addJSON(data?.font_file)
    } catch (err: any) {
      setNetLoading(false);
    }
    setNetLoading(false);

  }

  // 加载更多数据
  const getMoreValue = async (nowItemClass: any, clear: string, NewPage: number) => {
    setLoading(false)
    if (NewPage) {
      pageIndex.current = NewPage
    }
    // 当前的数据大于等于总数时，就不跑加加载跟多的方法
    if (nowItemClass?.list?.length >= nowItemClass?.total) {
      setHasLoading(false)
      setHasMore(false)
      return
    }
    if (clear === 'clear') {
      setSeeAllData([])
      pageIndex.current = 2;
    }
    if (typeof window === 'undefined') return [];
    let ret: any = [];
    // setHasLoading(true);
    const item = { class_name: nowItemClass?.label, id: nowItemClass?.id };

    const result = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      {
        // cms接口地址
        content_type: 'make-2d-text-groups',
        populate: ['font_file', 'font_image', 'tags'],
        filters: {
          group_class: {
            text_group_class: {
              $eq: item?.class_name
            }
          }
        },
        pagination: {
          page: pageIndex.current,
          pageSize: PAGE_SIZE,
        },
      },
    )
    const AllData = { [item?.class_name]: result.data || [] };
    DataChange(AllData, [item]).then(result => {

      if (result[0] && result[0]?.list?.length > 0) {
        ret = result[0]?.list;
        pageIndex.current++;
      }

      setSeeAllData((oldData: any) => {
        // 创建一个新的数组，包含旧的sideData和新的list数据
        const newData = [...oldData];
        const newItem = result[0];
        const existingItem = newData.find((data: any) => data.id === newItem.id);
        // console.log("-------------", result[0]);

        if (existingItem) {
          // 如果item已经存在于sideData中，那么更新它的list
          existingItem.list = [...existingItem.list, ...newItem.list];
        } else {
          // 如果item不存在于sideData中，那么添加它，需要加入第一页的数据
          newData.push({ ...nowItemClass, list: [...nowItemClass?.list, ...newItem.list] });
        }
        // console.log("SeeAllref.current", SeeAllref.current);
        // 返回新的sideData
        if (SeeAllref.current) {
          setSideData(newData);
          // 更新缓存内的数据，使得在首页横向滚动的数据是最新的
          setCacheItem('textMenu',
            replaceGraphicData(newData, getCacheItem('textMenu'))
          )
        }
        return newData;
      });
      setHasLoading(false)
      setHasMore(ret.length >= PAGE_SIZE);
    });
  };

  // 往右侧滚动加载跟多方法
  const RightMoreData = async (nowItemClass: any) => {
    if (refRightState.current === true) {
      return
    }
    let nextPage = 1;
    // 计算当前页数
    const currentPage = Math.ceil(nowItemClass?.list.length / PAGE_SIZE);
    // 判断是否有下一页
    if (nowItemClass?.list.length >= nowItemClass?.total) {
      // console.log("不需要调用接口，已加载所有数据。");
      return
    } else {
      // 计算下一次调用接口的页数
      nextPage = currentPage + 1;
      refRightState.current = true
    }

    const item = { class_name: nowItemClass?.label, id: nowItemClass?.id };
    const result = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      {
        // cms接口地址
        content_type: 'make-2d-text-groups',
        populate: ['font_file', 'font_image', 'tags'],
        filters: {
          group_class: {
            text_group_class: {
              $eq: item?.class_name
            }
          }
        },
        pagination: {
          page: nextPage,
          pageSize: PAGE_SIZE,
        },
      },
    )
    const AllData = { [item?.class_name]: result.data || [] };
    // DataChange(AllData, [item]).then(result => {
    //   const newItem = result[0];
    //   const newData = appendListToDataA(sideData, newItem)
    //   setSideData(newData)
    //   refRightState.current = false
    // });
    // return 'success'
    try {
      const result = await DataChange(AllData, [item]);
      const newItem = result[0];
      const newData = appendListToDataA(sideData, newItem);
      setSideData(newData);
      refRightState.current = false;
      return 'success'; // 只有在这里返回成功
    } catch (error) {
      console.error("处理更多数据时出错:", error);
      refRightState.current = false;
      return 'error'; // 处理失败返回错误
    }
  }

  // 点击seeAll时调用，seeAllState：是否点击了seeAll，item：当前点击的小类，clear：清空数据状态
  const IsSeeAll = (seeAllState: any) => {
    SeeAllref.current = seeAllState
    setIsSeeAll(seeAllState)
  }

  const item_refresh = (item: any) => {
    // 添加需要loading状态的id项
    setRefreshLoading((oldData: any) => [...oldData, item.id])
    fetchData([{ 'label': item.label, 'id': item?.id }])
  }

  useEffect(() => {
    const cacheData = getCacheItem('textMenu') || {};
    setAllTypeData(cacheData.FontTypeData || [])

    if (cacheData && cacheData?.pageData?.length > 0) {
      setSideData(cacheData?.pageData);
      // 总数据大于当前数据时，加载更多
      if (cacheData.FontTypeData.length > cacheData?.pageData?.length) {
        currentIndex.current = cacheData?.pageData?.length
        console.log("rrr");
        setListMore(true)
      } else {
        console.log("lll");
        setListMore(false)
        return
      }
    } else {
      fetchSonClass();
    }
  }, [])

  useEffect(() => {
    // @ts-ignore
    DataCache.getInstance().updateMaterialtEmitter(event);
    // @ts-ignore
    DataCache.getInstance().updateProjectCreateEmitter(event);
    return () => {
      DataCache.getInstance().removeUpdateMaterialtEmitter();
      DataCache.getInstance().removeUpdateProjectCreateEmitter();
    }
  }, [])

  useEffect(() => {
    // 没有点击seeAll时,不是切换tab,不是刚进入页面时,使用旧的数据
    if (!isSeeAll && isSeeAll !== '') {
      setSideData(getCacheItem('textMenu')?.pageData);
    }

  }, [isSeeAll])

  return (
    <div className='TextMenus_box'>
      <div className="TextMenus_top">
        <div className='TextMenus_title'>{getTranslation(TranslationsKeys.Text)}</div>
        {/* {location.host.includes('ci') && 
        <div className="TextMenus_btn"><Button onClick={() => { font_json() }}>生成文字json</Button></div>
        } */}
        {/* <div className="TextMenus_btn"><Button onClick={() => { font_json() }}>生成文字json</Button></div> */}
      </div>

      <div className="TextMenus_Font">
        <div className="Font_Headline" onClick={() => addHeadline()} draggable={true} onDragEnd={() => onDragend('text')}>
          <img src={font_icon} className="font_icon" />
          <div>{getTranslation(TranslationsKeys.AddHeadline)}</div>
        </div>
        <div className="Font_Paragraph" onClick={() => addParagraph()} draggable={true} onDragEnd={() => onDragend('textBox')}>
          <img src={font_icon} className="font_icon" />
          <div>{getTranslation(TranslationsKeys.AddParagraph)}</div>
        </div>
      </div>
      {
        isError &&
        <div className="error_box">
          <div className="item_refresh" onClick={() => { fetchSonClass() }}>{getTranslation(TranslationsKeys.Refresh)}</div>
          <div className="no_data_box">
            <img src={empty_data_icon} className="no_data_icon" />
            <div>{getTranslation(TranslationsKeys.NO_DATA_AVAILABLE)}</div>
          </div>
        </div>
      }

      <div style={{ height: '80%', overflow: 'auto' }}>
        <SideTable
          data={sideData}
          CardClick={CardClick}
          isLoading={isLoading}
          hasLoading={hasLoading}
          type={'TextMenus'}
          hasMore={hasMore}
          fetchDataMore={getMoreValue}
          IsSeeAll={IsSeeAll}
          refdata={refdata}
          item_refresh={item_refresh}
          RefreshLoading={RefreshLoading}
          fetchListMore={fetchListMore}
          ListLoading={ListLoading}
          ListMore={ListMore}
          RightMoreData={RightMoreData}
          isDetailsIcon={true}
        />
      </div>
      <Loading loading={isNetLoading} />
    </div>
  )
}

export default TextMenus
