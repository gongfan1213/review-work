import React, { useCallback, useEffect, useState } from 'react'
import { useCanvasEditor, useEvent } from '../../hooks/context';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import Slider from '@mui/material/Slider';
import { SketchPicker } from 'react-color';
import { SelectEvent } from '../../utils/event/types';

function AttrMenu() {
  const [baseAttr, setBaseAttr] = useState({
    id: '',
    opacity: 0,
    angle: 0,
    fill: '#fff',
    left: 0,
    top: 0,
    strokeWidth: 0,
    strokeDashArray: [],
    stroke: '#fff',
    shadow: {
      color: '#fff',
      blur: 0,
      offsetX: 0,
      offsetY: 0,
    },
    points: {},
  })

  const canvasEditor = useCanvasEditor();

  const event = useEvent();

  const getObjectAttr = useCallback((e) => {
    const activeObject = canvasEditor.canvas.getActiveObject();
    // 不是当前obj，跳过
    if (e && e.target && e.target !== activeObject) return;
    if (activeObject) {
      setBaseAttr({
        id: activeObject.get('id'),
        opacity: activeObject.get('opacity') * 100,
        fill: activeObject.get('fill'),
        left: activeObject.get('left'),
        top: activeObject.get('top'),
        strokeWidth: activeObject.get('strokeWidth'),
        strokeDashArray: activeObject.get('strokeDashArray'),
        stroke: activeObject.get('stroke'),
        shadow: activeObject.get('shadow') || {},
        angle: activeObject.get('angle') || 0,
        points: activeObject.get('points') || {},
      })
    }
  }, [canvasEditor]);

  useEffect(() => {
    if (!canvasEditor || !event) return;
    event.on(SelectEvent.ONE, getObjectAttr);
    canvasEditor.canvas.on('object:modified', getObjectAttr);
    return () => {
      event.off(SelectEvent.ONE, getObjectAttr);
      canvasEditor.canvas.off('object:modified', getObjectAttr);
    }
  }, [canvasEditor, event])

  const strokeDashList = [
    {
      data: {
        strokeUniform: true,
        strokeDashArray: [],
        strokeLineCap: 'butt',
      },
      value: 'Stroke',
      label: 'Stroke',
    },
    {
      data: {
        strokeUniform: true,
        strokeDashArray: [1, 10],
        strokeLineCap: 'butt',
      },
      label: 'Dash-1',
      value: 'Dash-1',
    },
    {
      data: {
        strokeUniform: true,
        strokeDashArray: [1, 10],
        strokeLineCap: 'round',
      },
      label: 'Dash-2',
      value: 'Dash-2',
    },
    {
      data: {
        strokeUniform: true,
        strokeDashArray: [15, 15],
        strokeLineCap: 'square',
      },
      label: 'Dash-3',
      value: 'Dash-3',
    },
    {
      data: {
        strokeUniform: true,
        strokeDashArray: [15, 15],
        strokeLineCap: 'round',
      },
      label: 'Dash-4',
      value: 'Dash-4',
    },
    {
      data: {
        strokeUniform: true,
        strokeDashArray: [25, 25],
        strokeLineCap: 'square',
      },
      label: 'Dash-5',
      value: 'Dash-5',
    },
    {
      data: {
        strokeUniform: true,
        strokeDashArray: [25, 25],
        strokeLineCap: 'round',
      },
      label: 'Dash-6',
      value: 'Dash-6',
    },
    {
      data: {
        strokeUniform: true,
        strokeDashArray: [1, 8, 16, 8, 1, 20],
        strokeLineCap: 'square',
      },
      label: 'Dash-7',
      value: 'Dash-7',
    },
    {
      data: {
        strokeUniform: true,
        strokeDashArray: [1, 8, 16, 8, 1, 20],
        strokeLineCap: 'round',
      },
      label: 'Dash-8',
      value: 'Dash-8',
    },
  ];


  const changeCommon = (key, value) => {
    const activeObject = canvasEditor.canvas.getActiveObjects()[0];
    // 透明度特殊转换
    if (key === 'opacity') {
      activeObject && activeObject.set(key, value / 100);
    } else if (key === 'angle') {
      activeObject.rotate(value);
    } else {
      activeObject && activeObject.set(key, value);
    }
    canvasEditor.canvas.renderAll();

    // 更新属性
    getObjectAttr();
  };

  // 阴影设置
  const changeShadow = (key: string, value) => {
    const shadow = {
      ...baseAttr.shadow,
      [key]: value,
    };
    setBaseAttr((val) => ({
      ...val,
      shadow,
    }))
    const activeObject = canvasEditor.canvas.getActiveObjects()[0];
    activeObject && activeObject.set('shadow', new fabric.Shadow(shadow));
    canvasEditor.canvas.renderAll();
  };
  const [border, setBorder] = useState(strokeDashList[0].value);

  const setBorderFun = (option) => {
    const activeObject = canvasEditor.canvas.getActiveObjects()[0];
    if (activeObject) {
      activeObject.set(option.data);
      canvasEditor.canvas.renderAll();
    }
  }
  return (
    <div style={{ display: 'flex', flexDirection: "column" }}>
      <div style={{ color: "#000" }}>外观</div>
      {/* <ColorPicker value={baseAttr.fill} onChange={(_, value) => changeCommon('fill', value)} size="middle" showText defaultFormat={'hex'} /> */}

      {/* <SketchPicker
        color={baseAttr.fill}
        onChangeComplete={(color) => changeCommon('fill', color.hex)}
      /> */}
      <div className='field-wrapper'>
        <div className='field-box'>
          <span>x轴：</span>
          <TextField
            type="number"
            value={baseAttr.left}
            onChange={(event) => changeCommon('left', event.target.value)}
            inputProps={{ step: "1" }} // 可以根据需要设置步长
          />
        </div>
        <div className='field-box'>
          <span>y轴：</span>
          <TextField
            type="number"
            value={baseAttr.top}
            onChange={(event) => changeCommon('top', event.target.value)}
            InputLabelProps={{
              shrink: true,
            }}
            variant="outlined"
          />
        </div>
      </div>
      <div>
        <div className="field-box">
          <span>旋转：</span>
          <div style={{ flex: 1 }}>
            <Slider
              min={0}
              max={360}
              value={baseAttr.angle}
              onChange={(e, value) => changeCommon('angle', value)}
            />
          </div>
        </div>
      </div>
      <div>
        <div className="field-box">
          <span>透明：</span>
          <div style={{ flex: 1 }}>
            <Slider
              min={0}
              max={100}
              value={baseAttr.opacity}
              onChange={(e, value) => changeCommon('opacity', value)}
            />
          </div>
        </div>
      </div>
      <div style={{ color: "#000" }}>边框</div>
      <div>
        <div className="field-box">
          <span>颜色</span>
          <div style={{ flex: 1 }}>
            {/* <ColorPicker value={baseAttr.stroke} onChange={(_, value) => changeCommon('stroke', value)} size="middle" showText defaultFormat={'hex'} /> */}
          </div>
        </div>
        <div className="field-box">
          <span>宽度</span>
          <div style={{ flex: 1 }}>
            <TextField
              type="number"
              value={baseAttr.strokeWidth || ''}
              onChange={(event) => changeCommon('strokeWidth', Number(event.target.value))}
              variant="outlined"
            />
          </div>
        </div>
      </div>
      <div>
        <div className="field-box">
          <span>边框</span>
          <div style={{ flex: 1 }}>
            <Select
              style={{ width: '100%' }}
              onChange={(event) => setBorderFun(event.target.value)}
              value={border}
            >
              {strokeDashList.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </Select>

          </div>
        </div>
      </div>
      <div style={{ color: "#000" }}>阴影</div>
      <div>
        <div className="field-box">
          <span>颜色</span>
          <div style={{ flex: 1 }}>
            {/* <ColorPicker value={baseAttr.shadow.color} onChange={(_, value) => changeShadow('color', value)} size="middle" showText defaultFormat={'hex'} /> */}
          </div>
        </div>
        <div className="field-box">
          <span>模糊</span>
          <div style={{ flex: 1 }}>
            <TextField
              type="number"
              value={baseAttr.strokeWidth}
              onChange={(event) => changeCommon('strokeWidth', event.target.value)}
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
            />
          </div>
        </div>
      </div>
      <div>
        <div className="field-box">
          <span>X轴</span>
          <div style={{ flex: 1 }}>
            <TextField
              type="number"
              value={baseAttr.shadow.offsetX}
              onChange={(event) => changeShadow('offsetX', event.target.value)}
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
            />
          </div>
        </div>
        <div className="field-box">
          <span>Y轴</span>
          <div style={{ flex: 1 }}>
            <TextField
              type="number"
              value={baseAttr.shadow.offsetY}
              onChange={(event) => changeShadow('offsetY', event.target.value)}
              InputLabelProps={{
                shrink: true,
              }}
              variant="outlined"
            />
          </div>
        </div>
      </div>
      <div style={{ color: "#000" }}>标识</div>
      <div>
        <div className="field-box">
          <span>ID</span>
          <div style={{ flex: 1 }}>
            <TextField
              value={baseAttr.id || ''}
              onChange={(event) => changeCommon('id', event.target.value)}
              variant="outlined"
            />
          </div>
        </div>
      </div>
    </div >
  )
}

export default AttrMenu