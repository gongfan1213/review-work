import React, { useCallback, useState, useRef, useMemo, useEffect, useImperativeHandle, forwardRef } from 'react'
import clsx from 'clsx'
import { Search, Clear } from 'src/components/icon'
import * as classes from './index.module.scss'
import { useTranslation } from '@volcengine/i18n'
import search_icon from '../../../../images/2dEditor/search_icon.png'
import Icon_Sliders from '../../../../images/2dEditor/Icon_Sliders.png'
import useDataCache from '../../utils/DataCache';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

// 该组件基于项目内SearchC组件进行修改，如果后续UI需要靠拢，可以再参考SearchC组件 
// props：SearchValue(function)用于传递搜索框的值
// IconClick(function)用于点击搜索框左侧搜索图标的回调
// editClick(function)用于点击搜索框右侧编辑图标的回调
// getSearchData(function)搜索框回车后的回调（搜索框有数据情况用）
// fetchSonClass(function)搜索框回车后的回调(需要展示所有数据用，如搜索框为空时)
// CloseState(function)搜索时，清空数据的回调
// filterValue筛选框的数据，用于判断
// clearSeeAllState(function)清除SeeAll的状态

export default forwardRef(function TemplatesInput(props: any) {
  const { getCacheItem, } = useDataCache();
  const { getTranslation } = useCustomTranslation();
  const { SearchValue, IconClick, editClick, getSearchData, fetchSonClass, CloseState, filterValue, clearSeeAllState, refInput } = props
  //输入框的值
  const [searchKey, setSearchKey] = useState<string>('')
  const clearButtonVisible = useMemo(() => {
    return searchKey && searchKey.length > 0
  }, [searchKey])
  const [isFocused, setIsFocused] = useState(false); // 新增状态

  const handleFocus = () => setIsFocused(true);
  const handleBlur = () => setIsFocused(false);

  useImperativeHandle(refInput, () => ({
    resetExpandedStates: () => {
      setSearchKey('')
    }
  }));

  // 按下回车后触发
  const handleOnSearch = (event: any) => {
    if (event?.code === 'Enter') {
      clearSeeAllState();
      CloseState()
      if (event?.target?.value === '' && (filterValue.length === 0 || (filterValue?.product?.length === 0 && filterValue?.tags?.length === 0))) {
        fetchSonClass()
      } else {
        getSearchData('', '')
      }
    }
  }

  const SearchOnchange = (e: any) => {
    setSearchKey(e)
    SearchValue(e)
  }

  const clearClick = () => {
    setSearchKey('')
    SearchValue('')
    CloseState()
    if (filterValue?.product?.length > 0 || filterValue?.tags?.length > 0) {
      getSearchData('', 'clear')
    } else {
      fetchSonClass()
    }
  }

  useEffect(() => {
    const searchValue = getCacheItem('templatesMenu')?.['searchValue'];
    if (searchValue) {
      setSearchKey(searchValue);
    }
  }, [])

  return (
    <div className={clsx(classes.searchContainer, { [classes.inputFocused]: isFocused })}>
      <img src={search_icon} className={classes.search_icon} onClick={IconClick} />
      <input
        // ref={inputRef}
        // autoFocus={focusOnSearch}
        onFocus={handleFocus} // 添加聚焦事件处理
        onBlur={handleBlur} // 添加失焦事件处理
        onChange={(e) => { SearchOnchange(e.target.value) }}
        onKeyUp={(e) => handleOnSearch(e)}
        value={searchKey}
        placeholder={getTranslation(TranslationsKeys.Search)}
      />
      {clearButtonVisible && (
        <div
          className={classes.clearButton}
          onClick={() => {
            clearClick()
          }}
        >
          <Clear width={20} height={20} />
        </div>
      )}
      {
        <div className={classes.Icon_Sliders_box}>
          <img src={Icon_Sliders} className={classes.Icon_Sliders} onClick={editClick} />
        </div>
      }
    </div>
  )
})
