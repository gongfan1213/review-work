import { ILoadingScreen } from "@babylonjs/core";
import loading_icon from 'src/assets/svg/loading.svg';

export class CustomLoadingScreen implements ILoadingScreen {
    public loadingUIText: string;
    public loadingUIBackgroundColor: string;
    private parentElement: HTMLElement;
    private loadingDiv: HTMLElement | null = null;

    constructor(loadingUIText: string, parentElement: HTMLElement) {
        this.loadingUIText = loadingUIText;
        this.loadingUIBackgroundColor = "rgba(233, 233, 233,255)";
        this.parentElement = parentElement;
    }

    displayLoadingUI(): void {
        // 创建并显示自定义的加载UI
        this.loadingDiv = document.createElement("div");
        this.loadingDiv.id = "customLoadingScreen";
        this.loadingDiv.style.position = "absolute";
        this.loadingDiv.style.top = "0";
        this.loadingDiv.style.left = "0";
        this.loadingDiv.style.width = "100%";
        this.loadingDiv.style.height = "100%";
        this.loadingDiv.style.backgroundColor = this.loadingUIBackgroundColor;
        this.loadingDiv.style.display = "flex";
        this.loadingDiv.style.flexDirection = "column";
        this.loadingDiv.style.justifyContent = "center";
        this.loadingDiv.style.alignItems = "center";

        // 创建自定义图标
        const icon = document.createElement("img");
        icon.src = loading_icon;
        icon.style.width = "20px"; // 根据需要调整图标大小
        icon.style.height = "20px";
        icon.style.animation = "spin 2s linear infinite"; // 添加旋转动画

        // 创建加载文本
        // const loadingText = document.createElement("div");
        // loadingText.innerHTML = this.loadingUIText;
        // loadingText.style.color = "black";
        // loadingText.style.fontSize = "14px";
        // loadingText.style.marginTop = "20px";
        // loadingText.style.textAlign = "center";

        // 将图标和文本添加到加载UI
        this.loadingDiv.appendChild(icon);
        // this.loadingDiv.appendChild(loadingText);

        this.parentElement.appendChild(this.loadingDiv);

        // 添加 CSS 样式
        const style = document.createElement("style");
        style.innerHTML = `
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
    }

    hideLoadingUI(): void {
        // 隐藏并移除自定义的加载UI
        const loadingDiv = document.getElementById("customLoadingScreen");
        if (loadingDiv && loadingDiv.parentElement === this.parentElement) {
            this.parentElement.removeChild(loadingDiv);
        }
    }
}