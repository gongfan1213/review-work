// start_ai_generated 
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader';
import { useLoader } from '@react-three/fiber';
import { useGesture } from 'react-use-gesture';
import * as THREE from 'three';
import { useCanvasEditor, useEvent, useProjectData } from '../../hooks/context';
import * as classes from './ObjViewer.module.scss'
import { EventNameCons } from '../../cons/2dEditorCons';
import FastClick from 'src/common/utils/FastClick';
import { delay } from '@reduxjs/toolkit/dist/utils';
import { ProjectCutDataModel } from '../SelectDialog/model/ProjectModel';
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import { debounce } from 'lodash';

import { Engine, Scene, Mesh, DirectionalLight, PointLight, Color3 } from "@babylonjs/core";
import { FreeCamera, ArcRotateCamera, Vector3, HemisphericLight, MeshBuilder, Color4 } from "@babylonjs/core";
import BabyLonModelView from "./BabyLonModelView"; // uses above component in same directory



const onSceneReady = (scene: Scene) => {
    const camera = new FreeCamera("camera1", new Vector3(0, 3, -10), scene);
    camera.setTarget(Vector3.Zero());
    const canvas = scene.getEngine().getRenderingCanvas();
    camera.attachControl(canvas, true);
    // 创建半球光，照向 (0, 1, 0) - 天空方向
    // const hemisphericLight1 = new HemisphericLight("hemisphericLight1", new Vector3(0, -1, -1), scene);
    // hemisphericLight1.intensity = 1;

    // const dlight = new DirectionalLight("DirectionalLight", new Vector3(0, 0, 1), scene);
    // dlight.intensity = 1;

    // const dlight1 = new DirectionalLight("DirectionalLight", new Vector3(0, 0, -1), scene);
    // dlight1.intensity = 1;
    // hemisphericLight1.diffuse = new Color3(1, 1, 1);
    // hemisphericLight1.specular = new Color3(1, 1, 1);
    // hemisphericLight1.groundColor = new Color3(1, 1, 1);
};

/**
 * Will run on every frame render.  We are spinning the box on y-axis.
 */
const onRender = (scene: Scene) => {
};

interface ObjModelProps {
    path: string;
    texturePath: string;
}

type MaterialValue = {
    metalness: number;
    roughness: number;
}

const ObjModel: React.FC<ObjModelProps> = ({ path, texturePath }) => {
    const groupRef = useRef<THREE.Group>(null);
    var obj: any;
    if (path.endsWith("gltf") || path.endsWith("glb")) {
        const gltf = useLoader(GLTFLoader, path);
        obj = gltf.scene; // 获取场景对象
    } else {
        obj = useLoader(OBJLoader, path);
    }

    const texture = texturePath ? useLoader(THREE.TextureLoader, texturePath) : null;
    const canvasRef = useThree((state) => state.gl.domElement); // 获取 Canvas DOM 元素
    const { gl: renderer, camera, scene } = useThree();
    const event = useEvent();
    const [materialValue, setMaterialValue] = useState<MaterialValue>({ metalness: 0.5, roughness: 0.4 })

    const bind = useGesture(
        {
            onDrag: ({ offset: [x, y] }) => {
                if (groupRef.current) {
                    // 将拖动偏移量转换为旋转角度
                    groupRef.current.rotation.x = y / 100;
                    groupRef.current.rotation.y = x / 100;
                }
            },
            onPinch: ({ da: [distance], event, memo }) => {
                event.preventDefault(); // 阻止浏览器默认的缩放行为
                event.stopPropagation(); // 阻止事件冒泡
                if (!groupRef.current) return memo;

                // 如果memo未定义，则使用当前缩放值
                const lastScale = memo || groupRef.current.scale.x;
                // 根据捏合距离计算新的缩放值
                const newScale = lastScale * (1 + distance / window.innerWidth);
                // 限制缩放范围在0.5倍到2倍之间
                const clampedScale = Math.max(0.5, Math.min(2, newScale));
                groupRef.current.scale.set(clampedScale, clampedScale, clampedScale);

            },
        },
        { domTarget: canvasRef }
    );

    // 计算模型的边界
    const box = new THREE.Box3().setFromObject(obj);
    const center = box.getCenter(new THREE.Vector3());

    // 将模型的中心移动到世界坐标原点
    obj.position.x -= center.x;
    obj.position.y -= center.y;
    obj.position.z -= center.z;

    // 调整摄像机位置和朝向
    // camera.position.set(300, 200, 250);
    // 计算边界框的大小
    if (camera instanceof THREE.PerspectiveCamera) {
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z) / 2;
        const fov = camera.fov * (Math.PI / 180);
        let cameraZ = Math.abs(maxDim / Math.tan(fov / 2));
        const aspect = camera.aspect;
        const cameraX = cameraZ * aspect;
        cameraZ = Math.max(cameraX, cameraZ);

        // 增加一些额外的空间，确保在旋转时模型仍然在视锥体内
        const extraSpace = 1.2;
        cameraZ *= extraSpace;
        // 设置相机的位置
        camera.position.set(center.x, center.y, center.z + cameraZ);
        // 调整相机的朝向，使其指向模型的中心
        camera.lookAt(center);
        // 调整相机的远平面，确保模型不会被裁剪
        camera.far = camera.position.distanceTo(center) + maxDim * extraSpace;
        // 调整相机的近平面，避免过小导致z-fighting
        camera.near = cameraZ / 100;
        // 更新相机的投影矩阵
        camera.updateProjectionMatrix();
    }

    // 添加平行光
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
    directionalLight.position.set(0, 200, 0); // 设置光源的位置
    scene.add(directionalLight);

    // 添加环境光
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.3); // 第二个参数是光照强度
    scene.add(ambientLight);

    // 使用 useEffect 监听 texturePath 的变化
    const setMaterial = useCallback((materialId: number) => {
        switch (materialId) {
            case 1:
                setMaterialValue({ metalness: 0.5, roughness: 0.4 });
                break;
            case 2:
                setMaterialValue({ metalness: 0.0, roughness: 0.1 });
                break;
            case 3:
                setMaterialValue({ metalness: 0.8, roughness: 0.1 });
                break;
            default:
                break;
        }
    }, []);

    useEffect(() => {
        const canvasDomElement = canvasRef;
        const onWheel = (e: any) => e.preventDefault();
        canvasDomElement.addEventListener('wheel', onWheel, { passive: false });

        return () => {
            canvasDomElement.removeEventListener('wheel', onWheel);
        };
    }, []);

    useEffect(() => {
        event?.on(EventNameCons.EventMaterialSet, setMaterial)
        return () => {
            event?.off(EventNameCons.EventMaterialSet, setMaterial)
        }
    }, [texturePath])
    useEffect(() => {
        if (texture) {
            texture.encoding = THREE.sRGBEncoding; // 确保纹理颜色正确

            obj.traverse((child: any) => {
                if (child instanceof THREE.Mesh) {
                    // 如果有旧的纹理，释放资源
                    if (child.material.map) {
                        child.material.map.dispose();
                    }
                    const material = new THREE.MeshStandardMaterial({
                        map: texture,
                        metalness: materialValue.metalness, // 控制材质的金属感，范围从0.0到1.0
                        roughness: materialValue.roughness, // 控制材质的粗糙度，范围从0.0到1.0
                        color: 0xffffff, // 添加基础颜色
                    });
                    // 设置纹理
                    child.material = material;

                    child.material.needsUpdate = true;
                    child.castShadow = true; // 设置模型投射阴影
                    child.receiveShadow = true; // 设置模型接收阴影
                }
            });
        }
    }, [texturePath, obj, materialValue]);


    return (
        <>
            <group ref={groupRef}>
                <primitive object={obj} frustumCulled={false} />
            </group>
        </>
    );
};

interface ObjViewerProps {
    modelPath: string;
    texturePath: string;
}

const ObjViewer: React.FC<ObjViewerProps> = ({ modelPath, texturePath }) => {
    const [texturePathState, setTexturePathState] = useState<string>('');
    const canvasEditor = useCanvasEditor();
    // 设置texturePath 的usestate
    const canvasRef = useRef<HTMLDivElement>(null); // 创建一个引用
    const event = useEvent();
    const projectModel = useProjectData();

    useEffect(() => {
        if (!canvasEditor) return;
        const updateTexture = debounce(() => {
            if (!canvasEditor) return;
            var cut_data: ProjectCutDataModel | undefined = undefined;
            if (projectModel?.canvases[projectModel.canvasesIndex].extra && JSON.parse(projectModel.canvases[projectModel.canvasesIndex].extra!).cutData) {
                cut_data = JSON.parse(JSON.parse(projectModel.canvases[projectModel.canvasesIndex].extra!).cutData)
            }
            canvasEditor.preview1(projectModel).then((data: any) => {
                setTexturePathState(data.dataUrl);
            });
        }, 500);
        // 监听鼠标松开事件，并在事件发生时更新贴图
        const handleMouseUp = () => {
            updateTexture();
        };

        updateTexture();
        // 监听画布上的鼠标松开事件
        canvasEditor.canvas.on('mouse:up', handleMouseUp);
        canvasEditor.canvas.on('object:added', handleMouseUp);
        canvasEditor.canvas.on('object:removed', handleMouseUp);

        // 清理事件监听器
        return () => {
            canvasEditor.canvas.off('mouse:up', handleMouseUp);
            canvasEditor.canvas.off('object:added', handleMouseUp);
            canvasEditor.canvas.off('object:removed', handleMouseUp);
        };
    }, [canvasEditor, projectModel]);

    return (
        <div ref={canvasRef} className={classes.layout}>
            {/* <Canvas onWheel={(e) => e.preventDefault()} >
                <ambientLight intensity={0.5} />
                <ObjModel path={modelPath} texturePath={texturePathState} />
            </Canvas> */}
            <BabyLonModelView antialias path={modelPath} texturePath={texturePathState} onSceneReady={onSceneReady}
                onRender={onRender} id="my-canvas" className={classes.layout}
                engineOptions={undefined} adaptToDeviceRatio={undefined} sceneOptions={undefined} />
        </div>
    );
};

export default ObjViewer;
// end_ai_generated 