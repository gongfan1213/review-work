import { useEffect, useRef, useState } from "react";
import { Engine, Scene, SceneLoader, CubeTexture, Color4, StandardMaterial, Color3, Texture, PBRMaterial, HemisphericLight,DirectionalLight, Vector3 } from "@babylonjs/core";
import '@babylonjs/loaders'
import React from "react";
import { CustomLoadingScreen } from "./CustomLoadingScreen";

interface MyComponentProps {
  path: string;
  texturePath: string;
  antialias: boolean;
  onRender: (scene: any) => void; // 替换为具体的类型
  onSceneReady: (scene: any) => void; // 替换为具体的类型
  [key: string]: any; // 用于rest参数和其他未定义的属性
  engineOptions: any; // 替换为具体的类型
  adaptToDeviceRatio: any;
  sceneOptions: any; // 替换为具体的类型  
}

const BabyLonModelView: React.FC<MyComponentProps> = ({
  path,
  texturePath,
  antialias,
  engineOptions,
  adaptToDeviceRatio,
  sceneOptions,
  onRender,
  onSceneReady,
  ...rest
}) => {
  const reactCanvas = useRef<HTMLCanvasElement>(null);
  const [sceneState, setScene] = useState<Scene | null>(null); // 添加状态来存储scene对象


  // 创建纯色的立方体贴图
  function createSolidColorCubeTexture(scene: Scene, color: string): CubeTexture {
    const size = 1; // 纹理的大小（1x1像素）
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const context = canvas.getContext('2d');
    if (!context) {
      throw new Error('Unable to get canvas context');
    }
    context.fillStyle = color;
    context.fillRect(0, 0, size, size);

    const data = canvas.toDataURL('image/png');
    const cubeTexture = new CubeTexture(data, scene, null, false, [data, data, data, data, data, data]);
    return cubeTexture;
  }

  // set up basic engine and scene
  useEffect(() => {
    const { current: canvas } = reactCanvas;

    if (!canvas) return;

    const engine = new Engine(canvas, true, engineOptions, adaptToDeviceRatio);
    const canvasParentElement = canvas.parentElement;
    if (canvasParentElement) {
      engine.loadingScreen = new CustomLoadingScreen("Loading, please wait...", canvasParentElement);
    }
    const scene = new Scene(engine, sceneOptions);

    scene.clearColor = new Color4(0, 0, 0, 0.0000000000000001);
    // 显示加载屏幕
    engine.displayLoadingUI();
    if (scene.isReady()) {
      onSceneReady(scene);   
      SceneLoader.Append(path, "", scene, function (scene: Scene) {
        // const hdrTexture = CubeTexture.CreateFromPrefilteredData("https://playground.babylonjs.com/textures/environment.dds", scene);
        // const currentSkybox = scene.createDefaultSkybox(hdrTexture, true);
        setSceneBase(scene)        
      });
    } else {
      scene.onReadyObservable.addOnce((scene) => onSceneReady(scene));
    }

    // 加载资源
    scene.executeWhenReady(() => {
      // 隐藏加载屏幕
      console.log("scene===executeWhenReady")
      engine.hideLoadingUI();
    });

    engine.runRenderLoop(() => {
      if (typeof onRender === "function") onRender(scene);
      scene.render();
    });

    const resize = () => {
      scene.getEngine().resize();
    };

    if (window) {
      window.addEventListener("resize", resize);
    }

    return () => {
      scene.getEngine().dispose();

      if (window) {
        window.removeEventListener("resize", resize);
      }
    };
  }, [path, antialias, engineOptions, adaptToDeviceRatio, sceneOptions, onRender, onSceneReady]);



  function setSceneBase(scene){
    const cubeTexture = createSolidColorCubeTexture(scene, "rgb(240, 240, 240)");
        scene.environmentTexture = cubeTexture;
        scene.createDefaultSkybox(cubeTexture, true);
        // }
        scene.createDefaultCameraOrLight(true, true, true);

        // const hemisphericLight1 = new HemisphericLight("hemisphericLight1", new Vector3(0, 1, 0), scene);
        // hemisphericLight1.intensity = 0.1;

        const dlight = new DirectionalLight("DirectionalLight", new Vector3(0.5, -0.5, 1), scene);
        dlight.intensity = 0.4;

        const dlight1 = new DirectionalLight("DirectionalLight1", new Vector3(-0.6, -0.5, -1), scene);
        dlight1.intensity = 0.4;

        scene.removeLight(scene.lights[0])

        const hemisphericLight1 = new HemisphericLight("hemisphericLight1", new Vector3(0, 1, 0), scene);
        hemisphericLight1.intensity = 0.5;

        const hemisphericLight2 = new HemisphericLight("hemisphericLight2", new Vector3(0, -1, 0), scene);
        hemisphericLight2.intensity = 0.5;

        setScene(scene);
  }

  useEffect(() => {   
    if (texturePath && sceneState) {
      // 加载完成后，为需要的网格添加贴图
      sceneState.meshes.forEach((mesh, index) => {  
        if(mesh.id == 'hdrSkyBox'){
          return;
        }    
        // 检查网格是否有材质
        var existingMaterial = mesh.material;
        if (!existingMaterial) {
          existingMaterial = new StandardMaterial("newMaterial", sceneState);
          mesh.material = existingMaterial;
        }
        // if (mesh.material && index == 1) {
        if (existingMaterial instanceof StandardMaterial) {
          // 创建一个新的纹理
          const texture = new Texture(texturePath, sceneState);
          // 将新纹理设置为材质的漫反射纹理
          existingMaterial.diffuseTexture = texture;
          // 设置材质为双面渲染
          existingMaterial.backFaceCulling = false;
          existingMaterial.roughness = 0.8;
          // existingMaterial.twoSidedLighting = true;
        } else if (existingMaterial instanceof PBRMaterial) {
          // 创建一个新的纹理
          if(mesh.id == "杯子_primitive0"){
            const texture = new Texture(texturePath, sceneState);
            // 将新纹理设置为PBR材质的albedo纹理
            existingMaterial.albedoTexture = texture;
            existingMaterial.alpha = 0.9; // 透明度值，根据需要调整
            existingMaterial.transparencyMode = PBRMaterial.PBRMATERIAL_ALPHABLEND;
            existingMaterial.backFaceCulling = false; // 禁用背面剔除
            existingMaterial.twoSidedLighting = true; // 启用双面光照
          }           
        }
        // }
      });
    }
  }, [texturePath, sceneState]);
  return <canvas ref={reactCanvas} {...rest} />;
};

export default BabyLonModelView;
