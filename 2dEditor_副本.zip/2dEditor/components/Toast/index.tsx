import React, { forwardRef, useImperativeHandle, useCallback } from 'react';
import { Button, Snackbar as MaterialSnackbar, IconButton } from '@material-ui/core';
import CheckCircleOutlineOutlinedIcon from '@mui/icons-material/CheckCircleOutlineOutlined';
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import loading_icon from 'src/assets/svg/loading.svg';

import * as classes from './index.module.scss';

// toast;
export const toast: React.RefObject<{
  show: () => void;
  hidden: () => void;
  tips: React.Dispatch<React.SetStateAction<string>>;
  type: React.Dispatch<React.SetStateAction<'default' | 'success' | 'error' | 'warning' | 'loading'>>;
  setAutoHideDuration: React.Dispatch<React.SetStateAction<number>>;
}> = React.createRef();

export enum EditorToastType {
  defaultType = 'default',
  success = 'success',
  error = 'error',
  warning = 'warning',
  loading = 'loading',
}

interface toastShowProps {
  tips: string;
  type?: EditorToastType;
  autoHideDuration?: number;
}

export const editorToastShow = (props: toastShowProps) => {
  toast.current?.tips(props.tips);
  toast.current?.type(props.type || EditorToastType.defaultType);
  toast.current?.setAutoHideDuration(props.autoHideDuration || 3000);
  toast.current?.show();
};

export const editorToastHidden = () => {
  toast.current?.hidden();
};

// Toast;
const ToastSnackbar = forwardRef((_: any, ref: any) => {
  const [open, setOpen] = React.useState(false);
  const [tips, setTips] = React.useState('');
  const [type, setType] = React.useState<'default' | 'success' | 'error' | 'warning' | 'loading'>('default');
  const [autoHideDuration, setAutoHideDuration] = React.useState(3000);

  const show = useCallback(() => {
    setOpen(true);
  }, []);

  const hidden = useCallback(() => {
    setOpen(false);
  }, []);

  useImperativeHandle(
    ref,
    () => ({
      show,
      hidden,
      type: setType,
      setAutoHideDuration,
      tips: setTips,
    }),
    [hidden, show],
  );

  const handleClose = (event: React.SyntheticEvent | React.MouseEvent, reason?: string) => {
    // 点击了其他地方
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
  };

  return (
    <MaterialSnackbar
      // style={{
      //   top: '100px', left: 'calc(50% + 200px + 38.5px)', borderRadius: '10px', zIndex: 2
      // }}
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
      open={open}
      autoHideDuration={type === 'loading' ? 999999 : autoHideDuration}
      onClose={handleClose}
    >
      {type === 'loading' ? (
        <div className={classes.loading_div}>
          <img src={loading_icon} />
          <p>{tips}</p>
        </div>
      ) : (
        <div
          className={classes.toast_div}
          style={{
            backgroundColor:
              type === 'default'
                ? '#f7f7f7'
                : type === 'success'
                ? '#58a056'
                : type === 'error'
                ? '#ba4c4a'
                : '#f4ca31',
            color: type === 'default' ? 'black' : 'white',
          }}
        >
          {type === 'success' || type === 'default' ? <CheckCircleOutlineOutlinedIcon /> : <ErrorOutlineOutlinedIcon />}
          <p>{tips}</p>
        </div>
      )}
    </MaterialSnackbar>
  );
});

export const Toast = () => <ToastSnackbar ref={toast} />;
