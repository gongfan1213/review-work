import { sendCommandToPc } from "src/common/jsbridge";
import { ACTION_OPENCV, CanvasCategory, CanvasParams, CustomPcAction, EventNameCons, FabricObjectType, PROJECT_STANDARD_TYPE } from "src/templates/2dEditor/cons/2dEditorCons";
// import cv from "@techstark/opencv-js";
import { OutLineData, SelectImgToPngData } from "../model/OutLineData";
// @ts-ignore
import OpencvWorker from 'src/templates/2dEditor/core/worker/opencv.worker';
import ProjectManager from "src/templates/2dEditor/utils/ProjectManager";
import { ProjectCreateRequestModel, ProjectModel, RotaryParams } from "../../SelectDialog/model/ProjectModel";
import { createProjectRequest } from "src/templates/2dEditor/utils/utils";
import { CategoryModel } from "../../SelectDialog/model/CategoryModel";
import { From2dEditorType } from "src/templates/2dEditor/utils/event/types";
import eventBus from "src/templates/2dEditor/core/eventbus";
import { WorkspaceID } from "src/templates/2dEditor/cons/2dEditorCons";
import StringUtil from "src/common/utils/stringUtil";
import { OpenCvManager } from "src/templates/2dEditor/common/logic/OpenCvManager";
import { getRotaryParams } from "src/templates/2dEditor/common/cavasUtil";

export class BaseMapChangeManager {
    private static instance: BaseMapChangeManager;
    private cv: any = null; // 添加 cv 属性

    private constructor() {
    }

    public static getInstance(): BaseMapChangeManager {
        if (!BaseMapChangeManager.instance) {
            BaseMapChangeManager.instance = new BaseMapChangeManager();
        }
        return BaseMapChangeManager.instance;
    }

    public init() {
        OpenCvManager.getInstance().initOpenCv().then(async (cv) => {
            console.log('====BaseMapChangeManager===000=')
            this.cv = await (window as any).cv;
            console.log('====BaseMapChangeManager===1111=')
        });
        // let worker = new OpencvWorker();
        // worker.postMessage({
        //     action: ACTION_OPENCV.ACTION_TYPE_OPENCV_INIT,
        // });
        // worker.onmessage = function (data: any) {
        //     console.log('onmessage=======', data);
        // };
    }

    public getDeviceInfo() {
        sendCommandToPc(CustomPcAction.GetDeviceInfoAction);
    }

    public takePhoto(data) {
        sendCommandToPc(CustomPcAction.TakePhotoAction, data);
    }

    /**
     * 获取选中图片转为底图
     * @param selectObj 选中图片对象
     */
    public async getSelectImgToPng(selectObj: fabric.Object): Promise<SelectImgToPngData | null> {
        if (selectObj.type === FabricObjectType.Image || (selectObj.type === 'group' && (selectObj as fabric.Group).getObjects().every((o: any) => o.type === 'path'))) {
            let src: string;
            if (selectObj.type === 'group') {
                // Convert the group to a data URL
                const group = selectObj as fabric.Group;
                // @ts-ignore
                const canvas = new fabric.Canvas(null, {
                    width: group.width,
                    height: group.height
                });
                canvas.add(group);
                canvas.renderAll();
                src = canvas.toDataURL({ format: 'png' });
            } else {
                const data = selectObj.toJSON(['src'])
                src = data.src || '';
                // src = (selectObj as any).src;
            }
            // Load the image from src
            const image = await this.base64ToImage(src);
            const srcMat = this.cv.imread(image);

            // Create a mask where the non-transparent regions are 255 and the rest are 0
            const mask = new this.cv.Mat();
            const channels = new this.cv.MatVector();
            this.cv.split(srcMat, channels);
            const alphaChannel = channels.get(3);
            this.cv.threshold(alphaChannel, mask, 0, 255, this.cv.THRESH_BINARY);

            // Create a white image
            const whiteImg = new this.cv.Mat(srcMat.rows, srcMat.cols, this.cv.CV_8UC4, new this.cv.Scalar(255, 255, 255, 255));

            // Apply the mask to the white image
            const resultImg = new this.cv.Mat();
            whiteImg.copyTo(resultImg, mask);

            // Find contours to get the bounding box of the white content
            const contours = new this.cv.MatVector();
            const hierarchy = new this.cv.Mat();
            this.cv.findContours(mask, contours, hierarchy, this.cv.RETR_EXTERNAL, this.cv.CHAIN_APPROX_SIMPLE);

            // Convert the cropped image to base64
            const canvas = document.createElement('canvas');
            // canvas.width = width;
            // canvas.height = height;
            this.cv.imshow(canvas, resultImg);
            const newImgBase64 = canvas.toDataURL('image/png');

            // Clean up
            srcMat.delete();
            whiteImg.delete();
            mask.delete();
            resultImg.delete();
            contours.delete();
            hierarchy.delete();
            // croppedImg.delete();
            channels.delete();
            alphaChannel.delete();
            return { width: image.width, height: image.height, newImgBase64: newImgBase64 };
        } else {
            return null;
        }
    }


    public replaceImgToCanvas(selectImgToPngData: SelectImgToPngData | null) {
        return new Promise((resolve, reject) => {
            if (selectImgToPngData) {
                // 以自定义非标品数据封装，重新更新项目信息
                console.log("ProjectManager.getInstance().mockBlankData===", ProjectManager.getInstance().mockMaterialData)
                var categoryData: CategoryModel = ProjectManager.getInstance().mockMaterialData?.[0]?.attributes;
                const projectRequest: any = createProjectRequest(
                    { ...categoryData.options[0], is_standard_product: PROJECT_STANDARD_TYPE.PROJECT_STANDARD_NON }, true,
                )
                var print_param = JSON.parse(projectRequest.canvases[0].print_param);
                const extra = JSON.parse(projectRequest.canvases[0].extra);
                extra.isPhotograph = true;

                print_param.cavas_map = '';
                print_param.format_size_w_non = selectImgToPngData.sizeMM.width || 0;
                print_param.format_size_h_non = selectImgToPngData.sizeMM.height || 0;
                print_param.format_size_w = selectImgToPngData.sizeMM.width || 0;
                print_param.format_size_h = selectImgToPngData.sizeMM.height || 0;
                console.log("======replaceImgToCanvas===== ", print_param.format_size_w, print_param.format_size_h)

                var projectCreateRequestModel: ProjectCreateRequestModel = {
                    project_info: projectRequest.project_info,
                    canvases: [
                        {
                            ...projectRequest.canvases[0],
                            base_map_width: selectImgToPngData.size.width,
                            base_map_height: selectImgToPngData.size.height,
                            print_param: JSON.stringify(print_param),
                            extra: JSON.stringify(extra)
                        }
                    ]
                }

                ProjectManager.getInstance().chageProjectCategory(projectCreateRequestModel).then(newMpdel => {
                    if (newMpdel) {
                        const newProject = { ...newMpdel };
                        if (newProject && newProject.project_info) {
                            newProject.project_info.project_name = '';
                            newProject.project_info.category =
                                categoryData?.categoryType?.data?.attributes?.categoryKey || '';
                        }
                        newProject.canvasesIndex = 0;
                        selectImgToPngData.newProjectModel = newProject;
                        eventBus.emit(EventNameCons.EventCanvasChangeImg, selectImgToPngData);
                        //   canvasEditor?.clearHistory();
                        const params = {
                            project_id: newMpdel?.project_info?.project_id,
                            type: From2dEditorType.Replace,
                        }
                        const queryString = new URLSearchParams(params).toString()
                        history.pushState({}, '', `/apps/2dEditor/?${queryString}`)
                        resolve(params);
                    }
                });
            }
        })

    }

    public replaceCategory(category: number, subCategory: number) {
        return new Promise((resolve, reject) => {
            // 以自定义非标品数据封装，重新更新项目信息
            if (ProjectManager.getInstance().mockMaterialData) {
                var categoryData: any = ProjectManager.getInstance().mockMaterialData?.[0]?.attributes.options[0];

                ProjectManager.getInstance().mockMaterialData.forEach((item: any) => {
                    if (item.attributes.categoryType.data.attributes.categoryKey == category) {
                        item.attributes.options.forEach((option: any) => {
                            if (option.categorySubType.data.attributes.categorySubKey == subCategory) {
                                categoryData = option;
                                if (category == CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL) {
                                    let circle: number =
                                        Number(option?.cupTopDiameter) >= Number(option?.cupBottomDiameter)
                                            ? Number(option?.cupTopDiameter)
                                            : Number(option?.cupBottomDiameter)
                                    categoryData.width = Math.round(Math.floor(Math.PI * StringUtil.mmToPixel(circle, CanvasParams.canvas_dpi_def)))
                                    categoryData.height = Math.round(StringUtil.mmToPixel(option?.cupHeight, CanvasParams.canvas_dpi_def))
                                } else {
                                    categoryData.width = Math.round(StringUtil.mmToPixel(option.baseMapWidth, CanvasParams.canvas_dpi_def));
                                    categoryData.height = Math.round(StringUtil.mmToPixel(option.baseMapHeight, CanvasParams.canvas_dpi_def));
                                }
                                categoryData.categoryType = item.attributes.categoryType;
                                return;
                            }

                        })
                    }
                })
                const projectRequest: any = createProjectRequest(
                    { ...categoryData }, true,
                )
                var print_param = JSON.parse(projectRequest.canvases[0].print_param);
                //旋转体属性设置
                if (category == CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL) {
                    var size = StringUtil.pixelsToMM(categoryData.width, categoryData.height, CanvasParams.canvas_dpi_def);
                    print_param.format_size_w = size.widthMM;
                    print_param.format_size_h = size.heightMM;
                    print_param.format_size_w_non = size.widthMM;
                    print_param.format_size_h_non = size.heightMM;
                    projectRequest.canvases[0].print_param = JSON.stringify({
                        ...print_param,
                        rotary_params: getRotaryParams(categoryData.width, categoryData.height, categoryData.handleHeight),
                    });
                }

                var projectCreateRequestModel: ProjectCreateRequestModel = {
                    project_info: projectRequest.project_info,
                    canvases: [
                        {
                            ...projectRequest.canvases[0],
                        }
                    ]
                }
                ProjectManager.getInstance().chageProjectCategory(projectCreateRequestModel).then(newMpdel => {
                    if (newMpdel) {
                        const newProject = { ...newMpdel };
                        if (newProject && newProject.project_info) {
                            newProject.project_info.project_name = '';
                            newProject.project_info.category =
                                categoryData?.categoryType?.data?.attributes?.categoryKey || '';
                        }
                        newProject.canvasesIndex = 0;
                        let data: SelectImgToPngData = {
                            size: {
                                width: 0,
                                height: 0
                            },
                            sizeMM: {
                                width: 0,
                                height: 0
                            },
                            atOnceSave: true,
                            newProjectModel: newProject,
                        }
                        console.log("======projectCreateRequestModel===end== ", data)
                        eventBus.emit(EventNameCons.EventCanvasChangeImg, data);
                        // const params = {
                        //     project_id: newMpdel?.project_info?.project_id,
                        //     type: From2dEditorType.Replace,
                        // }
                        // const queryString = new URLSearchParams(params).toString()
                        // history.pushState({}, '', `/apps/2dEditor/?${queryString}`)
                        // resolve(params);
                    }
                });
            }
        })

    }

    public selectImgToCanvas(selectObj: fabric.Object, canvas: fabric.Canvas, projectSource: ProjectModel) {

        this.getSelectImgToPng(selectObj).then((selectImgToPngData: SelectImgToPngData | null) => {

            if (selectImgToPngData) {
                // 以自定义非标品数据封装，重新更新项目信息
                var categoryData: CategoryModel = ProjectManager.getInstance().mockMaterialData?.[0]?.attributes;

                const projectRequest: any = createProjectRequest(
                    { ...categoryData.options[0], is_standard_product: PROJECT_STANDARD_TYPE.PROJECT_STANDARD_NON }, true,
                )
                var print_param = JSON.parse(projectRequest.canvases[0].print_param);

                print_param.cavas_map = '';
                console.log("===selectImgToCanvas======", selectImgToPngData)
                var retSizeMM = StringUtil.pixelsToMM(selectImgToPngData.width, selectImgToPngData.height, CanvasParams.canvas_dpi_def);
                print_param.format_size_w = retSizeMM.widthMM;
                print_param.format_size_h = retSizeMM.heightMM;

                var projectCreateRequestModel: ProjectCreateRequestModel = {
                    project_info: projectRequest.project_info,
                    canvases: [
                        {
                            ...projectRequest.canvases[0],
                            base_map_width: selectImgToPngData.width,
                            base_map_height: selectImgToPngData.height,
                            print_param: JSON.stringify(print_param)
                        }
                    ]
                }

                ProjectManager.getInstance().chageProjectCategory(projectCreateRequestModel).then(newMpdel => {
                    if (newMpdel) {
                        const newProject = { ...newMpdel };
                        if (newProject && newProject.project_info) {
                            newProject.project_info.project_name = projectSource.project_info.project_name || '';
                            newProject.project_info.category =
                                categoryData?.categoryType?.data?.attributes?.categoryKey || '';
                        }
                        newProject.canvasesIndex = 0;
                        selectImgToPngData.newProjectModel = newProject;

                        eventBus.emit(EventNameCons.EventCanvasChangeImg, selectImgToPngData);
                        //   canvasEditor?.clearHistory();
                        const params = {
                            project_id: newMpdel?.project_info?.project_id,
                            type: From2dEditorType.Replace,
                        }
                        const queryString = new URLSearchParams(params).toString()
                        history.pushState({}, '', `/apps/2dEditor/?${queryString}`)
                        selectObj.set({
                            scaleX: 1,
                            scaleY: 1,
                            left: 0,
                            top: 0
                        });
                    }
                });
            }
        });
    }

    /**
     * 根据OutLineData数据，在底图上裁剪，得到轮廓图列表
     */
    public async getCutImgs(imgStr: string, datas) {

        const image = await this.base64ToImage(imgStr);
        const src = this.cv.imread(image);
        let outlinePaths = [];
        for (let data of datas) {
            const rect = new this.cv.Rect(data.aabb[0], data.aabb[1], data.aabb[2], data.aabb[3]);
            const cropped = src.roi(rect);
            // Get outline SVG string for the cropped image
            const outlinePath = this.getOutlineImgFromMat(cropped);
            outlinePaths.push(outlinePath)
            // Clean up
            cropped.delete();
        }
        // Clean up
        src.delete();

        return outlinePaths;
    }


    public async getCutBaseImg(bgImgStr: string, imgStr: string, data) {
        const rect = new this.cv.Rect(data.aabb[0], data.aabb[1], data.aabb[2], data.aabb[3]);

        const image = await this.base64ToImage(imgStr);
        const original = this.cv.imread(image);
        const src = original.roi(rect);
        const gray = new this.cv.Mat();
        const binary = new this.cv.Mat();

        // 将 src 转换为灰度图像, 并将结果保存到 gray
        this.cv.cvtColor(src, gray, this.cv.COLOR_RGBA2GRAY, 0);
        //  对 gray 应用二值化阈值，将结果保存到 binary
        this.cv.threshold(gray, binary, 70, 255, this.cv.THRESH_BINARY);

        // 创建了一个具有透明背景的新图像
        let newImg = new this.cv.Mat(src.rows, src.cols, this.cv.CV_8UC4, new this.cv.Scalar(0, 0, 0, 0));

        // 创建了一个 mask，其中白色区域为255，其余为0，这是为了区分不同区域
        const mask = new this.cv.Mat();

        //对图像执行按位取反操作。其中 “binary” 是要进行取反操作的二值图像，mask是一个掩码
        this.cv.bitwise_not(binary, mask);

        // 创建了一个具有相同尺寸的白色图像
        const white = new this.cv.Mat(src.rows, src.cols, this.cv.CV_8UC3, new this.cv.Scalar(255, 255, 255));

        // 使用 cv.split 将 white 图像分离成其通道，并将结果保存到 whiteChannels。
        const whiteChannels = new this.cv.MatVector();
        this.cv.split(white, whiteChannels);

        // 将二值化图像作为 alpha 通道添加到 whiteChannels。
        whiteChannels.push_back(binary);

        // 将通道合并到一个新的图像 whiteWithAlpha。
        const whiteWithAlpha = new this.cv.Mat();
        this.cv.merge(whiteChannels, whiteWithAlpha);

        // 使用 cv.bitwise_or 将 newImg 和 whiteWithAlpha 进行取反操作，并将结果保存到 newImg。
        this.cv.bitwise_or(newImg, whiteWithAlpha, newImg);

        // Convert the new image to base64
        const canvas = document.createElement('canvas');
        this.cv.imshow(canvas, newImg);
        const newImgBase64 = canvas.toDataURL('image/png');
        console.log('getCutBaseImgs:===newImgBase64=', newImgBase64);
        // this.downloadBase64Image(newImgBase64, 'contour_image_base.png');

        const bgImage = await this.base64ToImage(bgImgStr);
        const bgOriginal = this.cv.imread(bgImage);
        const bgSrc = bgOriginal.roi(rect);

        this.cv.bitwise_and(bgSrc, newImg, bgSrc)
        this.cv.imshow(canvas, bgSrc);
        const newBgImgBase64 = canvas.toDataURL('image/png');

        // Clean up
        src.delete();
        gray.delete();
        binary.delete();
        mask.delete();
        newImg.delete();
        white.delete();
        whiteChannels.delete();
        whiteWithAlpha.delete();

        return { newImgBase64, newBgImgBase64 };
    }

    private getOutlineImgFromMat(src: any): Array<any> {
        const gray = new this.cv.Mat();
        const binary = new this.cv.Mat();
        const contours = new this.cv.MatVector();
        const hierarchy = new this.cv.Mat();

        // Convert to grayscale
        this.cv.cvtColor(src, gray, this.cv.COLOR_RGBA2GRAY, 0);
        // Apply binary threshold
        this.cv.threshold(gray, binary, 70, 255, this.cv.THRESH_BINARY);
        // Find contours using cv.RETR_TREE to get all contours including nested ones
        this.cv.findContours(binary, contours, hierarchy, this.cv.RETR_TREE, this.cv.CHAIN_APPROX_SIMPLE);

        // Convert contours to SVG
        // const svgContent = this.contoursOutLineToSVG(contours, src.cols, src.rows, true);
        const svgContent = this.contoursOutLineToPath(contours);
        // this.downloadSVG(svgContent, 'contour_image.svg');
        // Clean up
        gray.delete();
        binary.delete();
        contours.delete();
        hierarchy.delete();

        return svgContent;
    }

    /**
     * pc-》web指令监听
     *  */
    public initNotifyListener(callBack: Function) {
        console.log('<---Received message from initNotifyListener=====');
        // @ts-ignore
        if (window.anker_msg) {
            window.anker_msg.receiveMessageFromClient = (dataSource: any) => {
                const { action, data } = dataSource;
                console.log('<---Received message from client===', action, data, new Date().toISOString());
                callBack(action, data);
                switch (action) {
                    case CustomPcAction.GetDeviceInfoAction:
                        break;
                    default:
                }
            }
        }

    }

    /**
     * 根据二值图得到轮廓svg
     *  */
    public async getOutlineImg(imageStr: string) {
        // Convert base64 string to HTMLImageElement
        const image = await this.base64ToImage(imageStr);

        const src = this.cv.imread(image);
        const gray = new this.cv.Mat();
        const binary = new this.cv.Mat();
        const contours = new this.cv.MatVector();
        const hierarchy = new this.cv.Mat();

        // Convert to grayscale
        this.cv.cvtColor(src, gray, this.cv.COLOR_RGBA2GRAY, 0);
        // Apply binary threshold
        this.cv.threshold(gray, binary, 0, 255, this.cv.THRESH_BINARY);
        // Find contours using cv.RETR_TREE to get all contours including nested ones
        this.cv.findContours(binary, contours, hierarchy, this.cv.RETR_EXTERNAL, this.cv.CHAIN_APPROX_TC89_KCOS);

        // Convert contours to SVG
        const svgContent = this.contoursOutLineToSVG(contours, src.cols, src.rows, true);
        // 图片下载
        // this.downloadSVG(svgContent, 'contour_image.svg');

        // Clean up
        src.delete();
        gray.delete();
        binary.delete();
        contours.delete();
        hierarchy.delete();

        return svgContent;
    }

    /**
     * 根据二值图得到底图base64
     *  */
    public async getOutlineBaseImg(imageStr: string): Promise<void> {
        // Convert base64 string to HTMLImageElement
        const image = await this.base64ToImage(imageStr);

        console.log('getOutlineBaseImg:===1111111=');
        const src = this.cv.imread(image);
        const gray = new this.cv.Mat();
        const binary = new this.cv.Mat();

        // Convert to grayscale
        this.cv.cvtColor(src, gray, this.cv.COLOR_RGBA2GRAY, 0);
        // Apply binary threshold
        this.cv.threshold(gray, binary, 70, 255, this.cv.THRESH_BINARY);

        console.log('getOutlineBaseImg:===222222=');
        // Create a new image with transparent background
        const newImg = new this.cv.Mat.zeros(src.rows, src.cols, this.cv.CV_8UC4);

        // Create a mask where the white regions are 255 and the rest are 0
        const mask = new this.cv.Mat();
        this.cv.bitwise_not(binary, mask);
        console.log('getOutlineBaseImg:===333333=');
        // Create a white image with the same size
        const white = new this.cv.Mat(src.rows, src.cols, this.cv.CV_8UC3, new this.cv.Scalar(255, 255, 255));

        // Split the white image into its channels
        const whiteChannels = new this.cv.MatVector();
        this.cv.split(white, whiteChannels);

        // Add the binary image as the alpha channel
        whiteChannels.push_back(binary);

        // Merge the channels back into a single image
        const whiteWithAlpha = new this.cv.Mat();
        this.cv.merge(whiteChannels, whiteWithAlpha);

        // Combine the new image with the white regions
        this.cv.bitwise_or(newImg, whiteWithAlpha, newImg);
        console.log('getOutlineBaseImg:===444444=');

        // Convert the new image to base64
        const canvas = document.createElement('canvas');
        console.log('getOutlineBaseImg:===55555=');
        this.cv.imshow(canvas, newImg);
        const newImgBase64 = canvas.toDataURL('image/png');
        console.log('getOutlineBaseImg:===666666=');

        this.downloadBase64Image(newImgBase64, 'contour_image_base.png');
        console.log('getOutlineBaseImg:===777777=');
        // Clean up
        src.delete();
        gray.delete();
        binary.delete();
        mask.delete();
        newImg.delete();
        white.delete();
        whiteChannels.delete();
        whiteWithAlpha.delete();
    }

    private downloadBase64Image(base64Str: string, filename: string): void {
        const link = document.createElement('a');
        link.href = base64Str;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    private base64ToImage(base64: string): Promise<HTMLImageElement> {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = reject;
            img.src = `${base64}`;
        });
    }

    private contoursOutLineToPath(contours: any) {
        const contoursSize = contours.size();
        const pathArr = [];
        for (let i = 0; i < contoursSize; ++i) {
            const contour = contours.get(i);
            let path = [];
            for (let j = 0; j < contour.rows; ++j) {
                const x = contour.data32S[j * 2];
                const y = contour.data32S[j * 2 + 1];
                path.push([x, y])
            }
            pathArr.push(path)
        }
        return pathArr;
    }

    // private contoursOutLineToSVG(contours: cv.MatVector, width: number, height: number, dashed: boolean = false, offset?: number): string {
    //     let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`;
    //     const contoursSize = contours.size() as unknown as number;
    //     // Define the stroke-dasharray based on the dashed parameter
    //     const strokeDashArray = dashed ? '4 4' : 'none';

    //     for (let i = 0; i < contoursSize; ++i) {
    //         const contour = contours.get(i);
    //         svgContent += '<path d="';
    //         for (let j = 0; j < contour.rows; ++j) {
    //             const x = contour.data32S[j * 2];
    //             const y = contour.data32S[j * 2 + 1];
    //             if (j === 0) {
    //                 svgContent += `M ${x} ${y}`;
    //             } else {
    //                 svgContent += ` L ${x} ${y}`;
    //             }
    //         }
    //         svgContent += ` Z" fill="none" stroke="blue" stroke-width="2" stroke-dasharray="${strokeDashArray}"/>`;
    //     }
    //     svgContent += '</svg>';
    //     return svgContent;
    // }
    private contoursOutLineToSVG(contours: any, width: number, height: number, dashed: boolean = false, offset?: number): string {
        let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`;
        const contoursSize = contours.size() as unknown as number;
        const strokeDashArray = dashed ? '4 4' : 'none';

        // 计算缩放比例和偏移量
        let transform = '';
        if (offset !== undefined) {
            const { widthMM, heightMM } = StringUtil.pixelsToMM(width, height, 100);
            const scaleX = (widthMM - 2 * offset) / widthMM;
            const scaleY = (heightMM - 2 * offset) / heightMM;
            const offsetPixelsX = (offset / widthMM) * width;
            const offsetPixelsY = (offset / heightMM) * height;
            transform = `translate(${offsetPixelsX}, ${offsetPixelsY}) scale(${scaleX}, ${scaleY})`;
        }

        // 包装 <g> 元素以应用变换
        if (transform) {
            svgContent += `<g transform="${transform}">`;
        }

        for (let i = 0; i < contoursSize; ++i) {
            const contour = contours.get(i);
            svgContent += '<path d="';
            for (let j = 0; j < contour.rows; ++j) {
                const x = contour.data32S[j * 2];
                const y = contour.data32S[j * 2 + 1];
                if (j === 0) {
                    svgContent += `M ${x} ${y}`;
                } else {
                    svgContent += ` L ${x} ${y}`;
                }
            }
            // svgContent += ` Z" fill="none" stroke="#33BF5A" stroke-width="5" stroke-dasharray="${strokeDashArray}"/>`;
            svgContent += ` Z" fill="none" stroke="#33BF5A" stroke-width="20" stroke-dasharray="none"/>`;
        }

        // 关闭 <g> 元素
        if (transform) {
            svgContent += '</g>';
        }

        svgContent += '</svg>';
        return svgContent;
    }

    /**
     * 更新svg的stroke-dasharray属性，实线还是虚线
     * @param svgString 
     * @param dashed 
     * @returns 
     */
    public refreshSvg(svgString: string, dashed: boolean = false): string {
        // Create a DOM parser to parse the SVG string
        const parser = new DOMParser();
        const svgDoc = parser.parseFromString(svgString, 'image/svg+xml');
        const paths = svgDoc.querySelectorAll('path');

        // Define the stroke-dasharray based on the dashed parameter
        const strokeDashArray = dashed ? '4 4' : 'none';

        // Update each path's stroke-dasharray attribute
        paths.forEach(path => {
            path.setAttribute('stroke-dasharray', strokeDashArray);
        });

        // Serialize the updated SVG document back to a string
        const serializer = new XMLSerializer();
        return serializer.serializeToString(svgDoc);
    }

    private downloadSVG(svgContent: string, filename: string): void {
        const blob = new Blob([svgContent], { type: 'image/svg+xml' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }

}

function pixelsToMM(): any {
    throw new Error("Function not implemented.");
}
