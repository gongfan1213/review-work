import { boolean } from "yup";
import { ProjectModel } from "../../SelectDialog/model/ProjectModel";

export type OutLineData = {
    orginX: number;
    orginY: number;
    width: number;
    height: number;
    // 轮廓图string
    outlineSvgStr: string;
    outlinePath: Array<any>;
}

export type SelectImgToPngData = {
    size: { width: number, height: number };
    sizeMM: { width: number, height: number };
    newImgBase64?: string;
    newProjectModel?: ProjectModel;
    newBgImgBase64?: string;
    atOnceSave?: boolean;
}