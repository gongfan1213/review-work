import { useTranslation } from '@volcengine/i18n';
import React, { useEffect } from 'react';
import { LeftTabValue } from '../../cons/2dEditorCons';
import Elements from '../../../../images/2dEditor/side_icon/Elements.png';
import Elements2 from '../../../../images/2dEditor/side_icon/Elements2.png';
import Projects from '../../../../images/2dEditor/side_icon/Projects.png';
import Projects2 from '../../../../images/2dEditor/side_icon/Projects2.png';
import Templates from '../../../../images/2dEditor/side_icon/Templates.png';
import Templates2 from '../../../../images/2dEditor/side_icon/Templates2.png';
import text_icon from '../../../../images/2dEditor/side_icon/text_icon.png';
import text_icon2 from '../../../../images/2dEditor/side_icon/text_icon2.png';
import Upload from '../../../../images/2dEditor/side_icon/Upload.png';
import Upload2 from '../../../../images/2dEditor/side_icon/Upload2.png';
import Default from '../../../../images/2dEditor/side_icon/Default.png';
import Default2 from '../../../../images/2dEditor/side_icon/Default2.png';
import Craft1 from 'src/assets/svg/craft1.svg';
import Craft2 from 'src/assets/svg/craft.svg';
import { useProjectData } from 'src/templates/2dEditor/hooks/context';
import { isPc } from 'src/common/jsbridge';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';

const Menu = (props: any) => {
  //默认显示的模块
  const [active, setActive] = React.useState(LeftTabValue.LeftTabValueModel);
  const [isHideActive, setIsHideActive] = React.useState(false);
  const { t } = useTranslation();
  const { handleShowTab, showLeftTabPanel, fatherActive, craftList } = props;
  const params = new URLSearchParams(window?.location?.search || location?.location?.search);
  const AiTitle = typeof window !== 'undefined' ? window.sessionStorage.getItem('AiTitle') || params.get('AiTitle') ||
    '' : '';
  const useProjectDataInfo: any = useProjectData();
  console.log('---AiTitle', AiTitle);
  useEffect(() => {
    props.onChangeMenu(active);
  }, [active]);

  useEffect(() => {
    // 当是魔术字体模块以及滤镜模块时，取消高亮左侧菜单
    if (fatherActive === 7 || fatherActive === 8) {
      setIsHideActive(true);
      fatherActive === 7 ? setActive(7) : setActive(8);
    } else {
      setIsHideActive(false);
    }
  }, [fatherActive]);

  useEffect(() => {
    // AiTitle存在时，则跳转到Ai模块
    if (AiTitle && craftList.includes(AiTitle)) {
      // 进入2.5d模块
      setActive(1);
    } else if (AiTitle) {
      setActive(0);
    } else {
      setActive(2);
    }
    props.onChangeMenu(active);
  }, []);

  useEffect(() => {
    if (useProjectDataInfo?.isPcAiToolTitleId && isPc()) {
      setActive(0);
    }
  }, [useProjectDataInfo]);

  useEffect(() => {
    if (!showLeftTabPanel) {
      setIsHideActive(true);
    } else {
      setIsHideActive(false);
    }
  }, [showLeftTabPanel]);
  useEffect(() => {
    const handler = (data: any) => {
      setActive(LeftTabValue.LeftCraft);
      handleShowTab('2.5D');
      setTimeout(() => {
        eventBus.emit('triggerNextClick', data);
      }, 1);
    };
    eventBus.on('jumpToCraft', handler);
    return () => {
      eventBus.off('jumpToCraft', handler);
    };
  }, []);
  return (
    <div className="menu-list">
      <div
        className={'menu-item' + (active === LeftTabValue.LeftTabApps && !isHideActive ? ' active' : ' normal')}
        onClick={() => {
          setActive(LeftTabValue.LeftTabApps);
          handleShowTab('aiTools');
        }}
      >
        <img
          src={active === LeftTabValue.LeftTabApps && !isHideActive ? Default2 : Default}
          className="menu-icon"
          alt=""
        />
        <div className="menu-item-text">AI Tools</div>
      </div>
      <div
        className={'menu-item' + (active === LeftTabValue.LeftCraft && !isHideActive ? ' active' : ' normal')}
        onClick={() => {
          setActive(LeftTabValue.LeftCraft);
          handleShowTab('2.5D');
        }}
      >
        <img
          src={active === LeftTabValue.LeftCraft && !isHideActive ? Craft2 : Craft1}
          style={{ width: 17 }}
          className="menu-icon"
          alt=""
        />
        <div className="menu-item-text">2.5D craft</div>
      </div>
      <div className="boundary"></div>
      <div
        className={'menu-item' + (active === LeftTabValue.LeftTabValueModel && !isHideActive ? ' active' : ' normal')}
        onClick={() => {
          //埋点
          StatisticalReportManager.getInstance().addStatisticalEvent(
            CONS_STATISTIC_TYPE.canvas_left_tab_click,
            'templates',
          );
          setActive(LeftTabValue.LeftTabValueModel);
          handleShowTab();
        }}
      >
        <img
          src={active === LeftTabValue.LeftTabValueModel && !isHideActive ? Templates2 : Templates}
          className="menu-icon"
          alt=""
        />
        <div className="menu-item-text">Templates</div>
      </div>
      <div
        className={
          'menu-item' + (active === LeftTabValue.LeftTabValueElements && !isHideActive ? ' active' : ' normal')
        }
        onClick={() => {
          setActive(LeftTabValue.LeftTabValueElements);
          handleShowTab();
        }}
      >
        <img
          src={active === LeftTabValue.LeftTabValueElements && !isHideActive ? Elements2 : Elements}
          className="menu-icon"
          alt=""
        />
        <div className="menu-item-text">Elements</div>
      </div>
      <div
        className={'menu-item' + (active === LeftTabValue.LeftTabValueText && !isHideActive ? ' active' : ' normal')}
        onClick={() => {
          setActive(LeftTabValue.LeftTabValueText);
          handleShowTab();
        }}
      >
        <img
          src={active === LeftTabValue.LeftTabValueText && !isHideActive ? text_icon2 : text_icon}
          className="menu-icon"
          alt=""
        />
        <div className="menu-item-text">Text</div>
      </div>
      <div className="boundary"></div>
      <div
        className={'menu-item' + (active === LeftTabValue.LeftTabProject && !isHideActive ? ' active' : ' normal')}
        onClick={() => {
          setActive(LeftTabValue.LeftTabProject);
          handleShowTab();
        }}
      >
        <img
          src={active === LeftTabValue.LeftTabProject && !isHideActive ? Projects2 : Projects}
          className="menu-icon"
          alt=""
        />
        <div className="menu-item-text">{t('str_common_projects', 'Projects')}</div>
      </div>
      <div
        className={'menu-item' + (active === LeftTabValue.LeftTabUpload && !isHideActive ? ' active' : ' normal')}
        onClick={() => {
          setActive(LeftTabValue.LeftTabUpload);
          handleShowTab();
        }}
      >
        <img
          src={active === LeftTabValue.LeftTabUpload && !isHideActive ? Upload2 : Upload}
          className="menu-icon"
          alt=""
        />
        <div className="menu-item-text">{t('Upload')}</div>
      </div>
    </div>
  );
};

export default Menu;
