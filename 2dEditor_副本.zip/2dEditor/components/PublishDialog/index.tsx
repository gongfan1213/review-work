import React, { useState, useMemo, useEffect, useRef } from 'react'
import { Dialog, IconButton } from '@mui/material'
import * as classes from './index.module.scss'
import { useCanvas, useCanvasEditor, useProjectData, useFabric } from '../../hooks/context'
import CustomForm from './form';
import { upload2dEditFile } from "src/hooks/useUpload";
import { dataURItoFile, compressorImage } from 'src/common/utils';
import { v4 as uuid } from 'uuid';
import { publish } from 'src/templates/2dEditor/service/2dEditService';
import { updateWorks } from 'src/templates/Home/services';
import loading_icon from 'src/assets/svg/loading_white.svg';
import circle_left from 'src/assets/svg/circle_left.svg';
import circle_right from 'src/assets/svg/circle_right.svg';
import { EditorToastType, editorToastShow } from 'src/templates/2dEditor/components/Toast';
import ProjectManager from 'src/templates/2dEditor/utils/ProjectManager';
import { FabricObjectType, WorkspaceID, ACTION_MAGICK, CustomKey } from 'src/templates/2dEditor/cons/2dEditorCons';
import { jsonToZipFile } from "src/common/utils";
//@ts-ignore
import IMagickWorker from 'src/templates/2dEditor/core/worker/imagick.worker';
import { getCanvasThumbnail } from '../../common/cavasUtil';
import { CanvasesResInfo, ProjectModel } from '../SelectDialog/model/ProjectModel';
import { CategoryScenesModel } from '../SelectDialog/model/CategoryModel';
import CloseIcon from 'src/assets/svg/close.svg';
import { updateTopPageTab, getRefreshHome, HomeState, selectHome } from 'src/state/reducers/home';
import { uploadFile } from 'src/hooks/useUpload';
import { GetUpTokenFileTypeEnum } from 'src/services';

import { useDispatch, useSelector } from 'react-redux';
import ConstNode from 'three/examples/jsm/nodes/core/ConstNode';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";
import { openToast } from 'src/state/reducers/toast'
import axios from 'axios';
import { getCraftProjectDetail } from 'src/templates/FridgeMagnet/GenerateAndPrint/services'

export default function PublishDialog(props: any) {
  // console.log('====props===111', props)
  const [fabric, setFabric] = useState<any>();
  useEffect(() => {
    import('fabric').then(res => {
      setFabric(res.fabric);
    })
    return () => {
      setCanvasReviewImages([]);
    }
  }, []);
  // ;
  const {
    isOpen: propsIsOpen,
    publishImgDef: publishImgDef,
    onPropsClose,
    propsProjectData,
    onSuccess,
    originFormData,
    publishStatus = 'add'
  } = props;
  console.log('---propsProjectData', propsProjectData)
  let canvasEditor: any = useRef<any>(useCanvasEditor());
  let projectData = useRef<ProjectModel | null>(useProjectData());
  let canvasJson = useRef<any[]>([]);
  const [isOpen, setIsOpen] = useState(false)
  const [canvasReviewImages, setCanvasReviewImages] = useState<string[]>([]);
  const [imageCurrentIndex, setImageCurrentIndex] = useState<number>(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const sliderRef = useRef(null);
  const dispatch = useDispatch();
  const homeState: HomeState = useSelector(selectHome)
  const { getTranslation } = useCustomTranslation();
  if (propsProjectData) {
    projectData.current = propsProjectData;
  }

  const _projectData = projectData.current?.canvases || [];
  var baseMapBg: string = ''
  if (_projectData[0]) {
    baseMapBg = projectData.current?.canvases[0].base_map || '';
    // var baseMapCavas;
    // if (projectData.current?.canvases[0].print_param) {
    //   baseMapCavas = JSON.parse(projectData.current?.canvases[0].print_param).cavas_map;
    // }
  }


  useEffect(() => {
    console.log('========fabric', fabric, propsProjectData)
    if (propsProjectData) {
      if (propsProjectData?.type === 'my-project-publish-edit') {
        projectData.current = propsProjectData.works_info
        baseMapBg = projectData.current?.works_canvas_infos[0]?.base_map;
        getCanvasImage('my-project-publish-edit');
      } else {
        projectData.current = propsProjectData;
        getCanvasImage();
      }
    } else {
      getCanvasImage();
    }

    setIsOpen(propsIsOpen);
  }, [isOpen, props.isOpen, fabric]);

  // close;
  const onClose = () => {
    setIsOpen(false);
    onPropsClose(false);
    setPublishLoading(false);
  };
  // get current canvas image;
  const getCanvasImage = (type?: string) => {
    if (!projectData.current) return;
    if (type === 'my-project-publish-edit') {
      Promise.all(projectData?.current?.works_canvas_infos?.map((canvasData: any, index: number) => getBase64Image(canvasData.thumb_image, index))).then(canvasBase64s => {
        setCanvasReviewImages(canvasBase64s as string[]);
      })
    } else {
      projectData?.current?.canvases && Promise.all(projectData?.current?.canvases?.map((canvasData: any, index: number) => getBase64Image(canvasData.thumb_file.download_url, index))).then(canvasBase64s => {
        setCanvasReviewImages(canvasBase64s as string[]);
      })
    }
    // #endregion ;
  }
  // #region publish;
  // Publish button click;
  const [isPublish, setIsPublish] = useState<boolean>(false);
  // 表单验证不通过;
  const handleFormUnvali = () => {
    setIsPublish(false);
  }
  const handlePublish = (formData?: any) => {
    setIsPublish(true);
    if (!!formData) doPublish(formData)
  }

  // @ts-ignore;
  const [publishLoading, setPublishLoading] = useState<boolean>(false);
  // @ts-ignore;
  const doPublish = async (formData) => {

    console.log('====formData', formData)
    console.log('=proejct=type', propsProjectData?.project_info?.project_type)

    if (!formData) return;
    if (!projectData.current) return;
    setPublishLoading(true);
    if ([2, 3, 4, 5].includes(propsProjectData?.project_info?.project_type)) { // 灯光画/笔触画/冰箱贴/海报详情修改编辑发布设计
      let params = {
        works_type: 1,
        works_canvas_infos: [{
          canvas_id: '1',
          category: formData.category,
          is_standard_product: 2,
          sub_category: formData.sub_category,
          scenes_images: [],
          project_template_path: '',
          thumb_image: ''
        }],
        // works_canvas_infos: propsProjectData?.project_info?.works_canvas_infos,
        cover_tiny: '',
        project_id: propsProjectData?.project_info.project_id,
        name: formData.project_name,
        category: formData.category,
        sub_category: formData.sub_category,
        theme: formData.theme,
        style_type: formData.style_type,
        allow_remix: 1,
        commercial: 3,
        license: 9,
        description: '',
        tags: formData.tags,
        ai_category: formData.ai_category,
        exclusive: 1,
        category_value: formData.category_value,
        // category_value: `${formData.category},${formData.sub_category},${formData.theme},${formData.style_type}`
      }
      console.log('--propsProjectData', propsProjectData)
      console.log('--111', propsProjectData?.project_info?.thumb_file?.download_url) //先下载再上传


      const project_id = propsProjectData?.project_info.project_id
      const getdeta = await getCraftProjectDetail({ project_id, }) // 从外部传入的数据上传图片会出现跨域 所以这里再次调用一次接口去接口值
      if (getdeta?.code == 0) {
        const imageUrl = [
          getdeta?.data?.project_info?.thumb_file?.download_url,
          getdeta?.data?.project_info?.thumb_file?.download_url,
        ]
        const imageResults = await Promise.all(imageUrl.map((url) => getCoverTiny(url, propsProjectData?.project_info?.thumb_file?.file_name)));
        if (!imageResults) {
          dispatch(openToast({
            message: getTranslation(TranslationsKeys.PUBLISH_FAILED_TIP),
            severity: 'error',
          }));
          setPublishLoading(false);
          return;
        }
        imageResults.forEach((item, index) => {
          if (index === 0) {
            params.cover_tiny = item;
          } else if (index === 1) {
            params.works_canvas_infos[0].thumb_image = item;
          }
        });
      }
      const downloadUrl = propsProjectData?.canvas?.project_file?.download_url;
      const fileName = propsProjectData?.canvas?.project_file?.file_name;
      try {
        const result = await downloadAndUploadFile(downloadUrl, fileName);
        console.log('Process completed:', result);
        if (result) {
          params.works_canvas_infos[0].project_template_path = result;
        }
      } catch (error) {
        console.error('Error processing file:', error);
      }

      updateWorks({ ...params, works_id: originFormData.works_id }).then((publishResponse) => {
        if (publishResponse.code === 0) {
          dispatch(openToast({
            message: getTranslation(TranslationsKeys.PUBLISH_SUCCESS),
            severity: 'success',
          }));

          !!propsProjectData && onSuccess(true);
          onClose();
        } else {
          console.log('报错')
          dispatch(openToast({
            message: getTranslation(TranslationsKeys.PUBLISH_FAILED_TIP),
            severity: 'error',
          }));
          !!propsProjectData && onSuccess(false);
        }
      }).catch(err => {
        console.log(err);
        dispatch(openToast({
          message: getTranslation(TranslationsKeys.PUBLISH_FAILED_TIP),
          severity: 'error',
        }));
        !!propsProjectData && onSuccess(false);
      }).finally(() => {
        setPublishLoading(false);
        // onClose();
      });

    } else {
      //普通项目(2d编辑器项目)发布/修改设计
      let canvasDataArray = projectData.current.canvases
      if (propsProjectData?.type === 'my-project-publish-edit') {
        canvasDataArray = projectData.current?.works_canvas_infos || []
      }

      if (publishStatus == 'edit') {
        const params = {
          works_id: originFormData.works_id,
          project_id: projectData.current?.project_info.project_id,
          works_type: 1,
          category: formData.category,
          style_type: formData.style_type,
          ai_category: formData.ai_category,
          tags: formData.tags,
          name: formData.project_name,
          theme: formData.theme,
          sub_category: formData.sub_category || null,
          exclusive: formData.exclusive,
          category_value: formData.category_value,
          allow_remix: 1,
          commercial: 3,
          license: 9,
        };
        updateWorks(params).then(res => {
          if (res.code == 0) {
            dispatch(openToast({
              message: getTranslation(TranslationsKeys.EDIT_SUCCESS),
              severity: 'success',
            }));
            !!propsProjectData && onSuccess(true);
          } else {
            dispatch(openToast({
              message: getTranslation(TranslationsKeys.EDIT_SUCCESS),
              severity: 'success',
            }));
            !!propsProjectData && onSuccess(false);
          }
        }).finally(() => {
          setPublishLoading(false);
          onClose();
        })
      } else {
        Promise.all(canvasDataArray.map((canvasData, index) => getWorkCanvasInfo(canvasData, index)))
          .then(async (workCanvasInfo: any[]) => {
            fillWorkCanvasInfo(workCanvasInfo).then(workCanvasInfoResult => {
              let project_id = propsProjectData?.type === 'my-project-publish-edit' ? projectData?.current?.project_id : projectData.current?.project_info.project_id
              // let category = propsProjectData?.type === 'my-project-publish-edit' ? projectData?.current?.category : projectData.current?.project_info.category
              // const tempParms = (formData.commercial == 1 && formData.allow_remix == 1) ? { 'license': 1 } : { 'license': 9 };
              const postData = {
                project_id: project_id,
                works_type: 1,
                category: formData.category,
                style_type: formData.style_type,
                ai_category: formData.ai_category,
                tags: formData.tags,
                name: formData.project_name,
                print_images: formData.print_images.map((item: any) => item.key_prefix),
                description: formData.description,
                allow_remix: 1,
                works_canvas_infos: workCanvasInfoResult,
                theme: formData.theme,
                commercial: 3,
                sub_category: formData.sub_category || null,
                license: 9,
                exclusive: formData.exclusive,
                category_value: formData.category_value,
                // category_value: `${formData.category},${formData.sub_category},${formData.theme},${formData.style_type}`
                // ...tempParms
              };
              if (!!formData.print_images && formData.print_images.length > 0) {
                // postData['cover_tiny'] = formData.print_images[0].key_prefix;
                postData['print_image_tiny'] = formData.print_images[0].key_prefix;
              } else {
                // postData['cover_tiny'] = "";
                postData['print_image_tiny'] = "";
              }
              const url = projectData?.current?.canvases?.[0]?.thumb_file?.download_url || '';
              const thumbFileName = projectData?.current?.canvases?.[0]?.thumb_file?.file_name || ''
              console.log('--thumbFileName--普通', thumbFileName)
              getCoverTiny(url, thumbFileName).then(res => {
                const params = { ...postData, cover_tiny: res } as any;
                console.log('--params', params)
                // const submitPromise = publish(params);
                // publish(postData)
                publish(params)
                  .then((publishResponse) => {
                    if (publishResponse.code === 0) {
                      editorToastShow({
                        tips: getTranslation(TranslationsKeys.PUBLISH_SUCCESS),
                        type: EditorToastType.success
                      });

                      // 刷新首页
                      if (homeState.topPageTab == 'Project Detail' && publishStatus == 'add') {
                        dispatch(updateTopPageTab('Explore'))
                      }

                    !!propsProjectData && onSuccess(true);
                  } else {
                    editorToastShow({
                      tips: getTranslation(TranslationsKeys.PUBLISH_FAILED_TIP),
                      type: EditorToastType.error
                    });
                    !!propsProjectData && onSuccess(false);
                  }
                })
                .catch(error => {
                  console.log(error);
                  editorToastShow({
                    tips: getTranslation(TranslationsKeys.PUBLISH_FAILED_TIP),
                    type: EditorToastType.error
                  });
                  !!propsProjectData && onSuccess(false);
                })
                .finally(() => {
                  setPublishLoading(false);
                  onClose();
                });
            });

            });
          })
          .catch(error => {
            console.log(error);
            setPublishLoading(false);
          });
      }
    }
  }


  async function downloadAndUploadFile(downloadUrl: any, fileName: string) {
    console.log('---downloadUrl', downloadUrl)
    console.log('--fileName', fileName)
    try {
      if (!downloadUrl) {
        throw new Error('Download URL not found');
      }

      // 下载文件
      const response = await axios.get(downloadUrl, { responseType: 'blob' });
      const file = new File([response.data], fileName, { type: response.headers['content-type'] });
      console.log('--file', file)
      const uploadResponse = await upload2dEditFile(file, 1020);
      console.log('File uploaded successfully:', uploadResponse);
      return uploadResponse?.key_prefix;

    } catch (error) {
      console.error('Error downloading or uploading file:', error);
      throw error;
    }
  }



  // fill work canvas info;
  const fillWorkCanvasInfo = (workCanvasInfos: any[]) => {
    return new Promise((resolve, reject) => {
      resolve(Promise.all(workCanvasInfos.map((workCanvasInfo, index: number) => {
        var json = canvasJson.current[index]
        const removeKeyprefixJson = removeJsonKeyprefix(json);
        return jsonToZipFile(removeKeyprefixJson, 'project.json', 'project.zip')
          .then((zipFile: File) => {
            // console.log('zipFile;', zipFile);
            // 1020 发布作品;
            return upload2dEditFile(zipFile, 1020).then((uploadResult) => {
              console.log('uploadResult;', uploadResult);
              workCanvasInfo.project_template_path = uploadResult.key_prefix;
              return workCanvasInfo;
            })
          })
      })));
    });
  }
  const removeJsonKeyprefix = (json: string) => {
    const tempJson = JSON.parse(json);
    const deleteKeyprefix = (object: any) => {
      if (object.type === FabricObjectType.Group) {
        object.objects.forEach((item: any) => {
          deleteKeyprefix(item);
        })
      } else {
        if (object.key_prefix) delete object.key_prefix;
      }
    };
    tempJson.objects.forEach((object: any) => {
      deleteKeyprefix(object);
    });
    console.log('tempJson;', tempJson);
    return JSON.stringify(tempJson);
  }

  const getCoverTiny = async (url: string, fileName: string) => {

    try {
      console.log('---url', url, '--fileName', fileName)
      const getFile = await fetch(url);
      console.log('--getFile', getFile)
      const blob = await getFile.blob() as any;
      console.log('--blob', blob)
      const compressedBlob = await compressorImage(blob);
      console.log('--compressedBlob', compressedBlob)
      // const imageType = compressedBlob?.type?.indexOf('/') !== -1 ? compressedBlob?.type?.slice(compressedBlob?.type?.indexOf('/') + 1) : 'webp';
      // console.log('---imageType', imageType)
      let fileToUpload: File;
      if (compressedBlob instanceof Blob) {
        fileToUpload = new File([compressedBlob], (compressedBlob.name || fileName), { type: compressedBlob.type });
      } else {
        fileToUpload = compressedBlob;
      }
      const uploadResult = await upload2dEditFile(fileToUpload, GetUpTokenFileTypeEnum.PublishProject);
      console.log('---uploadResult?.key_prefix', uploadResult)
      return uploadResult?.key_prefix;
    } catch (error) {
      console.error(error);
      return '';
    }
  };

  // get work canvas info;
  // @ts-ignore;
  const getWorkCanvasInfo = (canvasData: CanvasesResInfo, index: number) => {
    return new Promise((resolve, reject) => {
      getMergeImages(canvasData, index)
        .then((data: any) => {
          if (!data) {
            reject();
          };
          return getMergeImagesUploadData(data);
        })
        .then((data: any) => {
          if (!data) {
            reject();
          };
          getCanvasThumbnail(data.tempCanvas).then((dataRet: any) => {
            const imageFile = dataURItoFile(dataRet.dataUrl, uuid());
            return upload2dEditFile(imageFile, 1020)
          })
            .then((thumbUploadImage) => {
              const workCanvasInfo = {
                canvas_id: canvasData.canvas_id,
                category: canvasData.category,
                sub_category: canvasData.sub_category,
                scenes_images: data!.margeImages ? (data!.margeImages as string[]).map((item: any) => item.key_prefix) : [],
                is_standard_product: canvasData.is_standard_product,
                thumb_image: thumbUploadImage.key_prefix,
                // project_template_path,
              };
              resolve(workCanvasInfo);
            });
        })
    })
  }
  // upload merge images and get upload data;
  const getMergeImagesUploadData = (dataRet: any) => {
    var mergeImages: string[] = dataRet.margeImages;
    return new Promise((resolve, reject) => {
      if (!mergeImages || mergeImages.length === 0) {
        resolve(dataRet);
        return;
      }
      const uploadData = mergeImages.map((imageBase64) => {
        const imageFile = dataURItoFile(imageBase64, uuid());
        return upload2dEditFile(imageFile, 1020)
      });
      Promise.all(uploadData).then((uploadResults) => {
        var data = {
          margeImages: uploadResults,
          tempCanvas: dataRet.tempCanvas,
        }
        resolve(data);
      }).catch(error => {
        reject();
      });
    })
  }
  // 获取merge images;
  const getMergeImages = (canvasData: CanvasesResInfo, index: number) => {
    return new Promise((resolve, reject) => {
      // const scenes: any[] = JSON.parse(canvasData?.scenes);
      // console.log('scenes;', scenes);
      const scenes: any[] = [];
      canvasJson.current = [];
      try {
        if (canvasEditor.current && projectData.current?.canvasesIndex == index) {
          const dataJson = JSON.stringify(canvasEditor.current.getJson());
          canvasJson.current.push(dataJson);
          getMergeImagesGenerate(canvasData, scenes, dataJson).then(resolve).catch(reject);
        } else {
          ProjectManager.getInstance().getProjectJson(projectData.current!, index).then((json: any) => {
            if (!json) return;
            canvasJson.current.push(json);
            getMergeImagesGenerate(canvasData, scenes, json).then(resolve).catch(reject);
          });
        }
      } catch (error) {
        console.log('handlePublish mergeImage; ERROR 2:', error);
        reject();
      }
    });
  }

  const getMergeImagesGenerate = (canvasData: CanvasesResInfo, scenes: any[], json: any) => {
    return new Promise((resolve, reject) => {
      if (!json) return;
      const tempCanvas = new fabric.StaticCanvas(null, {
        width: canvasData.base_map_width,
        height: canvasData.base_map_height
      });
      tempCanvas.loadFromJSON(json, () => {
        tempCanvas.renderAll.bind(tempCanvas);
        preview(false, tempCanvas)
          .then((base64: string) => {
            Promise.all(scenes.map((scene: any) => {
              scene['scenesImgSelect'] = 0;
              return mergeSceneImages(
                scene,
                base64
              )
            })).then(margeImages => {
              console.log('margeImages;', margeImages);
              var data = {
                margeImages: margeImages,
                tempCanvas: tempCanvas,
              }
              resolve(data);
            }).catch(error => {
              console.log(error);
              reject();
            });
          })
          .catch(error => {
            console.log(error);
          })
      });
    });
  }


  // 根据http地址download and transform to base64;
  const getBase64Image = (imgUrl: string, index: number) => {
    if (projectData.current.canvasesIndex == index && publishImgDef) {
      return new Promise((resolve, reject) => {
        resolve(publishImgDef);
      });
    } else {
      return new Promise((resolve, reject) => {
        fetch(imgUrl)
          .then(response => response.blob())
          .then(blob => {
            const reader = new FileReader();
            reader.readAsDataURL(blob);
            reader.onloadend = () => {
              resolve(reader.result)
            }
          })
          .catch(error => {
            reject();
          });
      })
    }
  }

  // #endregion ;
  // #region utils;
  const preview = (is3dPre: boolean, canvas: fabric.Canvas) => {
    return new Promise((resolve, reject) => {
      const currentCanvas = canvas;
      console.log('currentCanvas;', currentCanvas);
      const workspace = currentCanvas.getObjects().find((item) => item.id === WorkspaceID.WorkspaceCavas);
      var bgWidth = workspace?.width;
      var bgHeight = workspace?.height;
      const baseLayer = workspace;
      // 检查baseLayer是否为fabric.Image类型
      if (baseLayer) {
        // 获取底图的DataURL
        const baseImageDataUrl = baseLayer.toDataURL({
          format: 'png',
          left: 0,
          top: 0,
          width: bgWidth,
          height: bgHeight
        });

        // 创建一个离屏Canvas
        const offscreenCanvas = document.createElement('canvas');
        offscreenCanvas.width = bgWidth!;
        offscreenCanvas.height = bgHeight!;
        const offscreenCtx = offscreenCanvas.getContext('2d');
        // 确保离屏Canvas的上下文存在
        // 手动绘制除底层以外的图层
        currentCanvas.getObjects().forEach((obj, index) => {
          if (obj.id && !(obj.id as string).includes(WorkspaceID.WorkspaceCavas)) {
            obj.render(offscreenCtx!);
          } else if (!obj.id) {
            obj.render(offscreenCtx!);
          }
        });
        // 导出离屏Canvas的图像数据
        const otherLayersDataUrl = offscreenCanvas.toDataURL('image/png');

        // 创建一个新的canvas元素
        const finalCanvas = document.createElement('canvas');
        finalCanvas.width = bgWidth!;
        finalCanvas.height = bgHeight!;
        const ctx = finalCanvas.getContext('2d');

        if (ctx) {
          // 加载底图
          const baseImage = new Image();
          baseImage.onload = () => {
            // 绘制底图
            ctx.drawImage(baseImage, 0, 0, bgWidth!, bgHeight!);
            // 设置合成模式为source-in
            ctx.globalCompositeOperation = 'source-in';
            // 加载其他图层的图像
            const otherLayersImage = new Image();
            otherLayersImage.onload = () => {
              // 在底图上绘制其他图层的图像
              ctx.drawImage(otherLayersImage, 0, 0, bgWidth!, bgHeight!);

              setTimeout(() => {
                // 导出最终的图片
                var dataURL: unknown;
                if (is3dPre && bgWidth && bgHeight) {
                  const tempCanvas = document.createElement('canvas');
                  tempCanvas.width = bgWidth;
                  tempCanvas.height = bgHeight;
                  const ctx = tempCanvas.getContext('2d');
                  // 设置背景为白色，填充整个 Canvas
                  if (!ctx) return;
                  ctx.fillStyle = 'white';
                  ctx.fillRect(0, 0, bgWidth, bgHeight);
                  // 将原始 Canvas 绘制到临时 Canvas 上
                  ctx.drawImage(finalCanvas, 0, 0, bgWidth, bgHeight);
                  // 导出最终的图片
                  dataURL = tempCanvas.toDataURL('image/jpeg');
                } else {
                  dataURL = finalCanvas.toDataURL();
                }
                // 输出最终的图片
                resolve(dataURL);
              }, 0);
            };
            otherLayersImage.src = otherLayersDataUrl;
          };
          baseImage.src = baseImageDataUrl;
        }
      }
    });
  }
  // @ts-ignore;
  const mergeSceneImages = (scene, dataUrl: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      fabric.Image.fromURL(scene.scenesImg[scene.scenesImgSelect!], (sceneImg) => {
        const canvas = new fabric.StaticCanvas(null, { width: sceneImg.width, height: sceneImg.height });
        // 设置 scenesImg 图片的位置和大小
        sceneImg.scaleToWidth(sceneImg.width!);
        sceneImg.scaleToHeight(sceneImg.height!);
        sceneImg.set({
          left: 0,
          top: 0,
        });
        let skewData;
        if (scene.skewData && scene.skewData.length > 0) {
          skewData = JSON.parse(scene.skewData!)
        }
        if (skewData && skewData.rectPerspective) {
          let worker = new IMagickWorker();
          worker.onmessage = function (e: { data: any; }) {
            // 使用处理后的图像数据
            const base64 = e.data;
            fabric.Image.fromURL(base64, (dataImg) => {
              var left: number = scene.positionX!;
              var top: number = scene.positionY!;
              // 设置 dataUrl 图片的位置和大小
              dataImg.set({
                left: left * 100 / 100,
                top: top * 100 / 100,
                scaleX: scene.width / dataImg.width!,
                scaleY: scene.height / dataImg.height!,
                angle: scene.angle,
              });
              // 先添加 scenesImg，然后添加 dataUrl 图片
              canvas.add(sceneImg);
              canvas.add(dataImg);
              // 导出合成后的图片
              const mergedUrl = canvas.toDataURL();
              resolve(mergedUrl);
              // 清理画布
              canvas.dispose();
            }, {
              crossOrigin: 'anonymous',
              onError: (error) => {
                reject(error);
              }
            });
            worker.terminate();
            worker = null;
          };
          worker.postMessage({
            action: ACTION_MAGICK.ACTION_TYPE_DISTORT,
            data: {
              dataUrl: dataUrl, // 原始图像数据
              params: skewData.rectPerspective // 透视变换参数,
            }
          });
        }
        // ;
        else {
          // @ts-ignore;
          fabric.Image.fromURL(dataUrl, (dataImg) => {
            var left: number = scene.positionX!;
            var top: number = scene.positionY!;
            // 设置 dataUrl 图片的位置和大小
            dataImg.set({
              left: left * 100 / 100,
              top: top * 100 / 100,
              scaleX: scene.width / dataImg.width!,
              scaleY: scene.height / dataImg.height!,
              angle: scene.angle,
            });
            // 先添加 scenesImg，然后添加 dataUrl 图片
            canvas.add(sceneImg);
            canvas.add(dataImg);
            // 导出合成后的图片
            const mergedUrl = canvas.toDataURL();
            resolve(mergedUrl);
            // 清理画布
            canvas.dispose();
          }, {
            crossOrigin: 'anonymous',
            onError: (error) => {
              reject(error);
            }
          });
        }
      }, {
        crossOrigin: 'anonymous',
        onError: (error) => {
          reject(error);
        }
      });
    });
  }
  // #endregion ;

  // ;
  const [dialogClickFlag, setDialogClickFlag] = useState<boolean>(false);
  const handleDialogClick = () => {
    console.log('handleDialogClick');
    setDialogClickFlag(!dialogClickFlag);
  }

  const silderImage = (index: number) => {
    if (index >= canvasReviewImages.length) {
      setImageCurrentIndex(canvasReviewImages.length);
      setIsTransitioning(true);
    } else if (index < 0) {
      setImageCurrentIndex(-1);
      setIsTransitioning(true);
    } else {
      setImageCurrentIndex(index);
      setIsTransitioning(true);
    }
  }

  const prevImage = () => {
    silderImage(imageCurrentIndex - 1);
  }

  const nextImage = () => {
    silderImage(imageCurrentIndex + 1);
  }

  useEffect(() => {
    if (canvasReviewImages.length > 0) {
      const interval = setInterval(() => {
        nextImage();
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [imageCurrentIndex]);

  useEffect(() => {
    if (canvasReviewImages.length < 2) return;
    if (imageCurrentIndex === canvasReviewImages.length) {
      setTimeout(() => {
        setIsTransitioning(false);
        setImageCurrentIndex(0);
      }, 500); // 500ms should match the CSS transition duration
    } else if (imageCurrentIndex === -1) {
      setTimeout(() => {
        setIsTransitioning(false);
        setImageCurrentIndex(canvasReviewImages.length - 1);
      }, 500); // 500ms should match the CSS transition duration
    }
  }, [imageCurrentIndex]);


  return (
    <Dialog
      className={classes.publish_design_dialog}
      open={isOpen || props.isOpen}
      onClose={onClose}
    >
      <div className={classes.contentLayout}>
        <div className={classes.header_div}>
          <h1>{getTranslation(TranslationsKeys.PUBLISH_A_DESIGN)}</h1>
          <img src={CloseIcon} className={classes.close_icon} alt="" onClick={() => onClose()} />
        </div>
        <div className={classes.content_div} onClick={handleDialogClick}>
          <div className={classes.left_content}>

            {/* {propsProjectData?.project_info?.project_type == 1 &&  */}
            <ul
              ref={sliderRef}
              className={classes.imageSilder}
              style={{
                transform: [2, 3, 4, 5].includes(propsProjectData?.project_info?.project_type) ? '0' : `translateX(-${(imageCurrentIndex + 1) * 100}%)`,
                transition: isTransitioning ? 'transform 0.5s ease' : 'none'
              }}
            >
              { // 工艺作品的时候展示这个
                [2, 3, 4, 5].includes(propsProjectData?.project_info?.project_type) && canvasReviewImages.length == 0 && <li className={classes.image_item}>
                  <img src={propsProjectData?.project_info?.thumb_file?.download_url} alt="Image" />
                </li>
              }
              {canvasReviewImages.length > 0 // 普通项目(2d编辑器项目)展示这个
                &&
                <>
                  <li className={classes.image_item}>
                    <img src={canvasReviewImages[canvasReviewImages.length - 1]} alt="Image" />
                  </li>
                  {
                    canvasReviewImages.map((item, index) => (
                      <li key={index} className={classes.image_item}>
                        <img src={item} alt="Image" />
                      </li>
                    ))
                  }
                  <li className={classes.image_item}>
                    <img src={canvasReviewImages[0]} alt="Image" />
                  </li>
                </>
              }
            </ul>
            {/* } */}
            {
              canvasReviewImages.length > 1 && <div className={classes.btn_group}>
                <img src={circle_left} alt="" onClick={prevImage} />
                <img src={circle_right} alt="" onClick={nextImage} />
              </div>
            }
          </div>

          <div className={classes.right_content}>
            {
              !!projectData.current &&
              <CustomForm
                projectData={projectData.current}
                isSubmit={isPublish}
                onSubmit={handlePublish}
                onFormUnVali={handleFormUnvali}
                dialogClickFlag={dialogClickFlag}
                originFormData={originFormData}
                disabeld={publishLoading}
              />
            }
          </div>
        </div>
        <div className={classes.button_group}>
          <button onClick={() => {
            !publishLoading && onClose();
          }}>{getTranslation(TranslationsKeys.BUTTON_CANCEL)}</button>
          <button onClick={() => {
            !publishLoading && handlePublish()
          }}>
            {publishLoading ?
              (
                <img className={classes.loading_img} src={loading_icon} />
              )
              : getTranslation(TranslationsKeys.BUTTON_PUBLISH)}
          </button>
        </div>
      </div>
    </Dialog>
  )
}