import React, { useState, useEffect, useRef } from 'react'
import debounce from 'lodash/fp/debounce'
import { useTranslation } from '@volcengine/i18n'
import * as classes from './form.module.scss'
import { Form } from 'src/components/MakeUI'
import { fetchProjectList, ProjectItem } from 'src/templates/Home/services'
import zoom_in from 'src/assets/svg/zoom_in.svg';
import { upload2dEditFile } from "src/hooks/useUpload";
import { blobToBase64 } from 'src/common/utils';
import close from 'src/assets/svg/close.svg';
import Loading from 'src/components/Loading';
import { get } from 'src/services'
import { Close } from '@mui/icons-material'
import DOMPurify from 'dompurify';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";
// utils
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';
import { getUserInfo } from 'src/common/storage'

interface MixedFormProps {
  projectData: ProjectItem;
  isSubmit: boolean
  onSubmit: (e) => void
  onFormUnVali: () => void
  dialogClickFlag: boolean,
  originFormData: any,
  disabeld: boolean
}

export default function PublishForm(props: MixedFormProps) {
  const userInfo = getUserInfo()
  console.log('--userInfo', userInfo)
  const {
    projectData,
    isSubmit,
    onSubmit,
    onFormUnVali,
    dialogClickFlag,
    originFormData,
    disabeld
  } = props;

  const { getTranslation } = useCustomTranslation();


  useEffect(() => {
    getFetchFilters()
    getAITools();
    getTagsData();

    // 首页发布选择设计项目后默认展示项目名称
    if (projectData?.project_info && !originFormData) {
      const { project_name } = projectData?.project_info;
      setProjectName(project_name);
    }
  }, [projectData]);
  useEffect(() => {
    isSubmit && handleSubmit();
  }, [isSubmit]);
  useEffect(() => {
    handleFromDocClick();
  }, [dialogClickFlag]);

  // 从详情页带过来的数据
  useEffect(() => {
    if (originFormData && Object.keys(originFormData).length > 0) {
      console.log('-1-1-1---1', originFormData)
      const { ai_category, allow_remix, commercial, name, tags, theme, style_type, category, sub_category } = originFormData;
      setProjectName(name)
      setAiToolUsedIds(ai_category)
      // setAllowRemix(allow_remix)
      // 这里是由于后端有个bug 当前端没传值时，后端会默认会有一个空字符，后端暂时没空处理 前端先处理了
      if (tags.length !== 1 || tags[0] !== "") {
        setTags(tags);
      }

      // setCommercial(commercial)
      setThemeNamesIds(theme)
      setStylesIds(style_type)

    }
  }, [originFormData])
  const { t } = useTranslation()
  const [form] = Form.useForm()
  const { getFieldValue, getFieldsValue, submit, resetFields } = form
  const [loading, setLoading] = useState(false);
  const [contentLength, setCL] = useState(0)
  const [tagsLength, setTagsLength] = useState(0)
  const [originUrl, setOriginUrl] = useState<string>()
  const [subCategory, setSubCategory] = useState('');
  const [subCategoryName, setSubCategoryName] = useState('');
  const [exclusive, setExclusive] = useState(1)
  const handleValuesChange = (changed: any, v: any) => {
    // if (changed.tags) {
    //   handleTagChange(changed.tags);
    // }
    setCL(v?.description?.length ?? 0)
    setTagsLength(v?.tags?.length ?? 0)
    if (changed.origin_model_url) {
      getTitle(changed.origin_model_url)
    }
  }

  const [thmems, setThemes] = useState<any[]>([]);
  const [materials, setMaterial] = useState<any[]>([]);

  const getFetchFilters = async () => {
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-home-filters',
      populate: [
        'icon',
        'subTitle.subIcon',
        'subTitle.itemTitle.itemIcon',
        'positions',
      ],
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'], // 按weight降序排列
    });
    const data = json?.data?.data;

    const categorys = data?.filter((item: any) => item.attributes.name === "Categories");
    const tempCategorys = categorys[0]?.attributes.subTitle.map((item: any) => {
      let child = item?.itemTitle?.map((i: any) => {
        return {
          id: i.id,
          label: i.itemName,
        }
      })
      return {
        id: item.id,
        label: item.subName,
        children: child || []
      }
    });
    console.log('====tempCategorys', tempCategorys)
    setCategorys(tempCategorys);

    const styleTypes = data?.filter((item: any) => item.attributes.name === "Styles");
    const tempStyleTypes = styleTypes[0]?.attributes.subTitle.map((item: any) => {
      return {
        id: item.id,
        label: item.subName,
      }
    });
    console.log('tempStyleTypes', tempStyleTypes)
    setStyleTypes(tempStyleTypes);

    const themes = data?.filter((item: any) => item.attributes.name === "Themes");
    const tempThemes = themes[0]?.attributes.subTitle.map((item: any) => {
      let child = item?.itemTitle?.map((i: any) => {
        return {
          id: i.id,
          label: i.itemName,
        }
      })
      return {
        id: item.id,
        label: item.subName,
        children: child || []
      }
    });
    setThemes(tempThemes);

    const material = data?.filter((item: any) => item.attributes.name === "Materials");
    const tempMaterial = material[0]?.attributes.subTitle.map((item: any) => {
      return {
        id: item.id,
        label: item.subName,
      }
    });
    setMaterial(tempMaterial);

    if (originFormData && Object.keys(originFormData).length > 0) {
      const { category, style_type, theme, sub_category } = originFormData;
      console.log('--style_type', style_type)
      if (style_type.length > 0) {
        let tempStyleName: any[] = [];
        style_type.forEach((style: any) => {
          const foundStyle = tempStyleTypes?.find((item: any) => item.id === style);
          if (foundStyle) tempStyleName.push(foundStyle.label);
        });
        console.log('--tempStyleName', tempStyleName)
        setStyleName(tempStyleName);
      } else {
        const styleType = tempStyleTypes?.find((item: any) => item.id === style_type);
        setStyleTypes(styleType);
      }

      const categoryType = tempCategorys?.find((item: any) => item.id === category);
      console.log('categoryType', categoryType, '===sub_category', sub_category)
      // setSubCategoryName
      setCategoryType(categoryType);
      setSubCategory(sub_category);
      const _tempSubCategoryName = categoryType?.children?.find((item: any) => item.id === sub_category);
      console.log('==_tempSubCategoryName', _tempSubCategoryName)
      setSubCategoryName(_tempSubCategoryName?.label || '');

      if (theme.length > 0) {
        let tempThemeName: any[] = [];
        const tempThemes = themes[0]?.attributes?.subTitle || [];
        // 根据theme数组 去遍历查询
        for (let i = 0; i < theme.length; i++) {
          for (let y = 0; y < tempThemes.length; y++) {
            for (let x = 0; x < tempThemes[y]?.itemTitle.length; x++) {
              if (theme[i] == tempThemes[y]?.itemTitle[x]?.id) {
                console.log('======', tempThemes[y]?.itemTitle[x])
                tempThemeName.push(tempThemes[y]?.itemTitle[x]?.itemName);
              }
            }
          }
        }
        setThemeName(tempThemeName);
      }

    }
  }

  const handleFromDocClick = () => {
    if (showAiSelectOptions) {
      setShowAiSelectOptions(false);
    }
    if (showTagsSelectOptions) {
      setShowTagsSelectOptions(false);
    }
    if (showStyleTypeSelectOptions) {
      setShowStyleTypeSelectOptions(false);
    }
    if (showCategorySelectOptions) {
      setShowCategorySelectOptions(false);
    }

    if (showThemesSelectOptions) {
      setShowThemesSelectOptions(false);
    }

    if (showMaterialSelectOptions) {
      setShowMaterialSelectOptions(false);
    }
  }

  // Submit;
  const [doSubmitFlag, setDoSubmitFlag] = useState(false)
  const handleSubmitAll = async (values: any) => {
    setDoSubmitFlag(true);
    const _themeNames = themeNames.join(',');
    const _styleNames = styleName.join(',');

    values['project_name'] = projectName;
    // values['allow_remix'] = allowRemix;
    values['print_images'] = printImages;
    values['ai_category'] = aiToolUsedIds;
    values['description'] = description;
    values['tags'] = tags;
    values['style_type'] = stylesIds;
    values['category'] = !!categoryType ? categoryType?.id : '';
    values['theme'] = themeNamesIds;
    // values['commercial'] = 3;
    values['sub_category'] = subCategory;
    values['exclusive'] = exclusive;
    values['category_value'] = `${categoryType?.label},${subCategoryName},${_themeNames},${_styleNames}`

    console.log('values;===', values);
    if (!values['project_name'] || !values['category'] || !values['style_type'] || !values['theme']) {
      onFormUnVali();
      return
    };
    onSubmit?.(values)
  }

  const handleSubmit = () => {
    submit()
  }

  const getTitle = debounce(500, async (url) => {
    setOriginUrl(url)
  })

  const sanitizeInput = (value: string) => {
    // 允许的字符：字母、数字、空格和中文字符
    const allowedChars = /^[a-zA-Z0-9\s\u4e00-\u9fa5]*$/;
    return value.split('').filter(char => allowedChars.test(char)).join('');
  }

  // #region handle project name;
  const [projectName, setProjectName] = useState<string>('');
  const handleProjectName = (value: string) => {
    // let _value = value.replace(/\s/g, '')
    const sanitizedInput = sanitizeInput(value);
    const tempVlaue = sanitizedInput.slice(0, 50);

    setProjectName(tempVlaue);
  }
  // #endregion ;
  // #region handle description;
  const [description, setDescription] = useState<string>('')
  const handleDescription = (value: string) => {
    setDescription(value);
  }
  // #endregion ;
  // #region get ai used tools data;
  const [aiTools, setAiTools] = useState<any[]>([]);
  const [showAiSelectOptions, setShowAiSelectOptions] = useState<boolean>(false);
  const getAITools = async () => {
    let result = await get<any>('/web/cms-proxy/common/content', {
      // cms接口地址
      content_type: 'make-2d-all-tools',
      populate: ['class'],
      pagination: {
        page: 1,
        pageSize: 9999,
      },
    });
    if (!!result && !!result.data && !!result.data.data) {
      const aiAllTools = result.data.data.map(item => {
        return {
          id: item.id,
          label: item.attributes.title,
        }
      });
      const aiTools = aiAllTools.reduce((acc: any[], current: { id: any }) => {
        if (!acc.find(item => item.id === current.id)) {
          acc.push(current);
        }
        return acc;
      }, []);

      if (originFormData && Object.keys(originFormData).length > 0) {
        const { ai_category } = originFormData;
        let tempAiToolName: any[] = [];
        if (ai_category?.length > 0) {
          ai_category.forEach((category: any) => {
            const foundTool = aiAllTools.find((tool: any) => tool.id === category);
            if (foundTool) tempAiToolName.push(foundTool.label);
          });
        }
        console.log('==tempAiToolName', tempAiToolName)
        setAiToolUsedNames(tempAiToolName);
      }
      setAiTools(aiTools);
    }
  }
  const handleAIToolInputClick = () => {
    setShowAiSelectOptions(!showAiSelectOptions);
    setShowCategorySelectOptions(false);
    setShowStyleTypeSelectOptions(false)
    setShowTagsSelectOptions(false);
  }

  const [styleTypes, setStyleTypes] = useState([]);
  const [showStyleTypeSelectOptions, setShowStyleTypeSelectOptions] = useState<boolean>(false);

  const handleStyleTypeInputClick = () => {
    setShowStyleTypeSelectOptions(!showStyleTypeSelectOptions);
    setShowCategorySelectOptions(false);
    setShowAiSelectOptions(false);
    setShowTagsSelectOptions(false);
  };

  const [stylesIds, setStylesIds] = useState<string[]>([]);
  const [styleName, setStyleName] = useState<string[]>([]);
  const handleStyleTypeSelect = (e: any) => {
    console.log('handleStyleTypeSelect; e', e);

    if (stylesIds.length == 5) return;
    if (stylesIds.includes(e.id)) {
      setStylesIds(stylesIds.filter((i) => i !== e.id));
    } else {
      setStylesIds([...stylesIds, e.id]);
    }

    if (styleName.includes(e.label)) {
      setStyleName(styleName.filter((i) => i !== e.label));
    } else {
      setStyleName([...styleName, e.label]);
    }
  }

  const handleStyleDel = (item: any) => {
    // @ts-ignore
    const id = styleTypes?.find((i) => i.label === item).id;
    setStylesIds(stylesIds.filter((i) => i !== id));
    setStyleName(styleName.filter((i) => i !== item));
  }

  const [category, setCategory] = useState();
  const [categorys, setCategorys] = useState<any>([]);
  const [themeNames, setThemeName] = useState<string[]>([]);
  const [themeNamesIds, setThemeNamesIds] = useState<string[]>([]);
  const [materialNames, setMaterialNames] = useState<string[]>([]);
  const [materialNamesIds, setMaterialNamesIds] = useState<string[]>([]);
  const [showCategorySelectOptions, setShowCategorySelectOptions] = useState<boolean>(false);
  const [showThemesSelectOptions, setShowThemesSelectOptions] = useState<boolean>(false);
  const [showMaterialSelectOptions, setShowMaterialSelectOptions] = useState<boolean>(false);
  const [categoryType, setCategoryType] = useState();

  const handleCategoryInputClick = () => {
    setShowCategorySelectOptions(!showCategorySelectOptions);
    setShowStyleTypeSelectOptions(false);
    setShowAiSelectOptions(false);
    setShowTagsSelectOptions(false);
  };

  const handleThemesInputClick = () => {
    setShowThemesSelectOptions(!showThemesSelectOptions);
    setShowStyleTypeSelectOptions(false);
    setShowAiSelectOptions(false);
    setShowTagsSelectOptions(false);
  }

  const handleThemeSelect = (e: any) => {
    console.log('==handleThemeSelect', e)

    if (themeNamesIds.length == 5) return;
    if (themeNamesIds.includes(e.id)) {
      setThemeNamesIds(themeNamesIds.filter((i) => i !== e.id));
    } else {
      setThemeNamesIds([...themeNamesIds, e.id]);
    }

    if (themeNames.includes(e.label)) {
      setThemeName(themeNames.filter((i) => i !== e.label));
    } else {
      setThemeName([...themeNames, e.label]);
    }
  }

  const handleThemeDel = (e: any) => {
    const themeNameSet = new Set(themeNames);
    const themeNamesIdsSet = new Set(themeNamesIds);
    for (const theme of thmems) {
      if (theme?.children?.length) {
        for (const child of theme.children) {
          if (e === child?.label) {
            themeNameSet.delete(e);
            themeNamesIdsSet.delete(child?.id);
            break;
          }
        }
      }
    }

    setThemeName(Array.from(themeNameSet));
    setThemeNamesIds(Array.from(themeNamesIdsSet));
  }

  const [aiToolUsedIds, setAiToolUsedIds] = useState<string[]>([]);
  const [aiToolUsedNames, setAiToolUsedNames] = useState<string[]>([]);
  const handleAlToolSelect = (e: any) => {
    // ;
    if (aiToolUsedIds.includes(e.id)) {
      setAiToolUsedIds(aiToolUsedIds.filter((i) => i !== e.id));
    } else {
      setAiToolUsedIds([...aiToolUsedIds, e.id]);
    }
    // ;
    if (aiToolUsedNames.includes(e.label)) {
      setAiToolUsedNames(aiToolUsedNames.filter((i) => i !== e.label));
    } else {
      setAiToolUsedNames([...aiToolUsedNames, e.label]);
    }
  }
  const handleAIToolDetele = (e: any) => {
    // ;
    const id = aiTools.find((i) => i.label === e).id;
    setAiToolUsedIds(aiToolUsedIds.filter((i) => i !== id));
    setAiToolUsedNames(aiToolUsedNames.filter((i) => i !== e));
  }
  // #endregion ;
  // #region handle print photo upload;
  const [printImages, setPrintImages] = useState<any[]>([]);
  const handlePrintPhotoUpload = async (files: FileList) => {
    if (printImages.length >= 10) return;
    if (files.length + printImages.length > 10) {
    }
    console.log('files.length;', files.length);
    let i = 0;
    setLoading(true);
    // 多个文件上传;
    for (const file of files) {
      console.log('file;', file);
      ++i;
      if (i + printImages.length > 10) continue;
      if (!file) return;
      const fileSize = file.size / 1024 / 1024;
      const fileType = file.type;
      // svg格式文件限制大小 3M;
      if (!!~fileType.indexOf('svg')) {
        if (fileSize > 3) {
          console.log('.svg image file size is limited to 3M');
          return;
        }
      }
      // 其他格式图片文件限制大小25M;
      else {
        if (fileSize > 25) {
          console.log('other image file size is limited to 3M');
          return;
        }
      };

      await upload2dEditFile(file, 1020, projectData.project_info.project_id).then((res) => {
        blobToBase64(file).then((base64) => {
          res['base64'] = base64;
          // setPrintImages([...printImages, res]);
          setPrintImages((printImages) => {
            return [...printImages, res];
          });
        });
      })
    }
    setLoading(false);
    // 单个文件上传;
    // const file = files[0];
    // if (!file) return;
    // setLoading(true);
    // upload2dEditFile(file, 1020, projectData.project_info.project_id).then((res) => {
    //   blobToBase64(file).then((base64) => {
    //     res['base64'] = base64;
    //     setPrintImages([...printImages, res]);
    //     setLoading(false);
    //   });
    // })
  }
  // #endregion ;
  // #region allow remix;
  enum AllowRemix {
    Yes = 1,
    No = 2,
  }
  enum AllowShare {
    Yes = 1,
    No = 2,
  }
  enum AllowWork {
    Yes = 1,
    No = 2,
  }
  const [allowRemix, setAllowRemix] = useState(AllowRemix.Yes);
  const [allowShare, setAllowShare] = useState(AllowShare.Yes);
  const [commercial, setCommercial] = useState(AllowWork.Yes);
  // #endregion ;
  // #region handle tags;
  const [tagsData, setTagsData] = useState<any[]>([]);
  const [tags, setTags] = useState<string[]>([]);
  const getTagsData = async () => {
    const result = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      {
        // cms接口地址
        content_type: 'make-2d-tag-names',
        populate: ['tag_name'],
      },
    );
    if (!result || !result.data || !result.data.data) return;
    const tempTagsData = result.data.data.map(item => item.attributes.tag_name);
    console.log('tempTagsData;', tempTagsData);
    setTagsData(tempTagsData);
  }
  // ;
  const [showTagsSelectOptions, setShowTagsSelectOptions] = useState<boolean>(false);
  const handleTagsInputClick = () => {
    setShowTagsSelectOptions(!showTagsSelectOptions);
    setShowCategorySelectOptions(false);
    setShowStyleTypeSelectOptions(false);
    setShowAiSelectOptions(false);
  }
  const handleTagSelect = (tag: string) => {
    if (tags.includes(tag)) {
      setTags(tags.filter((i) => i !== tag));
    } else if (tags.length < 10) {
      setTags([...tags, tag]);
    }
  }
  const handleTagDetele = (tag: string) => {
    setTags(tags.filter((i) => i !== tag));
  }
  const handleTagChange = (tags: string[]) => {
    setTags(tags);
  }
  // #endregion ;

  //categories 下拉选项
  const renderOptions = (options: any[], level = 1, parentItem = null) => {
    return options.map((item: any, index) => (
      <React.Fragment key={`${level}-${item.id}`}>
        <li
          className={(subCategory || categoryType?.id) === item.id ? classes.bgc_gray : ''}
          onClick={(e) => {
            e.stopPropagation();
            if (level == 1) {
              // setSubCategory('');
            } else {
              setSubCategoryName(item.label);
              setSubCategory(item?.id);
              parentItem && setCategoryType(parentItem)
              setShowCategorySelectOptions(false);
            }

          }}
          style={{ paddingLeft: `${level * 20}px` }}
        >
          <p>{item.label}</p>
        </li>
        {item.children && renderOptions(item.children, level + 1, level === 1 ? item : parentItem)}
      </React.Fragment>
    ));
  };

  const renderThmemsOptions = (options: any[], level = 1) => {
    return options.map((item: any) => (
      <React.Fragment key={item.id}>
        <li
          className={themeNamesIds.includes(item.id) ? classes.bgc_gray : ''}
          onClick={(e) => {
            e.stopPropagation();
            if (level !== 1) {
              e.stopPropagation();
              console.log('===item', item)
              handleThemeSelect(item);
              // 事件埋点
              StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.design_theme, item.id);
            }
          }}
          style={{ paddingLeft: `${level * 20}px` }}
        >
          <p>{item.label}</p>
        </li>
        {item.children && renderThmemsOptions(item.children, level + 1)}
      </React.Fragment>
    ));
  };


  // console.log('themeNames', themeNames, 'styleName', styleName, '==categoryType', categoryType.label, 'subCategoryName', subCategoryName)

  return (
    <>
      <Form
        className={classes.form}
        form={form}
        onClick={handleFromDocClick}
        onValuesChange={handleValuesChange}
        onFinish={handleSubmitAll}
        layout="vertical"
      >
        <Form.Item
          className={classes.form_item}
          name="project_name"
          label={
            <div className={classes.required}>
              {getTranslation(TranslationsKeys.FORM_DESIGN_NAME)}
            </div>
          }
        >
          <input
            className={classes.project_name_input}
            type="text"
            value={projectName}
            placeholder={getTranslation(TranslationsKeys.DESIGN_NAME_PLACEHOLDER)}
            maxLength={60}
            onChange={(e) => { handleProjectName(DOMPurify.sanitize(e.target.value)) }}
            disabled={disabeld}
          />
          {doSubmitFlag && !projectName && <p className={classes.red_text_p}>{getTranslation(TranslationsKeys.DESIGN_NAME_REQUIRED)}</p>}
        </Form.Item>

        <Form.Item
          className={classes.form_item}
          name="category"
          label={
            <div className={classes.required}>
              {getTranslation(TranslationsKeys.FORM_CATEGORY)}
            </div>
          }
        >
          <div className={classes.ai_tools_select}>
            {
              <>
                <div className={classes.ai_tools_select_inputdiv} onClick={(e) => {
                  e.stopPropagation()
                  !disabeld && handleCategoryInputClick()
                }}>
                  {
                    <p className={(subCategoryName !== '' || !!categoryType) ? classes.category_p : classes.placeholder_p_for_required}>
                      {subCategoryName !== '' ? subCategoryName : !!categoryType ? categoryType.label : getTranslation(TranslationsKeys.SELECT_CATEGORY)}
                    </p>
                  }
                </div>
                {doSubmitFlag && !categoryType && <p className={classes.red_text_p}>{getTranslation(TranslationsKeys.CATEGORY_REQUIRED)}</p>}
              </>
            }
            <ul style={showCategorySelectOptions ?
              {
                maxHeight: '162px',
                zIndex: 2,
                boxShadow: '0 0 10px 0 rgba(0, 0, 0, 0.2)'
              } :
              {
                maxHeight: 0,
                zIndex: 0,
                boxShadow: 'none'
              }
            }>
              {renderOptions(categorys) || []}
            </ul>
          </div>
        </Form.Item>

        <Form.Item
          className={classes.form_item}
          name="Theme"
          label={
            <div className={classes.required}>
              {getTranslation(TranslationsKeys.FORM_THEME)}
            </div>
          }
        >
          <div className={classes.ai_tools_select}>
            {
              <>
                <div className={classes.ai_tools_select_inputdiv} onClick={(e) => {
                  e.stopPropagation()
                  !disabeld && handleThemesInputClick();
                }}>
                  {
                    themeNames.map(item => (
                      <span className={classes.aitool_name_span} key={item}>
                        <p>{item}</p>
                        {/* @ts-ignore */}
                        <Close className={classes.delete_aitool_icon} onClick={(e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          !disabeld && handleThemeDel(item)
                        }} />
                      </span>
                    ))
                  }
                </div>
                {doSubmitFlag && themeNames.length === 0 && <p className={classes.red_text_p}>{getTranslation(TranslationsKeys.THEME_REQUIRED)}</p>}
              </>
            }
            <ul style={showThemesSelectOptions ?
              {
                maxHeight: '162px',
                zIndex: 2,
                boxShadow: '0 0 10px 0 rgba(0, 0, 0, 0.2)'
              } :
              {
                maxHeight: 0,
                zIndex: 0,
                boxShadow: 'none'
              }
            }>
              {renderThmemsOptions(thmems || [])}
            </ul>
          </div>
        </Form.Item>

        <Form.Item
          className={classes.form_item}
          name="style_type"
          label={
            <div className={classes.required}>
              {getTranslation(TranslationsKeys.FORM_STYLE)}
            </div>
          }
        >
          <div className={classes.ai_tools_select}>
            {
              <>
                <div className={classes.ai_tools_select_inputdiv} onClick={(e) => {
                  e.stopPropagation()
                  !disabeld && handleStyleTypeInputClick();
                }}>
                  {
                    styleName.map(item => (
                      <span className={classes.aitool_name_span} key={item}>
                        <p>{item}</p>
                        <Close className={classes.delete_aitool_icon} onClick={(e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          !disabeld && handleStyleDel(item)
                        }} />
                      </span>
                    ))
                  }
                </div>
                {doSubmitFlag && styleName.length === 0 && <p className={classes.red_text_p}>{getTranslation(TranslationsKeys.STYLE_REQUIRED)}</p>}
              </>
            }
            <ul style={showStyleTypeSelectOptions ?
              {
                maxHeight: '162px',
                zIndex: 2,
                boxShadow: '0 0 10px 0 rgba(0, 0, 0, 0.2)'
              } :
              {
                maxHeight: 0,
                zIndex: 0,
                boxShadow: 'none'
              }
            }>
              {
                (styleTypes || []).map(item => (
                  <li
                    className={stylesIds.includes(item.id) ? classes.bgc_gray : ''}
                    key={item.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleStyleTypeSelect(item);
                      // 事件埋点
                      StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.design_style, item.id);
                    }}
                  >
                    <div>
                      <span></span>
                    </div>
                    <p>{item.label}</p>
                  </li>

                ))
              }
            </ul>
          </div>
        </Form.Item>

        <Form.Item
          className={classes.form_item}
          name="ai_category"
          label={
            <div>
              {getTranslation(TranslationsKeys.FORM_AI_TOOL_USED)}
            </div>
          }
        >
          <div className={classes.ai_tools_select}>
            {!aiToolUsedNames || aiToolUsedNames.length === 0 &&
              <p
                className={classes.placeholder_p}
                onClick={(e) => {
                  e.stopPropagation()
                  !disabeld && handleAIToolInputClick()
                }}
              >
                {getTranslation(TranslationsKeys.SELECT_AI_TOOL_USED)}
              </p>}
            <div className={classes.ai_tools_select_inputdiv} onClick={(e) => {
              e.stopPropagation()
              !disabeld && handleAIToolInputClick()
            }}>
              {
                aiToolUsedNames.map(item => (
                  <span className={classes.aitool_name_span} key={item}>
                    <p>{item}</p>
                    {/* @ts-ignore */}
                    <Close className={classes.delete_aitool_icon} onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      !disabeld && handleAIToolDetele(item)
                    }} />
                  </span>
                ))
              }

            </div>
            <ul style={showAiSelectOptions ?
              {
                maxHeight: '162px',
                zIndex: 2,
                boxShadow: '0 0 10px 0 rgba(0, 0, 0, 0.2)'
              } :
              {
                maxHeight: 0,
                zIndex: 0,
                boxShadow: 'none'
              }
            }>
              {
                aiTools.map(item => (
                  <li
                    className={aiToolUsedIds && aiToolUsedIds.includes(item.id) ? classes.bgc_gray : ''}
                    key={item.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAlToolSelect(item);
                    }}
                  >
                    <div>
                      <span></span>
                    </div>
                    <p>{item.label}</p>
                  </li>

                ))
              }
            </ul>
          </div>
        </Form.Item>

        {/* Tags; */}
        <Form.Item
          className={classes.form_item}
          name="tags"
          label={
            <div style={{ display: 'flex' }}>
              <div> {getTranslation(TranslationsKeys.FORM_TAGS)}</div>
            </div>
          }
        >
          <div className={classes.ai_tools_select}>
            {
              !tags || tags.length === 0 &&
              <p
                className={classes.placeholder_p}
                onClick={(e) => {
                  e.stopPropagation()
                  !disabeld && handleTagsInputClick()
                }}
              >
                {getTranslation(TranslationsKeys.SELECT_TAGS)}
              </p>
            }
            <div
              className={classes.ai_tools_select_inputdiv}
              onClick={(e) => {
                e.stopPropagation()
                !disabeld && handleTagsInputClick()
              }}>
              {
                tags && tags.map(item => (
                  <span className={classes.aitool_name_span} key={item}>
                    <p>{item}</p>
                    {/* @ts-ignore */}
                    <Close className={classes.delete_aitool_icon} onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      !disabeld && handleTagDetele(item)
                    }} />
                  </span>
                ))
              }

            </div>
            <ul style={showTagsSelectOptions ?
              {
                maxHeight: '162px',
                zIndex: 2,
                boxShadow: '0 0 10px 0 rgba(0, 0, 0, 0.2)'
              } :
              {
                maxHeight: 0,
                zIndex: 0,
                boxShadow: 'none'
              }
            }>
              {
                tagsData && tagsData.map(item => (
                  <li
                    className={tags && tags.includes(item) ? classes.bgc_gray : ''}
                    key={item.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleTagSelect(item);
                    }}
                  >
                    <div>
                      <span></span>
                    </div>
                    <p>{item}</p>
                  </li>

                ))
              }
            </ul>
          </div>
        </Form.Item>
        <Form.Item
          className={classes.form_item}
          name='exclusive'
          label={getTranslation(TranslationsKeys.FORM_SETAS_EXCLUSIVE)}
        >
          <div className={classes.checkbox_container}>
            <ul>
              <li onClick={() => { !disabeld && setExclusive(1) }}>
                <div className={exclusive == 1 ? classes.active_checkbox_div : ''}>
                  <span></span>
                </div>
                <p>{getTranslation(TranslationsKeys.YES)}</p>
              </li>
              <li onClick={() => { !disabeld && setExclusive(2) }}>
                <div className={exclusive == 2 ? classes.active_checkbox_div : ''}>
                  <span></span>
                </div>
                <p>{getTranslation(TranslationsKeys.NO)}</p>
              </li>
            </ul>
          </div>
        </Form.Item>

        {/* Print photo; */}
        {/* <Form.Item
          className={classes.form_item}
          name="print_images"
          label={
            <div>
              <div style={{ display: 'block' }} >
                {t('string_upload_title', 'Add Print Photos (Up To 10)')}
              </div>
            </div>
          }
        >
          <div className={classes.add_file_container}>
            {
              (!!printImages && printImages.length > 0) &&
              printImages.map((item) => (
                <div className={classes.add_file_div} key={item.key_prefix}>
                  <span>
                    <img className={classes.add_file_base64} src={item.base64} />
                  </span>

                  <img className={classes.add_file_close_icon} src={close} onClick={() => {
                    setPrintImages(printImages.filter((i) => i.key_prefix !== item.key_prefix));
                  }} />
                </div>
              ))
            }
            <div
              className={classes.add_file_div}
              style={printImages.length >= 10 ? {
                opacity: 0.6,
                cursor: 'not-allowed',
              } : {
                opacity: 1,
                cursor: 'pointer',
              }}
            >
              <Loading className={classes.loading} loading={loading} isAbsolute />
              <span>
                <img className={classes.add_file_plu_icon} src={zoom_in} />
              </span>
              <input
                type="file"
                multiple
                accept=".jpg,.jpeg,.png,.webp,.svg"
                disabled={printImages.length == 10}
                style={{ cursor: printImages.length == 10 ? 'not-allowed' : 'pointer' }}
                onChange={(e) => {
                  handlePrintPhotoUpload(e.target.files);
                }}
              />
            </div>
          </div>
        </Form.Item > */}

        {/* Allow Remix; */}
        {/* < Form.Item
          className={classes.form_item}
          name="allow_remix"
          label={
            <div className={classes.required}>
              {getTranslation(TranslationsKeys.FORM_LICENSE)}
            </div>
          }
        >
          <div className={classes.checkbox_container} style={{ marginTop: 10 }}>
            <p>{getTranslation(TranslationsKeys.ALLOW_REMIX)}</p>
            <ul>
              <li onClick={() => { !disabeld && setAllowRemix(AllowRemix.Yes) }}>
                <div className={allowRemix === AllowRemix.Yes ? classes.active_checkbox_div : ''}>
                  <span></span>
                </div>
                <p>{getTranslation(TranslationsKeys.YES)}</p>
              </li>
              <li onClick={() => { !disabeld && setAllowRemix(AllowRemix.No) }}>
                <div className={allowRemix === AllowRemix.No ? classes.active_checkbox_div : ''}>
                  <span></span>
                </div>
                <p>{getTranslation(TranslationsKeys.NO)}</p>
              </li>
            </ul>
            <p>{allowRemix == AllowRemix.Yes ? <p>License: Creative Commons BY 4.0 <a href=''>View license</a></p> : 'Derivatives of this design are not allowed to be shared'}</p>
          </div>
        </Form.Item > */}
      </Form >
    </>
  )
}

