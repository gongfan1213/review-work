import React, { useState, forwardRef, useImperativeHandle, useCallback } from "react";
import {
  Snackbar as MaterialSnackbar
} from "@material-ui/core";
import good from 'src/assets/svg/good.svg';
import bad from 'src/assets/svg/bad.svg';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import * as classes from "./index.module.scss";

const toast: React.RefObject<{
  show: () => void;
  hidden: () => void;
}> = React.createRef();

export const editorAIFeedbackShow = () => {
  toast.current?.show();
};

export const editorAIFeedbackHidden = () => {
  toast.current?.hidden();
};

// Toast;
const ToastSnackbar = forwardRef((_: any, ref: any) => {
  const [open, setOpen] = React.useState(false);

  const show = useCallback(() => {
    setOpen(true);
  }, []);

  const hidden = useCallback(() => {
    setOpen(false);
  }, []);

  useImperativeHandle(
    ref,
    () => ({
      show,
      hidden,
    }),
    [hidden, show]
  );

  // close;
  const handleClose = (
    event: React.SyntheticEvent | React.MouseEvent,
    reason?: string
  ) => {
    // 点击了其他地方
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };

  // handle feedback click;
  enum FeedbackFlag {
    NoChose,
    Good,
    Bad
  }
  const [feedbackFlag, setFeedbackFlag] = useState<FeedbackFlag>(FeedbackFlag.NoChose);
  const handleFeedbackClick = (type: FeedbackFlag) => {
    console.log('handleFeedbackClick; type', type);
    setFeedbackFlag(type);
  }
  // #region GOOD feedback;
  const [goodCheckLabels, setGoodCheckLabels] = useState([
    {
      id: 1,
      label: "Faithful To The Original Photo",
      checked: false,
    },
    {
      id: 2,
      label: "Good Template",
      checked: false,
    },
    {
      id: 3,
      label: "Looks Very Natural",
      checked: false,
    },
  ]);
  const [goodOtherReasons, setGoodOtherReasons] = useState("");
  // #endregion ;
  // #region BAD feedback;
  const [badCheckLabels, setBadCheckLabels] = useState([
    {
      id: 1,
      label: "Not Like My Photo",
      checked: false,
    },
    {
      id: 2,
      label: "Don't Like The Template",
      checked: false,
    },
    {
      id: 3,
      label: "Looks Very Unnatural",
      checked: false,
    },
  ]);
  const [badOtherReasons, setBadOtherReasons] = useState("");
  // #endregion ;

  // ;
  const init = () => {
    setFeedbackFlag(FeedbackFlag.NoChose);
    setGoodCheckLabels([
      {
        id: 1,
        label: "Faithful To The Original Photo",
        checked: false,
      },
      {
        id: 2,
        label: "Good Template",
        checked: false,
      },
      {
        id: 3,
        label: "Looks Very Natural",
        checked: false,
      },
    ]);
    setGoodOtherReasons("");
    setBadCheckLabels([
      {
        id: 1,
        label: "Not Like My Photo",
        checked: false,
      },
      {
        id: 2,
        label: "Don't Like The Template",
        checked: false,
      },
      {
        id: 3,
        label: "Looks Very Unnatural",
        checked: false,
      },
    ]);
    setBadOtherReasons("");
  }
  // submit;
  const submit = () => {
    hidden();
    setTimeout(() => {
      init();
    }, 200);
  }

  return (
    <MaterialSnackbar
      style={{
        borderRadius: '10px', zIndex: 2
      }}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "right",
      }}
      open={open}
      onClose={handleClose}
    >
      {
        <section>
          {/* GOOD OR BAD! */}
          {
            feedbackFlag === FeedbackFlag.NoChose &&
            <div className={classes.feedback_toast_div}>
              <IconButton
                className={classes.close_btn}
                aria-label="close"
                color="inherit"
                sx={{ p: 0.5 }}
                onClick={handleClose}
              >
                <CloseIcon className={classes.close_icon} />
              </IconButton>
              <p>Did you satisfy with the results?</p>
              <div className={classes.button_div}>
                <button onClick={() => handleFeedbackClick(FeedbackFlag.Good)}>
                  <img src={good} />
                  YES
                </button>
                <button onClick={() => handleFeedbackClick(FeedbackFlag.Bad)}>
                  <img src={bad} />
                  NO
                </button>
              </div>
            </div>
          }
          {/* Detail GOOD OR BAD! */}
          <div
            className={classes.feedback_detail_toast_div}
            style={feedbackFlag === FeedbackFlag.Good || feedbackFlag === FeedbackFlag.Bad ?
              { bottom: '10px' } :
              { bottom: '-9999px', zIndex: -9999 }}
          >
            {
              feedbackFlag === FeedbackFlag.Good &&
              <>
                <h3>Why did you think it's good</h3>
                <ul>
                  {
                    goodCheckLabels.map(item => (
                      <li key={item.id}>
                        <input type="checkbox" checked={item.checked} />
                        <span>{item.label}</span>
                      </li>
                    ))
                  }
                </ul>
                <div>
                  <p>Other Reasons:</p>
                  <textarea
                    value={goodOtherReasons}
                    onChange={(e) => setGoodOtherReasons(e.target.value)}>
                    placeholder="Please enter other reasons"
                  </textarea>
                </div>
              </>
            }
            {
              feedbackFlag === FeedbackFlag.Bad &&
              <>
                <h3>Why did you think it's not good</h3>
                <ul>
                  {
                    badCheckLabels.map(item => (
                      <li key={item.id}>
                        <input type="checkbox" checked={item.checked} />
                        <span>{item.label}</span>
                      </li>
                    ))
                  }
                </ul>
                <div>
                  <p>Other Reasons:</p>
                  <textarea
                    value={goodOtherReasons}
                    onChange={(e) => setBadOtherReasons(e.target.value)}>
                    placeholder="Please enter other reasons"
                  </textarea>
                </div>
              </>
            }
            {/* ; */}
            <button onClick={submit}>Submit</button>
          </div>
        </section>
      }
    </MaterialSnackbar>
  );
});

export const AIFeedback = () => <ToastSnackbar ref={toast} />;


