import React, { useState, useEffect, useCallback, useRef, forwardRef } from 'react';

// comnpnents
import CustomDataList from 'src/components/CustomDataList';
import clsx from 'clsx';
import LottiePlayer from 'react-lottie-player';
import LoadingAnimation from 'src/images/lottie/loading.json';

// utils
import useDataCache from 'src/templates/2dEditor/utils/DataCache';
import { convertToBase64 } from 'src/common/utils';
import { useCanvasEditor, useEvent } from 'src/templates/2dEditor/hooks/context';
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common';
import { CustomKey, TextureType, EventNameCons } from '../../../cons/2dEditorCons';
// import { TextureImage, TextureType } from 'src/templates/2dEditor/core/plugin/ImagePlugin/TextureImage'
import { useTranslation } from '@volcengine/i18n';
import _ from 'lodash';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { ImageStatus } from 'src/templates/2dEditor/core/eventbus/types/image';
import Base64Worker from 'src/templates/2dEditor/core/worker/base64.worker';

// css
import './index.scss';

// services
import { get } from 'src/services';
import { getMyAssetsTextureList, deleteTexture, getReliefMakerList, deletRelief } from '../services/TextureService';

// icon
import returnIcon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png';
import addIcon from 'src/assets/svg/zoom_in.svg';
import { Opacity } from '@material-ui/icons';
import { promises } from 'dns';

import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
//埋点
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';

const TextureTypeMap = {
  '2': TextureType.CMYK,
  '1': TextureType.GLOSS,
  '3': TextureType.RELIEF,
} as any;

// originDataList数据格式：
// {'tabMenu': [{childMenu: '小类的名称'，total:小类数据总数, data:[{img:'这里一定要有img属性，原数据没有的话自己组织一个'}],tab:'tabMenu'}]}

export default function TextureLib(props: any) {
  const { allRight_state, previewClick, nextClick, dimensionTypes, textureStyle } = props;
  const { setCacheItem, getCacheItem } = useDataCache();
  const canvasEditor = useCanvasEditor();
  const [seeAllData, setSeeAllData] = useState<any>([]);
  const [isSeeAll, setIsSeeAll] = useState<boolean>(false);
  const [tabMenu, setTabMenu] = useState<any>([]);
  const [tabKey, setTabKey] = useState<any>([]);
  const [activeKey, setActiveKey] = useState<any>(0);
  const [tabIndexMenu, setIndexTabMenu] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [pageSize] = useState<number>(10);
  const [tabPageInfo, setTabPageInfo] = useState<any>({
    'Color Texture': { hasMore: false, page: 1 },
    'Gloss Texture': { hasMore: false, page: 1 },
  });
  const [originDataList, setOrignDataList] = useState<any>({}); // 原始数据 预防小类比较多的时候 用来切割做分页展示的数据来源
  const [tempDataList, setTempDataList] = useState<any>([]); // 这个是用来展示的数据
  const isMyAssetsSeeAll = useRef(false);
  const { t } = useTranslation();
  const defaultPageSize = 20;
  const myAssets1CurrentPage = useRef(1);
  const myAssets2CurrentPage = useRef(1);
  const myAssets1DataRef = useRef({});
  const myAssets2DataRef = useRef({});
  const [isMoreLoading, setIsMoreLoading] = useState(false);
  const event = useEvent();
  const { getTranslation } = useCustomTranslation();
  console.log(dimensionTypes, 'dimensionTypes');
  const seeAllChildMenu = useRef('');
  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  }, []);

  const seeAllHandle = (tab: string, childMenu: string, isSeeAll: boolean) => {
    console.log('tab', tab, 'childMenu', childMenu, 'isSeeAll', isSeeAll);
    if (childMenu.includes('My')) isMyAssetsSeeAll.current = !isSeeAll;
    seeAllChildMenu.current = childMenu;
    const cacheData = getCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker');

    setCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker', {
      ...cacheData,
      isSeeAll: !isSeeAll,
      tabIndexMenu: tab,
      childMenu: childMenu,
    });
    if (isSeeAll) {
      setIsSeeAll(false);
    } else {
      const tempdata = JSON.parse(JSON.stringify(originDataList));
      const result = tempdata[tab].filter((item: any) => item.childMenu === childMenu);
      if (!result.length) return setIsSeeAll(false);
      setSeeAllData(result);
      setIsSeeAll(true);
    }
  };

  const clickTabMenmu = (index: number) => {
    const title = tabMenu[index];
    setActiveKey(index);
    if (isSeeAll) {
      seeAllHandle(title, seeAllChildMenu.current, !isSeeAll);
    }
    setIndexTabMenu(title);
    const cachedata = getCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker');
    setCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker', {
      ...cachedata,
      tabIndexMenu: title,
    });
  };

  const loadMoreData = () => {
    if (!tabPageInfo?.[tabIndexMenu]?.hasMore) return;
    const currentData = originDataList[tabIndexMenu];
    // @ts-ignore
    const newPage = tabPageInfo?.[tabIndexMenu]?.page + 1;
    const newData = currentData.slice(0, newPage * pageSize);
    tempDataList[tabIndexMenu] = newData;
    setTimeout(() => {
      setTempDataList(tempDataList);
      setTabPageInfo({
        ...tabPageInfo,
        [tabIndexMenu]: {
          hasMore: newData.length < currentData.total,
          page: newPage,
        },
      });
    }, 1000);
  };

  // useEffect(() => {
  //   const container = document.querySelector('.dataListContainer')
  //   container?.scrollTo(0, 0)
  //   if (originDataList?.[tabIndexMenu]?.length > 10) {
  //     const tempData = JSON.parse(JSON.stringify(originDataList))
  //     tempData[tabIndexMenu] = originDataList?.[tabIndexMenu].slice(0, 10)
  //     setTabPageInfo({
  //       ...tabPageInfo,
  //       [tabIndexMenu]: { hasMore: true, page: 1 },
  //     })
  //     setTempDataList(tempData)
  //   }
  // }, [tabIndexMenu])

  useEffect(() => {
    const handleScroll = () => {
      const container = document.querySelector('.dataListContainer');
      if (container) {
        const { scrollTop, scrollHeight, clientHeight } = container;
        if (scrollTop + clientHeight >= scrollHeight - 5) {
          if (isMyAssetsSeeAll.current && !isMoreLoading) {
            getMoreMyAssetsData(tabIndexMenu);
          }
        }
      }
    };
    const container = document.querySelector('.dataListContainer');
    if (container) {
      container.addEventListener('scroll', handleScroll);
    }

    return () => {
      if (container) {
        container.removeEventListener('scroll', handleScroll);
      }
    };
  }, [tabPageInfo?.[tabIndexMenu]?.page, tabPageInfo?.[tabIndexMenu]?.hasMore, isMyAssetsSeeAll.current]);

  useEffect(() => {
    const type = dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker';
    const { pageData, tabMenu, tabKey } = getCacheItem(type) || {};
    if (pageData && Object.keys(pageData).length > 0) {
      setOrignDataList(pageData);
      setTempDataList(pageData);
      tabMenu && setTabMenu(tabMenu);
      console.log(tabMenu, 'tabMenu123');
      setIndexTabMenu(tabMenu[0]);
      setTabKey(tabKey);
      setActiveKey(0);
    } else {
      if (dimensionTypes) {
        getDimensionTypes(dimensionTypes, type);
      }
    }
  }, []);

  useEffect(() => {
    const { isSeeAll, tabIndexMenu, childMenu, pageData } =
      getCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker') || {};
    if (isSeeAll) {
      setIsSeeAll(isSeeAll);
    }

    // if (tabIndexMenu) {
    //   setIndexTabMenu(tabIndexMenu)
    // }
    if (childMenu) {
      const tempdata = JSON.parse(JSON.stringify(pageData));
      const result = tempdata[tabIndexMenu]?.filter((item: any) => item.childMenu === childMenu);
      setSeeAllData(result);
    }
  }, []);

  useEffect(() => {
    const handleTriggerRefresh = async (textureStyle: string, textureTabs: [], refresh: boolean) => {
      await getMyAssetsDataList(textureStyle, textureTabs, refresh);
    };
    eventBus.on('triggerMyAssetsDataRefresh', handleTriggerRefresh);
    return () => {
      eventBus.off('triggerMyAssetsDataRefresh', handleTriggerRefresh);
    };
  }, []);

  const addToCavas = async (data: any, activeObject?: any) => {
    const fileExtension =
      data?.attributes?.texture_img?.data?.attributes?.url?.split('.').pop() ||
      data?.attributes?.org_img.split('?')[0]?.split('.')?.pop();
    const textureType = TextureTypeMap[tabKey[activeKey]] + '' || '1';
    const base64 = await convertToBase64(data?.img);
    canvasEditor?.addTextureImage(
      base64,
      {
        importSource: ImportSource.Cloud,
        fileType: fileExtension,
        textureType,
        isPublish: !!data?.attributes?.publishedAt,
      },
      activeObject,
      async (object: any, g) => {
        if (object) {
          const attributes = data?.attributes;

          const grayUrl = decodeURIComponent(
            attributes.depth_img || attributes.texture_gray_img?.data?.attributes?.url || attributes?.gray_img,
          );

          let textureUrl = decodeURIComponent(attributes?.texture_img?.data?.attributes?.url || attributes?.org_img);

          if (!grayUrl || !textureUrl) {
            return;
          }
          canvasEditor?.addLoadingElement(object);
          Promise.all([convertToBase64(grayUrl), convertToBase64(textureUrl)]).then(async (res) => {
            object.set({
              grayscale: res[0],
            });
            replaceThumbnailWithOriginal(res[1], object);
          });
        }
      },
    );
  };

  const replaceThumbnailWithOriginal = async (base64Original: any, imageElement: any) => {
    if (base64Original) {
      // 获取画布的缩放因子
      const zoom = imageElement.isCanvasTexture ? canvasEditor?.canvas.getZoom() : 1;
      // 考虑缩放因子计算原始尺寸
      const originalWidth = Math.round(imageElement.width! * imageElement.scaleX! * zoom!);
      const originalHeight = Math.round(imageElement.height! * imageElement.scaleY! * zoom!);
      //@ts-ignore
      imageElement.set(CustomKey.key_prefix, '');
      //@ts-ignore
      imageElement.set(CustomKey.skip_upload, false);
      imageElement.setSrc(
        base64Original,
        async () => {
          if (imageElement.group) {
            canvasEditor?.canvas.setActiveObject(imageElement.group);
            canvasEditor?.ungroup(true);
            await imageElement.removeClipPathAndCache();
            imageElement.set({
              scaleX: (originalWidth / imageElement.width).toFixed(3),
              scaleY: (originalHeight / imageElement.height).toFixed(3),
            });
            canvasEditor?.removeLoadingElement(imageElement);
            imageElement.restoreClipPath();

            //原方法是通过setSrc的方式修改src值，但在编组的情况下似乎触发了Fabric的一个未知bug，缩放时候图片会变模糊，临时先采用克隆的方式解决
            // canvasEditor?.stopSaveHistory();
            // const group = await canvasEditor?.cloneTextureGroup(object, base64Original)
            // canvasEditor?.canvas.add(group)
            // canvasEditor?.canvas.remove(object)
          } else {
            imageElement.scaleToWidth(originalWidth);
            imageElement.scaleToHeight(originalHeight);
            canvasEditor?.removeLoadingElement(imageElement);
            eventBus?.emit(ImageStatus.Editing, {
              value: false,
              target: imageElement,
            });
          }
          eventBus.emit(EventNameCons.EventHanlederSliderMax, imageElement);
          canvasEditor?.startSaveHistory(true);
          canvasEditor?.canvas.renderAll();

          console.log(888, imageElement);
        },
        { crossOrigin: 'anonymous' },
      );
    } else {
      eventBus?.emit(ImageStatus.Editing, {
        value: false,
        target: imageElement,
      });
      canvasEditor?.startSaveHistory(true);
    }
  };

  // 大类 -- tabMenu菜单栏
  const getDimensionTypes = async (type: string, cacheType: string) => {
    setLoading(true);
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-ai-fractal-dimension-types',
      filters: { ai_tool: { title: { $eq: type } } },
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'], // 按weight降序排列
    });

    if (json?.data?.data?.length > 0) {
      const tempTab = json.data.data.map((item: any) => item.attributes.type_name);
      const tabKey = json.data.data.map((item: any) => item.attributes.type_key);
      setIndexTabMenu(tempTab[0]);
      getDimensionClasses(tempTab);
      setTabKey(tabKey);
      setActiveKey(0);
      setTabMenu(tempTab);
      const cachedata = getCacheItem(cacheType);
      setCacheItem(cacheType, { ...cachedata, tabMenu: tempTab, tabKey: tabKey });
    } else {
      setLoading(false);
    }
  };

  // 大类下面的小类
  const getDimensionClasses = async (tabMenuData: any) => {
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-ai-fractal-dimension-classes',
      filters: { ai_tool: { title: { $eq: dimensionTypes } } },
      populate: ['fractal_type'],
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'], // 按weight降序排列
    });
    console.log('大类下面的小类', json?.data?.data);
    if (json?.data?.data?.length > 0) {
      const obj: Record<string, any[]> = {};
      console.log('---tabMenuData', tabMenuData);
      tabMenuData.forEach(async (menu: string) => {
        const filteredData = json.data.data
          .filter((item: any) => item?.attributes?.fractal_type?.data?.attributes?.type_name === menu)
          .map((item: any) => ({
            childMenu: item.attributes.class_name,
            total: 0,
            data: [],
            tab: menu,
            hasMore: false,
          }));
        if (filteredData.length > 0) {
          obj[menu] = filteredData;
        }
      });
      console.log('---obj', obj);
      // setTabPageInfo = { ...tabPageInfo, [tabIndexMenu]: { hasMore: true, page: 1 } };
      if (Object.keys(obj).length > 0) {
        await getMyAssetsDataList(tabMenuData[0], tabMenuData);
        await getMyAssetsDataList(tabMenuData[1], tabMenuData);
        // tabMenuData.forEach(async(tabName:string) => {
        //   await getMyAssetsDataList(tabName, tabMenuData);
        // });
        fractalDimensions(obj, tabMenuData);
      }
    } else {
      setLoading(false);
    }
  };

  // 获取小类的数据
  const fractalDimensions = async (dimensionClasses: {}, tabMenuData: []) => {
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-ai-fractal-dimensions',
      filters: { ai_tool: { title: { $eq: dimensionTypes } } },
      populate: [
        'texture_gray_img',
        'texture_img_thumb',
        'fractal_type',
        'fractal_class',
        'ai_tool',
        'texture_thumb',
        'texture_img',
      ],
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'], // 按weight降序排列
    });
    const data = json?.data?.data || [];
    console.log(json, 'hahahha');

    filterFractalClass(dimensionClasses, data, tabMenuData);
    console.log('小类的数据', json, 'tabMenu', tabMenuData);
  };
  //refresh字段是用于添加纹理的时候刷新用的
  const getMyAssetsDataList = async (tabName: string, tabMenuData: any, refresh?: boolean) => {
    if (refresh) {
      tabMenuData.indexOf(tabName) ? (myAssets2CurrentPage.current = 1) : (myAssets1CurrentPage.current = 1);
    }
    try {
      let json: any;
      let newData;
      if (dimensionTypes == 'Texture Lib') {
        json = await getMyAssetsTextureList({
          category: tabMenuData.indexOf(tabName) + 1,
          pagination: {
            page: tabMenuData.indexOf(tabName) ? myAssets2CurrentPage.current : myAssets1CurrentPage.current,
            page_size: defaultPageSize,
          },
        });
        newData = json?.data?.texture_list.map((asset: any) => ({
          img: asset.thumb, // 提供图片 URL
          attributes: { ...asset }, // 其他属性
        }));
      } else {
        json = await getReliefMakerList({
          category: tabMenuData.indexOf(tabName) + 1,
          pagination: {
            page: tabMenuData.indexOf(tabName) ? myAssets2CurrentPage.current : myAssets1CurrentPage.current,
            page_size: defaultPageSize,
          },
        });
        newData = json?.data?.relief_list.map((asset: any) => ({
          img: asset.thumb, // 提供图片 URL
          attributes: { ...asset }, // 其他属性
        }));
      }
      if (json && newData) {
        const myAssetsData: any = {
          childMenu: t('string_texture_myAssets', 'My Assets'),
          total:
            json?.data?.total !== 0
              ? json?.data?.total
              : tabMenuData.indexOf(tabName)
              ? myAssets2DataRef.current.total || 0
              : myAssets1DataRef.current.total || 0,
          data: [],
          tab: tabName,
          hasMore: true,
        };
        if (tabMenuData.indexOf(tabName)) {
          myAssetsData.data = refresh ? newData : [...(myAssets2DataRef.current.data || []), ...newData];
          myAssets2DataRef.current = myAssetsData;
        } else {
          myAssetsData.data = refresh ? newData : [...(myAssets1DataRef.current.data || []), ...newData];
          myAssets1DataRef.current = myAssetsData;
        }
        setSeeAllData((prevState: any) => {
          return prevState.map((item: any) => {
            if (item.childMenu === t('string_texture_myAssets', 'My Assets')) {
              item.data = myAssetsData.data;
              item.total = myAssetsData.total;
            }
            return item;
          });
        });

        setOrignDataList((prevState) => ({
          ...prevState,
          [tabName]: [
            myAssetsData,
            ...(prevState[tabName]?.filter((item: any) => !item.childMenu.includes('My')) || []),
          ],
        }));

        setTempDataList((prevState) => ({
          ...prevState,
          [tabName]: [
            myAssetsData,
            ...(prevState[tabName]?.filter((item: any) => !item.childMenu.includes('My')) || []),
          ],
        }));
        const cachedata = getCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker');
        setCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker', {
          ...cachedata,
          pageData: {
            ...cachedata.pageData,
            [tabName]: [
              myAssetsData,
              ...(cachedata.pageData?.[tabName]?.filter((item: any) => !item.childMenu.includes('My')) || []),
            ],
          },
        });
      }
    } catch (error) {
      console.error('Error loading My Assets:', error);
    }
  };
  const getMoreMyAssetsData = useCallback(
    _.debounce(async (tabName: string, item?: any) => {
      const currentDataLength =
        getCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker').pageData[tabName]?.[0]?.data
          ?.length || 0;
      const totalData = originDataList[tabName]?.[0]?.total || 0;
      if (currentDataLength >= totalData) {
        console.log(`All data loaded for ${tabName}`);
        return;
      }
      if (isMoreLoading) return;
      setIsMoreLoading(true);
      setTabPageInfo({
        ...tabPageInfo,
        [tabIndexMenu]: { hasMore: true },
      });
      tabMenu.indexOf(tabName) ? myAssets2CurrentPage.current++ : myAssets1CurrentPage.current++;
      await getMyAssetsDataList(tabName, tabMenu);
      setIsMoreLoading(false);
      setTabPageInfo({
        ...tabPageInfo,
        [tabIndexMenu]: { hasMore: false },
      });
    }, 500),
    [originDataList, myAssets1CurrentPage, myAssets2CurrentPage, tabMenu, isMoreLoading, tabIndexMenu],
  );
  // 刷选每个小类的数据
  const filterFractalClass = (dataSource: {}, data: any, tabMenu: []) => {
    console.log('----刷选每个小类的数据', dataSource, data, tabMenu);
    if (data.length > 0) {
      const tempDataSource = dataSource || originDataList;
      for (let i = 0; i < tabMenu.length; i++) {
        // @ts-ignore
        const tempClassesData = tempDataSource[tabMenu[i]] || [];
        for (let j = 0; j < tempClassesData.length; j++) {
          const element = tempClassesData[j];
          let tempData = data.filter(
            (item: any) => item?.attributes?.fractal_class?.data?.attributes?.class_name === element.childMenu,
          );
          tempDataSource[tabMenu[i]].map((item: any) => {
            if (item.childMenu === element.childMenu) {
              const tempImgData = tempData;
              tempImgData.map((item: any) => {
                item.img =
                  item?.attributes?.texture_img?.data?.attributes?.formats?.thumbnail?.url ||
                  item?.attributes?.texture_img?.data?.attributes?.url;
              });
              item.data = tempImgData;
              item.total = tempData.length;
            }
          });
        }
        tempDataSource[tabMenu[i]]?.unshift(i ? myAssets2DataRef.current : myAssets1DataRef.current);
      }
      setLoading(false);
      // console.log('-2-tempDataSource', tempDataSource)
      setOrignDataList(tempDataSource);
      setTempDataList(tempDataSource);
      const cacheType = dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker';
      const cachedata = getCacheItem(cacheType);
      setCacheItem(cacheType, { ...cachedata, pageData: tempDataSource });
    }
  };
  const deleteTextureData = async (ids: number[]) => {
    try {
      const tempData = originDataList; // 创建一个新的数组副本
      for (const key in tempData) {
        if (tempData.hasOwnProperty(key)) {
          const element = tempData[key];
          for (let i = 0; i < element.length; i++) {
            const item = element[i];
            if (item.data) {
              ids.forEach((id) => {
                const index = item.data.findIndex((item: any) => item.attributes.id === id);
                if (index !== -1) {
                  item.data.splice(index, 1);
                  item.total = item.total - 1;
                }
              });
            }
          }
        }
      }
      console.log(tempData, 'tempData');

      setOrignDataList(tempData);
      setTempDataList(tempData);
      const cachedata = getCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker');
      setCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker', {
        ...cachedata,
        pageData: tempData,
      });
      if (dimensionTypes == 'Texture Lib') {
        return await deleteTexture(ids);
      } else {
        return await deletRelief(ids);
      }
    } catch (error) {
      console.error('Error deleting texture:', error);
    }
  };
  // const datas = isSeeAll ? seeAllData : (originDataList?.[tabIndexMenu] || []);
  const datas = isSeeAll ? seeAllData : tempDataList?.[tabIndexMenu] || [];
  return (
    <div className="__textureLibPage">
      <div className="pageTop">
        <div className="topLeft">
          <img src={returnIcon} alt="" onClick={previewClick} />
          <p>{dimensionTypes}</p>
        </div>
      </div>
      {loading ? (
        <div className="loadContainer">
          <div className="loadIcon">
            <LottiePlayer loop play className="loadingBox" animationData={LoadingAnimation} />
          </div>
        </div>
      ) : (
        <>
          <div
            className="createBox"
            onClick={() =>
            {
              nextClick({
                pageTag: 'createTextureLib',
                title: dimensionTypes,
                tabMenuData: tabMenu,
                textureStyle: tabIndexMenu,
              });
              console.log('埋点',dimensionTypes==='Texture Lib')
              StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.reliefMaker_textureLib_create_click,dimensionTypes==='Texture Lib'?0:1)
            }
            }
          >
            <img src={addIcon} alt="" />
            <p>{getTranslation(TranslationsKeys.USER_CREATED)}</p>
          </div>
          {
            <div className="dataLayout">
              <div className="dataTab">
                {tabMenu.map((item: any, index: number) => {
                  return (
                    <div
                      className="tabItem"
                      style={{
                        marginRight: index !== tabMenu.length - 1 ? 24 : 0,
                      }}
                      onClick={() => clickTabMenmu(index)}
                    >
                      <p
                        className={clsx({
                          defaultTabMenu: tabIndexMenu !== item,
                          activeTabMenu: tabIndexMenu == item,
                        })}
                      >
                        {item}
                      </p>
                      <p
                        className={clsx({
                          activeTabMenuLine: tabIndexMenu == item,
                        })}
                      ></p>
                    </div>
                  );
                })}
              </div>
              <div className="dataListContainer" onDragOver={handleDragOver}>
                <CustomDataList
                  data={datas}
                  isSeeAll={isSeeAll}
                  seeAllHandle={seeAllHandle}
                  allRightState={allRight_state}
                  tabMenu={tabIndexMenu}
                  tabMenuData={tabMenu}
                  addToCavas={addToCavas}
                  // loadMoreData={loadMoreData}
                  getMoreMyAssetsData={getMoreMyAssetsData}
                  deleteTextureData={deleteTextureData}
                  dimensionTypes={dimensionTypes}
                />
                {tabPageInfo?.[tabIndexMenu]?.hasMore && (
                  <div className="loadContainer" style={{ height: 40, padding: 30 }}>
                    <div className="loadIcon">
                      <LottiePlayer loop play className="loadingBox" animationData={LoadingAnimation} />
                    </div>
                  </div>
                )}
              </div>
            </div>
          }
        </>
      )}
    </div>
  );
}
