export type TextureModel = {
  img: string;
  imgGray: string;
};

export type Texture3dGrayImage = {
  cmykGrayImg: string;
  glossGrayImg: string;
  cmykIsBottom: boolean;
  thickness: number;
};

export type Texture3dGrayImageItem = {
  grayType: string;
  grayImg: string;
  thickness: number;
  id: string;
  grayColorImg?: string;
  contrast?: number;
  invert?: boolean;
  normal?: string;
};

export type Texture3dGrayPrint = {
  mergeGrayImg: string;
  glossGrayImg: string;
  thickness: number;
};
export type CreateTextureReq = {
  name?: string;
  param: string;
  category: number;
  thumb_key: string;
  org_img_key: string;
  gray_img_key?: string;
  depth_img_key?: string;
};
export type UpdateTextureReq = {
  id: number;
  gray_img_key?: any;
  name?: string;
  param?: string;
};
export type GetTextureReq = {
  category?: number;
  pagination: object;
};
