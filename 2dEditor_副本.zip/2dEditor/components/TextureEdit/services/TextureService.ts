
import { post,get } from 'src/services'
import { CreateTextureReq ,UpdateTextureReq, GetTextureReq} from '../model/TextureModel';
//创建纹理
export async function createTexture(data:CreateTextureReq) {
    try {
      const resp = await post('/web/editor/texture/create_texture', data);
      return resp;
    }catch{
      return null
    }
}
//更新纹理
export async function updateTexture(data:UpdateTextureReq) {
    try {
      const resp = await post('/web/editor/texture/update_texture', data);
      return resp;
    }catch{
      return null
    }
}
//删除纹理
export async function deleteTexture(data:any) {
    try {
      const resp = await post('/web/editor/texture/delete_texture', {ids:data});
      return resp;
    }catch{
      return null
    }
}
//获取自定义纹理列表
export async function getMyAssetsTextureList(data:GetTextureReq) {
  try {
    const resp = await post('/web/editor/texture/get_texture_list',data);
    return resp;
  } catch (error) {
    return null
  }
}
//获取浮雕库列表
export async function getReliefMakerList(data:GetTextureReq) {
  try {
    const resp = await post('/web/editor/relief/get_relief_list',data);
    return resp;
  } catch (error) {
    return null
  }
}
//创建浮雕
export async function createRelief(data:CreateTextureReq) {
  try {
    const resp = await post('/web/editor/relief/create_relief', data);
    return resp;
  }catch{
    return null
  }
}
//更新浮雕
export async function updatRelief(data:UpdateTextureReq) {
  try {
    const resp = await post('/web/editor/relief/update_relief', data);
    return resp;
  }catch{
    return null
  }
}
//删除浮雕
export async function deletRelief(data:any) {
  try {
    const resp = await post('/web/editor/relief/delete_relief', {ids:data});
    return resp;
  }catch{
    return null
  }
}

//创建深度图
export async function createTask(data:any) {
  try {
    const resp = await post('/web/aihub/depthmap/create_task', data);
    return resp;
  }catch{
    return null
  }
}
//获取深度图
export async function getTask(data:any) {
  try {
    const resp = await post('/web/aihub/depthmap/get_task_status', data);
    return resp;
  }catch{
    return null
  }
}
// 获取当前漫画风格的Id
export const getComicStyleId = async () => {
  const json: any = await get<{ data: any }>(
    '/web/cms-proxy/common/content',
    {
      // cms接口地址
      content_type: 'make-2d-style-transfer-templates',
      pagination: {
        page: 1,
        pageSize: 20,
      },
      filters: {
        name: {
          $eq: 'relief_default'
        }
      }
    },
  );

  return json?.data?.data[0]?.id;

}
//创建风格图
export async function createStyleTask(data:any) {
  try {
    const resp = await post('/web/aihub/styletransfer/create_task', data);
    return resp;
  }catch{
    return null
  }
}
//获取深度图
export async function getCreateStyleTask(data:any) {
  try {
    const resp = await post('/web/aihub/styletransfer/get_task_status', data);
    return resp;
  }catch{
    return null
  }
}