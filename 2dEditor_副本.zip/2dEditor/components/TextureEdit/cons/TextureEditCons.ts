export enum TextureEditType {
    TEXTURE_TYPE_CMYK = 'cmyk',
    TEXTURE_TYPE_GLOSS = 'gloss',
    TEXTURE_TYPE_RELIEF = 'relief',
}