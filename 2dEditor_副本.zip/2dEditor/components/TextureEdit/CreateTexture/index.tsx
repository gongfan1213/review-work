import React, { useState, useCallback, useRef, useEffect } from 'react';
import './index.scss';
import pic_format from '../../../../../images/2dEditor/Apps_icon/pic_format.svg';
// @ts-ignore
import login_img from '../../../../../images/2dEditor/Apps_icon/login_img.gif';
import clear_icon from 'src/images/2dEditor/clear_icon.png';
import { EditorToastType, editorToastHidden, editorToastShow } from 'src/templates/2dEditor/components/Toast';
import loading_icon from 'src/assets/svg/loading.svg';
import { useTranslation } from '@volcengine/i18n';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import Slider from '@mui/material/Slider';
import Switch from '@mui/material/Switch';
import { LinearProgress } from '@mui/material';
import { TextureEffect2dManager } from '../logic/TextureEffect2dManager';
import { GetUpTokenFileTypeEnum } from 'src/services';
import { getAiCreditConsumeInfo } from 'src/templates/2dEditor/service/2dEditService';
import { dataURItoFile, compressorImage1, convertToBase64 } from 'src/common/utils';
import { upload2dEditFile } from 'src/hooks/useUpload';
import {
  createTexture,
  updateTexture,
  createRelief,
  updatRelief,
  createTask,
  getTask,
  createStyleTask,
  getComicStyleId,
  getCreateStyleTask,
} from '../services/TextureService';
import _ from 'lodash';
import returnIcon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png';
import leftLightIcon from '/src/images/2dEditor/Apps_icon/Expand_left_light.svg';
import TextureScene from '../TexturePreview/textureScene';
import { useCanvasEditor } from 'src/templates/2dEditor/hooks/context';
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common';
import useDataCache from 'src/templates/2dEditor/utils/DataCache';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import Icon_Coins from 'src/images/2dEditor/Apps_icon/Icon_Coins.png';
import { selectHome, HomeState, getUserIntegralData } from 'src/state/reducers/home';
import { useSelector, useDispatch } from 'react-redux';
import { TextureType } from 'src/templates/2dEditor/cons/2dEditorCons';
import { removebgTask, removebgTaskStaus } from 'src/templates/FridgeMagnet/GenerateAndPrint/services';
import { imageUrlToBlob, blobToFile } from 'src/templates/LightPainting/utils';
import Dropdown from 'src/templates/2dEditor/common/widget/Dropdown/Dropdown';
import { TaskType } from 'src/templates/LightPainting/const';
import { clear } from 'console';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import { getModulIntegral } from 'src/state/reducers/home';
//埋点
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';
const TextureTypeMap = {
  'Color Texture': TextureType.CMYK,
  'Gloss Texture': TextureType.GLOSS,
  'Color Relief': TextureType.RELIEF,
} as any;

export default function CreateTexture(props: any) { 
  const {
    textureStyle: sourceTextureStyle,
    textureTabs,
    previewClick,
    nextClick,
    createImgObj,
    dimensionTypes,
  } = props;
  const manager = TextureEffect2dManager.getInstance();
  const canvasEditor = useCanvasEditor();
  const homeState: HomeState = useSelector(selectHome);
  const { t } = useTranslation();
  const { getTranslation } = useCustomTranslation();
  const { setCacheItem, getCacheItem } = useDataCache();
  const dispatch = useDispatch();
  const [downUpload, setDownUpload] = useState<any>({});
  const [orgImgExt, setOrgImgExt] = useState('');
  const grayImgRef = useRef('');
  const textureCanvas = useRef<any>();
  const textureScene = useRef<any>();
  const [isNetLoading, setNetLoading] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const isLoadingState = useRef(false);
  const [textureStyle, setTextureStyle] = useState(sourceTextureStyle);
  const [isCreated, setIsCreated] = useState(false);
  const [isShowText, setIsShowText] = useState(false);
  const [thicknessValue, setThicknessValue] = useState<number>(
    TextureTypeMap[textureStyle] === TextureType.RELIEF ? 5 : 2,
  );
  const [contrastValue, setContrastValue] = useState<number>(1);
  const [isInvert, setIsInvert] = useState<boolean>(false);
  const [progress, setProgress] = useState(0);
  const [removeBg, setRemoveBg] = useState(1);
  const [removeName, setRemoveName] = useState('Yes');
  const [modulIntegral, setmodulIntegral] = useState();
  const textureId = useRef(null);
  const [textureData, setTextureData] = useState<any>({
    grayColorBase64: '',
    grayGlossBase64: '',
    colorBase64: '',
    thickness: 0,
  });
  const [downloadUrl, setDownloadUrl] = useState<any>('');
  const [depthUrl, setDepthUrl] = useState<any>('');
  console.log(dimensionTypes, 'dimensionTypesdimensionTypes');
  const [originUploadFile, setOrignUploadFile] = useState<File>();
  let UserAllIntegral = homeState?.UserIntegral;
  const [NowModulIntegral, setNowModulIntegral] = useState(1); //默认1积分
  //获取积分
  const fetchAiCredit = async () => {
    const data: any = await getAiCreditConsumeInfo();
    if (typeof window !== 'undefined' && data?.data?.consume_info) {
      const dataInfo = data?.data?.consume_info;
      const transformedData =
        (dataInfo &&
          Object.values(dataInfo).reduce((acc: any, item: any) => {
            acc[item.ai_tool_type] = item.cost;
            return acc;
          }, {})) ||
        null;
      dispatch(getModulIntegral(transformedData));
      setmodulIntegral(transformedData);
    }
  };
  //浮雕去背和不去背积分区分
  const fun = (falg: string) => {
    if (dimensionTypes == 'Texture Lib') {
      setNowModulIntegral(modulIntegral?.[TaskType['TASK_TYPE_Web_Texture']] || 1);
    } else {
      if (falg == 'Yes') {
        setNowModulIntegral(
          Number(modulIntegral?.[TaskType['TASK_TYPE_Remove_Background']] || 12) +
            Number(modulIntegral?.[TaskType['TASK_TYPE_Depth_Map_Generation']] || 1) +
            Number(modulIntegral?.[TaskType['TASK_TYPE_Style_Transfer']] || 15),
        );
      } else {
        setNowModulIntegral(
          Number(modulIntegral?.[TaskType['TASK_TYPE_Depth_Map_Generation']] || 1) +
            Number(modulIntegral?.[TaskType['TASK_TYPE_Style_Transfer']] || 15),
        );
      }
    }
  };

  useEffect(() => {
    if (!homeState?.ModulIntegral) {
      fetchAiCredit();
    }
    fun(removeName);
  }, [dimensionTypes]);
  const handleChange = (event: any) => {
    setTextureStyle(event.target.value); // 获取用户选择的值
  };
  const radioStyle = {
    color: '#878787', // 未选中时颜色
    '&.Mui-checked': {
      color: '#33BF5A', // 选中时颜色
    },
  };
  const options = [
    { str: `${getTranslation(TranslationsKeys.YES)}`, value: 1 },
    { str: `${getTranslation(TranslationsKeys.NO)}`, value: 2 },
  ];
  // 打开上传模块
  const uploads_click = (index: number) => {
    if (isLoadingState.current) {
      return;
    }
    try {
      // 创建一个 input 元素用于文件选择
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.jpeg,.jpg,.png,.webp,.svg'; // 限制文件类型
      input.multiple = false; // 只允许选择单张图片
      // 监听文件选择事件
      input.onchange = (event: any) => {
        const file = event.target.files[0];
        console.log(file.name.length, 'namename');
        // if (file) {
        //   const fileName = file.name // 获取文件名
        //   const validFileNamePattern = /^[a-zA-Z0-9_\-\.]+$/ // 定义一个正则表达式，限制文件名只能包含字母、数字、下划线和连字符
        //   console.log(fileName,validFileNamePattern.test(fileName),'fileName')
        //   if (!validFileNamePattern.test(fileName)) {
        //     return editorToastShow({
        //       tips: t(
        //         'string_texture_overSize',
        //         'The file name contains special characters. Please upload a file with a valid name.',
        //       ),
        //       type: EditorToastType.error,
        //     })
        //     input.value = '' // 清空文件选择器
        //   } else {
        //     console.log('文件名有效:', fileName)
        //     // 这里可以继续处理文件，例如上传文件
        //   }
        // }
        const fileExtension = file.name.split('.').pop()?.toLowerCase() ?? '';
        setOrignUploadFile(file);
        setOrgImgExt(fileExtension);
        if (!file) return;
        // 创建 FileReader 对象来读取文件并将其转换为 Base64
        const reader = new FileReader();
        reader.onload = (e: any) => {
          // 当读取完成时，获取 Base64 数据并更新状态
          if (file.size > 50 * 1024 * 1024) {
            return editorToastShow({
              tips: getTranslation(TranslationsKeys.TEXTURE_OVERSIZE),
              type: EditorToastType.error,
            });
          }
          setDownUpload((prevData: any) => ({
            ...prevData,
            [index]: {
              download_url: e.target.result, // 将 Base64 数据存储到 download_url
              file_name: file.name,
            },
          }));
        };
        // 读取图片文件，结果将会是 Base64 格式的 URL
        reader.readAsDataURL(file);
        setIsShowText(true);
      };
      // 模拟点击文件选择框
      input.click();
    } catch (e) {
      isLoadingState.current = false;
      setNetLoading(false);
      editorToastHidden();
    }
  };

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault(); // 阻止默认行为
  }, []);

  // 拖拽时的方法
  const uploadIamge = (action: React.DragEvent<HTMLDivElement>, index: number) => {
    if (isLoadingState.current) {
      return;
    }

    action.stopPropagation(); // 阻止冒泡
    action.preventDefault(); // 阻止默认行为
    const files = action.dataTransfer.files;

    if (files.length > 0) {
      const file = files[0];
      // 当读取完成时，获取 Base64 数据并更新状态
      if (file.size > 50 * 1024 * 1024) {
        return editorToastShow({
          tips: getTranslation(TranslationsKeys.TEXTURE_OVERSIZE),
          type: EditorToastType.error,
        });
      }
      const fileExtension = file.name.split('.').pop()?.toLowerCase() ?? '';
      if (!/(?:jpeg|jpg|png|webp|svg)$/i.test(fileExtension)) {
        editorToastShow({
          tips: getTranslation(TranslationsKeys.UNSUPPORTED_IMAGE_TYPE),
          type: EditorToastType.error,
        });
      } else {
        setNetLoading(true);
        setOrgImgExt(fileExtension);
        setOrignUploadFile(file);
        const reader = new FileReader();
        reader.onload = (e) => {
          setDownUpload((prevData: any) => ({
            ...prevData,
            [index]: {
              download_url: e.target?.result,
              file_name: file.name,
            },
          }));
          setNetLoading(false);
          isLoadingState.current = false;
        };
        reader.readAsDataURL(file);
        const formData = new FormData();
        formData.append('file', file);
      }
    }
  };

  //图片转bese64
  async function imageUrlToBase64(imageUrl: string): Promise<string> {
    const response = await fetch(imageUrl);
    if (!response.ok) {
      throw new Error('Failed to fetch image');
    }
    const blob = await response.blob();
    return fileToBase64(blob);
  }
  function fileToBase64(file: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  }

  const clearDownUpload = () => {
    setDownUpload({});
    setIsCreated(false);
    setIsShowText(false);
    if (textureScene.current) {
      textureScene.current.removeScene();
    }
  };
  const handleThicknessChange = (event: Event, newValue: number | number[]) => {
    // if (isNetLoading) return
    setThicknessValue(newValue as number);
    setCacheItem('thicknessValue', newValue);
    textureData.thickness = newValue;
    textureScene.current.update(textureData);
  };
  const handleContrastChange = async (event: Event, newValue: number) => {
    setContrastValue(newValue as number);
    setCacheItem('contrastValue', newValue);
    await manager.convertToGrayscale(downUpload[0].download_url, isInvert, newValue).then((res) => {
      grayImgRef.current = res.grayscaleImage;
      textureData.grayImg = grayImgRef.current;
      textureScene.current.update(textureData);
    });
    // debouncedContrastChange(newValue, isInvert)
  };
  const handleInvertChange = async (event: any) => {
    setIsInvert(event.target.checked);
    setCacheItem('isInvertValue', event.target.checked);
    // setNetLoading(true)
    try {
      await manager.convertToGrayscale(downUpload[0].download_url, event.target.checked, contrastValue).then((res) => {
        grayImgRef.current = res.grayscaleImage;
        textureData.grayImg = grayImgRef.current;
        textureScene.current.update(textureData);
      });
    } catch (error) {
      throw error;
    }
  };
  const imgHandler = async (thumbnail: string, origin: File, gray: string) => {
    try {
      const beforeCompressThumbnail = dataURItoFile(thumbnail, 'thumbnail');
      const thumbnailFile = await compressorImage1(beforeCompressThumbnail, 0, 0, 1, 200).then((blob) => {
        return new File([blob], 'thumbnail.webp', {
          type: blob.type,
          lastModified: Date.now(),
        });
      });
      // const originFile = dataURItoFile(origin, downUpload[0].file_name)
      const grayFile = dataURItoFile(gray, 'gray');
      const [res1, res2, res3] = await Promise.all([
        upload2dEditFile(thumbnailFile, GetUpTokenFileTypeEnum.Edit2dLocal),
        upload2dEditFile(origin, GetUpTokenFileTypeEnum.Edit2dLocal),
        upload2dEditFile(grayFile, GetUpTokenFileTypeEnum.Edit2dLocal),
      ]);
      return {
        thumb_key: res1?.key_prefix,
        org_img_key: res2?.key_prefix,
        gray_img_key: res3?.key_prefix,
      };
    } catch (error) {}
  };

  const getCompressGrayAndNormal = async (gray: string) => {
    const compressGray = await manager.compressionImage(gray);
    const normal = await manager.grayToNormalMap(compressGray);
    return { compressGray, normal };
  };
  const progressHandler = () => {
    const interval = setInterval(() => {
      setProgress((prevProgress) => {
        if (prevProgress >= 90) {
          clearInterval(interval);
          return prevProgress;
        }
        return Math.min(prevProgress + Math.random() * 2, 90); // 假进度慢慢到达90%
      });
    }, 100);
  };
  const handleCreate = async () => {
    console.log('handleCreate called');
    if (!downUpload[0]?.download_url) return;
    if (!(homeState?.UserIntegral >= NowModulIntegral)) return;
    setIsCreating(true);
    setProgress(0);
    progressHandler();
    console.log(downUpload[0].download_url, 'downUpload[0].download_url');
    const res1 = await manager.convertToGrayscale(downUpload[0].download_url);
    grayImgRef.current = res1.grayscaleImage;
    console.log(downUpload[0].download_url,originUploadFile || dataURItoFile(downUpload[0].download_url, 'origin'),res1.grayscaleImage,'origin111')
    const res2 = await imgHandler(
      downUpload[0].download_url,
      originUploadFile || dataURItoFile(downUpload[0].download_url, 'origin'),
      res1.grayscaleImage,
    );
    if (res2) {
      let res3: any;
      if (dimensionTypes == 'Texture Lib') {
        
        let timeoutDuration = 10000;
        const timeoutPromise = new Promise((resolve, reject) => {
          setTimeout(() => {
            reject(new Error('请求超时'));
          }, timeoutDuration); // 设置超时时间，单位为毫秒
        });
        try {
          StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.textureLib_color_style_select,textureTabs.indexOf(textureStyle) + 1)
          console.log(textureTabs.indexOf(textureStyle) + 1,'textureTabs.indexOf(textureStyle) + 1')
          res3 = await Promise.race([
            createTexture({
              category: textureTabs.indexOf(textureStyle) + 1,
              thumb_key: res2.thumb_key,
              org_img_key: res2.org_img_key,
              gray_img_key: res2.gray_img_key,
              param: `{thickness:${thicknessValue},contrast:${contrastValue},invert:${isInvert}}`,
            }),
            timeoutPromise,
          ]);

          // 处理正常请求结果
          // ...
        } catch (error) {
          // 处理请求超时
          console.log('请求超时:', (error as any).message);
          // 显示请求超时的提示信息
          // ...
        }
        // res3 = await createTexture({
        //   category: textureTabs.indexOf(textureStyle) + 1,
        //   thumb_key: res2.thumb_key,
        //   org_img_key: res2.org_img_key,
        //   gray_img_key: res2.gray_img_key,
        //   param: `{thickness:${thicknessValue},contrast:${contrastValue},invert:${isInvert}}`,
        // })
        if (res3.code === 0) {
          UserAllIntegral = UserAllIntegral - NowModulIntegral;
          dispatch(getUserIntegralData(UserAllIntegral));
          setProgress(100); // 将进度设为100%
          textureId.current = res3?.data?.id;
          const base64Data = await getCompressGrayAndNormal(res1.grayscaleImage);
          handleCacheData(res3?.data);
          const data = {
            grayType: TextureTypeMap[textureStyle],
            grayImg: base64Data.compressGray,
            normal: base64Data.normal,
            thickness: 0.2,
            id: 'texture',
          };

          setTextureData(data);

          setTimeout(() => {
            setIsCreating(false), setIsCreated(true);
            textureScene.current = new TextureScene(textureCanvas.current);
            textureScene.current.init({
              grayData: [data],
              colorBase64: downUpload[0].download_url,
            });
          }, 1000); // 加载完成
        } else {
          console.error('创建失败');
          editorToastShow({
            tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
            type: EditorToastType.error,
          });
          setIsCreating(false);
          setProgress(0);
        }
      } else {
        console.log(removeBg, textureTabs.indexOf(textureStyle) + 1,'removeBg');
        StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.reliefMaker_color_relief_select,1)
        if (removeBg === 1) {
          const removeBgDate = {
            src_image: res2.org_img_key,
          };
          const removeId: any = await removebgTask(removeBgDate);
          if (removeId.code === 0) {
            const pollInterval = 2500; // 轮询间隔时间

            const startPolling = async () => {
              const poll = async () => {
                try {
                  console.log(removeId, 'removeId');
                  const removeData: any = await removebgTaskStaus({
                    task_id: removeId.data.task_id,
                  });

                  if (removeData.data.status === 2) {
                    console.log('深度图', removeData.data.status);
                    // 深度图
                    const test: any = await createTask({
                      src_image: removeData.data.result_list[0].file_name,
                      model_type: 0,
                    });

                    if (test.code === 0) {
                      const pollDepthTask = async () => {
                        try {
                          const test2: any = await getTask({
                            task_id: test?.data.task_id,
                          });

                          if (test2?.data?.status === 2) {
                            const TemplateId = await getComicStyleId();
                            // 风格图
                            const getTaskId: any = await createStyleTask({
                              src_image: test2?.data?.result_list[0]?.file_name,
                              ref_images: [removeData.data.result_list[0].file_name],
                              template_id: TemplateId,
                            });

                            const pollStyleTask = async () => {
                              const endData: any = await getCreateStyleTask({
                                task_id: getTaskId?.data?.task_id,
                              });

                              if (endData?.data?.status === 2) {
                                console.log('风格图', endData?.data?.status);
                                const res3: any = await createRelief({
                                  category: textureTabs.indexOf(textureStyle) + 1,
                                  thumb_key: removeData?.data?.result_list[0]?.file_name,
                                  org_img_key: removeData?.data?.result_list[0]?.file_name,
                                  depth_img_key: endData?.data?.result_list[0]?.file_name,
                                  param: `{thickness:${thicknessValue},contrast:${contrastValue},invert:${isInvert}}`,
                                });
                                // const img=await manager.convertToGrayscale(res3.data.depth_img)
                                // console.log(img,'imgimg')
                                if (res3?.code === 0) {
                                  console.log('UserAllIntegral - NowModulIntegral', UserAllIntegral, NowModulIntegral);
                                  UserAllIntegral = UserAllIntegral - NowModulIntegral;
                                  dispatch(getUserIntegralData(UserAllIntegral));
                                  setProgress(100); // 将进度设为100%
                                  textureId.current = res3?.data?.id;
                                  handleCacheData(res3?.data);
                                  const removeImgBase64 = await Promise.all([
                                    imageUrlToBase64(endData.data.result_list[0].download_url),
                                  ]);

                                  const base64Data = await getCompressGrayAndNormal(removeImgBase64[0]);
                                  const data = {
                                    grayType: TextureTypeMap[textureStyle],
                                    grayImg: base64Data.compressGray,
                                    normal: base64Data.normal,
                                    thickness: 0.2,
                                    id: 'texture',
                                  };

                                  setTextureData(data);
                                  const colorImg = await Promise.all([imageUrlToBase64(res3.data.org_img)]);
                                  const thumbImg = await Promise.all([imageUrlToBase64(res3.data.thumb)]);
                                  const depthImg = await Promise.all([imageUrlToBase64(res3.data.thumb)]);
                                  setDownloadUrl(thumbImg);
                                  setDepthUrl(depthImg);
                                  setTimeout(() => {
                                    setIsCreating(false);
                                    setIsCreated(true);
                                    textureScene.current = new TextureScene(textureCanvas.current);
                                    console.log(data, 'data11');
                                    textureScene.current.init({
                                      grayData: [data],
                                      colorBase64: colorImg[0],
                                    });
                                  }, 1000); // 加载完成
                                } else {
                                  console.error('创建失败');
                                  editorToastShow({
                                    tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
                                    type: EditorToastType.error,
                                  });
                                  setIsCreating(false);
                                  setProgress(0);
                                }
                              } else if (endData?.data?.status === 1 || endData?.data?.status === 0) {
                                setTimeout(pollStyleTask, pollInterval); // 等待两秒后再轮询
                              } else {
                                editorToastShow({
                                  tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
                                  type: EditorToastType.error,
                                });
                                setIsCreating(false);
                                setProgress(0);
                              }
                            };

                            pollStyleTask();
                          } else if (test2?.data?.status === 0 || test2?.data?.status === 1) {
                            setTimeout(pollDepthTask, pollInterval); // 等待两秒后再轮询
                          } else {
                            editorToastShow({
                              tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
                              type: EditorToastType.error,
                            });
                            setIsCreating(false);
                            setProgress(0);
                          }
                        } catch (error) {
                          console.error('轮询请求失败', error);
                          setTimeout(pollDepthTask, pollInterval); // 等待两秒后再轮询
                        }
                      };

                      pollDepthTask();
                    } else {
                      editorToastShow({
                        tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
                        type: EditorToastType.error,
                      });
                      setIsCreating(false);
                      setProgress(0);
                    }
                  } else if (removeData.data.status === 1 || removeData.data.status === 0) {
                    setTimeout(poll, pollInterval); // 等待两秒后再轮询
                  } else {
                    editorToastShow({
                      tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
                      type: EditorToastType.error,
                    });
                    setIsCreating(false);
                    setProgress(0);
                  }
                } catch (error) {
                  console.error('轮询请求失败', error);
                  setTimeout(poll, pollInterval); // 等待两秒后再轮询
                }
              };

              poll();
            };

            // 开始轮询
            startPolling();
          } else {
            editorToastShow({
              tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
              type: EditorToastType.error,
            });
            setIsCreating(false);
            setProgress(0);
          }
        } else {
          //深度图
          const test: any = await createTask({
            src_image: res2.org_img_key,
            model_type: 0,
          });
          if (test.code === 0) {
            const pollInterval = 2500; // 轮询间隔时间
            let pollTimer: any = null;
            let pollTimer2: any = null;
            let isStyleTaskCreated = false; // 标志位，确保 createStyleTask 只被调用一次

            const startPolling = async () => {
              const poll = async () => {
                try {
                  const test2: any = await getTask({
                    task_id: test?.data.task_id,
                  });

                  if (test2?.data?.status === 2) {
                    clearInterval(pollTimer); // 请求成功后取消轮询
                    const TemplateId = await getComicStyleId();

                    if (!isStyleTaskCreated) {
                      isStyleTaskCreated = true; // 设置标志位，确保 createStyleTask 只被调用一次
                      // 风格图
                      const getTaskId: any = await createStyleTask({
                        src_image: test2?.data?.result_list[0]?.file_name,
                        ref_images: [res2.org_img_key],
                        template_id: TemplateId,
                      });

                      const pollStyleTask = async () => {
                        const endData: any = await getCreateStyleTask({
                          task_id: getTaskId?.data?.task_id,
                        });

                        if (endData?.data?.status === 2) {
                          console.log('风格图', endData?.data?.status);
                          clearInterval(pollTimer2); // 请求成功后取消轮询
                          const res3: any = await createRelief({
                            category: textureTabs.indexOf(textureStyle) + 1,
                            thumb_key: res2.thumb_key,
                            org_img_key: res2.org_img_key,
                            depth_img_key: endData?.data?.result_list[0]?.file_name,
                            param: `{thickness:${thicknessValue},contrast:${contrastValue},invert:${isInvert}}`,
                          });
                          const removeImgBase64 = await Promise.all([
                            imageUrlToBase64(endData.data.result_list[0].download_url),
                          ]);
                          if (res3?.code === 0) {
                            const colorImg = await Promise.all([imageUrlToBase64(res3.data.org_img)]);
                            UserAllIntegral = UserAllIntegral - NowModulIntegral;
                            dispatch(getUserIntegralData(UserAllIntegral));
                            setProgress(100); // 将进度设为100%
                            textureId.current = res3?.data?.id;

                            const base64Data = await getCompressGrayAndNormal(removeImgBase64[0]);

                            handleCacheData(res3?.data);
                            const data = {
                              grayType: TextureTypeMap[textureStyle],
                              grayImg: base64Data.compressGray,
                              normal: base64Data.normal,
                              thickness: 0.2,
                              id: 'texture',
                            };

                            setTextureData(data);

                            setTimeout(() => {
                              setIsCreating(false);
                              setIsCreated(true);
                              textureScene.current = new TextureScene(textureCanvas.current);
                              textureScene.current.init({
                                grayData: [data],
                                colorBase64: colorImg[0],
                              });
                            }, 1000); // 加载完成
                          } else {
                            console.error('创建失败');
                            editorToastShow({
                              tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
                              type: EditorToastType.error,
                            });
                            setIsCreating(false);
                            setProgress(0);
                          }
                        } else if (endData?.data?.status === 1 || endData?.data?.status === 0) {
                          setTimeout(pollStyleTask, pollInterval); // 等待两秒后再轮询
                        } else {
                          editorToastShow({
                            tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
                            type: EditorToastType.error,
                          });
                          setIsCreating(false);
                          setProgress(0);
                        }
                      };

                      pollStyleTask();
                    }
                  } else if (test2?.data?.status === 0 || test2?.data?.status === 1) {
                    setTimeout(poll, pollInterval); // 等待两秒后再轮询
                  } else {
                    clearInterval(pollTimer); // 请求失败后取消轮询
                    editorToastShow({
                      tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
                      type: EditorToastType.error,
                    });
                    setIsCreating(false);
                    setProgress(0);
                  }
                } catch (error) {
                  console.error('轮询请求失败', error);
                  editorToastShow({
                    tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
                    type: EditorToastType.error,
                  });
                  setIsCreating(false);
                  setProgress(0);
                }
              };

              poll();
            };

            // 开始轮询
            startPolling();
          } else {
            editorToastShow({
              tips: `${getTranslation(TranslationsKeys.STRING_TEXTURE_CREATEFAILED)}`,
              type: EditorToastType.error,
            });
            setIsCreating(false);
            setProgress(0);
          }
        }
      }
    }
  };
  const updateTextureHandler = async (thicknessValue1?: number, contrastValue1?: number, isInvert1?: boolean) => {
    if (!textureId.current) return;
    const res: any = await upload2dEditFile(
      dataURItoFile(grayImgRef.current, 'gray'),
      GetUpTokenFileTypeEnum.Edit2dLocal,
    );
    const params: any = {
      id: textureId.current,
      param: `{thickness:${thicknessValue1 ? thicknessValue1 : thicknessValue},contrast:${
        contrastValue1 ? contrastValue1 : contrastValue
      },${dimensionTypes == 'Texture Lib' ? 'invert' : isInvert1 ? isInvert1 : isInvert}}`,
      gray_img_key: res.gray_img_key,
    };
    console.log(params, 'params');
    if (dimensionTypes == 'Texture Lib') {
      return await updateTexture(params);
    } else {
      return await updatRelief(params);
    }
    // eventBus.emit('triggerMyAssetsDataRefresh', textureStyle, textureTabs, true)
  };
  const addToCanvasHandler = async () => {
    let textureUrl = dimensionTypes.includes('Texture')
      ? decodeURIComponent(downloadUrl || downUpload[0]?.download_url)
      : depthUrl[0];
    console.log(downUpload[0]?.download_url, downUpload, depthUrl[0], 'downUpload[0]?.download_url');
    // const base64 = await convertToBase64(textureUrl)
    console.log('-base64-', textureUrl);
    canvasEditor?.addTextureImage(
      textureUrl,
      {
        importSource: ImportSource.Cloud,
        fileType: orgImgExt,
        textureType: TextureTypeMap[textureStyle],
        grayscale: grayImgRef.current,
      },
      // null
      // async (imageElement) => {
      //   imageElement.set({
      //     grayscale: grayImgRef.current,
      //   })
      // },
    );
    const nextData = getCacheItem('craft')?.data?.filter((item: any) => item.title === dimensionTypes)[0];
    nextClick(nextData);
    // eventBus.emit('triggerMyAssetsDataRefresh', textureStyle, textureTabs, true)
  };
  const backHandler = () => {
    console.log(dimensionTypes, 'dimensionTypes');

    const type = dimensionTypes.includes('Texture') ? 'TextureLib' : 'ReliefMaker';
    const data = {
      title: dimensionTypes,
      pageTag: type,
      tabMenuData: textureTabs,
      textureStyle: textureStyle,
    };
    nextClick(data);
    // eventBus.emit('triggerMyAssetsDataRefresh', textureStyle, textureTabs, true)
    clearDownUpload();
  };
  const handleCacheData = (data: any) => {
    const cachedata = getCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker');
    if (!cachedata) return;
    setCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker', {
      ...cachedata,
      pageData: {
        ...cachedata.pageData,
        [textureStyle]: [
          {
            ...cachedata.pageData?.[textureStyle]?.filter((item: any) => item.childMenu.includes('My'))[0],
            data: [
              {
                img: data?.thumb,
                attributes: data,
              },
              ...(cachedata.pageData?.[textureStyle]?.filter((item: any) => item.childMenu.includes('My'))[0].data ||
                []),
            ],
            total:
              cachedata.pageData?.[textureStyle]?.filter((item: any) => item.childMenu.includes('My'))[0]?.total + 1,
          },
          ...(cachedata.pageData?.[textureStyle]?.filter((item: any) => !item.childMenu.includes('My')) || []),
        ],
      },
    });
  };
  const handleSelection = (option: any) => {
    setRemoveBg(option.value);
    setRemoveName(option.str);
    fun(option.str);
  };
  useEffect(() => {
    createImgObj
      ? setDownUpload([{ download_url: createImgObj.src, file_name: createImgObj.file_name }])
      : setDownUpload([]);
  }, []);
  useEffect((): any => {
    return async () => {
      const isUpdate =
        getCacheItem('thicknessValue') || getCacheItem('contrastValue') || getCacheItem('isInvertValue') !== undefined;
      if (isCreated) {
        if (isUpdate) {
          const res: any = await updateTextureHandler(
            getCacheItem('thicknessValue'),
            getCacheItem('contrastValue'),
            getCacheItem('isInvertValue'),
          );
          res.code === 0 && handleCacheData(res?.data);
        }
        setTimeout(() => {
          setCacheItem('thicknessValue', undefined),
            setCacheItem('contrastValue', undefined),
            setCacheItem('isInvertValue', undefined);
          const cachedata = getCacheItem(dimensionTypes.includes('Texture') ? 'textureLib' : 'reliefMaker');
          cachedata && eventBus.emit('triggerMyAssetsDataRefresh', textureStyle, textureTabs, true);
        });
      }
    };
  }, [isCreated]);
  useEffect(() => {
    createImgObj && setDownUpload([{ download_url: createImgObj.src, file_name: createImgObj.ext }]);
    setTextureStyle(sourceTextureStyle);
  }, [sourceTextureStyle, createImgObj]);
  return (
    <div className="create_texture_box">
      <div className="pageTop">
        <div className="topLeft">
          <img src={returnIcon} alt="" onClick={backHandler} />
          <p>{dimensionTypes}</p>
        </div>
      </div>
      <div style={{ height: 'calc(100vh - 110px)', overflowY: 'scroll' }}>
        <div className="texture_scroll_box">
          <div className="box_title">{!isCreated ? '' : 'Generate successfully, fine-tune parameters'}</div>
          {!isCreated && (
            <div className="texture_style">
              {!isShowText && (
                <div className="box_title">
                  {dimensionTypes == 'Texture Lib'
                    ? `${getTranslation(TranslationsKeys.TEXTURE_ASSET)}`
                    : `${getTranslation(TranslationsKeys.RELIEF_ASSET)}`}
                </div>
              )}
              {dimensionTypes === 'Relief Maker' ? (
                <div className="style_title">{getTranslation(TranslationsKeys.RELIEF_STYLE)}</div>
              ) : (
                <div className="style_title">{getTranslation(TranslationsKeys.TEXTURE_STYLE)}</div>
              )}
              <div className="texture_radio_group">
                <FormControl>
                  <RadioGroup row value={textureStyle} name="radio-buttons-group" onChange={handleChange}>
                    {textureTabs.map((item: any, index: number) => {
                      return (
                        <FormControlLabel
                          key={index}
                          value={item}
                          control={<Radio sx={radioStyle} disabled={isCreating} />}
                          label={
                            <span
                              style={{
                                fontSize: '14px',
                                color: textureStyle === item ? '#000' : 'rgba(0,0,0,.3)',
                              }}
                            >
                              {item}
                            </span>
                          }
                        />
                      );
                    })}
                  </RadioGroup>
                </FormControl>
              </div>
              {dimensionTypes === 'Relief Maker' && (
                <div className="remove_bg">
                  <div className="select_name">
                    <div>{getTranslation(TranslationsKeys.REMOVE_BACKGROUND)}</div>
                  </div>
                  <div className="select_box">
                    <Dropdown
                      classNames="createRelief"
                      values={options}
                      defaultSelectValue={removeBg}
                      callback={handleSelection}
                    />
                  </div>
                </div>
              )}
            </div>
          )}
          {/* 上传模块 */}
          {Array.from({ length: 1 }).map((_, index) =>
            // @ts-ignore
            downUpload && downUpload[index] && !isCreated ? (
              <div className="relative">
                <div className="upload_img_box">
                  <div className="downUpload_box">
                    <img key={index} src={downUpload && downUpload[index]?.download_url} className="upload_img" />
                    <img src={clear_icon} className="clear_icon" onClick={clearDownUpload} />
                  </div>
                </div>
                {isCreating && (
                  <div className="isCreating_box">
                    <div className="isCreating_text">{getTranslation(TranslationsKeys.GENERATING)}</div>
                    <LinearProgress
                      variant="determinate"
                      value={progress}
                      sx={{
                        width: 294,
                        height: 14,
                        borderRadius: 21,
                        bgcolor: 'rgba(255,255,255,.5)',
                      }}
                    />
                  </div>
                )}
              </div>
            ) : isCreated ? (
              // <div className="isCreated_box">123</div>
              <div className="relative">
                <div className="isCreated_box">
                  {/* <img className="upload_img" src={grayImgRef.current} /> */}
                  <div ref={textureCanvas} className="textureSceneWarp"></div>
                  {/* <TextureScene textureData={textureData}></TextureScene> */}
                </div>
                {isNetLoading && (
                  <div className="isNetLoading_box">
                    <img className="isNetLoading_img" src={loading_icon} />
                    <div className="upload_img_text">{getTranslation(TranslationsKeys.LOADING)}</div>
                  </div>
                )}
              </div>
            ) : isNetLoading ? (
              <div className="isNetLoading_box">
                <img className="isNetLoading_img" src={loading_icon} />
                <div className="upload_img_text">{getTranslation(TranslationsKeys.LOADING)}</div>
              </div>
            ) : (
              <div key={index} className="upload_box" onDragOver={handleDragOver} onDrop={(e) => uploadIamge(e, index)}>
                <div
                  className="upload_box_top"
                  onClick={() => {
                    uploads_click(index);
                  }}
                >
                  <img src={pic_format} className="upload_box_top_pic" />
                  <div className="upload_box_top_title">{getTranslation(TranslationsKeys.UPLOAD_PHOTO_HERE)}</div>
                  <div className="upload_box_top_tip">{'Image Size<=50m'}</div>
                </div>
              </div>
            ),
          )}
          {(isCreating || isCreated) && (
            <div className="texture_adjust_box">
              <div className="slide_box">
                <div className="slide_name">{getTranslation(TranslationsKeys.STRING_THICKNESS)}</div>
                <Slider
                  value={thicknessValue}
                  onChange={handleThicknessChange}
                  disabled={isCreating}
                  sx={{ height: 6, width: 175 }}
                  min={TextureTypeMap[textureStyle] === TextureType.RELIEF ? 2 : 0.2}
                  step={0.1}
                  max={TextureTypeMap[textureStyle] === TextureType.RELIEF ? 5 : 2}
                />
                <div className="slide_value">{thicknessValue}</div>
                <div className="slide_unit">mm</div>
              </div>
              <div className="slide_box">
                <div className="slide_name">{getTranslation(TranslationsKeys.STRING_VIEW3D_SMOOTHNESS)}</div>
                <Slider
                  value={contrastValue}
                  onChange={handleContrastChange}
                  disabled={isCreating}
                  sx={{ height: 6, width: 175 }}
                  min={0.5}
                  step={0.1}
                  max={2}
                />
                <div className="slide_value">{contrastValue}</div>
                {/* <div className="slide_unit">%</div> */}
              </div>
              {dimensionTypes == 'Texture Lib' && (
                <div className="slide_box">
                  <div className="slide_name">{getTranslation(TranslationsKeys.INVERT)}</div>
                  <Switch checked={isInvert} disabled={isCreating} onChange={handleInvertChange} />
                </div>
              )}
            </div>
          )}
        </div>
        <div className="Generate_down">
          {isCreated ? (
            <div className={`Generate_btn`} onClick={addToCanvasHandler}>
              <div className="Generate_btn_text">{getTranslation(TranslationsKeys.STRING_TEXTURE_ADDTOCANVAS)}</div>
            </div>
          ) : (
            <div>
              <div
                className={`Generate_btn ${
                  isCreating ||
                  isNetLoading ||
                  !downUpload[0]?.download_url ||
                  !(homeState?.UserIntegral >= NowModulIntegral)
                    ? 'disabled'
                    : ''
                }`}
                onClick={handleCreate}
              >
                <div className="Generate_btn_text">{getTranslation(TranslationsKeys.string_generate)}</div>
                <img src={Icon_Coins} className="Generate_btn_img" />
                <div>{NowModulIntegral}</div>
              </div>
              <div className="credit_text">
                {getTranslation(TranslationsKeys.MY_CREDITS)} {homeState?.UserIntegral}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
