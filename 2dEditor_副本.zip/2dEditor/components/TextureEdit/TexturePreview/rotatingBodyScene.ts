import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { TextureType } from 'src/templates/2dEditor/cons/2dEditorCons';
import { HtmlElementTexture } from '@babylonjs/core';

export default class RotatingBodyScene {
  // const { textureData } = props;
  private scene?: THREE.Scene;
  private normalMaterial?: THREE.Material;
  private helper?: THREE.GridHelper;
  private container?: any;
  private textureCache: THREE.Texture[] = [];
  private renderer?: THREE.WebGLRenderer;
  private textureLoader: THREE.TextureLoader = new THREE.TextureLoader();
  private quality: number;
  private textureCanvas: any;

  constructor(textureCanvas: any, quality?: number) {
    this.textureCanvas = textureCanvas;
    this.quality = quality || 1;
  }

  init(textureData: any, rotary_params: any) {
    if (!textureData || !this.textureCanvas) return;
    if (this.scene) return;
    this.container = this.textureCanvas;

    // CAMERA
    const camera = new THREE.PerspectiveCamera(30, this.container.offsetWidth / this.container.offsetHeight, 1, 4000);
    const max = Math.max(rotary_params.upperD, rotary_params.bottomD);
    camera.position.set(0, 60, 350 + max);

    // SCENE
    const scene = new THREE.Scene();

    scene.add(camera);

    // LIGHTS
    scene.add(new THREE.AmbientLight(0x666666, 2));

    const light = new THREE.DirectionalLight(0xffffff, 2.7);
    light.position.set(-50, 25, 30);

    scene.add(light);

    const light1 = new THREE.DirectionalLight(0xffffff, 1);
    light1.position.set(50, 30, 20);
    scene.add(light1);

    const light2 = new THREE.DirectionalLight(0xffffff, 1);
    light2.position.set(20, 40, -80);
    scene.add(light2);

    const helper = new THREE.GridHelper(700, 30);

    helper.material.opacity = 0.5;
    helper.material.transparent = true;
    scene.add(helper);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(this.container.offsetWidth, this.container.offsetHeight);
    renderer.setAnimationLoop(() => {
      renderer.render(scene, camera);
    });

    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setClearColor('#eee');

    this.container.appendChild(renderer.domElement);

    // CONTROLS
    const cameraControls = new OrbitControls(camera, renderer.domElement);
    cameraControls.target.set(0, 0, 0);
    cameraControls.update();

    window.onresize = () => {
      renderer.setSize(this.container.offsetWidth, this.container.offsetHeight);
    };
    this.renderer = renderer;
    this.helper = helper;
    this.scene = scene;
    this.create(textureData, rotary_params);
  }

  //更新模型
  update(data: any, rotary_params: any) {
    const scene = this.scene;
    if (!scene) return;
    const mesh = scene.children.filter((obj: any) => obj._id === data.id)[0];
    if (!mesh) return;
    const grayImage = new Image();
    grayImage.src = data.grayImg;

    const upperRadius = rotary_params.upperD / 2,
      lowerRadius = rotary_params.bottomD / 2,
      height = rotary_params.cupHeight;

    grayImage.onload = () => {
      mesh.geometry = this.getTextureGeometry(grayImage, data.thickness, upperRadius, lowerRadius, height);
    };

    if (data.normal) {
      const normalTexture = this.textureLoader.load(data.normal);
      this.textureCache.push(normalTexture);
      mesh.material.normalMap = normalTexture;
    }
  }

  //创建模型
  create(textureData: any, rotary_params: any) {
    this.normalMaterial = new THREE.MeshStandardMaterial({
      color: '#fff',
      side: THREE.DoubleSide,
    });

    const texture = this.textureLoader.load(textureData.colorBase64);
    this.textureCache.push(texture);
    texture.colorSpace = THREE.SRGBColorSpace;
    const cylinderMaterial = new THREE.MeshPhysicalMaterial({
      metalness: 0,
      roughness: 0.6,
      map: texture,
      transparent: true,
      opacity: 1,
    });

    const upperRadius = rotary_params.upperD / 2,
      lowerRadius = rotary_params.bottomD / 2,
      height = rotary_params.cupHeight,
      cylinderThickness = upperRadius * 0.13;

    // const torusOffset = textureData.grayData.length * 0.01
    const torusOffset = 0;

    //loading的时候占位
    this.createCylinder(upperRadius - 0.08, lowerRadius - 0.08, height, this.normalMaterial);
    //里圈
    this.createCylinder(upperRadius - cylinderThickness, lowerRadius - cylinderThickness, height);
    // //隔层
    this.createCylinder(upperRadius - 0.02, lowerRadius - 0.02, height, cylinderMaterial);
    //上杯口
    this.createTorus(
      upperRadius - cylinderThickness / 2 + torusOffset,
      cylinderThickness / 2 + torusOffset,
      height / 2,
    );
    //下杯口
    this.createTorus(
      lowerRadius - cylinderThickness / 2 + torusOffset,
      cylinderThickness / 2 + torusOffset,
      -height / 2,
    );
    //杯底
    this.createCircle(lowerRadius - cylinderThickness / 2, -height / 2 - cylinderThickness / 2);

    if (rotary_params.hasHandle) {
      const min = Math.min(upperRadius, lowerRadius);
      const max = Math.max(upperRadius, lowerRadius);
      const right = (max - min) / 2 + min;
      const tan = (upperRadius - lowerRadius) / height;

      //杯把手
      this.createTube(height / 2 - height * 0.18, ((upperRadius + lowerRadius) / 2) * 0.11, tan, right);
    }

    this.helper.position.y = -height / 2 - cylinderThickness / 2 - 0.1;

    textureData.grayData.forEach((data: any) => {
      const texture = this.textureLoader.load(data.grayColorImg || textureData.colorBase64);
      this.textureCache.push(texture);
      texture.colorSpace = THREE.SRGBColorSpace;

      const grayImage = new Image();
      grayImage.src = data.grayImg;

      const cylinderMaterial = new THREE.MeshPhysicalMaterial({
        metalness: 0,
        roughness: 0.6,
        map: texture,
        transparent: true,
        normalScale: new THREE.Vector2(6.0, 6.0),
        opacity: 1,
      });
      if (data.normal) {
        const normalTexture = this.textureLoader.load(data.normal);
        this.textureCache.push(normalTexture);
        cylinderMaterial.normalMap = normalTexture;
      }
      grayImage.onload = () => {
        // const offset = 0.01 * (index+1);
        const offset = 0;
        //外圈
        const cylinderGeometry = this.getTextureGeometry(
          grayImage,
          data.thickness,
          upperRadius + offset,
          lowerRadius + offset,
          height,
        );

        if (data.grayType === TextureType.GLOSS) {
          cylinderMaterial.clearcoat = 1;
          cylinderMaterial.clearcoatRoughness = 0;
          cylinderMaterial.metalness = 0.1;
          cylinderMaterial.roughness = 0;
          cylinderMaterial.specularIntensity = 0.6;
          cylinderMaterial.reflectivity = 0.8;
        }
        const cylinder = this.createColorCylinder(cylinderGeometry, cylinderMaterial);
        cylinder._id = data.id;
        cylinder._type = data.grayType;
      };
    });
  }
  createTube(radius: number, thickness: number, tan: number, right: number) {
    const width = radius + radius * 0.28;
    // 起始点
    const startPoint = new THREE.Vector3(-radius, 0, 0);
    // 结束点
    const endPoint = new THREE.Vector3(radius, 0, 0);
    // 控制点
    const controlPoint1 = new THREE.Vector3(-(radius + radius * 0.3), width, 0);

    const controlPoint2 = new THREE.Vector3(radius + radius * 0.3, width, 0);

    const curve = new THREE.CubicBezierCurve3(startPoint, controlPoint1, controlPoint2, endPoint);

    const tubeGeometry = new THREE.TubeGeometry(curve, 40, thickness, 20, false);

    const tube = new THREE.Mesh(tubeGeometry, this.normalMaterial);
    tube.rotation.z = -Math.PI / 2 - Math.atan(tan);
    tube.position.set(right - right * 0.03, 0, 0);
    this.scene?.add(tube);
  }

  getTextureGeometry(image: any, thickness = 1, upperRadius: number, lowerRadius: number, height: number) {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d') as CanvasRenderingContext2D;
    canvas.width = image.width * this.quality;
    canvas.height = image.height * this.quality;
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    //绘制4条黑边
    context.fillStyle = '#000';
    context.fillRect(0, 0, canvas.width, 1);
    context.fillRect(0, canvas.height - 1, canvas.width, 1);
    context.fillRect(0, 0, 1, canvas.height);
    context.fillRect(canvas.width - 1, 0, 1, canvas.height);
    //计算图片像素
    const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    const grays = [];
    let max = 0;
    for (let i = 0; i < pixels.length; i += 4) {
      const r = pixels[i];
      const g = pixels[i + 1];
      const b = pixels[i + 2];
      const gray = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
      if (gray > max) max = gray;
      grays.push(gray);
    }
    const cylinderGeometry = new THREE.CylinderGeometry(
      upperRadius,
      lowerRadius,
      height,
      canvas.width - 1,
      canvas.height - 1,
      true,
    );
    const vertices = cylinderGeometry.attributes.position.array;
    const normalArray = cylinderGeometry.attributes.normal.array;
    // 根据灰度值调整顶点的高度
    for (let i = 0; i < vertices.length; i += 3) {
      const normal = new THREE.Vector3(normalArray[i], normalArray[i + 1], normalArray[i + 2]);
      const offset = normal.multiplyScalar((thickness / max) * grays[i / 3]);

      vertices[i] += offset.x;
      vertices[i + 1] += offset.y;
      vertices[i + 2] += offset.z;
    }

    cylinderGeometry.attributes.position.needsUpdate = true;
    canvas.remove();
    return cylinderGeometry;
  }

  createColorCylinder(cylinderGeometry: any, cylinderMaterial: any) {
    const cylinder = new THREE.Mesh(cylinderGeometry, cylinderMaterial);
    cylinder.rotation.y = Math.PI / 2;

    this.scene?.add(cylinder);
    return cylinder;
  }

  createCylinder(upperRadius: number, lowerRadius: number, height: number, cylinderMaterial?: any) {
    const cylinderGeometry = new THREE.CylinderGeometry(upperRadius, lowerRadius, height, 60, 60, true);
    const cylinder = new THREE.Mesh(cylinderGeometry, cylinderMaterial || this.normalMaterial);
    cylinder.rotation.y = Math.PI / 2;
    this.scene?.add(cylinder);
    return cylinder;
  }

  createTorus(torusRadius: number, torusSectionRadius: number, top: number) {
    const torusGeometry = new THREE.TorusGeometry(torusRadius, torusSectionRadius, 30, 60);
    const torus = new THREE.Mesh(torusGeometry, this.normalMaterial);
    torus.rotation.x = -Math.PI / 2;
    torus.position.set(0, top, 0);
    this.scene?.add(torus);
    return torus;
  }

  createCircle(radius: number, top: number) {
    const circleGeometry = new THREE.CircleGeometry(radius, 60);
    const circle = new THREE.Mesh(circleGeometry, this.normalMaterial);
    circle.rotation.x = -Math.PI / 2;
    circle.position.set(0, top, 0);
    this.scene?.add(circle);
    return circle;
  }

  removeScene() {
    if (this.scene) {
      for (var i = 0; i < this.scene.children.length; i++) {
        const object = this.scene.children[i] as any;
        if (object.geometry) {
          object.geometry.dispose();
          object.geometry = null;
        }
        if (object.material) {
          if (object.material.map) {
            object.material.map.dispose();
            object.material.map = null;
          }
          if (object.material.normalMap) {
            object.material.normalMap.dispose();
            object.material.normalMap = null;
          }
          object.material.dispose();
          object.material = null;
        }
        this.scene.remove(object);
      }
      this.textureCache.forEach((texture) => {
        texture.dispose();
      });
      this.renderer.dispose();
      this.renderer = null;
      this.scene = null;
    }
  }
}
