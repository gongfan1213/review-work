import React, { useEffect, useState, useRef } from 'react';
import TextureScene from './textureScene';
import RotatingBodyScene from './rotatingBodyScene';
import * as classs from './index.module.scss';
import { TextureEffect2dManager } from '../../TextureEdit/logic/TextureEffect2dManager';
import { useCanvasEditor, useProjectData } from 'src/templates/2dEditor/hooks/context';
import { Texture3dGrayImageItem } from '../model/TextureModel';
import {
  TextureType,
  TextureMaxThickness,
  TextureMinThickness,
  WorkspaceID,
  CanvasCategory,
} from 'src/templates/2dEditor/cons/2dEditorCons';
import switch3d from 'src/assets/img/3d1.png';
import Slider from '@mui/material/Slider';
import Switch from '@mui/material/Switch';
import textureIcon from 'src/assets/img/smart fill.png';
import itemIcon from 'src/assets/img/augment.svg';
import layer from 'src/assets/svg/layer.svg';
import ProjectManager from 'src/templates/2dEditor/utils/ProjectManager';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import loading_icon from 'src/assets/svg/loading.svg';

export default function TexturePreview(props: any) {
  const { setShowTextureView } = props;
  const canvasEditor = useCanvasEditor();
  const projectModel: any = useProjectData();

  const textureCanvas = useRef<any>();
  const textureScene = useRef<any>();
  const rotary_params = useRef<any>();

  //缓存生成的灰度图
  const temGrayData = useRef<any>({});

  const [contrast, setContrast] = useState(1);
  const [invert, setInvert] = useState(false);
  const [thickness, setThickness] = useState(2);
  const [showLayers, setShowLayers] = useState(true);
  const [activeData, setActiveData] = useState<Texture3dGrayImageItem>();
  const [grayData, setGrayData] = useState<Texture3dGrayImageItem[]>([]);
  const [showInvert, setShowInvert] = useState(true);
  const [loading, setLoading] = useState(true);
  const { getTranslation } = useCustomTranslation();

  const textureEffect2dManager = TextureEffect2dManager.getInstance();

  useEffect(() => {
    const isCylindrical =
      projectModel.canvases[projectModel.canvasesIndex].category === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL;
    const print_param = JSON.parse(projectModel.canvases[projectModel.canvasesIndex].print_param);

    const widthMM = print_param.format_size_w_non;

    if (isCylindrical) {
      textureScene.current = new RotatingBodyScene(textureCanvas.current);
      rotary_params.current = print_param.rotary_params;
    } else {
      textureScene.current = new TextureScene(textureCanvas.current);
    }

    hanlderGlossTexture(true);

    const hasBaseMap = getHasBaseMap();

    var projectData = ProjectManager.getInstance().getProjectData();

    const isUseGray = !ProjectManager.getInstance().isFilterTextureEffect(projectModel);
    const grayPromise = textureEffect2dManager.getCanvasGrayImgOf3dRelief(canvasEditor, true, projectData);

    //获取灰度图和预览图
    grayPromise.then((res) => {
      const compressGrayPromise = isUseGray ? getCompressionImage(res.grayImgs) : new Promise((resolve) => resolve([]));
      const colorData = res.canvasPreviewData.dataUrl;

      //压缩灰度图和处理预览图
      Promise.all([compressGrayPromise, hanlderColorImg(colorData)]).then((res) => {
        const colorData = res[1];
        const compressGrayData = res[0];
        //生成法线图
        getNormalMap(compressGrayData).then((grayData: any) => {
          const data = {
            grayData: grayData,
            widthMM,
            colorBase64: colorData,
            hasBaseMap, //是否有彩色底图
          };

          setGrayData(grayData);

          grayData.forEach((data: Texture3dGrayImageItem) => {
            //@ts-ignore;
            if (temGrayData.current) {
              temGrayData.current[data.id] = data.grayImg;
            }
          });
        
          setLoading(false);
          if (isCylindrical) {
            textureScene.current.init(data, rotary_params.current);
          } else {
            textureScene.current.init(data);
          }
          setActiveData(grayData[0] || null);
          if (grayData[0]) {
            setThickness(grayData[0].thickness || (grayData[0].grayType === TextureType.RELIEF ? 5 : 2));
            setShowInvert(grayData[0].grayType === TextureType.RELIEF ? false : true);
          }
        });
      });
    });

    return () => {
      textureScene.current?.removeScene();
      textureScene.current = null;
      temGrayData.current = null;
      textureCanvas.current = null;
      rotary_params.current = null;
      setGrayData([]);
      setActiveData(undefined);
    };
  }, []);

  function getNormalMap(grayData: Texture3dGrayImageItem[]) {
    const promises = grayData.map((data: any) => {
      return textureEffect2dManager.grayToNormalMap(data.grayImg);
    });
    return new Promise((resolve, reject) => {
      Promise.all(promises).then((res) => {
        res.forEach((normal, index) => {
          grayData[index].normal = normal;
        });
        resolve(grayData);
      });
    });
  }

  function getCompressionImage(grayData: Texture3dGrayImageItem[]) {
    const promises = grayData.map((data: any) => {
      return textureEffect2dManager.compressionImage(data.grayImg);
    });

    return new Promise((resolve, reject) => {
      Promise.all(promises).then((res) => {
        res.forEach((grayImg, index) => {
          grayData[index].grayImg = grayImg;
        });
        resolve(grayData);
      });
    });
  }

  function hanlderGlossTexture(isOpen?: boolean) {
    const objects = canvasEditor?.canvas.getObjects();
    objects?.forEach((item: any) => {
      if (item.textureType == TextureType.GLOSS) {
        item.set({ opacity: isOpen ? 1 : 0.5 });
      } else if (item._isTextureGroup && item._objects[1].textureType == TextureType.GLOSS) {
        item._objects[1].set({ opacity: isOpen ? 0 : 0.5 });
      }
    });
  }

  function getHasBaseMap() {
    const objects = canvasEditor?.canvas
      .getObjects()
      .filter((obj: any) => !obj.id.includes(WorkspaceID.WorkspaceCavas) && !obj.textureType && !obj._isTextureGroup);

    //@ts-ignore
    return objects?.length > 0;
  }

  function hanlderColorImg(base64: string) {
    // return base64;
    //todo, 生成预览图时，逐张图片放大几像素
    const image = new Image();
    image.src = base64;
    return new Promise((resolve) => {
      image.onload = () => {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d') as CanvasRenderingContext2D;
        canvas.width = image.width;
        canvas.height = image.height;
        context.fillStyle = '#fff';
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        const colorBase64 = canvas.toDataURL('image/png');
        resolve(colorBase64);
      };
    });
  }

  async function updateTexture() {
    if (grayData.length === 0) return;
    const textureObject = getTextureObject();
    let thickness = 0;
    textureObject.forEach(async (object) => {
      const grayscale = object.grayscale;
      const data = grayData.filter((obj) => obj.id === object.id)[0];
      //重新处理原图
      const res = await textureEffect2dManager.convertToGrayscale(grayscale, data.invert, data.contrast);
      if(object.textureType !== TextureType.RELIEF && !thickness){
        thickness = data.thickness
      }
      object.set({
        thickness: object.textureType == TextureType.RELIEF ? data.thickness : thickness,
        grayscale: res.grayscaleImage,
      });
    });
    console.log(888, textureObject);
  }

  function hanlderThickness(thickness: number) {
    if (activeData?.grayType === TextureType.RELIEF) {
      grayData.forEach((data) => {
        if (data.id === activeData?.id) {
          data.thickness = thickness;
          textureScene.current.update(data, rotary_params.current);
        }
      });
    } else {
      grayData.forEach((data) => {
        if (data.grayType !== TextureType.RELIEF) {
          data.thickness = thickness;
          textureScene.current.update(data, rotary_params.current);
        }
      });
    }
  }

  async function hanlderContrast(contrast: number) {
    grayData.forEach(async (data) => {
      if (data.id === activeData?.id) {
        let img;
        if (invert) {
          //反转前先把透明部分变成白色
          img = await textureEffect2dManager.replaceTransparentWithBlack(temGrayData.current[data.id], true);
        } else {
          img = temGrayData.current[data.id];
        }
        const res = await textureEffect2dManager.convertToGrayscale(img, invert, contrast);
        // const normal = await textureEffect2dManager.grayToNormalMap(res.grayscaleImage);
        data.grayImg = res.grayscaleImage;
        // data.normal = normal;
        data.contrast = contrast;
        textureScene.current.update(data, rotary_params.current);
      }
    });
  }

  async function hanlderInvert(invert: boolean) {
    grayData.forEach(async (data) => {
      if (data.id === activeData?.id) {
        let img;
        if (invert) {
          //反转前先把透明部分变成白色
          img = await textureEffect2dManager.replaceTransparentWithBlack(temGrayData.current[data.id], true);
        } else {
          img = temGrayData.current[data.id];
        }
        const res = await textureEffect2dManager.convertToGrayscale(img, invert, contrast);
        const normal = await textureEffect2dManager.grayToNormalMap(res.grayscaleImage);
        data.grayImg = res.grayscaleImage;
        data.normal = normal;
        data.invert = invert;
        textureScene.current.update(data, rotary_params.current);
      }
    });
  }

  function getTextureObject() {
    const textureObject = [] as any[];
    const objects = canvasEditor?.canvas.getObjects();
    objects?.forEach((obj: any) => {
      if (obj.textureType) {
        textureObject.push(obj);
      } else if (obj._isTextureGroup) {
        textureObject.push(obj._objects[1]);
      }
    });

    return textureObject;
  }

  function getGrayData(id) {
    return grayData.filter((obj: any) => {
      return obj.id === id;
    })[0];
  }

  function getTextureLayersList() {
    const otherObjects = canvasEditor?.canvas
      .getObjects()
      .filter((obj) => !(obj as any).id.includes(WorkspaceID.WorkspaceCavas));
    //@ts-ignore
    otherObjects.reverse();
    if (otherObjects.length > 0) {
      return (
        <div className={classs.layersBox}>
          {otherObjects?.map((data: any) => {
            if (data.textureType || data._isTextureGroup) {
              const id = data.textureType ? data.id : data._objects[1].id;
              const _grayData = getGrayData(id);
              return (
                <div
                  className={classs.texturelayerItem}
                  style={id === activeData?.id ? { background: '#F2F2F2' } : { background: '#fff' }}
                  onClick={() => {
                    if (!activeData) return false;
                    if (id === activeData?.id) {
                      setActiveData(undefined);
                    } else {
                      setActiveData(_grayData);
                      setContrast(_grayData.contrast || 1);
                      setThickness(_grayData.thickness || (_grayData.grayType === TextureType.RELIEF ? 5 : 2));
                      setInvert(_grayData.invert || false);
                      setShowInvert(_grayData.grayType === TextureType.RELIEF ? false : true);
                    }
                  }}
                >
                  <span className={classs.textureName}>
                    <img src={textureIcon} />
                    {data._layerNameCus || data._layerName}
                  </span>
                  <span className={classs.textureTab}>2.5D</span>
                </div>
              );
            } else {
              return (
                <div className={classs.layerItem}>
                  <span className={classs.textureName}>
                    <img src={itemIcon} />
                    {data._layerNameCus || data._layerName}
                  </span>
                </div>
              );
            }
          })}
        </div>
      );
    } else {
      return null;
    }
  }

  return (
    <div className={classs.texturePreviewContent}>
      {loading && <img className={classs.loading_icon} src={loading_icon} />}(
      {activeData && (
        <div className={classs.settingBox}>
          <div className={classs.title}>{getTranslation(TranslationsKeys.VIEW3D_SETTING)}</div>
          <div className={classs.handleBox}>
            <span className={classs.sliderTitle}>{getTranslation(TranslationsKeys.VIEW3D_THICKNESS)}</span>
            <Slider
              className={classs.slider}
              min={activeData.grayType === TextureType.RELIEF ? TextureMinThickness.RELIEF : TextureMinThickness.GLOSS}
              max={activeData.grayType === TextureType.RELIEF ? TextureMaxThickness.RELIEF : TextureMaxThickness.GLOSS} //纹理2毫米，浮雕5毫米
              value={thickness}
              step={0.1}
              onChange={(e: any, value: number) => {
                hanlderThickness(value);
                setThickness(value);
              }}
            />
            <input
              type="number"
              value={thickness}
              onChange={(e) => {
                let _thickness = Number(parseFloat(e.target.value).toFixed(2));
                if (Number.isNaN(_thickness)) {
                  _thickness = 0;
                }
                if (
                  _thickness >= 0 &&
                  _thickness <=
                    (activeData.grayType === TextureType.RELIEF
                      ? TextureMaxThickness.RELIEF
                      : TextureMaxThickness.GLOSS)
                ) {
                  hanlderThickness(_thickness);
                  setThickness(_thickness);
                }
              }}
            />
            <span className={classs.unit}>mm</span>
          </div>
          <div className={classs.handleBox}>
            <span className={classs.sliderTitle}>{getTranslation(TranslationsKeys.VIEW3D_SMOOTHNESS)}</span>
            <Slider
              className={classs.slider}
              min={0.1} // 0
              max={2} // 2
              step={0.1}
              value={contrast}
              onChange={async (e, value) => {
                let _contrast = value;
                if (Number.isNaN(_contrast)) {
                  _contrast = 0;
                }
                if (_contrast >= 0 && _contrast <= 2) {
                  hanlderContrast(_contrast);
                  setContrast(_contrast);
                }
              }}
            />
            <input
              type="number"
              value={contrast}
              onChange={(e) => {
                let _contrast = Number(parseFloat(e.target.value).toFixed(2));
                if (Number.isNaN(_contrast)) {
                  _contrast = 0;
                }
                if (_contrast >= 0 && _contrast <= 2) {
                  hanlderContrast(_contrast);
                  setContrast(_contrast);
                }
              }}
            />
          </div>
          {showInvert && (
            <div className={classs.handleBox}>
              <span className={classs.sliderTitle}>{getTranslation(TranslationsKeys.VIEW3D_INVERT)}</span>
              <Switch
                checked={invert}
                onClick={(e) => {
                  setInvert(!invert);
                  hanlderInvert(!invert);
                }}
              />
            </div>
          )}
        </div>
      )}
      <div className={classs.switch3D}>
        <img
          src={switch3d}
          onClick={() => {
            updateTexture();
            hanlderGlossTexture();
            setShowTextureView(false);
          }}
        />
      </div>
      <div
        className={classs.layers}
        onClick={() => {
          setShowLayers(!showLayers);
        }}
      >
        <img src={layer} />
        {getTranslation(TranslationsKeys.VIEW3D_LAYER)}
      </div>
      {showLayers && getTextureLayersList()}
      <div ref={textureCanvas} className={classs.textureSceneWarp}></div>)
    </div>
  );
}
