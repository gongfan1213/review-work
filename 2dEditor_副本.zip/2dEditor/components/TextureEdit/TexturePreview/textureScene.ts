import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { TextureType } from 'src/templates/2dEditor/cons/2dEditorCons';
// import env from 'src/images/2dEditor/equirectangular.png';
import env from 'src/images/2dEditor/texture_env.jpg';

export default class TextureScene {
  // const { textureData } = props;
  private scene?: THREE.Scene;
  private widthMM: number = 100;
  private textureCache: THREE.Texture[] = [];
  private renderer?: THREE.WebGLRenderer;
  private textureLoader: THREE.TextureLoader = new THREE.TextureLoader();
  private quality: number;
  private textureCanvas: any;

  constructor(textureCanvas: any, quality?: number) {
    this.textureCanvas = textureCanvas;
    this.quality = quality || 1;
  }

  init(textureData: any) {
    console.log(888, 'textureData', textureData);
    if (!textureData || !this.textureCanvas) return;
    if (this.scene) return;

    const container = this.textureCanvas;

    // CAMERA
    const camera = new THREE.PerspectiveCamera(45, container.offsetWidth / container.offsetHeight, 1, 4000);
    camera.position.set(0, 10, 16);

    // SCENE
    const scene = new THREE.Scene();

    this.scene = scene;

    scene.add(camera);

    // LIGHTS
    scene.add(new THREE.AmbientLight('#b6b6b6', 2.5));

    // const light = new THREE.DirectionalLight(0xffffff, 5);
    // light.position.set(-0.32, 0.39, -0.7);

    // light.castShadow = true;

    // scene.add(light);

    // const light1 = new THREE.DirectionalLight(0xffffff, 3);
    // light1.position.set(0.32, -2, 0.7);
    // // light1.position.set(0, 2, 0);

    // light1.castShadow = true;

    // scene.add(light1);
    const pointMaterial = new THREE.MeshPhongMaterial({
      color: '#fff',
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    const particleLight = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), pointMaterial);

    scene.add(particleLight);

    particleLight.add(new THREE.PointLight(0xffffff, 25));

    new THREE.TextureLoader().load(env, (texture) => {
      texture.mapping = THREE.EquirectangularReflectionMapping;
      scene.environment = texture;
    });

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(container.offsetWidth, container.offsetHeight);
    renderer.setAnimationLoop(() => {
      const timer = Date.now() * 0.00015;

      particleLight.position.x = Math.sin(timer * 7) * 4;
      particleLight.position.y = 0.5 + Math.cos(timer * 5) * 1;
      particleLight.position.z = Math.cos(timer * 3) * 4;
      renderer.render(scene, camera);
    });
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    renderer.setClearColor('#808080');
    const helper = new THREE.GridHelper(200, 100);
    helper.position.y = -0.05;
    helper.material.opacity = 0.5;
    helper.material.transparent = true;
    scene.add(helper);

    container.appendChild(renderer.domElement);

    // CONTROLS
    const cameraControls = new OrbitControls(camera, renderer.domElement);
    cameraControls.target.set(0, 0, 0);
    cameraControls.update();

    window.onresize = () => {
      renderer.setSize(container.offsetWidth, container.offsetHeight);
    };
    this.widthMM = textureData.widthMM || 100;
    this.renderer = renderer;
    this.scene = scene;
    this.create(textureData);
  }

  //更新模型
  update(data: any) {
    const scene = this.scene;
    if (!scene) return;
    const mesh = scene.children.filter((obj: any) => obj._id === data.id)[0];
    if (!mesh) return;
    const grayImage = new Image();
    if (grayImage) {
      grayImage.src = data.grayImg;
      grayImage.onload = () => {
        if (data.normal) {
          const normalTexture = this.textureLoader.load(data.normal);
          this.textureCache.push(normalTexture);
          mesh.material.normalMap = normalTexture;
        }
        mesh.geometry = this.getTextureGeometry(grayImage, data.thickness);
      };
    }
  }

  //创建模型
  create(textureData: any) {
    const scene = this.scene;
    let index = 0;

    textureData.grayData.forEach((data: any) => {
      const colorTexture = this.textureLoader.load(data.grayColorImg || textureData.colorBase64);
      this.textureCache.push(colorTexture);
      colorTexture.colorSpace = THREE.SRGBColorSpace;
      colorTexture.minFilter = THREE.LinearMipmapLinearFilter;
      colorTexture.magFilter = THREE.LinearFilter;
      colorTexture.wrapS = THREE.ClampToEdgeWrapping;
      colorTexture.wrapT = THREE.ClampToEdgeWrapping;

      const grayImage = new Image();
      grayImage.src = data.grayImg;

      const colorMaterial = new THREE.MeshPhysicalMaterial({
        transparent: true,
        opacity: 1,
        metalness: 0,
        roughness: 0.6,
        map: colorTexture,
        normalScale: new THREE.Vector2(6.0, 6.0),
        depthWrite: false,
      });

      if (data.normal) {
        const normalTexture = this.textureLoader.load(data.normal);
        this.textureCache.push(normalTexture);
        colorMaterial.normalMap = normalTexture;
      }

      grayImage.onload = () => {
        // 创建纹理网格并添加到场景
        const textureGeometry = this.getTextureGeometry(grayImage, data.thickness);
        if (data.grayType === TextureType.GLOSS) {
          colorMaterial.clearcoat = 1;
          colorMaterial.clearcoatRoughness = 0.1;
          colorMaterial.metalness = 0.1;
          colorMaterial.roughness = 0.1;
          colorMaterial.specularIntensity = 0.6;
          // colorMaterial.reflectivity = 0.3;
        }

        const mesh = new THREE.Mesh(textureGeometry, colorMaterial);
        mesh._id = data.id;
        mesh.rotation.x = -Math.PI / 2;
        index++;
        mesh.position.set(0, 0.2 + 0.015 + 0.005 * index, 0);
        scene?.add(mesh);
      };
    });

    const colorImage = new Image();
    colorImage.src = textureData.colorBase64;
    colorImage.onload = () => {
      //创建底板
      const bottmGeometry = new THREE.BoxGeometry(
        10,
        (10 * colorImage.height) / colorImage.width,
        0.2,
        10,
        (10 * colorImage.height) / colorImage.width,
        10,
      );
      const bottmMaterial = new THREE.MeshPhongMaterial({
        color: '#fff',
        transparent: true,
        opacity: 0.2,
      });
      const bottoMmesh = new THREE.Mesh(bottmGeometry, bottmMaterial);
      bottoMmesh.position.set(0, 0.1, 0);
      bottoMmesh.rotation.x = -Math.PI / 2;
      scene?.add(bottoMmesh);

      //创建隔层
      const planeGeometry = new THREE.PlaneGeometry(
        10,
        (10 * colorImage.height) / colorImage.width,
        10,
        (10 * colorImage.height) / colorImage.width,
      );
      const planeMaterial = new THREE.MeshBasicMaterial({ color: '#fff', transparent: true });
      const plane = new THREE.Mesh(planeGeometry, planeMaterial);
      plane.position.set(0, 0.2 + 0.005, 0);
      plane.rotation.x = -Math.PI / 2;
      scene?.add(plane);

      //创建彩色图层
      if (textureData.hasBaseMap && textureData.colorBase64) {
        const colorTexture = this.textureLoader.load(textureData.colorBase64);
        this.textureCache.push(colorTexture);
        colorTexture.colorSpace = THREE.SRGBColorSpace;
        const colorMaterial = new THREE.MeshBasicMaterial({ map: colorTexture, transparent: true });
        const colorPlane = new THREE.Mesh(planeGeometry, colorMaterial);
        colorPlane.position.set(0, 0.2 + 0.015, 0);
        colorPlane.rotation.x = -Math.PI / 2;
        scene?.add(colorPlane);
      }
    };
  }

  //创建几何体
  getTextureGeometry(image: any, thickness = 1) {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d') as CanvasRenderingContext2D;
    canvas.width = image.width * this.quality;
    canvas.height = image.height * this.quality;
    context.drawImage(image, 0, 0, canvas.width, canvas.height);

    //绘制4条黑边
    context.fillStyle = '#000';
    context.fillRect(0, 0, canvas.width, 1);
    context.fillRect(0, canvas.height - 1, canvas.width, 1);
    context.fillRect(0, 0, 1, canvas.height);
    context.fillRect(canvas.width - 1, 0, 1, canvas.height);

    //计算图片像素
    const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;

    // 创建几何体
    const geometry = new THREE.PlaneGeometry(
      10,
      (10 * canvas.height) / canvas.width,
      canvas.width - 1,
      canvas.height - 1,
    );
    const vertices = geometry.attributes.position.array;

    //计算灰度值
    const grays = [];
    let max = 0;
    for (let i = 0; i < pixels.length; i += 4) {
      const r = pixels[i];
      const g = pixels[i + 1];
      const b = pixels[i + 2];
      const gray = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
      if (gray > max) max = gray;
      grays.push(gray);
    }

    const n = 10 / this.widthMM;

    // 根据灰度值调整顶点的高度
    for (let i = 0; i < vertices.length; i += 3) {
      vertices[i + 2] = (thickness / max) * grays[i / 3] * n;
    }

    geometry.attributes.position.needsUpdate = true;
    canvas.remove();
    return geometry;
  }

  removeScene() {
    if (this.scene) {
      for (var i = 0; i < this.scene.children.length; i++) {
        const object = this.scene.children[i] as any;
        if (object.geometry) {
          object.geometry.dispose();
          object.geometry = null;
        }
        if (object.material) {
          if (object.material.map) {
            object.material.map.dispose();
            object.material.map = null;
          }
          if (object.material.normalMap) {
            object.material.normalMap.dispose();
            object.material.normalMap = null;
          }
          object.material.dispose();
          object.material = null;
        }
        this.scene.remove(object);
      }
      this.textureCache.forEach((texture) => {
        texture.dispose();
      });
      this.renderer.dispose();
      this.renderer = null;
      this.scene = null;
    }
  }
}
