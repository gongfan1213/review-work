import {
  EDITOR_JSON_KEY,
  FabricObjectType,
  WorkspaceID,
  TextureType,
  TextureMaxThickness,
  PrintSource,
  CustomPcAction,
  CanvasCategory,
  ReliefType,
  CanvasParams,
  CanvasSubCategory,
} from 'src/templates/2dEditor/cons/2dEditorCons';
import { Texture3dGrayImage, Texture3dGrayImageItem, Texture3dGrayPrint, TextureModel } from '../model/TextureModel';
// import { TextureEditType } from "../cons/TextureEditCons";
import Editor from 'src/templates/2dEditor/core';
// import cv from "@techstark/opencv-js";
import Tar from 'tar-js';
import {
  PrintLayerData,
  PrintLayerFileStr,
  PrintLayerModel,
  PrintLayerType,
  PrintModel,
  PrintQuality,
} from '../../MainUi/MainUiRightComponent/PrintLayer/model/PrintLayerModel';
import StringUtil from 'src/common/utils/stringUtil';
import { OpenCvManager } from 'src/templates/2dEditor/common/logic/OpenCvManager';
import { base64ToUint8Array, blobToBase64, blobToMd5 } from 'src/common/utils';
import { isPc, schemeUrlPC, sendCommandToPc } from 'src/common/jsbridge';
import { getUserInfo } from 'src/common/storage';
import { upload, upload2dEditFile } from 'src/hooks/useUpload';
import { PrintToPcModel } from '../../MainUi/MainUiRightComponent/PrintLayer/model/PrintToPcModel';
import { sendCommandToPcWithResponse } from 'src/common/jsbridge/util';
import { CanvasesResInfo, ProjectModel, RotaryParams } from '../../SelectDialog/model/ProjectModel';
import { OpenCvImgToolMangager } from 'src/templates/2dEditor/common/logic/OpenCvImgToolMangager';

export class TextureEffect2dManager {
  private static instance: TextureEffect2dManager;
  private isDroping: boolean = false;
  private mTextureModel: TextureModel | null = null;
  private mBase64Front = 'data:image/png;base64,';
  private cv: any = null; // 添加 cv 属性

  private constructor() {
    OpenCvManager.getInstance()
      .initOpenCv()
      .then(async () => {
        console.log('====TextureEffect2dManager===000=');
        this.cv = await (window as any).cv;
        console.log('====TextureEffect2dManager===1111=');
      });
  }
  public static getInstance(): TextureEffect2dManager {
    if (!TextureEffect2dManager.instance) {
      TextureEffect2dManager.instance = new TextureEffect2dManager();
    }
    return TextureEffect2dManager.instance;
  }

  public startDrop() {
    this.mTextureModel = {
      img: 'https://d36p1yx3f7pupn.cloudfront.net/makeitreal/makeitreal/editor_uploads/default/2c55e59b2ee4586f3e542066ed32d2cb7012a6f4/uploads_93dfe590b0fdaa1229bb0df0ae0351cb.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CQPCOG733/20241015/us-west-2/s3/aws4_request&X-Amz-Date=20241015T103046Z&X-Amz-Expires=86400&X-Amz-SignedHeaders=host&X-Amz-Signature=b91010b24fa3bdb08f3f7426ce810fd7b29d36783b619f5e56b9e2bd446e0130',
      imgGray: 'xxxxx',
    };
    this.isDroping = true;
  }

  public endDrop(highlightedLayerId?: string, canvas?: fabric.Canvas) {
    this.isDroping = false;
  }

  public isDrop(): boolean {
    return this.isDroping;
  }

  /**
   * 判断是否包含纹理
   * @param canvas
   * @returns
   */
  public checkGrayCanvas(canvas: fabric.Canvas, projectModel: ProjectModel | null): number {
    var retType = ReliefType.print_relief_type_def;
    var hasRelief: boolean = false;
    var hasTexture: boolean = false;
    var isHandleCylindrical: boolean = false;
    var isSticker: boolean = false;
    if (projectModel) {
      var canvaData: CanvasesResInfo = projectModel.canvases[projectModel.canvasesIndex];
      var rotary_params: RotaryParams = JSON.parse(canvaData.print_param!).rotary_params;
      isHandleCylindrical = canvaData.category === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL && (rotary_params.hasHandle || false);
      isSticker = canvaData.sub_category === CanvasSubCategory.CANVAS_CATEGORY_ACCESSORY_STICKER_S
        || canvaData.sub_category === CanvasSubCategory.CANVAS_CATEGORY_ACCESSORY_STICKER_M;
    }

    // 定义一个递归函数来检查对象及其子对象
    const checkObject = (obj: fabric.Object): void => {
      // 检查对象是否有 textureType 和 grayscale 属性
      if ((obj as any).textureType && (obj as any).grayscale) {
        switch ((obj as any).textureType) {
          case TextureType.CMYK:
          case TextureType.GLOSS:
            hasTexture = true;
            break;
          case TextureType.RELIEF:
            hasRelief = true;
            break;
        }
      }
      // 如果对象是一个 group，递归检查其子对象
      if (obj.type === FabricObjectType.Group && (obj as fabric.Group).getObjects) {
        const group = obj as fabric.Group;
        for (const child of group.getObjects()) {
          return checkObject(child);
        }
      }
    };

    // 遍历 canvas 中的所有对象
    for (const obj of canvas.getObjects()) {
      checkObject(obj);
    }
    if (hasRelief && hasTexture && !isHandleCylindrical && !isSticker) {
      retType = ReliefType.print_relief_type_textureRel;
    } else if (hasRelief && !isHandleCylindrical && !isSticker) {
      retType = ReliefType.print_relief_type_rel;
    } else if (hasTexture && !isHandleCylindrical && !isSticker) {
      retType = ReliefType.print_relief_type_texture;
    }
    return retType;
  }

  public compressionImage(base64: string, quality?: number): Promise<string> {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.src = base64;
      image.onload = () => {
        const max = Math.max(image.width, image.height);
        let scale = 0.8;
        if (quality) {
          scale = quality / max;
        } else if (max > 6000) {
          scale = 0.3;
        } else if (max > 4000) {
          scale = 0.4;
        } else if (max > 1000) {
          scale = 0.5;
        }
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d') as CanvasRenderingContext2D;
        canvas.width = image.width * scale;
        canvas.height = image.height * scale;
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        const newBase64 = canvas.toDataURL('image/jpeg');
        resolve(newBase64);
      };
      image.onerror = (err) => {
        reject(err);
      };
    });
  }

  /**
   * 3d渲染得到渲染灰度图
   * @param editor
   * @param bgIsTrans 是否需要将透明背景替换为黑色
   * @returns
   */
  public async getCanvasGrayImgOf3dRelief(
    editor: Editor,
    bgIsTrans: boolean = false,
    projectModel: ProjectModel | null = null,
    isPrnt: boolean = false
  ): Promise<any> {
    console.log('=====getCanvasGrayImgOf3dRelief====start=');
    var grayImgs: Texture3dGrayImageItem[] = [];

    let currentCanvas = editor.canvas;
    // 获取工作区对象和其他对象
    const workspaceObject = currentCanvas.getObjects()?.find((item: any) => {
      console.log('=====getCanvasGrayImgOf3dRelief====start=111111', item.id);
      return item.id === WorkspaceID.WorkspaceCavas;
    });
    console.log('=====getCanvasGrayImgOf3dRelief====start=workspaceObject=', workspaceObject, projectModel);
    var canvasWidth = workspaceObject!.width!;
    var canvasHeight = workspaceObject!.height!;
    var scale = 1;
    var imgQualityTemp = CanvasParams.canvas_dpi_def;
    if (projectModel) {
      var canvas = projectModel.canvases[projectModel.canvasesIndex];
      const printLayerModel = JSON.parse(canvas.print_param);
      imgQualityTemp = (printLayerModel.format_size_w < 300 || printLayerModel.format_size_h < 300) || isPrnt
        ? printLayerModel.printQuality || printLayerModel.imgQuality!
        : imgQualityTemp;
      var retSize = StringUtil.scaleToWidth(
        printLayerModel.format_size_w!,
        printLayerModel.format_size_h!,
        imgQualityTemp,
      );
      scale = retSize.width / workspaceObject!.width!;
      console.log('=====getCanvasGrayImgOf3dRelief===left==', printLayerModel.format_size_w, scale);
      canvasWidth = retSize.width;
      canvasHeight = retSize.height;
    }
    // 获取画布预览图
    let canvasPreviewData = await editor.preview1(projectModel, null, imgQualityTemp);
    let canvasPreviewImg: string = canvasPreviewData.dataUrl;

    let clonedCanvas = await this.cloneCanvas(editor);
    if (scale !== 1) {
      // 调整 clonedCanvas 的宽度和高度
      clonedCanvas.setWidth(canvasWidth);
      clonedCanvas.setHeight(canvasHeight);
      // 遍历 clonedCanvas 中的所有对象，并按照 scale 进行缩放和位置调整
      clonedCanvas.getObjects().forEach((obj: fabric.Object) => {
        // 缩放对象
        obj.set({
          left: obj.left! * scale,
          top: obj.top! * scale,
          scaleX: obj.scaleX! * scale,
          scaleY: obj.scaleY! * scale,
        });
      });
      // 重新渲染画布
      clonedCanvas.renderAll();
    }
    await this.flattenCanvas(clonedCanvas);
    console.log(
      '====getCanvasGrayImgOf3dRelief====scale=',
      scale,
      'canvasWidth=',
      canvasWidth,
      'canvasHeight=',
      canvasHeight,
      clonedCanvas,
    );

    const objects = clonedCanvas.getObjects()?.filter((item: any) => !item.id?.includes(WorkspaceID.WorkspaceCavas));
    const workspace = clonedCanvas.getObjects().find((item) => (item as any).id === (WorkspaceID.WorkspaceCavas));

    var textureTypeTemp: TextureType | null = null;
    for (let i = 0; i < objects.length; i++) {
      const obj = objects[i] as any;

      if (obj.type === FabricObjectType.Image && obj.textureType) {
        let texture3dGrayImageItem: Texture3dGrayImageItem = {
          grayType: obj.textureType,
          grayImg: '',
          grayColorImg: '',
          thickness: obj.thickness,
          id: obj.id,
        };
        texture3dGrayImageItem.thickness = obj.thickness;

        textureTypeTemp = obj.textureType;
        var isCanvasTexture = obj.isCanvasTexture;
        console.log('=====isCanvasTexture====for=1111=', isCanvasTexture);

        const canvasWorkTemp = document.createElement('canvas');
        canvasWorkTemp.width = canvasWidth;
        canvasWorkTemp.height = canvasHeight;
        // 添加背景图
        const tempWorkCtx = canvasWorkTemp.getContext('2d');
        if (!tempWorkCtx) continue;
        tempWorkCtx.globalCompositeOperation = 'source-in';
        workspace!.render(tempWorkCtx!);

        const canvasTemp = document.createElement('canvas');
        canvasTemp.width = canvasWidth;
        canvasTemp.height = canvasHeight;
        // 添加当前图片
        const tempCtx = canvasTemp.getContext('2d');
        if (!tempCtx) continue;
        const newImage = await this.cloneGrayImage(editor, obj);
        newImage.render(tempCtx!);

        // var grayTemp = canvasTemp.toDataURL();
        // console.log("====getCanvasGrayImgOf3dRelief====for=1111100000=", grayTemp)

        if (i + 1 < objects.length) {
          const canvasTempFont = document.createElement('canvas');
          canvasTempFont.width = canvasWidth;
          canvasTempFont.height = canvasHeight;
          const tempFontCtx = canvasTempFont.getContext('2d');
          if (!tempFontCtx) continue;

          const canvasTempColorFont = document.createElement('canvas');
          canvasTempColorFont.width = canvasWidth;
          canvasTempColorFont.height = canvasHeight;
          const tempFontColorCtx = canvasTempColorFont.getContext('2d');
          if (!tempFontColorCtx) continue;
          for (let j = i + 1; j < objects.length; j++) {
            const innerObj = objects[j] as any;
            // 如果是cmyk和浮雕，下面灰度图不需要处理
            if (
              (textureTypeTemp == TextureType.RELIEF || textureTypeTemp == TextureType.CMYK) &&
              !innerObj.textureType
            ) {
              continue;
            }
            //处理灰度图
            innerObj.render(tempFontCtx!);
            tempCtx.globalCompositeOperation = 'destination-out';
            tempCtx.drawImage(canvasTempFont, 0, 0, canvasTemp.width, canvasTemp.height);
            tempFontCtx.clearRect(0, 0, canvasTempFont.width, canvasTempFont.height);
          }
        }
        tempWorkCtx.drawImage(canvasTemp, 0, 0, canvasTemp.width, canvasTemp.height);

        var grayImg = canvasWorkTemp.toDataURL();
        if (!(isCanvasTexture && textureTypeTemp == TextureType.GLOSS)) {
          try {
            const image = await this.base64ToImage(grayImg);
            let img = this.cv.imread(image);
            console.log('====getCanvasGrayImgOf3dRelief====textureTypeTemp=11111=');
            try {
              img = this.replaceBlackWithTransparent(img);
              console.log('====getCanvasGrayImgOf3dRelief====textureTypeTemp=22222=');
              var grayColorImg = await this.combineImages(
                this.matToBase64(img),
                canvasPreviewImg,
                canvasTemp.width,
                canvasTemp.height,
              );
              texture3dGrayImageItem.grayColorImg = grayColorImg;
            } finally {
              img.delete(); // 确保释放 img
            }
          } catch (e) {
            console.error('=====grayColorImg==error=', e);
          }
        }
        if (!bgIsTrans) {
          texture3dGrayImageItem.grayImg = await this.replaceTransparentWithBlack(grayImg);
        } else {
          texture3dGrayImageItem.grayImg = grayImg;
        }

        grayImgs.push(texture3dGrayImageItem);
      }
    }
    console.log('=====getCanvasGrayImgOf3dRelief grayImgs=====', grayImgs);
    return { grayImgs, canvasPreviewData };
  }

  public combineImages(baseImgUrl: string, overlayImgUrl: string, width: number, height: number): Promise<string> {
    return new Promise((resolve, reject) => {
      // 创建一个新的 canvas 元素
      var compositeCanvas = document.createElement('canvas');
      var compositeContext = compositeCanvas.getContext('2d');

      // 设置新 canvas 的宽高
      compositeCanvas.width = width;
      compositeCanvas.height = height;

      // 创建图像对象用于加载图像数据
      var baseImage = new Image();
      var overlayImage = new Image();

      // 加载 baseImgUrl
      baseImage.src = baseImgUrl;
      baseImage.onload = function () {
        // 将 baseImgUrl 绘制到新 canvas 上
        compositeContext!.drawImage(baseImage, 0, 0);

        // 设置 globalCompositeOperation 为 'source-atop'
        compositeContext!.globalCompositeOperation = 'source-atop';

        // 加载 overlayImgUrl
        overlayImage.src = overlayImgUrl;
        overlayImage.onload = function () {
          // 将 overlayImgUrl 绘制到新 canvas 上
          compositeContext!.drawImage(overlayImage, 0, 0);

          // 获取合成后的图像数据 URL
          var combinedImgUrl = compositeCanvas.toDataURL();
          resolve(combinedImgUrl);
        };

        overlayImage.onerror = function (e) {
          reject(new Error('Failed to load overlay image'));
        };
      };

      baseImage.onerror = function (e) {
        reject(new Error('Failed to load base image'));
      };
    });
  }

  /**
   * 打印获取到的灰度图
   * @param editor
   * @returns
   */
  public async getCanvasGrayImgOfPrint(editor: Editor, projectModel: ProjectModel): Promise<Texture3dGrayPrint> {
    var grayImgs: Texture3dGrayImageItem[] = (await this.getCanvasGrayImgOf3dRelief(editor, true, projectModel, true))
      .grayImgs;
    var texture3dGrayPrint: Texture3dGrayPrint = {
      mergeGrayImg: '',
      glossGrayImg: '',
      thickness: 0,
    };
    console.log('=====getCanvasGrayImgOfPrint==start==', grayImgs);

    const reliefItem = grayImgs.find((item) => item.grayType === TextureType.RELIEF);
    const reliefItemNotOnly = grayImgs.find((item) => item.grayType != TextureType.RELIEF);
    const glossItems: Texture3dGrayImageItem[] = grayImgs.filter((item) => item.grayType === TextureType.GLOSS);
    console.log('=====getCanvasGrayImgOfPrint==0000==', glossItems);

    if (glossItems && glossItems.length > 0) {
      console.log('=====getCanvasGrayImgOfPrint==111111==', reliefItem);
      texture3dGrayPrint.glossGrayImg = await this.mergeGray(glossItems);
    }
    console.log('=====getCanvasGrayImgOfPrint==22222==', reliefItem);

    if (reliefItem && reliefItemNotOnly) {
      //包含浮雕，需要灰度图归一化
      let combinedImg = null;
      let maxThickness = 0;

      // 找到最大打印高度
      for (let item of grayImgs) {
        if (item.thickness > maxThickness) {
          maxThickness = item.thickness;
        }
      }
      texture3dGrayPrint.thickness = maxThickness;
      console.log('=====getCanvasGrayImgOfPrint==combinedImg mask0000==');
      for (let item of grayImgs) {
        // 读取灰度图
        const image = await this.base64ToImage(item.grayImg);
        let img = this.cv.imread(image);

        img = this.replaceBlackWithTransparent(img);
        // console.log('=====getCanvasGrayImgOfPrint==combinedImg end==', tempMap)

        // 调整灰度图的高度范围
        let adjustedImg = new this.cv.Mat();
        img.convertTo(adjustedImg, this.cv.CV_8UC4, item.thickness / maxThickness); // * 255.0 / 255.0

        if (combinedImg === null) {
          // 如果是第一张图像，直接赋值
          combinedImg = adjustedImg.clone();
        } else {
          this.cv.max(combinedImg, adjustedImg, combinedImg);
          adjustedImg.delete(); // 释放内存
        }
        img.delete(); // 释放内存
      }
      console.log('=====getCanvasGrayImgOfPrint==22222==', reliefItem);

      // 归一化合成后的灰度图到0-255范围
      let finalImg = new this.cv.Mat();
      this.cv.normalize(combinedImg, finalImg, 0, 255, this.cv.NORM_MINMAX);

      // 将合成后的图像保存为base64字符串
      let canvas = document.createElement('canvas');
      this.cv.imshow(canvas, finalImg);
      texture3dGrayPrint.mergeGrayImg = canvas.toDataURL('image/png');

      // 释放内存
      combinedImg.delete();
      finalImg.delete();
    } else {
      //不包含浮雕，直接灰度图合成
      texture3dGrayPrint.mergeGrayImg = await this.mergeGray(grayImgs);
      texture3dGrayPrint.thickness = grayImgs[0].thickness;
    }
    console.log('=====getCanvasGrayImgOfPrint==end==', texture3dGrayPrint);
    return texture3dGrayPrint;
  }

  private replaceBlackWithTransparent(img: any) {
    // console.log('===replaceBlackWithTransparent===tempImg==start', tempImg)
    let dst = new this.cv.Mat(img.rows, img.cols, this.cv.CV_8UC4, new this.cv.Scalar(0, 0, 0, 0)); // 创建 dst
    this.cv.cvtColor(img, img, this.cv.COLOR_RGB2RGBA);

    let mask = new this.cv.Mat(); // 创建 mask
    let lowerBound = new this.cv.Mat(img.rows, img.cols, img.type(), [0, 0, 0, 0]); // 创建 lowerBound
    let upperBound = new this.cv.Mat(img.rows, img.cols, img.type(), [0, 0, 0, 255]); // 创建 upperBound
    let invertedMask = new this.cv.Mat(); // 创建 invertedMask
    let kernel = this.cv.getStructuringElement(this.cv.MORPH_RECT, new this.cv.Size(3, 3)); // 创建 kernel
    try {
      this.cv.inRange(img, lowerBound, upperBound, mask);
      // 反转掩码，找到所有非黑色像素
      this.cv.bitwise_not(mask, invertedMask);
      // 形态学操作，膨胀和腐蚀
      this.cv.dilate(invertedMask, invertedMask, kernel);
      this.cv.erode(invertedMask, invertedMask, kernel);

      img.copyTo(dst, invertedMask);
    } catch (e) {
      console.log('===replaceBlackWithTransparent===error', e);
    } finally {
      // 释放内存
      mask.delete(); // 确保释放 mask
      invertedMask.delete(); // 确保释放 invertedMask
      lowerBound.delete(); // 确保释放 lowerBound
      upperBound.delete(); // 确保释放 upperBound
      kernel.delete(); // 确保释放 kernel
    }
    // console.log('===replaceBlackWithTransparent===tempImg==', tempImg1)
    return dst;
  }

  private async mergeGray(items: Texture3dGrayImageItem[]): Promise<string> {
    // 初始化合成图像
    let combinedImg = null;
    console.log('=====getCanvasGrayImgOfPrint==mergeGray start==', items);

    for (let item of items) {
      // 读取灰度图
      console.log('=====getCanvasGrayImgOfPrint==mergeGray start0000==', this.cv, this.cv.IMREAD_GRAYSCALE);
      const image = await this.base64ToImage(item.grayImg);
      let img = this.cv.imread(image);
      console.log('=====getCanvasGrayImgOfPrint==mergeGray 0000==');

      if (combinedImg === null) {
        // 如果是第一张图像，直接赋值
        combinedImg = img.clone();
      } else {
        // 合成图像
        this.cv.max(combinedImg, img, combinedImg);
        img.delete(); // 释放内存
      }
      console.log('=====getCanvasGrayImgOfPrint==mergeGray 1111==');
    }
    console.log('=====getCanvasGrayImgOfPrint==mergeGray end==');
    var imgBase64 = this.matToBase64(combinedImg);
    // 释放内存
    combinedImg.delete();
    return imgBase64;
  }

  private base64ToImage(base64: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = `${base64}`;
    });
  }

  private matToBase64(mat: any): string {
    // 创建一个 canvas 元素
    let canvas = document.createElement('canvas');
    this.cv.imshow(canvas, mat);
    // 将 canvas 转换为 base64 字符串
    return canvas.toDataURL();
  }

  // 使用 OpenCV.js 将透明区域改为黑色
  public replaceTransparentWithBlack = (base64Img: string, invert?: boolean): Promise<string> => {
    const img = new Image();
    img.src = base64Img;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    return new Promise<string>((resolve) => {
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx!.drawImage(img, 0, 0);
        const imageData = ctx!.getImageData(0, 0, canvas.width, canvas.height);
        // 使用 OpenCV.js 处理图像
        const src = this.cv.matFromImageData(imageData);
        const dst = new this.cv.Mat();
        const mask = new this.cv.Mat();
        this.cv.cvtColor(src, mask, this.cv.COLOR_RGBA2GRAY);
        this.cv.threshold(mask, mask, 0, 255, this.cv.THRESH_BINARY_INV);
        if (invert) {
          src.setTo(new this.cv.Scalar(255, 255, 255, 255), mask);
        } else {
          src.setTo(new this.cv.Scalar(0, 0, 0, 255), mask);
        }

        this.cv.imshow(canvas, src);
        src.delete();
        dst.delete();
        mask.delete();
        resolve(canvas.toDataURL());
      };
    });
  };

  private async cloneGrayImage(editor: Editor, obj: any): Promise<fabric.Object> {
    return await new Promise<fabric.Object>((resolve, reject) => {
      const oldClipPath = obj.clipPath;
      var scaleWidth = obj.width * obj.scaleX;
      var scaleHeight = obj.height * obj.scaleY;
      obj.setSrc(
        obj.grayscale,
        () => {
          obj.scaleToWidth(scaleWidth);
          obj.scaleToHeight(scaleHeight);
          if (oldClipPath && scaleWidth != 1) {
            //@ts-ignore
            const newClipPath = fabric.util.object.clone(oldClipPath);
            obj.set({
              clipPath: newClipPath,
            });
          }
          // const objProps = obj.toJSON(EDITOR_JSON_KEY);
          // let img = obj.toDataURL();
          // console.log('============cloneGrayImage==end=', img, obj, objProps)
          resolve(obj);
        },
        { crossOrigin: 'anonymous' },
      );
    });
  }

  private async cloneCanvas(editor: Editor): Promise<fabric.Canvas> {
    //@ts-ignore
    const tempCanvas = new fabric.Canvas(null, {
      width: editor.canvas.width,
      height: editor.canvas.height,
    });
    return new Promise<fabric.Canvas>((resolve, reject) => {
      editor.insertSvgFileTemp(JSON.stringify(editor.getJson()), tempCanvas).then(() => {
        resolve(tempCanvas);
      });
    });
  }

  public getElementPosition(element: fabric.Object) {
    const width = element.width! * element.scaleX!;
    const height = element.height! * element.scaleY!;
    let left = element.left!;
    let top = element.top!;
    switch (element.originX) {
      case 'left':
        break;
      case 'center':
        left -= width / 2;
        break;
      case 'right':
        left -= width;
        break;
      default:
        throw new Error(`Unsupported originX: ${element.originX}`);
    }
    switch (element.originY) {
      case 'top':
        break;
      case 'center':
        top -= height / 2;
        break;
      case 'bottom':
        top -= height;
        break;
      default:
        throw new Error(`Unsupported originY: ${element.originY}`);
    }
    return { left, top };
  }

  private async flattenCanvas(canvas: fabric.Canvas): Promise<void> {
    const objects = canvas.getObjects();
    const allObjects: fabric.Object[] = [];

    // console.log('=====flattenCanvas====start=', objects);

    const getAbsoluteCoords = (obj: any) => {
      const matrix = obj.calcTransformMatrix();
      const options = { x: obj.left, y: obj.top };
      //@ts-ignore
      const point = new fabric.Point(options.x, options.y);
      //@ts-ignore
      const transformedPoint = fabric.util.transformPoint(point, matrix);
      return {
        x: transformedPoint.x - (obj.width * obj.scaleX) / 2,
        y: transformedPoint.y - (obj.height * obj.scaleY) / 2,
      };
    };

    // Helper function to recursively ungroup objects
    const ungroupObjects = async (obj: fabric.Object) => {
      if (obj.type === FabricObjectType.Group && !(obj as any).isSVG) {
        const group = obj as fabric.Group;
        for (const child of group.getObjects()) {
          const clonedChild = await this.cloneObject(child);
          const absoluteCoords = getAbsoluteCoords(child);
          // if (child.type === FabricObjectType.Image && (child as any).textureType) {
          // console.log("=====flattenCanvas====start===_isTextureGroup=", group, (group as any)._isTextureGroup, getElementPosition(group))
          if ((group as any)._isTextureGroup) {
            if (child.type === FabricObjectType.Image && (child as any).textureType) {
              clonedChild.set({
                left: this.getElementPosition(group).left,
                top: this.getElementPosition(group).top,
                scaleX: child.scaleX! * group.scaleX!,
                scaleY: child.scaleY! * group.scaleY!,
                angle: child.angle! + group.angle!,
                originX: 'left',
                originY: 'top',
                opacity: 1,
              });
            } else {
              continue;
            }
          } else {
            clonedChild.set({
              left: absoluteCoords.x,
              top: absoluteCoords.y,
              scaleX: child.scaleX! * group.scaleX!,
              scaleY: child.scaleY! * group.scaleY!,
              angle: child.angle! + group.angle!,
            });
          }
          await ungroupObjects(clonedChild);
          // allObjects.push(clonedChild);
        }
      } else {
        allObjects.push(obj);
      }
    };

    for (const obj of objects) {
      await ungroupObjects(obj);
    }
    canvas.clear();
    allObjects.forEach((obj) => canvas.add(obj));
    // console.log('=====flattenCanvas====end=', allObjects);
  }

  private cloneObject(obj: fabric.Object): Promise<fabric.Object> {
    return new Promise<fabric.Object>((resolve, reject) => {
      obj.clone((clonedObj: fabric.Object) => {
        const objProps = obj.toJSON(EDITOR_JSON_KEY);
        if ((objProps as any).clipPath) {
          delete (objProps as any).clipPath;
        }
        //@ts-ignore
        clonedObj.set({ ...objProps });
        resolve(clonedObj);
      });
    });
  }

  public async convertToGrayscale(
    imageUrl: string,
    invert: boolean = false,
    contrast: number = 1,
  ): Promise<{ grayscaleImage: string }> {
    return new Promise((resolve, reject) => {
      let img = new Image();
      img.src = imageUrl;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d')!;
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        let src = this.cv.imread(canvas);
        let dst = new this.cv.Mat();
        this.cv.cvtColor(src, dst, this.cv.COLOR_RGBA2GRAY);
        dst.convertTo(dst, -1, contrast, 0); // contrast 为 α，亮度为 0
        if (invert) {
          this.cv.bitwise_not(dst, dst);
        }
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        this.cv.imshow(canvas, dst);
        const grayscaleBase64 = canvas.toDataURL('image/png');
        src.delete();
        dst.delete();
        resolve({
          grayscaleImage: grayscaleBase64,
        });
      };
      img.onerror = (err) => {
        reject(new Error('图片加载失败'));
      };
    });
  }

  public async grayToNormalMap(grayBase64: string) {
    return new Promise((resolve) => {
      let img = new Image();
      img.src = grayBase64;
      img.onload = () => {
        try {
          console.log('=====grayToNormalMap=====start==');
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d')!;
          canvas.width = img.width;
          canvas.height = img.height;
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

          let grayImg = this.cv.imread(canvas);
          const cv = this.cv;
          if (grayImg.channels() > 1) {
            cv.cvtColor(grayImg, grayImg, cv.COLOR_RGBA2GRAY);
          }
          // 缩小图像
          // const maxDim = 1000;
          // let scaleFactor = 1;
          // if (grayImg.cols > maxDim || grayImg.rows > maxDim) {
          //   scaleFactor = Math.min(maxDim / grayImg.cols, maxDim / grayImg.rows);
          // }
          // const smallSize = new cv.Size(grayImg.cols * scaleFactor, grayImg.rows * scaleFactor);
          // cv.resize(grayImg, grayImg, smallSize, 0, 0, cv.INTER_AREA);

          // 高斯平滑
          // let sigma = 1.5; // 标准差
          // let ksize = new cv.Size(31, 31); // 核大小
          // cv.GaussianBlur(grayImg, grayImg, ksize, sigma, sigma, cv.BORDER_DEFAULT);

          const gradX = new cv.Mat();
          const gradY = new cv.Mat();
          cv.Sobel(grayImg, gradX, cv.CV_32F, 1, 0, 1);
          cv.Sobel(grayImg, gradY, cv.CV_32F, 0, 1, 1);
          // Step 3: Compute normals
          const normalMap = new this.cv.Mat(grayImg.rows, grayImg.cols, this.cv.CV_32FC3);
          const maxX = this.cv.minMaxLoc(gradX).maxVal;
          const maxY = this.cv.minMaxLoc(gradY).maxVal;
          const maxValue = Math.max(maxX, maxY);
          const intensity = 2.0;
          const strength = maxValue / (maxValue / intensity);
          console.log('gradX type:', gradX.type(), 'size:', gradX.size());
          console.log('gradY type:', gradY.type(), 'size:', gradY.size());
          //归一化梯度
          cv.divide(gradX, new cv.Mat(gradX.rows, gradX.cols, cv.CV_32F, new cv.Scalar(maxValue)), gradX);
          cv.divide(gradY, new cv.Mat(gradY.rows, gradY.cols, cv.CV_32F, new cv.Scalar(maxValue)), gradY);
          // 创建一个与 gradX 和 gradY 尺寸相同的矩阵 dzMat
          const dz = 1.0 / strength;
          const dzMat = new cv.Mat(gradX.rows, gradX.cols, cv.CV_32F, new cv.Scalar(dz));

          // 计算法线向量的长度
          const length = new cv.Mat();
          cv.magnitude(gradX, gradY, length);
          cv.add(length, dzMat, length);
          cv.sqrt(length, length);

          // 归一化法线向量
          const normalX = new cv.Mat();
          const normalY = new cv.Mat();
          const normalZ = new cv.Mat();
          cv.divide(gradX, length, normalX);
          cv.divide(gradY, length, normalY);
          cv.divide(dzMat, length, normalZ);
          // 转换到 0-1 范围并存储在 normalMap
          const half = new cv.Mat(normalX.rows, normalX.cols, cv.CV_32F);
          half.setTo(new cv.Scalar(0.5));
          cv.addWeighted(normalX, 0.5, half, 1, 0, normalX);
          cv.addWeighted(normalY, 0.5, half, 1, 0, normalY);
          cv.addWeighted(normalZ, 0.5, half, 1, 0, normalZ);
          //合并通道
          const channels = new cv.MatVector();
          channels.push_back(normalX);
          channels.push_back(normalY);
          channels.push_back(normalZ);
          cv.merge(channels, normalMap);

          // let restoreSize = true;
          // if (restoreSize) {
          //   // 放大图像
          //   cv.resize(normalMap, normalMap, new cv.Size(grayImg.cols, grayImg.rows), 0, 0, cv.INTER_LINEAR);
          // }

          ctx.clearRect(0, 0, canvas.width, canvas.height);
          this.cv.imshow(canvas, normalMap);
          const grayscaleBase64 = canvas.toDataURL('image/png');
          // 释放内存
          grayImg.delete();
          gradX.delete();
          gradY.delete();
          normalMap.delete();
          dzMat.delete();
          length.delete();
          normalX.delete();
          normalY.delete();
          normalZ.delete();
          half.delete();
          channels.delete();
          console.log('=====grayToNormalMap=====end==');
          resolve(grayscaleBase64);
        } catch (e) {
          console.log('=====grayToNormalMap=====error==', e);
          resolve('');
        }
      };
    });
  }

  public async base64ToGrayscale(imageBase64: string): Promise<{ grayscaleImage: string }> {
    return new Promise((resolve, reject) => {
      let img = new Image();
      img.src = imageBase64;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d')!;
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        let src = this.cv.imread(canvas);
        let dst = new this.cv.Mat();
        this.cv.cvtColor(src, dst, this.cv.COLOR_RGBA2GRAY);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        this.cv.imshow(canvas, dst);
        const grayscaleBase64 = canvas.toDataURL('image/png');
        src.delete();
        dst.delete();
        resolve({
          grayscaleImage: grayscaleBase64,
        });
      };
      img.onerror = (err) => {
        reject(new Error('图片加载失败'));
      };
    });
  }

  public async printClick(
    projectModel: any,
    thickness: number,
    printSource: PrintSource,
    souceImg: Blob,
    souceGray: Blob,
    uploadUrl: string,
  ) {
    const tarball = new Tar(); // 创建一个新的 tar 实例
    var model: PrintLayerModel = {
      printModel: PrintModel.printModel8,
      printLayerData: [],
      imgQuality: PrintQuality.printQuality2,
    };
    var base64SourceImg = await blobToBase64(souceImg);
    var base64GrayImg = await blobToBase64(souceGray);
    const getImageDimensions = (blob: Blob) => {
      return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => {
          resolve({ width: img.width, height: img.height });
        };
        img.src = URL.createObjectURL(blob);
      });
    };
    var dimensions: any = await getImageDimensions(souceImg);
    const enhancedWidth = dimensions.width;
    const enhancedHeight = dimensions.height;
    const format_size_w = StringUtil.pixelToMm(enhancedWidth, 200);
    const format_size_h = StringUtil.pixelToMm(enhancedHeight, 200);

    var subPrintType = ReliefType.print_relief_type_def;

    var grayImg: PrintLayerData;
    if (printSource == PrintSource.print_2d_poster) {
      grayImg = {
        printType: PrintLayerType.printLayerType2,
        printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2,
        layerNum: 1,
        printLayerObjIds: [],
        dataUrl: base64SourceImg,
        grayGlosskUrl: base64GrayImg,
        thickness: thickness || 2,
        grayGlossFileStr: PrintLayerFileStr.printLayerTypeStr5,
      };
    } else {
      grayImg = {
        printType: PrintLayerType.printLayerType2,
        printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2,
        layerNum: 1,
        printLayerObjIds: [],
        dataUrl: base64SourceImg,
        grayCmykUrl: base64GrayImg,
        thickness: thickness || 2,
        grayCmykFileStr: PrintLayerFileStr.printLayerTypeStr4,
      };
    }

    switch (printSource) {
      case PrintSource.print_2d_brush_strokes:
        subPrintType = ReliefType.print_relief_type_brush_strokes;
        break;
      case PrintSource.print_2d_stick:
        subPrintType = ReliefType.print_relief_type_stick;
        break;
      case PrintSource.print_2d_poster:
        subPrintType = ReliefType.print_relief_type_poster;
        break;
    }

    model.printLayerData = [grayImg];

    model.printLayerData.forEach((data, index) => {
      if (data.dataUrl) {
        data.printTypeFileStr = data.printTypeFileStr + index;
        let prefix = data.printTypeFileStr;

        const filename = `${prefix}.png`;
        const fileData = base64ToUint8Array(data.dataUrl!.split(',')[1]);
        data.dataUrl = '';
        tarball.append(filename, fileData);
        console.log('===printLayerData===', data);

        if (data.grayCmykUrl) {
          data.grayCmykFileStr = data.grayCmykFileStr! + index;
          const filename = `${data.grayCmykFileStr}.png`;
          const fileData = base64ToUint8Array(data.grayCmykUrl!.split(',')[1]);
          tarball.append(filename, fileData);
          data.grayCmykUrl = '';
        }
        if (data.grayGlosskUrl) {
          data.grayGlossFileStr = data.grayGlossFileStr! + index;
          const filename = `${data.grayGlossFileStr}.png`;
          const fileData = base64ToUint8Array(data.grayGlosskUrl.split(',')[1]);
          tarball.append(filename, fileData);
          data.grayGlosskUrl = '';
        }
      }
    });
    model.format_size_w = format_size_w;
    model.format_size_h = format_size_h;
    model.format_size_w_non = format_size_w;
    model.format_size_h_non = format_size_h;

    const configData = new TextEncoder().encode(JSON.stringify(model));
    // 将 config.json 文件及其内容添加到 tarball 中
    tarball.append('config.json', configData);

    const blobTar = new Blob([tarball.out], { type: 'application/x-tar' });
    const fileTar = new File([blobTar], 'printLayers.tar', { type: 'application/x-tar' });
    const base64Tar = await blobToBase64(blobTar);
    const md5Tar = await blobToMd5(blobTar);

    let project_id = projectModel.project_info.project_id;
    console.log('printClick =上传完成==', projectModel.canvas, model);
    var url = `project_id=${project_id}&source=${printSource}&handle_id=${getUserInfo()!.user_id}&subPrintType=${subPrintType}`;
    if (isPc()) {
      upload(uploadUrl, fileTar);
      let newCanvas = [
        {
          ...projectModel.canvas,
          thumb_file: {
            thumbnail: base64SourceImg,
          },
          effect_file: {
            effectImage: base64SourceImg,
          },
          print_param: JSON.stringify({
            format_size_w_non: StringUtil.pixelToMm(enhancedWidth, 200),
            format_size_h_non: StringUtil.pixelToMm(enhancedHeight, 200),
            printModel: PrintModel.printModel8,
            subPrintType: subPrintType,
          }),
        },
      ];
      let newProjectModel = {
        ...projectModel,
        canvas: newCanvas,
      };
      let model: PrintToPcModel = {
        project_id: project_id,
        project_info: JSON.stringify(newProjectModel?.project_info),
        canvases: JSON.stringify(newProjectModel.canvas),
        sn: '',
        rectIndex: 0,
      };
      model.file_tar = base64Tar;
      model.file_md5 = md5Tar;
      sendCommandToPcWithResponse(CustomPcAction.Command_Have_Printer, (data: any) => {
        if (data) {
          sendCommandToPc(CustomPcAction.PrintAction, model);
        } else {
        }
      });
    } else {
      // 等待上传tar包
      const uploadResult = await upload(uploadUrl, fileTar);
      schemeUrlPC(url);
    }
  }
}
