import React, { useState, useEffect } from 'react';
import Popover from '@mui/material/Popover';
import './index.scss';
import ButtonPublic from '../ButtonPublic';
import collect_icon from '../../../../images/2dEditor/collect_icon.png';
import { IconButton } from '@mui/material';
import { Close } from '@mui/icons-material';
import clsx from 'clsx';
import useDataCache from '../../utils/DataCache';
import { getCollectOfficialt, getLikeWorks } from '../../service/2dEditService';
import Avatar from '@mui/material/Avatar';
import { deepOrange, deepPurple } from '@mui/material/colors';

export default function CardPopover(props: any) {
  const { data, open, anchorEl, onClose, onNowLike_status, type, active } = props;
  const [NewData, setNewData] = useState<any>(data);
  const [loading, setLoading] = useState(false);

  const StarItClick = async () => {
    setLoading(true);
    const isLiked = NewData.like_status === 1;
    const params: any = {
      works_id: data?.id,
    };
    const ElementMenusParams: any = {
      official_material_id: data?.id,
      type: 3,
    };
    const TextMenusParams: any = {
      official_material_id: data?.id,
      type: 2,
    };

    // 1:已收藏 2:未收藏(true调用收藏接口，false调用取消收藏接口)
    if (type === 'ElementMenus') {
      const res = await getCollectOfficialt(ElementMenusParams, !isLiked);
      setLoading(false);
      const newLikeStatus = isLiked ? 2 : 1;
      onNowLike_status(newLikeStatus);
      // onClose();
      setNewData({
        ...NewData,
        like_status: NewData.like_status === 1 ? 2 : 1,
      });
    } else if (type === 'TextMenus') {
      const res = await getCollectOfficialt(TextMenusParams, !isLiked);
      setLoading(false);
      const newLikeStatus = isLiked ? 2 : 1;
      onNowLike_status(newLikeStatus);
      setNewData({
        ...NewData,
        like_status: NewData.like_status === 1 ? 2 : 1,
      });
    } else if (type === 'Templates') {
      const res = await getLikeWorks(params, !isLiked);
      setLoading(false);
      const newLikeStatus = isLiked ? 2 : 1;
      onNowLike_status(newLikeStatus);
      // onClose();
      setNewData({
        ...NewData,
        like_status: NewData.like_status === 1 ? 2 : 1,
      });
    }
  };

  return (
    <Popover
      open={open}
      anchorReference="anchorPosition"
      anchorPosition={anchorEl}
      onClose={onClose}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'right',
      }}
      // transformOrigin={{
      //   vertical: 'top',
      //   horizontal: 'right',
      // }}
    >
      <div className="popover_CardPopover_box">
        <div className="CardPopover_top_box">
          {/* 通过样式控制展示省略号 */}
          <div className="CardPopover_title">{NewData?.title}</div>
          <div
            className="CardPopover_close_box"
            onClick={() => {
              onClose();
            }}
          >
            {/* @ts-ignore */}
            <Close className="CardPopover_close" />
          </div>
        </div>
        <div className="CardPopover_user">
          {NewData?.avatar ? (
            <img
              src={NewData.avatar}
              className="CardPopover_avatar"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
          ) : (
            // @ts-ignore
            <Avatar sx={{ bgcolor: deepOrange[500] }} className="IconImage">
              {NewData.username?.slice(0, 1)}
            </Avatar>
          )}
          <div className="CardPopover_username">
            {/* 当是中文时，使用默认值。当是英文时，则首字母大写 */}
            {NewData?.username
              ? /^[A-Za-z]/.test(NewData.username)
                ? NewData.username.charAt(0).toUpperCase() + NewData.username.slice(1)
                : NewData.username
              : ''}
          </div>
        </div>
        <div className="CardPopover_border_top"></div>
        <div className="CardPopover_span">
          {NewData?.CategoryList?.map((item: any) => {
            return <span>{item}</span>;
          })}
        </div>
        <div className="CardPopover_border_down"></div>
        {/* <ButtonPublic
          variant='greenWhite'
          style={{ width: '100%' }}
          onClick={StarItClick}
          loading={loading}
        >
          {
            NewData?.like_status === 1 ?
              // 已收藏状态
              <img src={collect_icon} className='CardPopover_icon' /> :
              // 未收藏状态
              <div className='CardPopover_icon'>收藏</div>
          }
          Star It
        </ButtonPublic> */}
        {/* 后续待调整，UI暂未给出 */}
        <ButtonPublic variant="greenWhite" style={{ width: '100%' }} onClick={StarItClick} loading={loading}>
          {
            // 1已收藏，2未收藏
            NewData?.like_status === 1 ? 'No Star It' : 'Star It'
          }
        </ButtonPublic>
      </div>
    </Popover>
  );
}
