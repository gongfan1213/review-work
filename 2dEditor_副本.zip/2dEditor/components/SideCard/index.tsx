import React, { useState } from "react";
import "./index.scss";
import Card_details from '../../../../images/2dEditor/Card_details.png'
import Card_collect from '../../../../images/2dEditor/Card_collect.png'
import CardPopover from '../CardPopover'
import useDataCache from '../../utils/DataCache';
import img_error from 'src/assets/svg/img_error.svg'
import MyLazyImage from 'src/components/LazyLoadImage';
// image:图片地址
// isCollect:是否收藏
// isCollectClick:是否收藏点击事件
// RulesClick:规则弹窗点击事件
// CardStyle:样式
export default function SideCard(props: any) {
  const { CardData, isCollectClick, CardStyle, CardClick, StarItClick, type, isDetailsIcon = false } = props
  const [NowData, setNowData] = useState<any>(CardData)
  const [popoverOpen, setPopoverOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [isHovered, setIsHovered] = useState(false);
  const [NowLike_status, setNowLike_status] = useState(null)
  const { cacheData, getCacheItem } = useDataCache();

  const RulesClick = (event: any) => {
    const rect = event.currentTarget.getBoundingClientRect();
    // @ts-ignore
    setAnchorEl({ left: rect.left, top: rect.bottom + 5 });
    // setAnchorEl(event.currentTarget);
    setPopoverOpen(true);
  };

  const handlePopoverClose = () => {
    setPopoverOpen(false);
  };

  // 直接匹配当前项id相同的数据替换掉（为了将最新的收藏状态存入缓存）
  function replaceItemById(data: any, newItem: any, type: any) {
    const { id } = newItem.rules;
    // console.log("---------data1233", data);

    if (type === 'ElementMenus') {
      Object.keys(data).forEach((key) => {
        data[key]?.data.forEach((category: any) => {
          category.list = category.list?.map((item: any) => {
            return item?.rules?.id === id ? newItem : item;
          });
        });
      });
    } else if (type === 'TextMenus' || type === 'Templates') {
      data?.forEach((category: any) => {
        category.list = category.list.map((item: any) => {
          return item.rules.id === id ? newItem : item;
        });
      });
    }
    return data;
  }

  const handleNowLike_status = (item: any) => {
    setNowLike_status(item)
    if (type === 'ElementMenus') {
      const now_data = { ...NowData, rules: { ...NowData.rules, like_status: item } }
      setNowData(now_data)
      //需要判断是否是存在搜索值的情况，分别存入缓存
      const cacheMunedata = cacheData('elementMenus') || {};
      replaceItemById(cacheMunedata, now_data, type)
    } else if (type === 'TextMenus') {
      const now_data = { ...NowData, rules: { ...NowData.rules, like_status: item } }
      setNowData(now_data)
      //需要判断是否是存在搜索值的情况，分别存入缓存
      const cacheMunedata = cacheData('textMenu') || {};
      replaceItemById(cacheMunedata, now_data, type)
    }
    else if (type === 'Templates') {
      const now_data = { ...NowData, rules: { ...NowData.rules, like_status: item } }
      setNowData(now_data)
      const cacheMunedata = getCacheItem('templatesMenu');
      replaceItemById(cacheMunedata?.pageData, now_data, type)
    }
  };
  return (
    <div
      className="sidecard_box"
      style={CardStyle}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* NowLike_status不存在时采用接口值，1:已收藏状态 2:未收藏状态 */}
      {NowLike_status !== null ? (
        NowLike_status === 1 ? (
          // 留空位拓展后续UI
          <img src={Card_collect} className="CardCollect" />
        ) : (
          ''
        )
      ) : NowData?.rules?.like_status === 1 ? (
        <img src={Card_collect} className="CardCollect" />
      ) : (
        ''
      )}
      <MyLazyImage
        src={NowData?.image}
        onClick={() => CardClick(NowData)}
        style={{ backgroundColor: '#eceeed', borderRadius: '8px' }}
      />

      {/* <img
        crossOrigin="anonymous"
        loading="lazy"
        src={NowData?.image}
        className="sidecard_img"
        onClick={() => {
          CardClick(NowData)
        }}
        onError={(e: any) => {
          e.target.src = img_error
        }}
      /> */}
      {isHovered && (
        <img
          style={{ display: isDetailsIcon ? '' : 'none' }}
          src={Card_details}
          className="CardRules"
          onClick={RulesClick}
          onError={(e: any) => {
            e.target.src = img_error
          }}
        />
      )}
      <CardPopover
        open={popoverOpen}
        anchorEl={anchorEl}
        onClose={handlePopoverClose}
        onNowLike_status={handleNowLike_status}
        data={NowData?.rules}
        StarItClick={StarItClick}
        type={type}
      />
    </div>
  )
}