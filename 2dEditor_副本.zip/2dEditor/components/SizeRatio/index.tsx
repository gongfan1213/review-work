import React, { useEffect, useState, useRef } from 'react'
import AddIcon from '@mui/icons-material/Add'
import RemoveIcon from '@mui/icons-material/Remove'
import PanToolIcon from '@mui/icons-material/PanTool';
import { useCanvas, useCanvasEditor } from '../../hooks/context'
import './index.scss'

export default function SizeRatio() {
  const canvas = useCanvas()
  const canvasEditor = useCanvasEditor();
  // 优化了缩放比例的计算，避免了重复代码
  const updateZoom = (isAdding: boolean) => {
    const zoom = canvas.getZoom();
    const ratio = zoom / 100;
    const newZoom = isAdding ? zoom + ratio * 10 : zoom - ratio * 10;
    canvas.setZoom(newZoom);
  };

  const handleAdd = () => {
    updateZoom(true);
  };

  const handleRemove = () => {
    updateZoom(false);
  };

  // #region 画布拖拽模式;
  const dragMode = useRef(true);
  // 开始拖拽;
  const startDring = () => {
    canvasEditor?.startDring();
  }
  // 结束拖拽;
  const endDring = () => {
    canvasEditor?.endDring();
  }
  // drag canvas handler;
  const handlePanTool = () => {
    dragMode.current = !dragMode.current;
    dragMode.current ? endDring() : startDring();
  }
  // #endregion ;
  return (
    <div className="SizeRatioBox">
      <div className="remove-btn" onClick={() => handleRemove()}>
        <RemoveIcon></RemoveIcon>
      </div>
      <div>100%</div>
      <div className="add-btn" onClick={() => handleAdd()}>
        <AddIcon></AddIcon>
      </div>

      <div className="pantoo" onClick={() => handlePanTool()}>
        <PanToolIcon></PanToolIcon>
      </div>
    </div>
  )
}
