import React, { useEffect, useState, useRef } from "react";
import './index.scss'
import { useTranslation } from '@volcengine/i18n'
import { useLocation } from '@reach/router'
import history from 'src/images/2dEditor/Apps_icon/history.png'
import { getAiCreditConsumeInfo, getAiCredit } from 'src/templates/2dEditor/service/2dEditService'
import { useProjectData } from 'src/templates/2dEditor/hooks/context'
import { isPc } from 'src/common/jsbridge'
import { get } from 'src/services'
import { AppsDataTYPE, AppsTitle } from 'src/templates/2dEditor/components/FrontApps/const'
import {
  getAiAllData,
  selectHome,
  HomeState,
  getAiModeIntegralData,
  getNowActiveAiModuleData,
  getUserIntegralData,
} from 'src/state/reducers/home'
import { useDispatch, useSelector } from 'react-redux'
import LottiePlayer from 'react-lottie-player'
import LoadingAnimation from 'src/images/lottie/loading.json'
import emptyProjectIcon from "src/images/empty_progress.png";
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';

export default function AppsPage(props: any) {
  const { nextStep, JumpStep, } = props
  const { getTranslation } = useCustomTranslation();
  const { t } = useTranslation()
  const location = useLocation()
  const useProjectDataInfo: any = useProjectData()
  const [AiData, setAiData] = useState<any>(null)
  const homeState: HomeState = useSelector(selectHome)
  const dispatch = useDispatch()
  const DataLoading = useRef(false)
  var AiAllData: any;

  if (typeof window !== 'undefined') {
    // @ts-ignore
    // 获取sessionStorage内存储的AiTools接口数据
    AiAllData = transformData(JSON.parse(window.sessionStorage.getItem('AiToolsAllData'))) || null
    // @ts-ignore
    // 获取sessionStorage内存储的Ai模块消耗积分数据
    var sessionAiModeIntegralData: any = JSON.parse(window.sessionStorage.getItem('sessionAiModeIntegralData')) || null
  }

  // 转换AiTools接口数据
  function transformData(data: any) {
    return data?.map((item: any) => {
      return {
        title: item?.attributes?.title,
        id: item?.id,
        text: item?.attributes?.description,
        img: item?.attributes?.image?.data?.attributes?.formats?.thumbnail?.url
          || item?.attributes?.image?.data?.attributes?.url,
        type: item?.attributes?.frontType?.data?.attributes?.fontName,
        color: item?.attributes?.backgroundColor,
        costClass: item?.attributes?.class?.data?.attributes?.value,
        toolClass: item?.attributes?.toolClass?.data?.attributes?.class_name,
      }
    });
  }

  useEffect(() => {
    fetchAiCredit()
    fetchUserIntegralData()
    if (homeState?.AiAllCacheData) {
      setAiData(homeState?.AiAllCacheData)
    } else if (!AiAllData) {
      // sessionStorage中没有AiAllData数据，则请求接口
      fetchAllToolsDataCms()
    } else {
      setAiData(AiAllData)
      dispatch(getAiAllData(AiAllData))
      dispatch(getAiModeIntegralData(sessionAiModeIntegralData))
    }
  }, [])


  // 获取ai模块消耗积分
  const fetchAiCredit = async () => {
    if (!sessionAiModeIntegralData) return
    const data: any = await getAiCreditConsumeInfo()
    dispatch(getAiModeIntegralData(data?.data?.consume_info))
  }

  const fetchUserIntegralData = async () => {
    const data: any = await getAiCredit({ need_detail: false })
    dispatch(getUserIntegralData(data?.data?.available_amount))
  }

  // 请求cms接口-AI tools
  const fetchAllToolsDataCms = async () => {
    DataLoading.current = true
    let result; // 在try块之外声明result
    try {
      result = await get<any>('/web/cms-proxy/common/content', {
        // cms接口地址
        content_type: 'make-2d-all-tools',
        populate: [
          'image',
          'title',
          'description',
          'backgroundColor',
          'frontType',
          'class',
          'toolClass',
        ],
        pagination: {
          page: 1,
          pageSize: 10000,
        },
        sort: ['weight:DESC'], // 按weight降序排列
      })
      setAiData(transformData(result?.data?.data))
      // 存储数据，避免重复请求
      dispatch(getAiAllData(transformData(result?.data?.data)))
    } catch (error) {
      console.log('Failed to fetch tools data:', error)
      // 可以在这里处理错误，例如设置错误状态、显示错误消息等
    } finally {
      DataLoading.current = false
    }
    return result
  }

  useEffect(() => {
    if (!AiAllData) return
    if (typeof window !== 'undefined') {
      // 2d详情页跳转过来
      const params = new URLSearchParams(window?.location?.search || location?.location?.search);
      const AiTitle = window.sessionStorage.getItem('AiTitle') || params.get('AiTitle')
      console.log('======AppsPage====AiTitle=', AiTitle,)
      // 2d详情页跳转过来传递的ai模块数据
      // console.log("AiAllData----===", AiAllData);
      let findItem = AiAllData?.find((item: any) => {
        return item?.title == AiTitle
      })
      console.log("getNowActiveAiModuleData", findItem);
      if (findItem) {
        // 传递当前活跃的ai模块数据
        dispatch(getNowActiveAiModuleData(findItem))
        // 当点击的是风格画或者是数字分身时，则使用这种跳转方式
        if (AiTitle == AppsTitle['5'] || AiTitle == AppsTitle['6']) {
          JumpStep(findItem.title, findItem.type, 'next')
        } else {
          nextStep(findItem.title, findItem.type)
        }
      }
    }
  }, [])

  useEffect(() => {
    if (!AiAllData) return
    let isPcAiToolTitleId = useProjectDataInfo?.isPcAiToolTitleId
    if (isPcAiToolTitleId && isPc()) {
      let findItem = AiAllData.find((item: any) => {
        return item?.title == isPcAiToolTitleId
      })
      console.log('findItem--pc----===', findItem)
      if (findItem) {
        // 传递当前活跃的ai模块数据
        dispatch(getNowActiveAiModuleData(findItem))
        // 当点击的是风格画或者是数字分身时，则使用这种跳转方式
        if (isPcAiToolTitleId == AppsTitle['5'] || isPcAiToolTitleId == AppsTitle['6']) {
          JumpStep(findItem.title, findItem.type, 'next')
        } else {
          nextStep(findItem.title, findItem.type)
        }
      }
    }
  }, [useProjectDataInfo])

  const NextClick = (item: any) => {
    console.log("当前点击的数据详情", item)
    // 点击所有ai模块时的埋点
    StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.canvas_aiTool_click, item?.type);
    // 传递当前活跃的ai模块数据
    dispatch(getNowActiveAiModuleData(item))
    if ([AppsDataTYPE['5'], AppsDataTYPE['6']].includes(item?.type)) {
      JumpStep(item?.title, item?.type, 'next', item)
    } else {
      nextStep(item?.title, item?.type)
    }
  }

  // 筛选出toolClass === 'AITools'的数据
  const filterAITools = (data: any) => {
    return data?.filter((item: any) => item.toolClass === 'AITools');
  };

  // console.log(":filterAITools", filterAITools(AiData));

  return (
    <div className="AppPage_Box">
      <div className="AppPage_Box_top">
        <div className="AppPage_Box_top_left">
          <div className='AppPage_Box_title'>{getTranslation(TranslationsKeys.TITLEAPP)}</div>
        </div>
      </div>
      <div className="btn_box" onClick={() => { nextStep('History_box', '', 5, 'home') }}>
        <img src={history} className="book_icon" />
        <div className="text">{getTranslation(TranslationsKeys.GenerateHistory)}</div>
      </div>
      {
        DataLoading.current ?
          <div className="load">
            <LottiePlayer
              loop
              play
              className="loadingBox"
              animationData={LoadingAnimation}
            />
          </div>
          : AiData?.length !== 0
            ? <div className="AppPage_item_box">
              {
                filterAITools(AiData)?.map((item: any, index: any) => {
                  return (
                    <div className="AppPage_item"
                      style={{ backgroundColor: item?.color ? `${item?.color}` : '' }}
                      onClick={() => { NextClick(item) }}
                    >
                      <div className="AppPage_item_left">
                        <div className="AppPage_item_title">{item?.title}</div>
                        <div className="AppPage_item_text">{item?.text}</div>
                      </div>
                      {
                        <img
                          src={item?.img}
                          style={{
                            width: '148px',
                            height: '120px',
                            borderRadius: '4px',
                            objectFit: 'cover'
                          }}
                        />
                      }
                    </div>
                  )
                })
              }
            </div>
            : <div className="nodata">
              <img className="nodataImg" src={emptyProjectIcon} alt="" />
              <p className="nodataText">{getTranslation(TranslationsKeys.NO_PROJECT)}</p>
            </div>
      }

    </div>
  )
}