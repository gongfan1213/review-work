import React, { useState, useEffect, useCallback, useRef } from "react";
import './index.scss';
import appbar_download_icon from '../../../../../images/2dEditor/Apps_icon/appbar_download_icon.png'
import Icon_Coins from '../../../../../images/2dEditor/Apps_icon/Icon_Coins.png'
import book_icon from '../../../../../images/2dEditor/book_icon.png'
// @ts-ignore
import login_img from '../../../../../images/2dEditor/Apps_icon/login_img.gif'
import return_icon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png'
import TipsPopover from '../../TipsPopover'
import { getImgStr, selectFiles } from 'src/templates/2dEditor/utils/utils';
import { getImgCompress, fileToBase64 } from 'src/common/utils';
import { upload2dEditFile } from 'src/hooks/useUpload';
import { GetUpTokenFileTypeEnum } from 'src/services';
import { createUserMaterial, } from 'src/templates/2dEditor/service/2dEditService';
import { useEvent, useCanvasEditor } from 'src/templates/2dEditor/hooks/context';
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common';
import { StartCreate_task, getTaskStatus, PopArtify_task } from "../../../service/2dEditService";
import { convertToBase64 } from 'src/common/utils';
import Loading from 'src/components/Loading';
import useDataCache from '../../../utils/DataCache';
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';
import { AppsDataTYPE } from 'src/templates/2dEditor/components/FrontApps/const'
import left_icon from 'src/images/2dEditor/Apps_icon/left_icon.png'
import right_icon from 'src/images/2dEditor/Apps_icon/right_icon.png'
import clear_icon from 'src/images/2dEditor/clear_icon.png'
import { EditorToastType, editorToastHidden, editorToastShow } from 'src/templates/2dEditor/components/Toast';
import TipsModal from 'src/templates/2dEditor/components/FrontApps/components/TipsModal'
import { checkFileSize } from 'src/templates/2dEditor/utils/checkFileSize';
import loading_icon from 'src/assets/svg/loading.svg';
import MyLazyImage from 'src/components/LazyLoadImage';
import LottiePlayer from 'react-lottie-player'
import LoadingAnimation from 'src/images/lottie/loading.json'
import Slider from '@mui/material/Slider';
import { useDispatch, useSelector } from 'react-redux'
import {
  selectHome,
  HomeState,
  getUserIntegralData,
} from 'src/state/reducers/home'
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";
import { measureExecutionTime } from 'src/common/utils/PublicMethods'

// type：大类，step：步骤数，title：标题，nextStep：前往下一步，
// prevStep：上一步，Step2Data：步骤二表格数据，Step4Data：步骤四数据（底部上传数据）
// handlePetData：传递到pet的数据方法，PetTransferData：传递到上传模块数据
// setStep4Data：修改pet中上传模块数据
export default function Pet(props: any) {
  const homeState: HomeState = useSelector(selectHome)
  const dispatch = useDispatch()
  const { getTranslation } = useCustomTranslation();
  const { type, step, title, nextStep, prevStep, Step2Data, Step4Data, handlePetData, PetTransferData, setStep4Data } = props

  const { setCacheItem, getCacheItem, cacheData, cacheHasMore, cachePageSize } = useDataCache();
  let timeoutId: NodeJS.Timeout | null = null;
  const [PopoverOpen, setPopoverOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [TopData, setTopData] = useState<any>(null)
  const [listData, setListData] = useState<any>([])
  const [downUpload, setDownUpload] = useState<any>({});
  const [clearUpload, setClearUpload] = useState(false)
  const [CreatTask_id, setCreatTask_id] = useState<any>('')
  const [Progress, setProgress] = useState(0)//生成进度
  const [GeneratingStatus, setGeneratingStatus] = useState(null)//生成状态
  const [showOverlay, setShowOverlay] = useState(false); // 新增状态变量
  const canvasEditor = useCanvasEditor();
  const [isNetLoading, setNetLoading] = useState(false)
  const event = useEvent();
  const isLoadingState = useRef(false)
  const nowType = (type === AppsDataTYPE['1'])
  const [sliderValue, setSliderValue] = useState(0);
  // 当前模块需要的积分
  const [NowModulIntegral, setNowModulIntegral] = useState(1)//默认1积分
  // 用户的总积分
  let UserAllIntegral = homeState?.UserIntegral

  const icon_click = (direction: 'left' | 'right') => {
    // 后期可以优化，切换时清空图片，展示加载动画，避免延迟
    if (!listData) return;
    // 找到当前now为true的项的索引
    const currentIndex = listData.findIndex((item: any) => item.now === true);
    // 根据点击的按钮来更新索引
    let newIndex = direction === 'left' ? currentIndex - 1 : currentIndex + 1;
    // 如果新的索引超出了数组的范围，将其设置为数组的另一端
    if (newIndex < 0) {
      newIndex = listData.length - 1;
    } else if (newIndex >= listData.length) {
      newIndex = 0;
    }
    // 使用新的索引来更新listData
    const updatedData = listData.map((item: any, index: number) => index === newIndex ? { ...item, now: true } : { ...item, now: false });
    const nowItem = updatedData[newIndex];
    setTopData(nowItem)
    setListData(updatedData)
    // 将数据传递到父组件，保存数据，以防进入下一页面时数据丢失
    handlePetData(updatedData, Step2Data?.active)
    setClearUpload(true)
  }

  // 打开下一个页面
  const download_click = (index: number) => {
    // setClearUpload(false)
    nextStep('Uploads', type, 4)
    PetTransferData(index, Step4Data || downUpload, clearUpload)
  }

  // 打开上传模块
  const uploads_click = (index: number) => {
    if (isLoadingState.current) {
      return
    }
    try {
      selectFiles({ accept: '.jpeg,.jpg,.png,.webp', multiple: true }).then((fileList) => {
        Array.from(fileList as FileList).forEach((item) => {
          if (!checkFileSize(item)) {
            return
          }
          isLoadingState.current = true
          setNetLoading(true);
          // editorToastShow({
          //   tips: 'Loading',
          //   type: EditorToastType.loading,
          // })
          getImgCompress(item, 1000, 0, 1).then((blob) => {
            var file: File = new File([blob], item.name, { type: blob.type, lastModified: Date.now() })
            upload2dEditFile(file, GetUpTokenFileTypeEnum.Edit2dLocal).then(async (resp) => {
              const ret = await createUserMaterial({ file_name: resp.key_prefix });
              if (!ret?.data) {
                isLoadingState.current = false
                setNetLoading(false);
                editorToastHidden()
                throw new Error('上传失败');
              }
              if (resp && resp.key_prefix) {
                // console.log("ret?.data", ret?.data);
                setDownUpload((prevData: any) => ({
                  ...prevData,
                  [index]: { 'file_name': ret?.data?.file_name, 'download_url': ret?.data?.download_url }
                }));
                // 是否有upload缓存，如果有缓存，则往缓存内添加这张图片，如果没有，则无需处理直接调接口
                if (cacheData('upload') && cacheData('upload').length > 0) {
                  setCacheItem('upload', { 'pageData': [ret?.data, ...cacheData('upload')] })
                }
                isLoadingState.current = false
                setNetLoading(false);
                editorToastHidden()
              } else {
                isLoadingState.current = false
                setNetLoading(false);
                editorToastHidden()
                throw new Error('上传失败，没有返回 key_prefix');
              }
            }).catch((error) => {
              // 处理上传错误
              console.error(error);
              editorToastHidden()
              isLoadingState.current = false
              setNetLoading(false);
            });
          });

        });
      });
    } catch (e) {
      isLoadingState.current = false
      setNetLoading(false);
      editorToastHidden()
      // throw new Error('上传失败');
    }
  }

  // const Generate_btn_click = () => {
  //   nextStep('History', type, 5)
  // }

  const toggleEdit = (event: any) => {
    setPopoverOpen(true);
    setAnchorEl(event.currentTarget);
  }

  const handlePopoverClose = () => {
    setPopoverOpen(false);
  };

  // 上传后的图片点击时
  const uploadimg = (index: number) => {
    // console.log("-------uploadimg");
    nextStep('Uploads', type, 4)
    PetTransferData(index, Step4Data || downUpload, clearUpload)
  }

  function extractFileNames(data: { [key: string]: { file_name: string, download_url: string } }) {
    return Object.values(data).map(item => item.file_name);
  }

  // 待优化的点，在失败的时候，可以重新获取一次用户积分，确保积分数量正常
  // 获取人物换脸任务进度及结果
  const getTaskStatusData = async (item: string): Promise<any> => {
    return new Promise(async (resolve, reject) => {
      try {
        const data: any = await getTaskStatus({
          task_id: item
        });
        // 任务状态(0:待处理;1:处理中;2:已完成;3:处理失败;4:已取消;)
        // 如果code不为0，或者status不为0或者1（待处理和处理中不能停），停止轮询
        if (data.code !== 0 || (data?.data?.status !== 0 && data?.data?.status !== 1)) {
          if (timeoutId) {
            clearTimeout(timeoutId);
            timeoutId = null;
          }
          // 如果status为3（合成失败的情况）
          if (data?.data?.status === 3) {
            editorToastShow({
              tips: getTranslation(TranslationsKeys.GENERATE_FAILED_NO_CREDITS_DEDUCTED),
              type: EditorToastType.error,
            });
            //接口失败时，积分需要再加回去。
            UserAllIntegral = UserAllIntegral + NowModulIntegral;
            dispatch(getUserIntegralData(UserAllIntegral));
            resolve({
              value: '0', // 成功
              templateId: item, // 返回 task_id
              type: type //返回类型，用于埋点
            });
          }
          // 后端此处result_list返回数组，只需要取第一个
          if (data?.data?.result_list.length > 0) {
            const fileExtension = data?.data?.result_list[0]?.file_name?.split('.').pop(); // 获取文件后缀
            if (fileExtension === 'svg') {
              const response = await fetch(data?.data?.result_list[0]?.download_url);
              const blob = await response.blob();
              getImgStr(blob).then((file) => {
                canvasEditor?.addSvgFile(file as string);
              });
              resolve({
                value: '1', // 成功
                templateId: item, // 返回 task_id
                type: type //返回类型，用于埋点
              });
            } else {
              const base64 = await convertToBase64(data?.data?.result_list[0]?.download_url);
              canvasEditor?.addImage(base64, {
                importSource: ImportSource.Cloud,
                fileType: fileExtension,
                key_prefix: data?.data?.result_list[0]?.file_name,
              });
              resolve({
                value: '1', // 失败
                templateId: item, // 返回 task_id
                type: type //返回类型，用于埋点
              });
            }
          }
          setShowOverlay(false); // 清理定时器时隐藏蒙版
        } else {
          setProgress(data?.data?.progress);
          setGeneratingStatus(data?.data?.status);
          // 接口调用成功后，再延迟2秒下一次调用（沟通后的需求）
          timeoutId = setTimeout(() => getTaskStatusData(item).then(resolve).catch(reject), 2000);
        }
      } catch (e) {
        setShowOverlay(false);
        editorToastShow({
          tips: getTranslation(TranslationsKeys.NETWORK_ABNORMAL),
          type: EditorToastType.error,
        });
        reject(e);
      }
    });
  };

  const Generate_click = async () => {
    try {
      if (TopData && downUpload && Object.keys(downUpload).length > 0) {
        setShowOverlay(true); // 显示蒙版
        let data;
        // 当前是人物换脸时
        if (nowType) {
          data = await StartCreate_task({
            template_id: TopData?.id,
            src_images: extractFileNames(downUpload)
          });
        } else if (Object.values(AppsDataTYPE).includes(type)) {
          data = await PopArtify_task({
            template_id: TopData?.id,
            src_image: extractFileNames(downUpload)[0]
          });
        }
        if (data?.code === 0) {
          // 此处扣除的数量需要根据后端返回的数据来确定，且如果接口失败时，需要再加回去。
          // 总积分 - 所有模块[当前模块].积分 = 剩余积分
          UserAllIntegral = UserAllIntegral - NowModulIntegral;
          dispatch(getUserIntegralData(UserAllIntegral));
          // 获取人物换脸任务进度及结果
          return await getTaskStatusData(data?.data?.task_id);
        } else if (data?.code === 220100) {
          setShowOverlay(false);
          editorToastShow({
            tips: getTranslation(TranslationsKeys.INSUFFICIENT_POINTS),
            type: EditorToastType.error,
          });
          return {
            value: '0', // 失败
            templateId: data?.data?.task_id, // 返回 task_id
            type: type //返回类型，用于埋点
          };
        } else {
          setShowOverlay(false);
          editorToastShow({
            tips: getTranslation(TranslationsKeys.FAILED_CREATE_TASK),
            type: EditorToastType.error,
          });
          return {
            value: '0', // 失败
            templateId: data?.data?.task_id, // 返回 task_id
            type: type //返回类型，用于埋点
          };
        }
      }
    } catch (e) {
      setShowOverlay(false);
      editorToastShow({
        tips: getTranslation(TranslationsKeys.NETWORK_ABNORMAL),
        type: EditorToastType.error,
      });
      throw e; // 重新抛出异常，以便在 measureExecutionTime 中捕获
    }
  };

  const measuredNextClick = measureExecutionTime(Generate_click);


  useEffect(() => {
    if (step === 3) {
      // 进入页面时，设置默认大图图片
      const nowItem = Step2Data?.data?.find((item: any) => item.now === true);
      console.log("setTableDatanowItem====", nowItem);
      setTopData(nowItem)
      setListData(Step2Data?.data)
      // 底部的下载图片
      setDownUpload(Step4Data)
    }
  }, [step])

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault(); // 阻止默认行为
  }, []);

  // 拖拽时的方法
  const uploadIamge = (action: React.DragEvent<HTMLDivElement>, index: number) => {
    if (isLoadingState.current) {
      return
    }
    action.stopPropagation(); // 阻止冒泡
    action.preventDefault(); // 阻止默认行为
    const files = action.dataTransfer.files;
    if (files.length > 0) {
      Array.from(files as FileList).forEach((item) => {
        if (!checkFileSize(item)) {
          return
        }
        isLoadingState.current = true
        // 打开加载动画
        setNetLoading(true);
        // editorToastShow({
        //   tips: 'Loading',
        //   type: EditorToastType.loading,
        // })
        const fileExtension = item.name.split('.').pop()?.toLowerCase() ?? '';
        if (!/(?:jpeg|jpg|png|webp|svg)$/i.test(fileExtension)) {
          editorToastShow({
            tips: getTranslation(TranslationsKeys.UNSUPPORTED_IMAGE_TYPE),
            type: EditorToastType.error,
          });
          isLoadingState.current = false
          setNetLoading(false);
          // 关闭加载动画
          editorToastHidden()
        } else {
          // console.log('item', item)
          getImgCompress(item, 1000, 0, 1).then((blob) => {
            var file: File = new File([blob], item.name, { type: blob.type, lastModified: Date.now() })
            upload2dEditFile(file, GetUpTokenFileTypeEnum.Edit2dLocal).then(async (resp) => {
              const ret = await createUserMaterial({ file_name: resp.key_prefix });
              if (!ret?.data) {
                isLoadingState.current = false
                setNetLoading(false);
                editorToastHidden()
                throw new Error('上传失败');
              }
              if (resp && resp.key_prefix) {
                // console.log("ret?.data", ret?.data);
                setDownUpload((prevData: any) => ({
                  ...prevData,
                  [index]: { 'file_name': ret?.data?.file_name, 'download_url': ret?.data?.download_url }
                }));
                // 是否有upload缓存，如果有缓存，则往缓存内添加这张图片，如果没有，则无需处理直接调接口
                if (cacheData('upload') && cacheData('upload').length > 0) {
                  setCacheItem('upload', { 'pageData': [ret?.data, ...cacheData('upload')] })
                }
                isLoadingState.current = false
                setNetLoading(false);
                editorToastHidden()
              } else {
                isLoadingState.current = false
                setNetLoading(false);
                editorToastHidden()
                throw new Error('上传失败，没有返回 key_prefix');
              }
            }).catch((error) => {
              // 处理上传错误
              isLoadingState.current = false
              console.error(error);
              editorToastHidden()
              setNetLoading(false);
            });
          });
        }
      })
    }
  }

  const showCloseIcon = () => {
    event?.emitEvent(EventNameCons.EventHiddenCloseIcon, true)
  }

  const clearDownUpload = () => {
    setDownUpload({})
    setStep4Data(null)
  }


  const SliderHange = (newValue: any) => {
    setSliderValue(newValue?.target?.value);
  };

  const returnClick = () => {
    prevStep('', 'Kid', title);
    showCloseIcon();
    setTopData([]);
    // 将滑块默认值恢复为0
    setSliderValue(0);
  }

  useEffect(() => {
    // 当前选中的ai模块所需积分
    if (!homeState?.nowActiveAiModule) return;
    const costClass = homeState.nowActiveAiModule?.costClass;
    const cost = homeState?.AiModeIntegralData?.[costClass]?.cost;
    // console.log("homeState?.AiModeIntegralData", homeState?.AiModeIntegralData);

    if (cost !== undefined) {
      // console.log("-----?数据", cost);

      setNowModulIntegral(cost);
    } else {
      console.log("costClass数据为空，请查看cms中class字段");
    }
  }, [homeState?.nowActiveAiModule]);

  return (
    <div className="Pet_box" style={{ display: step === 3 ? '' : 'none' }}>
      <div className="Pet_box_top">
        <div className="Pet_box_top_left">
          {
            history.length > 0 &&
            <div className="Pet_box_top_img_box"
              onClick={returnClick}
            >
              <img
                src={return_icon}
                className="Pet_box_top_img"
              />
            </div>
          }
          <div className='Pet_box_top_title'>{Step2Data?.active}</div>
        </div>
        <button className="Pet_box_top_btn" onClick={toggleEdit}>{getTranslation(TranslationsKeys.TITLETips)}</button>
        {/* <TipsPopover
          open={PopoverOpen}
          anchorEl={anchorEl}
          onClose={handlePopoverClose}
        // data={CardData}
        /> */}
        <TipsModal
          open={PopoverOpen}
          handlePopoverClose={handlePopoverClose}
          title={title}
          type={type}
        />
      </div>
      <div className="Pet_scroll_box">
        <div className="top_img_box">
          <div className="Pet_img_top_box">
            <MyLazyImage
              src={TopData?.canvas_image}
              key={TopData?.canvas_image}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
          </div>
        </div>
        <img src={left_icon} className="left_icon_img" onClick={() => { icon_click('left') }} />
        <img src={right_icon} className="right_icon_img" onClick={() => { icon_click('right') }} />
        {/* 上传模块 */}
        {
          Array.from({ length: TopData?.faceNumber || 0 }).map((_, index) => (
            // @ts-ignore
            downUpload && downUpload[index] ?
              <div className="upload_img_box">
                <div className="downUpload_box">
                  <img key={index} src={downUpload && downUpload[index]?.download_url} className="upload_img" />
                  <img src={clear_icon} className="clear_icon" onClick={clearDownUpload} />
                  <div className="changePhoto" onClick={() => { uploadimg(index) }}>{getTranslation(TranslationsKeys.ClickToChangePhoto)}</div>
                </div>
              </div>
              : isNetLoading
                ? <div className="isNetLoading_box">
                  <img className="isNetLoading_img" src={loading_icon} />
                  <div className="upload_img_text">{getTranslation(TranslationsKeys.Loading)}...</div>
                </div>
                : <div
                  key={index}
                  className="upload_box"
                  onDragOver={handleDragOver}
                  onDrop={(e) => uploadIamge(e, index)}
                >
                  <div className="upload_box_top">
                    <img src={appbar_download_icon} className="upload_box_img" onClick={() => { uploads_click(index) }} />
                    <div className="upload_box_top_title">{getTranslation(TranslationsKeys.DragOrUploadPhotoHere)}</div>
                    <div className="upload_box_border"></div>
                  </div>
                  <div className="upload_box_down" onClick={() => { download_click(index) }}>
                    {getTranslation(TranslationsKeys.SelectFromUploads)}
                  </div>
                </div>
          ))
        }
        {/* 底部滑块，暂时挂起，待后续接口支持,暂时隐藏 */}
        {/* {(type === AppsDataTYPE['2']
          || type === AppsDataTYPE['3']
          || type === AppsDataTYPE['9']) &&
          <div className="PopArtify_CusSeekBar">
            <div className="Slider_title">Parameter 1</div>
            <div className="sliderStyle">
              {//@ts-ignore
                <Slider defaultValue={sliderValue} className="green-slider" valueLabelDisplay="auto" onChange={SliderHange} />
              }
            </div>
          </div>
        } */}
      </div>

      <div className="Generate_down">
        <div
          // 判断是null与{}
          className={`Generate_btn_left 
            ${downUpload === null ||
              (typeof downUpload === 'object' && Object.keys(downUpload).length === 0)
              ? 'disabled' : ''}`}
          onClick={() => { measuredNextClick() }}>
          <div className="Generate_btn_text">
            {getTranslation(TranslationsKeys.string_generate)}
          </div>
          <img src={Icon_Coins} className="Generate_btn_img" />
          <div>{NowModulIntegral}</div>
        </div>
      </div>
      <div className="credit_text">
        {getTranslation(TranslationsKeys.MY_CREDITS)}{homeState?.UserIntegral}
      </div>

      {
        showOverlay &&
        <div className="Progress_box">
          {/* Progress是进度，暂时只有0与100两个状态，暂不使用这个数据 */}
          {/* <div className="Progress_title">{Progress}</div> */}
          {/* <img src={login_img} className="Progress_box_img" />
          <div className="Progress_title">Generating...</div> */}
          {/* <div className="Progress_btn" onClick={() => { Generate_btn_click() }}>{'Generate History >>'}</div> */}
          <div className="load">
            <LottiePlayer
              loop
              play
              className="loadingBox"
              animationData={LoadingAnimation}
            />
          </div>
        </div>
      }

      {/* <Loading loading={isNetLoading} /> */}
    </div>
  )
}