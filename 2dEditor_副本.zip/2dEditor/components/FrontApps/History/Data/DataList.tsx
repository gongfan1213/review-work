
// 依赖
import React, { Dispatch, SetStateAction, useState, useEffect } from "react";
// 组件
import { Masonry } from 'react-masonry-component2';
import Popover from '@material-ui/core/Popover';
import MyLazyImage from 'src/components/LazyLoadImage';
import CustomCheckbox from 'src/components/CustomCheckbox';

// 样式
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import * as classes from './DataListStyle.module.scss'
// 图标
import more_icon from 'src/images/2dEditor/more.png';
import Generating_img from '../../../../../../images/2dEditor/Apps_icon/Generating_img.png'


// 参数类型
interface PropsObj {
  dataList: any[], // 数据
  isEditing: boolean, // 是否编辑状态
  selectAll: boolean, // 是否全选
  selectedItems: any[], // 勾选数据
  clickItem: (arg0: any) => void, // 点击当前对象
  deleteProject: (id: number) => void, // 点击删除
  setIsEditing: () => void, // 设置是否编辑状态
  itemOperator: (id: any) => void, // 设置当前操作对象信息
  setIsShowFooterbar: Dispatch<SetStateAction<boolean>>,
  allRight_state: boolean, // 左侧布局是否放大
  setIsItemDeleteId: Dispatch<SetStateAction<number>>,
  setOpenDialog: Dispatch<SetStateAction<boolean>>,
  handleSelectItem: (arg0: any) => void, // 勾选复选框
}

// 自定义popover弹窗样式
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    paper: {
      width: '80px',
      backgroundColor: '#fff',
      fontSize: 12
    },
    operatorItem: {
      height: '34px',
      lineHeight: "34px",
      paddingLeft: '8px',
      cursor: 'pointer'
    }
  }),
);

const DataList: React.FC<PropsObj> = ({
  dataList, isEditing, selectAll, selectedItems, setIsItemDeleteId, setIsEditing, itemOperator,
  setIsShowFooterbar, setOpenDialog, clickItem, handleSelectItem
}) => {
  // popover样式
  const classess = useStyles();

  // popover相关定义 -- start
  const [anchorEl, setAnchorEl] = useState(null);
  const [openedPopoverId, setOpenedPopoverId] = useState(null);

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;
  // 使用一个对象来追踪每个卡片的悬停状态
  const [hoverStates, setHoverStates] = useState<{ [key: number]: boolean }>({});

  // 处理鼠标进入
  const handleMouseEnter = (id: number) => {
    setHoverStates({});
    setHoverStates(prev => ({ ...prev, [id]: true }));
  };

  // 处理鼠标离开
  const handleMouseLeave = (id: number) => {
    setHoverStates(prev => ({ ...prev, [id]: false }));
  };

  const handleClick = (event: any, id: any) => {
    setAnchorEl(event.currentTarget);
    setOpenedPopoverId(id);
  };
  const handleClose = () => {
    setAnchorEl(null);
    setOpenedPopoverId(null);
  };
  // popover相关定义 -- end

  // 删除操作
  const itemOperatorDelete = (event: React.MouseEvent<HTMLDivElement, MouseEvent>, id: number) => {
    console.log('=========', id)
    event.stopPropagation();
    setOpenDialog(true);
    setIsItemDeleteId(id)
    handleClose();
  }

  // 选择操作
  const itemOperatorSelect = (event: React.MouseEvent<HTMLDivElement, MouseEvent>, id: number) => {
    event.stopPropagation();
    setIsShowFooterbar(true);
    itemOperator(id)
    setIsEditing();
    handleClose();
  }
  // console.log('selectedItems====', selectedItems)
  return (
    <Masonry
      className={classes.listContainer}
      columnsCountBreakPoints={{ 0: 3 }}
      style={{ gap: 0 }}
    >
      {dataList.map((v, index) => {
        // console.log('v==index==', index, selectedItems.includes(v.id), selectAll)
        if (!v) return null
        let decodedUrl = v?.download_url.indexOf('oss-cn-shenzhen') !== -1 ? v.download_url : decodeURIComponent(v.download_url)
        return (
          <div className={classes.item}
            onMouseEnter={() => handleMouseEnter(v.id)}
            onMouseLeave={() => handleMouseLeave(v.id)}
          >
            {/* 当download_url为空时，是合成进行中的状态，且当图片未返回时给个默认值 */}
            {/* <img loading='lazy' crossOrigin="anonymous" src={decodedUrl || Generating_img} key={decodedUrl} onClick={() => { clickItem(v) }} /> */}
            <MyLazyImage
              src={decodedUrl || Generating_img}
              onClick={() => { clickItem(v); }}
            />
            {
              (isEditing || hoverStates[v.id]) && (
                <CustomCheckbox
                  key={index}
                  className={classes.itemSelectBox}
                  checked={selectAll || selectedItems.includes(v.id)}
                  onChange={(event: any) => {
                    handleSelectItem(v.id);
                  }}
                />
              )
            }
            <div key={v.id} className={classes.moreOperator}>
              <img
                src={more_icon}
                style={{
                  width: 16, height: 16, position: 'absolute', top: 4, right: 4,
                  background: "#fff", borderRadius: 2,
                  display: hoverStates[v.id] ? 'block' : 'none', // 根据该卡片的悬停状态显示或隐藏
                }}
                aria-describedby={id}
                onClick={(e) => { e.stopPropagation(); handleClick(e, v.id) }}
              />
              <Popover
                id={id}
                open={openedPopoverId === v.id}
                anchorEl={anchorEl}
                onClose={handleClose}
                classes={{ paper: classess.paper }}
                anchorOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
              >
                <div className={classes.operatorPopper}>
                  <div className={classess.operatorItem} onClick={(event) => itemOperatorDelete(event, v.id)}>Delete</div>
                  <div className={classess.operatorItem} onClick={(event) => itemOperatorSelect(event, v.id)}>Select</div>
                </div>
              </Popover>
            </div>
          </div>
        )
      })}
    </Masonry>
  );
}

export default DataList;