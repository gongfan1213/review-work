import React, { useState, useEffect, useRef } from "react";
import './index.scss';
import return_icon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png'
import { Select, MenuItem } from "@mui/material";
import dog_img2 from '/src/images/2dEditor/Apps_icon/dog_img2.png'
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import { getHistoryList } from "../../../service/2dEditService";
import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';
// import ScrollMoreView from 'src/templates/2dEditor/common/widget/ScrollMoreView/ScrollMoreView';
import Loading from 'src/components/Loading';
import { getImgStr, selectFiles } from 'src/templates/2dEditor/utils/utils';
import { useEvent, useCanvasEditor } from 'src/templates/2dEditor/hooks/context';
import { convertToBase64 } from 'src/common/utils';
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common';
import Generating_img from '../../../../../images/2dEditor/Apps_icon/Generating_img.png'
import DataList from '../../MainUi/MainUiLeft/MainUiLeftUpload/Data/DataList';

export default function History(props: any) {
  const { prevStep, Entrance } = props;
  const [selectedValue, setSelectedValue] = useState(1);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [isNetLoading, setNetLoading] = useState(false)
  const [HistoryData, setHistoryData] = useState<any>([])//返回的对象
  const [hasMore, setHasMore] = useState(false)
  const [isLoading, setLoading] = useState(false)
  const [total, setTotal] = useState(0)
  const pageIndex = useRef(1);
  const PAGE_SIZE = 20;
  const canvasEditor = useCanvasEditor();


  const handleSelectChange = (event: any) => {
    setHistoryData([])
    pageIndex.current = 1
    setSelectedValue(event.target.value);
  };

  const optionData = [{
    value: 0,
    label: 'All'
  }, {
    value: 1,
    label: 'Ai Portrait'
  }, {
    value: 2,
    label: 'Master Landscape'
  }]

  // 选中项
  const handleSelectItem = (id: string) => {
    const newSelectedItems = new Set(selectedItems);
    if (newSelectedItems.has(id)) {
      newSelectedItems.delete(id);
    } else {
      newSelectedItems.add(id);
    }
    setSelectedItems(Array.from(newSelectedItems));
  };

  // 点击
  const clickChangeProject = async (item: any) => {
    // 设置的时候
    if (isEditing) {
      handleSelectItem(item?.task_id);
      return;
    } else {
      // console.log('clickChangeProject======', item)
      if (item?.download_url && item?.file_name) {
        const fileExtension = item?.file_name?.split('.').pop(); // 获取文件后缀
        if (fileExtension === 'svg') {
          setNetLoading(true)
          const response = await fetch(item?.download_url);
          const blob = await response.blob();
          getImgStr(blob).then((file: any) => {
            canvasEditor?.addSvgFile(file as string);
          });
        } else {
          setNetLoading(true)
          const base64 = await convertToBase64(item?.download_url);
          canvasEditor?.addImage(base64, {
            importSource: ImportSource.Cloud,
            fileType: fileExtension,
            key_prefix: item?.file_name
          });
        }
        setNetLoading(false)
      }
    }
  }

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedItems([]);
    } else {
      const allIds = HistoryData?.map((project: any) => project.project_id);
      setSelectedItems(allIds);
    }
    setSelectAll(!selectAll);
  };

  const handleDeleteSelected = () => {
    // 删除选中项,暂时没接口，后续开发
    console.log("000", selectedItems);
  };

  const toggleEdit = () => {
    setIsEditing(!isEditing);
    setSelectedItems([]); // 清空选中项
    setSelectAll(false); // 重置全选状态
  };

  // 获取历史记录
  const getHistoryData = async () => {
    setLoading(true);
    var ret: any = [];
    var allData: any = [];
    const data = await getHistoryList({
      task_type: selectedValue,
      pagination: {
        page: pageIndex.current,
        page_size: PAGE_SIZE,
      }
    })
    // 只有在第一次才返回总数
    if (pageIndex.current === 1) {
      setTotal(data?.data?.total || 0)
    }

    if (data?.data && data?.data?.history_list.length > 0) {
      pageIndex.current++;
      allData = data?.data.history_list;
      data?.data.history_list.map((item: any) => {
        if ([0, 1, 2].includes(item.status)) {
          return ret.push(item);
        }
      })
    }
    setHistoryData((prevProjects: any) => [...prevProjects, ...ret])
    setLoading(false)
    setHasMore(allData.length >= PAGE_SIZE)
  }

  useEffect(() => {
    getHistoryData()
  }, [selectedValue])

  return (
    <div className="History_box">
      <div className="History_box_top">
        <div className="History_top_left">
          {
            history.length > 0 && <img src={return_icon} className="History_box_top_img" onClick={() => { prevStep(Entrance ? 1 : 3) }} />
          }
          <div className='History_box_top_title'>History</div>
        </div>
        {/* <button className={`${BaseStyles.cusButtonWrap}`} onClick={toggleEdit}>Edit</button> */}
      </div>
      <Select 
        value={selectedValue} 
        onChange={handleSelectChange}
        className="History_box_select"
      >
        {optionData?.map((item) => {
          return (
            // @ts-ignore
            <MenuItem value={item?.value}>{item?.label}</MenuItem>
          )
        })}
      </Select>
      <div className="History_Cardbox_scroll">
        <ScrollMoreView2d
          onLoadMore={getHistoryData}
          hasMore={hasMore}
          isLoading={isLoading}
        >
          <div className="History_Cardbox">
            {
              HistoryData?.map((item: any, index: any) => {
                // 只有在status为0,1,2时才显示,后续其他状态可能有其他需求，待修改
                if (!item || ![0, 1, 2].includes(item.status)) return null;
                return (
                  <div key={index} className="CardItem" onClick={() => { clickChangeProject(item) }}>
                    {/* 在只有在status为0和1时，展示Generating */}
                    <img key={index} src={(item.status === 0 || item.status === 1) ? Generating_img : item?.download_url} className="History_img" />
                    {
                      isEditing && (
                        <input
                          type="checkbox"
                          className="itemSelectBox"
                          checked={selectAll || selectedItems.includes(item?.task_id)}
                        />
                      )
                    }
                  </div>
                )
              })
            }
          </div>
          {/* 后续改为upload模块的UI与逻辑 */}
          {/* {
            HistoryData?.length === 0 && <DataList
              dataList={HistoryData}
              isEditing={isEditing}
              selectAll={selectAll}
              selectedItems={selectedItems}
              clickItem={clickItem}
              deleteProject={deleteProject}
            />
          } */}
        </ScrollMoreView2d>
      </div>
      {isEditing && (
        <div className="History_FooterBar">
          <input type="checkbox" checked={selectAll} onChange={handleSelectAll} />
          <button className={`${BaseStyles.cusButtonWrap}`} onClick={handleDeleteSelected}>Delete</button>
        </div>
      )}
      <Loading loading={isNetLoading} />
    </div>
  );
}