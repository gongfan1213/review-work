import React, { useState, useEffect, useRef } from "react";
import './index.scss';
import return_icon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png'
import { Select, MenuItem } from "@mui/material";
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import { getHistoryList, deleteHistory } from "../../../service/2dEditService";
import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';
// import ScrollMoreView from 'src/templates/2dEditor/common/widget/ScrollMoreView/ScrollMoreView';
import Loading from 'src/components/Loading';
import { getImgStr, selectFiles } from 'src/templates/2dEditor/utils/utils';
import { useEvent, useCanvasEditor } from 'src/templates/2dEditor/hooks/context';
import { convertToBase64 } from 'src/common/utils';
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common';
import { openToast } from 'src/state/reducers/toast';
import { useTranslation } from '@volcengine/i18n';
import { isNetSuccess } from 'src/templates/2dEditor/common/netUtil';
import DataList from './Data/DataList';
import MainUiLeftFooterBar from 'src/templates/2dEditor/components/MainUiLeftFooterBar/MainUiLeftFooterBar';
import { AppsDataTYPE } from 'src/templates/2dEditor/components/FrontApps/const'
import SelectDown from 'src/templates/2dEditor/components/FrontApps/AIProductDesigner/components/SelectDown'
import noProject from 'src/assets/studio/not-project.png'
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

// SourcePage在AIProductDesigner模块调用时传入，后续其他模块调用时，可以传入不同的字符串
export default function History(props: any) {
  const { prevStep, Entrance, allRight_state, SourcePage } = props;
  const [selectedValue, setSelectedValue] = useState(0);
  const [isEditing, setEditing] = useState(false);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [isNetLoading, setNetLoading] = useState(false)
  const [HistoryData, setHistoryData] = useState<any>([])//返回的对象
  const [hasMore, setHasMore] = useState(false)
  const [isLoading, setLoading] = useState(true)
  const [total, setTotal] = useState(0)
  const pageIndex = useRef(1);
  const PAGE_SIZE = 20;
  const canvasEditor = useCanvasEditor();
  const [isItemDeleteId, setIsItemDeleteId] = useState<any>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isShowFooterbar, setIsShowFooterbar] = useState(false);
  const { getTranslation } = useCustomTranslation();

  const optionData = [{
    value: 0,
    str: 'All',
    // image:''
  }, {
    value: 1,
    str: 'Ai Portrait',
    // image:''
  }, {
    value: 2,
    str: 'Photo to Art',
    // image:''

  }, {
    value: 3,
    str: 'Design copilot',
    // image:''
  }]

  // 选中项
  const handleSelectItem = (id: string) => {
    const newSelectedItems = new Set(selectedItems);
    if (newSelectedItems.has(id)) {
      newSelectedItems.delete(id);
      setSelectAll(false);
    } else {
      newSelectedItems.add(id);
    }
    setSelectedItems(Array.from(newSelectedItems));
    if (Array.from(newSelectedItems).length > 0) {
      setEditing(true)
    } else {
      setEditing(false);
    }
  };

  // 点击
  const clickChangeProject = async (item: any) => {
    // 设置的时候
    // if (isEditing) {
    //   handleSelectItem(item?.id);
    //   return;
    // } else {
    if (item?.download_url && item?.file_name) {
      const fileExtension = item?.file_name?.split('.').pop(); // 获取文件后缀
      if (fileExtension === 'svg') {
        setNetLoading(true)
        const response = await fetch(item?.download_url);
        const blob = await response.blob();
        getImgStr(blob).then((file: any) => {
          canvasEditor?.addSvgFile(file as string);
          setNetLoading(false)
        });
      } else {
        // setNetLoading(true)
        const base64 = await convertToBase64(item?.download_url);
        canvasEditor?.addImage(base64, {
          importSource: ImportSource.Cloud,
          fileType: fileExtension,
          key_prefix: item?.file_name
        });
      }
    }
    // }
  }

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedItems([]);
    } else {
      const allIds = HistoryData?.map((project: any) => project.id);
      setSelectedItems(allIds);
    }
    setSelectAll(!selectAll);
  };

  const handleDeleteSelected = () => {
    // console.log("000", selectedItems);
    console.log('isItemDeleteId', isItemDeleteId, "selectedItems", selectedItems);

    setNetLoading(true);
    const ids = isItemDeleteId ? [isItemDeleteId] : selectedItems;
    // deleteHistory这个是severs定义的删除接口

    deleteHistory({ ids: ids }).then((resp: any) => {
      setNetLoading(false);
      if (isNetSuccess(resp)) {
        // 过滤掉已删除的项目
        const newProjectList = HistoryData.filter(
          (data: any) => !ids.includes(data.id)
        );
        // console.log("newProjectList", newProjectList);

        // 更新projectList状态
        setHistoryData(newProjectList);
        // 清空选中项
        setSelectedItems([]);
        // 删除所有后，重新加载下一页数据
        if (newProjectList.length == 0 && hasMore) {
          pageIndex.current = 1
          getHistoryData();
        }
        // 关闭弹窗
        setOpenDialog(false);
        setEditing(false);
        setSelectAll(false);
        setIsItemDeleteId(null);
        setIsShowFooterbar(false);
      } else {
        openToast({
          message: getTranslation(TranslationsKeys.DELETE_FAST),
          severity: 'error',
        });
      }
    });

  };

  // 获取历史记录
  const getHistoryData = async () => {
    try {
      setLoading(true);
      let ret: any = [];
      let allData: any = [];
      const data = await getHistoryList({
        task_type: selectedValue,
        pagination: {
          page: pageIndex.current,
          page_size: PAGE_SIZE,
        }
      });

      // 确保data是有效的并且有data属性
      if (data && data.data) {
        // 只有在第一次才返回总数
        if (pageIndex.current === 1) {
          setTotal(data.data.total || 0);
        }

        if (data.data.history_list && data.data.history_list.length > 0) {
          pageIndex.current++;
          allData = data.data.history_list;
          // 如果需要过滤数据，可以取消注释下面的代码
          // allData = data.data.history_list.filter((item: any) => [0, 1, 2].includes(item.status));
        }
      }

      setHistoryData((prevProjects: any) => [...prevProjects, ...allData]);
      setHasMore(allData.length >= PAGE_SIZE);
      // console.log("allDataallData11111111", allData);
      // 如果是全选的话 要把继续加载的数据也加入到选中项
      if (selectAll || (selectedItems.length > 0 && (selectedItems.length == allData.length))) {
        // console.log("allDataallData2222222", allData);
        setSelectedItems([...HistoryData?.map((project: any) => project.id), ...allData]);
      }
    } catch (error) {
      console.error("获取历史数据时发生错误：", error);
      // 处理错误，例如显示错误消息
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getHistoryData()
  }, [selectedValue])

  const itemOperator = (id: any) => {
    const newSelectedItems = new Set(selectedItems);
    if (!newSelectedItems.has(id)) {
      newSelectedItems.add(id);
    }
    setSelectedItems(Array.from(newSelectedItems));
  }

  const deleteProject = (id: any) => {
    itemOperator(id);
    setOpenDialog(true);
  }

  const setIsNotEditing = () => {
    setEditing(false);
    setSelectedItems([]);
    setIsShowFooterbar(false);
  }

  const handleDialogClose = () => {
    setIsItemDeleteId(null);
    setOpenDialog(false);
    setIsShowFooterbar(false);
  }

  const handleDialogOpen = () => {
    setOpenDialog(true);
  }

  const setIsEditing = () => {
    setEditing(true);
    setSelectAll(false);
    setIsShowFooterbar(true);
  }

  const handleSelectChange = (item: any) => {
    setHistoryData([])
    pageIndex.current = 1
    setSelectedValue(item?.value);
  };

  return (
    <div className="History_box">
      <div className="History_box_top">
        <div className="History_top_left">
          {
            history.length > 0 &&
            <div className="History_box_top_img_box"
              onClick={() => {
                SourcePage === AppsDataTYPE['5']
                  ? prevStep(Entrance)
                  : prevStep(Entrance ? 1 : 3)
              }}
            >
              <img src={return_icon}
                className="History_box_top_img"
              />
            </div>
          }
          <div className='History_box_top_title'>History</div>
        </div>
      </div>
      {/* <Select
        value={selectedValue}
        onChange={handleSelectChange}
        className="History_box_select"
      >
        {optionData?.map((item) => {
          return (
            // @ts-ignore
            <MenuItem style={{ 'color': 'black', 'fontSize': '16px', 'fontWeight': '500' }} value={item?.value}>{item?.label}</MenuItem>
          )
        })}
      </Select> */}
      <SelectDown
        values={optionData}
        defaultSelectValue={selectedValue}
        callback={handleSelectChange}
      />
      <div className="History_Cardbox_scroll">
        {
          HistoryData.length == 0 && !isLoading &&
          <div className="noProjectBox">
            <img
              src={noProject}
              alt=""
              className="noProjectImg"
            />
          </div>
        }
        <ScrollMoreView2d
          onLoadMore={getHistoryData}
          hasMore={hasMore}
          isLoading={isLoading}
        >
          {HistoryData.length > 0 && <DataList
            dataList={HistoryData}
            isEditing={isEditing}
            selectAll={selectAll}
            selectedItems={selectedItems}
            deleteProject={deleteProject}
            setIsEditing={setIsEditing}
            itemOperator={itemOperator}
            setIsShowFooterbar={setIsShowFooterbar}
            allRight_state={allRight_state?.state || false}
            setIsItemDeleteId={setIsItemDeleteId}
            setOpenDialog={setOpenDialog}
            clickItem={clickChangeProject}
            handleSelectItem={handleSelectItem}
          />}
        </ScrollMoreView2d>
      </div>
      {
        ((isEditing && (selectAll || selectedItems.length > 0)) || isItemDeleteId) && <MainUiLeftFooterBar
          selectedItems={selectedItems}
          dataList={HistoryData}
          selectAll={selectAll}
          handleSelectAll={handleSelectAll}
          handleConfirm={handleDeleteSelected}
          isHandleConfirmSuccess={isNetLoading}
          setIsEditing={setIsNotEditing}
          openDialog={openDialog}
          setCloseDialog={handleDialogClose}
          setOpenDialog={handleDialogOpen}
          isShowFooterbar={isShowFooterbar}
          isItemDeleteId={isItemDeleteId}
          dialogDes={
            `Are You Sure Want To Delete ${selectedItems.length > 1 ? "These" : "This"} 
            ${selectedItems.length ? selectedItems.length : 1} 
            ${selectedItems.length > 1 ? "Histories" : "History"}? Delete Connot Be Recover.`
          }
        />
      }
      <Loading loading={isNetLoading} />
    </div>
  );
}