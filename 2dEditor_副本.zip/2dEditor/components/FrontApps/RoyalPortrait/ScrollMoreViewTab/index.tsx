import React, { useState, useRef, useEffect, useCallback, useImperativeHandle, forwardRef } from 'react'
import { useInView } from 'react-intersection-observer'
import LoadingAnimation from 'src/images/lottie/loading.json'
import LottiePlayer from 'react-lottie-player'
import * as classes from './ScrollMoreViewTab.module.scss'

type ScrollMoreViewProps = {
  onLoadMore: () => void
  hasMore?: boolean
  empty?: JSX.Element
  loaderView?: JSX.Element
  isLoading: boolean
  children: React.ReactNode;
}

const ScrollMoreView2d = forwardRef((props: ScrollMoreViewProps, ref) => {
  const {
    onLoadMore,
    hasMore,
    empty,
    loaderView,
    isLoading,
    children,
  } = props
  const { ref: inViewRef, inView } = useInView({ threshold: 0 })
  const onLoadMoreRef = useRef(onLoadMore)
  const scrollContainerRef = useRef(null); // 创建一个ref来引用滚动的元素

  onLoadMoreRef.current = onLoadMore

  useEffect(() => {
    if (inView && !isLoading) {
      onLoadMoreRef.current?.()
    }
  }, [inView])

  // 使用 useImperativeHandle 来暴露 scrollToTop 方法
  useImperativeHandle(ref, () => ({
    scrollToTop: () => {
      if (scrollContainerRef.current) {
        // @ts-ignore
        scrollContainerRef.current.scrollTop = 0;
      }
    }
  }));

  return (
    <div ref={scrollContainerRef} className={classes.layout} style={{ height: '100%' }}>
      {!isLoading && !hasMore && empty}
      {children}
      {(hasMore || isLoading) && (loaderView ? loaderView : (
        <div className={classes.load} ref={inViewRef}>
          <LottiePlayer
            loop
            play
            className={classes.loadingBox}
            animationData={LoadingAnimation}
          />
        </div>
      ))}
    </div>
  )
})

export default ScrollMoreView2d;