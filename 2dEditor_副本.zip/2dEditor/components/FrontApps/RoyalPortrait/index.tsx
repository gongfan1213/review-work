import React, { useEffect, useState, useRef, useCallback } from "react";
import './index.scss';
import { get } from 'src/services'
import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';
import _ from 'lodash';
import return_icon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png'
import { useEvent } from 'src/templates/2dEditor/hooks/context';
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';
import { AppsDataTYPE } from 'src/templates/2dEditor/components/FrontApps/const'
import empty_data_icon from 'src/images/empty_upload.png';
import CommonImage from 'src/components/CommonImage';
import NewRoyalPortrait from 'src/templates/2dEditor/components/FrontApps/NewRoyalPortrait/index';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

export default function RoyalPortrait(props: any) {
  const { type, step, title, nextStep, handlePetData, prevStep, JumpStep } = props;
  const { getTranslation } = useCustomTranslation();
  const [TableData, setTableData] = useState<any>([]);
  const [isLoading, setLoading] = useState(false)
  const event = useEvent();
  // 默认加载更多时的tab，RoyalPortrait默认为Kid
  const tabRef = useRef<any>('Kid');
  const dataObjectRef = useRef<any>({});//数据集合
  const classTabTitleRef = useRef([]);//列表小类
  const pageIndexRef = useRef(1);
  const AiTitle = typeof window !== 'undefined'
    ? window.sessionStorage.getItem('AiTitle') || ''
    : '';
  const interface_loading = useRef(false);

  const tempData = dataObjectRef.current?.[tabRef.current]?.data || [];
  const tempHasMore = dataObjectRef.current?.[tabRef.current]?.hasMore || false;
  // 判断当前是否是RoyalPortrait模块
  const nowType = (type === AppsDataTYPE['1'])
  // 当前的数据状态，避免一进入页面就显示空数据模块
  const nowDataState = useRef<any>(true);

  const imageClick = (item: any) => {
    event?.emitEvent(EventNameCons.EventHiddenCloseIcon, false)
    if (!nowType) {
      const nowData = TableData.map((dataItem: any) => dataItem.id === item.id ? { ...dataItem, now: true } : dataItem);
      handlePetData(nowData, title, title)
      nextStep(title, type, '', '', nowData)
    }
  }

  const transformData = (originalData: any) => {
    return originalData?.map((item: any) => ({
      image: item?.attributes?.faceImage?.data?.attributes?.formats?.small?.url,
      canvas_image: item?.attributes?.faceImage?.data?.attributes?.url,
      id: item?.id,
      // 人脸数量，几个人脸数量就有几个上传模块
      faceNumber: item?.attributes?.faceNumber,
      now: false
    }));
  }

  // 获取列表数据
  const fetchTabelData = async (tab: string) => {
    try {
      interface_loading.current = true;
      setLoading(true);
      const currentTab = tab || tabRef.current;
      const currentPageIndex = dataObjectRef.current?.[currentTab]?.pageIndex || 1;

      const json = await get<{ data: any }>(
        '/web/cms-proxy/common/content',
        {
          // cms接口地址
          content_type: 'make-2d-face-templates',
          populate: ['faceImage', 'facePosition', 'type'],
          sort: ['weight:DESC'],
          // 筛选（搜索）条件
          filters: {
            type: {
              name: {
                $eq: currentTab,
              }
            },
            aiTool: {
              title: {
                $eq: title
              }
            }
          },
          pagination: {
            page: currentPageIndex,
            pageSize: 20,
          },
        },
      );

      const currentData = dataObjectRef.current?.[currentTab]?.data || [];
      const newData = json?.data?.data || [];
      const hasMore = newData.length >= 20;

      if (dataObjectRef.current?.[tabRef.current]) {
        // 滚动分页加载
        dataObjectRef.current = {
          ...dataObjectRef.current,
          [currentTab]: {
            data: [...currentData, ...transformData(newData)],
            hasMore: hasMore,
            pageIndex: currentPageIndex + 1
          }
        }
        interface_loading.current = false;
      } else {
        // 首次加载
        dataObjectRef.current = {
          ...dataObjectRef.current,
          [tabRef.current]: {
            data: [...transformData(json?.data?.data)],
            hasMore: json?.data?.data?.length >= 20,
            pageIndex: pageIndexRef.current + 1
          }
        }
      }
      interface_loading.current = false;
    } catch (error) {
      console.log("列表数据方法执行错误", error);
    } finally {
      interface_loading.current = false;
      setLoading(false);
      nowDataState.current = false;
    }
  }

  const PopArtifyChange = (originalData: any) => {
    return originalData?.map((item: any) => ({
      name: item?.attributes?.name,
      image: item?.attributes?.image?.data?.attributes?.formats?.small?.url,
      canvas_image: item?.attributes?.image?.data?.attributes?.url,
      id: item?.id,
      faceNumber: 1,//用于下一个模块加一个上传模块，减少下一个模块的修改
      now: false
    }));
  }

  const fetchPopArtifyData = async () => {
    setLoading(true);
    try {
      const response = await get<{ data: any }>(
        '/web/cms-proxy/common/content',
        {
          // cms接口地址
          content_type: 'make-2d-style-transfer-templates',
          populate: ['image', 'template_id'],
          filters: {
            aiTool: {
              title: {
                $eq: title
              }
            }
          },
        },
      );
      if (response?.data?.data) {
        setTableData(PopArtifyChange(response.data.data));
      }
    } catch (error) {
      console.log("Fetching PopArtify data failed:", error);
    } finally {
      setLoading(false);
    }
  }

  const returnClick = () => {
    if (AiTitle) {
      JumpStep('', 1, 'prev')
    } else {
      //此处返回到首页了，清空上传处的数据
      prevStep('', 'Kid')
    }
    handlePetData([], '')
    setTableData([]);
    classTabTitleRef.current = [];
    dataObjectRef.current = {};
    tabRef.current = 'Kid';
  }

  useEffect(() => {
    // 只有当前页不是RoyalPortrait才直接跑获取数据接口
    // 当前是第二步，且表格数据为空，且不是RoyalPortrait时，调接口获取数据
    if (step === 2 && TableData?.length === 0 && !nowType) {
      fetchPopArtifyData();
    }
  }, [step])

  return (
    // 此处区分RoyalPortrait人物换脸与其他应用，加载不同组件，减少修改
    nowType
      ? <NewRoyalPortrait {...props} />
      : <div className="RoyalPortrait_box" style={{ display: step === 2 ? '' : 'none' }}>
        <div className="RoyalPortrait_Box_top">
          <div className="RoyalPortrait_top_left">
            <div className="RoyalPortrait_top_left_img_box" onClick={() => { returnClick() }} >
              <img src={return_icon} className="RoyalPortrait_top_left_img" />
            </div>
            <div className='RoyalPortrait_title'>{title}</div>
          </div>
        </div>
        <div className="top_title">{getTranslation(TranslationsKeys.CHOOSE_PET_STYLE)}</div>
        <div className="tabel_card_scroll" style={{ height: 'calc(100vh - 188px)' }}>
          {
            // 空数据模块
            !nowDataState.current && TableData.length === 0 && isLoading === false &&
            <div className="no_data_box">
              <img src={empty_data_icon} className="no_data_icon" />
              <div>{getTranslation(TranslationsKeys.NO_DATA_AVAILABLE)}</div>
            </div>
          }
          <ScrollMoreView2d
            // @ts-ignore
            onLoadMore={fetchTabelData}
            hasMore={tempHasMore}
            isLoading={isLoading}
          >
            <div className="tabel_card">
              {
                TableData?.map((item: any) => {
                  return (
                    <div className="tabelimage_box" onClick={() => { imageClick(item) }}>
                      {/* <img src={item?.image} className="tabelimage" /> */}
                      <CommonImage src={item?.image} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      <span className="item_name">{item?.name}</span>
                    </div>
                  )
                })
              }
            </div>
          </ScrollMoreView2d>

        </div>
      </div>
  )
}