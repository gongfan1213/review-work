import React, { useMemo } from 'react';
import './index.scss'
import loading_icon from 'src/assets/svg/loading.svg';

const LogingCard = ({ Proportion }: { Proportion: string }) => {
    // 使用useMemo避免不必要的重复计算
    const cardStyle = useMemo(() => {
        // 分割Proportion字符串，获取宽高比
        const [widthRatio, heightRatio] = Proportion.split(':').map(Number);
        // 假设基础宽度为100px，根据比例计算高度
        const baseWidth = 180;
        const height = (baseWidth * heightRatio) / widthRatio;

        return {
            width: '100%',
            height: '100%',
            backgroundColor: 'grey',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            color: 'white',
            fontSize: '24px',
            borderRadius: '8px',
        };
    }, [Proportion]);

    return (
        <div className='loading_cardStyle_img' style={cardStyle}>
            <img className='loading_icon_img' src={loading_icon} alt="loading" />
        </div>
    );
};

export default LogingCard;