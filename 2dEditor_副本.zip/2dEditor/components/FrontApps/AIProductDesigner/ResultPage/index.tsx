import React, { useState, useEffect } from "react";
import './index.scss'
import return_icon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png'
import Icon_Coins from 'src/images/2dEditor/Apps_icon/Icon_Coins.png'
import History_img from 'src/images/2dEditor/Apps_icon/History_img.png'
import login_img from 'src/images/2dEditor/Apps_icon/login_img.gif'
import { getImgStr, selectFiles } from 'src/templates/2dEditor/utils/utils';
import { useEvent, useCanvasEditor } from 'src/templates/2dEditor/hooks/context';
import { convertToBase64 } from 'src/common/utils';
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common';
import Loading from 'src/components/Loading';
import LogingCard from './components/LogingCard'

// history_page：从哪个页面进入的ResultPage
// handleTabClick：点击卡片切换tab，此处用于返回上一级
// JumpHistory：跳转到历史记录页面
// generating：生成文生图的状态
// Generate：点击生成文生图的方法
// SyntheticData：生成的文生图数据
// GenerateState:生成文生图的状态
export default function ResultPage(props: any) {
  const { history_page, handleTabClick, JumpHistory, generating, Generate, SyntheticData, descriptionData, Proportion, GenerateState } = props
  const [isNetLoading, setNetLoading] = useState(false)
  const canvasEditor = useCanvasEditor();
  // 分割Proportion字符串，获取宽高比
  const [widthRatio, heightRatio] = Proportion.split(':').map(Number);
  // 假设基础宽度为100px，根据比例计算高度
  const baseWidth = 180;
  const height = (baseWidth * heightRatio) / widthRatio;
  const [listData, setListData] = useState([{
    image: <LogingCard Proportion={Proportion} />,
  }])

  const loadingData = [{
    image: <LogingCard Proportion={Proportion} />,
  }]

  // 返回按钮
  const returnClick = () => {
    handleTabClick(history_page)
    setListData(loadingData)
  }

  function transformData(data: any) {
    return data.map((item: any) => ({
      image: item?.download_url,
      file_name: item?.file_name
    }));
  }

  const Generate_click = () => {
    // 如果 showOverlay 为 true，后续沟通再给提示
    if (generating === true) return;
    Generate(history_page);
    // 只有在上一次有数据返回时，再次点击才将四条空数据添加到 listData 的末尾，
    SyntheticData.length > 0 &&
      setListData(prevData => [...prevData, ...loadingData]);
  }

  const ImgClick = async (item: any) => {
    if (item?.image && item?.file_name) {
      const fileExtension = item?.file_name?.split('.').pop(); // 获取文件后缀
      if (fileExtension === 'svg') {
        setNetLoading(true)
        const response = await fetch(item?.image);
        const blob = await response.blob();
        getImgStr(blob).then((file: any) => {
          canvasEditor?.addSvgFile(file as string);
        });
      } else {
        setNetLoading(true)
        const base64 = await convertToBase64(item?.image);
        canvasEditor?.addImage(base64, {
          importSource: ImportSource.Cloud,
          fileType: fileExtension,
          key_prefix: item?.file_name
        });
      }
      setNetLoading(false)
    }
  }

  useEffect(() => {
    if (SyntheticData.length > 0) {
      // console.log("SyntheticData=========添加", SyntheticData);
      setListData(prevData => {
        // 创建一个新数组，前面的元素为 prevData 的前面的元素，最后四个元素为 SyntheticData 的前四个元素
        const newData = [...prevData.slice(0, -1), ...transformData(SyntheticData).slice(0, 1)];
        return newData;
      });
    }
  }, [SyntheticData]);

  useEffect(() => {
    // 任务状态(0:待处理;1:处理中;2:已完成;3:处理失败;4:已取消;)
    if (GenerateState == 3) {
      // 当生成失败时，需要沟通后续怎么展示，目前是只有一加载张图片
      // setListData(transformData(SyntheticData));
    }
  }, [GenerateState])

  return (
    <div className="ResultPage_box">
      <div className="ResultPage_box_top">
        <img src={return_icon} className="ResultPage_box_return_icon" onClick={() => { returnClick() }} />
        <p className="ResultPage_box_TopTitle">
          ResultPage
        </p>
      </div>
      <div className="title_box">
        <p>{descriptionData?.description}</p>
      </div>
      <div className="listData_img_box"
        style={{
          // 固定子数据内每一行的高度
          gridAutoRows: `${height}px`,
        }}
      >
        {listData?.map((item: any, index: number) => {
          return (
            <div
              className="listData_imgbox"
              style={{
                width: `${baseWidth}px`,
                height: `${height}px`,
                borderRadius: '8px',
              }}
            >
              {/* 检查item.image是否是React元素，如果是，则直接渲染 */}
              {React.isValidElement(item.image)
                ? item.image
                // 此处后续验证一下svg地址时是否能够正常展示
                : <img src={item?.image} className="listData_img" onClick={() => { ImgClick(item) }} />}
            </div>
          )
        })}
      </div>
      {
        // generating为false时，说明生成文生图的状态未进行，此时显示生成按钮
        !generating &&
        <div className="Generate_down">
          <div className="Generate_down_box">
            <div className="Generate_btn_left" onClick={() => { Generate_click() }}>
              <div className="Generate_btn_text">
                Generate
              </div>
              <img src={Icon_Coins} className="Generate_btn_img" />
              <div>2</div>
            </div>
            {/* <img src={History_img}
              className="History_img"
              onClick={() => { JumpHistory('ResultPage') }}
            /> */}
          </div>

          <div className="MyCredits">
            my credits：100
          </div>
        </div>
      }

      {/* {
        generating &&
        <div className="Progress_box">
          <img src={login_img} className="Progress_box_img" />
          <div className="Progress_title">Generating...</div>
        </div>
      } */}
      <Loading loading={isNetLoading} />

    </div>
  )
}