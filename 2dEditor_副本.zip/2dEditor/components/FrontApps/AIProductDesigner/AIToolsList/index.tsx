import React, { useState, useEffect, useRef } from "react";
import './index.scss'
import TabSwitcher from 'src/templates/2dEditor/common/widget/TabSwitcher/TabSwitcher';
import Icon_Coins from 'src/images/2dEditor/Apps_icon/Icon_Coins.png'
import { get } from 'src/services'
import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';
import useDataCache from "src/templates/2dEditor/utils/DataCache";
import { Tooltip } from "@mui/material";
import close_icon from 'src/assets/svg/close.svg';
import empty_data_icon from 'src/images/empty_upload.png';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

// filterData:顶部select选中的数据，
// handleTabClick：点击卡片切换tab，
// getAiToolData：传递数据给父组件
// generating: 生成文生图的状态
export default function AIToolsList(props: any) {
  const { filterData, handleTabClick, getAiToolData, EnterResultPage, AIToolsListTab, Generate, generating, getRenderingState, InspirationsClick } = props;
  const { getCacheItem, setCacheItem } = useDataCache();
  const { getTranslation } = useCustomTranslation();
  const [hoveredId, setHoveredId] = useState<any>(null);
  const [OldfilterStr, setOldfilterStr] = useState(filterData?.NowOptions?.str)
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [ActiveData, setActiveData] = useState<any>(null);
  // 保存当前的title数据
  const [AllTitleData, setAllTitleData] = useState<string[]>([]);
  // 保存未修改时的初始数据
  const [OldAllTitleData, setOldAllTitleData] = useState<string[]>([]);
  // 跟踪输入框是否已经被修改
  const [isInputChanged, setIsInputChanged] = useState<boolean[]>([]);
  const [nowTab, setNowTab] = useState<any>(null);
  const [TableData, setTableData] = useState<any>([])
  // 构造一个数据，将当前option的数据和tab数据，以及table表格内的数据缓存起来
  // const [CachedData, setCachedData] = useState<any>({})
  const [hasMore, setHasMore] = useState(false)
  const [hasLoading, setHasLoading] = useState(false)
  const pageIndex = useRef(1);
  const PAGE_SIZE = 20;
  const [totals, settotals] = useState<any>(0)
  const [Suspension, setSuspension] = useState('')
  const modalRef = useRef(null);
  const [dataLoginState, setDataLoginState] = useState(false)

  const handleTabChange = ((tab: any) => {
    setDataLoginState(false)
    if (tab === nowTab) return;
    const integratedData = {
      [OldfilterStr]: {
        ...getCacheItem('AIToolsList')?.[OldfilterStr],
        [nowTab?.tabName]: {
          total: totals,
          tableData: TableData
        }
      }
    }
    setCacheItem('AIToolsList', { ...getCacheItem('AIToolsList') || {}, ...integratedData })
    setTableData([]);
    setNowTab(tab)
  });

  // console.log("getCacheItem('AIToolsList'", getCacheItem('AIToolsList'));
  // console.log("totals", totals);

  // 卡片点击
  const Cardclick = (item: any) => {
    console.log("Cardclick", item);
    InspirationsClick(
      item,
      item?.title.split(/{([^}]+)}/) || [],
      item?.title.split(/{([^}]+)}/) || [],
      new Array(item?.title.split(/{([^}]+)}/).length).fill(false)
    )
    handleTabClick(4)
    setSuspension('CardMode')
    setActiveData(item)
    setIsModalOpen(true);
    setAllTitleData(item?.title.split(/{([^}]+)}/) || []);
    setOldAllTitleData(item?.title.split(/{([^}]+)}/) || []);
    // 设置所有的input框都未修改，即都是false
    setIsInputChanged(new Array(item?.title.split(/{([^}]+)}/).length).fill(false))
  }

  const parts = AllTitleData.map((part: any, index: any) => {
    // 如果index是奇数，那么这个部分是在<...>标签中的
    if (index % 2 === 1) {
      return (
        <Tooltip
          title={OldAllTitleData[index]}
        >
          <input
            className="input_box"
            placeholder={OldAllTitleData[index]}
            style={{ width: `calc(min(${OldAllTitleData[index].length - 1}ch, 100%))` }}
            value={
              // 如果未修改则使用空值，否则使用用户输入的值
              isInputChanged[index] ? AllTitleData[index] : ""
            }
            onChange={(e) => {
              if (e.target.value.length <= 40) {
                const newAllTitleData = [...AllTitleData];
                newAllTitleData[index] = e.target.value;
                setAllTitleData(newAllTitleData);

                const newIsInputChanged = [...isInputChanged];
                newIsInputChanged[index] = true;
                setIsInputChanged(newIsInputChanged);
              }
            }}
          />
        </Tooltip>
      );
    } else {
      return <span className="Modal_box_title">{part}</span>;
    }
  });

  // 去除字符串中的<...>
  function removeBrackets(str: string) {
    // 使用正则表达式替换所有的<...>为...
    const newStr = str.replace(/{([^}]+)}/g, '$1');
    return newStr;
  }

  const Generate_click = async () => {
    // console.log("Generate_click", AllTitleData);
    // if (generating === true) return;
    EnterResultPage(0)
    Generate(0)
  }

  const EditFull_click = () => {
    // console.log("EditFull_click", AllTitleData.join(''), ActiveData);
    // 如果在提交时，未填写input框，那么使用原始数据
    const finalData = AllTitleData.map((data, index) => data || OldAllTitleData[index]).join('');
    handleTabClick(1)
    setIsModalOpen(false)
    getAiToolData({ ...ActiveData, title: finalData })
  }

  // 将字符串分割为数字
  function splitString(input: any) {
    const parts = input?.split(':')?.map(Number);
    return parts;
  }
  // 转化表格数据
  function TableDataChange(data: any) {
    return data?.map((item: any) => {
      return {
        image: item?.attributes?.image?.data?.attributes?.formats?.thumbnail?.url || item?.attributes?.image?.data?.attributes?.url,
        OriginalImage: item?.attributes?.image?.data?.attributes?.url,
        id: item?.id,
        styleData: {
          style_id: item?.attributes?.style?.data?.id,
          style_name: item?.attributes?.style?.data?.attributes?.name,
          style_img: item?.attributes?.style?.data?.attributes?.image?.data?.attributes?.formats?.thumbnail?.url,
        },
        selectDown: {
          str: splitString(item?.attributes?.scale?.data?.attributes?.name),
          value: item?.attributes?.scale?.data?.id
        },
        title: item?.attributes?.description,
      };
    });
  }
  // 获取表格数据
  const getTableData = async (more?: string) => {
    setHasLoading(true)
    if (nowTab?.tabName === undefined) {
      setHasLoading(false)
      return
    }
    const AiToolData = getCacheItem('AIToolsList')?.[filterData?.NowOptions?.str]?.[nowTab?.tabName]
    const now = nowTab?.tabName
    const requestParams = {
      // cms接口地址
      content_type: 'make-2d-ai-designer-products',
      populate: ['image', 'description', 'style.name', 'style.image', 'scale'],
      filters: {
        producrt: {
          categoryName: {
            $eq: filterData?.NowOptions?.str
          }
        }
      },
      pagination: {
        page: pageIndex.current,
        pageSize: PAGE_SIZE
      }
    } as any;
    if (nowTab?.tabName !== 'All') {
      requestParams.filters.designerClass = {
        name: {
          $eq: nowTab?.tabName
        }
      };
    }
    const json = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      requestParams,
    );

    if (now !== nowTab?.tabName) return
    // const temp = CachedData?.[filterData?.NowOptions?.str]
    // setCachedData({ [filterData?.NowOptions?.str]: { ...temp, [nowTab?.tabName]: TableDataChange(json?.data?.data) } })
    if (json?.data && json?.data?.data.length > 0) {
      pageIndex.current++;
    }
    // more时说明是有缓存，且加载更多
    if (more === 'more') {
      setTableData([...AiToolData?.tableData, ...TableDataChange(json?.data?.data)])
      getRenderingState(true)
    } else {
      // @ts-ignore
      settotals(json?.data?.meta?.pagination?.total)
      setTableData([...TableData, ...TableDataChange(json?.data?.data)])
      getRenderingState(true)
    }
    setHasLoading(false)
    setHasMore(json?.data?.data?.length >= PAGE_SIZE);
    setDataLoginState(true)
  }

  useEffect(() => {
    const AiToolData = getCacheItem('AIToolsList')?.[filterData?.NowOptions?.str]?.[nowTab?.tabName] || {}
    // console.log("nowTab变化-------",);
    if (nowTab?.tabName !== undefined) {
      setHasMore(false)
      // 说明有缓存
      if (AiToolData?.tableData?.length > 0) {
        // 说明还可以加载跟多
        if (AiToolData?.tableData?.length < AiToolData?.total) {
          pageIndex.current = AiToolData?.tableData?.length / PAGE_SIZE + 1;
          getTableData('more')
        }
        setTableData([...AiToolData?.tableData])
        getRenderingState(true)
        settotals(AiToolData?.total)
      } else {
        pageIndex.current = 1;
        setTableData([])
        getTableData()
      }
    }
  }, [nowTab])

  useEffect(() => {
    if (AIToolsListTab[0]?.tabName !== undefined) {
      setNowTab({ tabValue: 999, tabName: 'All' })
      // setNowTab(AIToolsListTab[0])
    }
    setHoveredId(null)
  }, [AIToolsListTab])

  useEffect(() => {
    // 切换产品类型，清空table数据
    setTableData([])
    setDataLoginState(false)
    pageIndex.current = 1;
    // 切换标品时（离开当前标品）缓存当前的旧数据
    const integratedData = {
      [OldfilterStr]: {
        ...getCacheItem('AIToolsList')?.[OldfilterStr],
        [nowTab?.tabName]: {
          total: totals,
          tableData: TableData
        }
      }
    }
    setCacheItem('AIToolsList', { ...getCacheItem('AIToolsList') || {}, ...integratedData })
    setOldfilterStr(filterData?.NowOptions?.str)
  }, [filterData?.NowOptions])

  useEffect(() => {
    // console.log("ActiveData", ActiveData);
    getAiToolData({
      description: AllTitleData.join(''),
      selectDown: { str: ActiveData?.selectDown?.str || [1, 1], value: ActiveData?.selectDown?.value || 1 },
      style_id: ActiveData?.styleData?.style_id || 0
    })
  }, [AllTitleData])

  useEffect(() => {
    const handleClickOutside = (event: any) => {
      // @ts-ignore
      // 当点击发生时，事件处理器会检查点击的元素是否在弹窗内部。如果不在，那么关闭弹窗
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setSuspension('');
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="AIToolsList_box">
      <TabSwitcher tabs={AIToolsListTab} onTabChange={handleTabChange} nowTab={nowTab?.tabValue} />
      <div style={{ height: '10px' }}></div>
      <div className="AIToolsList_down">
        {
          TableData.length === 0 && !hasLoading && nowTab && dataLoginState &&
          <div className="no_data_box">
            <img src={empty_data_icon} className="no_data_icon" />
            <div>{getTranslation(TranslationsKeys.NO_DATA_AVAILABLE)}</div>
          </div>
        }
        <ScrollMoreView2d
          onLoadMore={() => { getTableData() }}
          hasMore={hasMore}
          isLoading={hasLoading}
        >
          <div className="AIToolsList_down_box">
            {
              TableData?.map((item: any, index: number) => {
                return (
                  <div className="AIToolsList_down_card"
                    onMouseEnter={() => setHoveredId(index)}
                    onMouseLeave={() => setHoveredId(null)}
                    style={{ position: 'relative' }}
                    onClick={() => { Cardclick(item) }}
                  >
                    <img src={item.image} className="AIToolsList_down_img" />
                    <div className={`AIToolsList_down_mask ${hoveredId === index ? 'show' : 'hide'}`}>
                      <p>{removeBrackets(item.title)}</p>
                    </div>
                  </div>
                )
              })
            }
          </div>
        </ScrollMoreView2d>
      </div>
      <div
        style={{ display: Suspension === 'CardMode' ? '' : 'none' }}
        className="Modal_box"
        ref={modalRef}
      >
        <img src={close_icon} className="Suspension_close" onClick={() => setSuspension('')} />
        <img src={ActiveData?.OriginalImage} className="Modal_box_image" key={ActiveData?.OriginalImage} />
        <div className="Modal_box_border"></div>
        <div className="modal_down">
          {
            // 只有当style_name和style_img都存在时才显示
            !!ActiveData?.styleData?.style_name && !!ActiveData?.styleData?.style_img && (
              <div className="Modal_box_style">
                <img src={ActiveData?.styleData?.style_img} className="style_img" key={ActiveData?.styleData?.style_img} />
                <div className="style_name">{ActiveData?.styleData?.style_name}</div>
              </div>
            )
          }
          <div className="modal_txt">
            {parts}
          </div>
          <div className="Generate_btn_left" onClick={() => { Generate_click() }}>
            <div className="Generate_btn_text">
              {getTranslation(TranslationsKeys.string_generate)}
            </div>
            <img src={Icon_Coins} className="Generate_btn_img" />
            <div>2</div>
          </div>
          <div className="Modal_box_Edit" onClick={() => { EditFull_click() }}>{getTranslation(TranslationsKeys.EditFullPrompt)}</div>
        </div>
      </div>
    </div>
  )
}
