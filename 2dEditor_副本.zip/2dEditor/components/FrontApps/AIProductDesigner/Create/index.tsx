import React, { useState, useEffect } from "react";
import './index.scss'
import random_icon from 'src/images/2dEditor/Apps_icon/random_icon.png'
import appbar_close_icon from 'src/images/2dEditor/appbar_close_icon.png'
import SelectTop from '../components/SelectTop';
import Icon_Coins from 'src/images/2dEditor/Apps_icon/Icon_Coins.png'
import History_img from 'src/images/2dEditor/Apps_icon/History_img.png'
import close_icon from 'src/assets/svg/close.svg';
import { get } from 'src/services'
import LoadingIcon from "../components/LoadingIcon";
import { useDispatch, useSelector } from 'react-redux'
import useDataCache from "src/templates/2dEditor/utils/DataCache";
import login_img from 'src/images/2dEditor/Apps_icon/login_img.gif'
import LottiePlayer from 'react-lottie-player'
import LoadingAnimation from 'src/images/lottie/loading.json'
import {
  selectHome,
  HomeState,
} from 'src/state/reducers/home'
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

// InspirationsData: Inspirations模块的数据(弹窗中选中后传递过来的数据)
// EnterResultPage：进入ResultPage页面
// JumpStep：跳转到指定步骤
// getAIToolData:传递数据到父组件
// generating:文生图生成状态
export default function Create(props: any) {
  const { InspirationsData, EnterResultPage, JumpHistory, filterData, getCreateData, Generate, generating, RenderingData } = props
  const homeState: HomeState = useSelector(selectHome)
  const { getTranslation } = useCustomTranslation();
  const [description, setDescription] = useState<string>('')//输入框
  const [selectDown, setSelectDown] = useState<any>({})
  const [Suspension, setSuspension] = useState('')
  const [keywordsList, setkeywordsList] = useState<any>([])
  const [styleList, setStyleList] = useState<any>([])
  const [ViewAllList, setViewAllList] = useState<any>([])
  const [nowStyle, setNowStyle] = useState<any>('')
  const [qualityOptions, setQualityOptions] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [RandomData, setRandomData] = useState([])//随机数
  const dispatch = useDispatch()
  const [showOverlay, setShowOverlay] = useState(false); // 新增状态变量
  const { getCacheItem, setCacheItem } = useDataCache();
  // 当前模块需要的积分
  const [NowModulIntegral, setNowModulIntegral] = useState(1)

  const handleDescription = (value: string) => {
    // 如果总长度超过600，只取前600个字符
    if (value.length > 600) {
      const trimmedValue = value.substring(0, 600); // 截取前600个字符
      setDescription(trimmedValue); // 更新描述
    } else {
      setDescription(value); // 如果未超过600，正常更新描述
    }
  }

  const Random_click = () => {
    // console.log("Random_click");
    if (RandomData.length > 0) {
      setDescription(ExtractRandomString(RandomData))
    } else {
      getRandomData()
    }
  }

  const Keywords_click = () => {
    console.log("Keywords_click");
    setSuspension('Keywords')
  }

  const ViewAll_click = () => {
    setSuspension('ViewAll')
  }

  // 分割字符串,且转化为数字
  function splitString(input: any) {
    const parts = input?.split(':')?.map(Number);
    return parts;
  }
  const handleQualitySelection = (item: any) => {
    // setSelectDown(item?.value)
    setSelectDown({ value: item?.value, str: splitString(item?.str) })
  }

  const Generate_click = () => {
    if (description.length === 0 || description.length > 600) {
      return
    }
    EnterResultPage(1)
    Generate(1)
  }

  const close_click = () => {
    setSuspension('')
  }

  const txt_click = (txt: string) => {
    if (description.length + txt.length > 600) {
      return;
    }
    setDescription((description: any) => description + txt);
  }

  const ViewAllCard_click = (item: any) => {
    close_click();

    setStyleList((prevList: any) => {
      // 检查 item 是否已经在 styleList 中
      const itemIndex = prevList.findIndex((i: any) => i.style_id === item.style_id);

      if (itemIndex > -1) {
        // 如果 item 已经在 styleList 中，将其移动到数组的最前面
        return [prevList[itemIndex], ...prevList.slice(0, itemIndex), ...prevList.slice(itemIndex + 1)];
      } else {
        // 如果 item 不在 styleList 中，将其添加到数组的最前面
        return [item, ...prevList];
      }
    });

    setNowStyle(item?.style_id);
  }

  // 转化数组，然后随机取值拼接为字符串
  function ExtractRandomString(data: string[]) {
    const names = data.map((item: any) => item.attributes.name);
    // 不足三条数据时直接拼接字符串
    // if (names.length < 3) {
    //   return names.join('');
    // }
    const shuffled = [...names];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled.slice(0, 1).join('');
  }
  // 获取随机数据的数组
  const getRandomData = async () => {
    const json = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      {
        // cms接口地址
        content_type: 'make-2d-ai-designer-randoms',
        populate: ['name'],
        filters: {
          categoryType: {
            categoryName: {
              $eq: filterData?.NowOptions?.str
            }
          }
        },
        pagination: {
          // 从第几条开始到第几条结束
          start: 0,
          limit: 10000,
        },
      },
    );
    setRandomData(json?.data?.data)
    // console.log("json?.data", ExtractRandomString(json?.data?.data));
    setDescription(ExtractRandomString(json?.data?.data))
  }

  // 组装以及转化Tag数据
  function changeKeywordsList(data: any) {
    const result = data.reduce((acc: any, item: any) => {
      const title = item.attributes.tagClass.data.attributes.title;
      const id = item.id;
      const txt = item.attributes.name;

      const existingCategory = acc.find((category: any) => category.title === title);

      if (existingCategory) {
        existingCategory.List.push({ id, txt });
      } else {
        acc.push({
          title,
          List: [{ id, txt }]
        });
      }

      return acc;
    }, []);

    return result;
  }
  // 获取tab的数据
  const getKeywordsList = async () => {
    const json = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      {
        // cms接口地址
        content_type: 'make-2d-ai-designer-tagitems',
        populate: ['name', 'tagClass'],
      },
    );

    // console.log("setkeywordsList", changeKeywordsList(json?.data?.data));
    setkeywordsList(changeKeywordsList(json?.data?.data))
  }

  // 组装推荐列表的数据
  function filterByCategoryName(categoryName: string, data: string[]) {
    const result = {
      title: 'Recommended',
      List: []
    };
    data?.forEach((item: any) => {
      item?.attributes?.products?.data?.forEach((product: any) => {
        if (product?.attributes?.categoryName === categoryName) {
          const newItem = {
            style_id: item?.id,
            style_name: item?.attributes?.name,
            style_img: item?.attributes?.image?.data?.attributes?.formats?.thumbnail?.url
          };
          // @ts-ignore
          result?.List.push(newItem);
        }
      });
    });

    return result;
  }
  // 组装展示更多的数据
  function changeViewAllList(data: any) {
    const result = data?.reduce((acc: any, item: any) => {
      const title = item?.attributes?.style?.data?.attributes?.name;
      const style_id = item?.id;
      const style_name = item?.attributes?.name;
      const style_img = item?.attributes?.image?.data?.attributes?.formats?.thumbnail?.url;

      const existingCategory = acc.find((category: any) => category?.title === title);

      if (existingCategory) {
        existingCategory.List.push({ style_id, style_name, style_img });
      } else {
        acc.push({
          title,
          List: [{ style_id, style_name, style_img }]
        });
      }

      return acc;
    }, []);

    return result;
  }
  // 获取更多的style的数据
  const getViewAllList = async () => {
    setIsLoading(true)
    setStyleList([])
    if (getCacheItem('ViewAllList') !== undefined) {
      setStyleList(filterByCategoryName(filterData?.NowOptions?.str, getCacheItem('ViewAllList'))?.List)
      setViewAllList([filterByCategoryName(filterData?.NowOptions?.str, getCacheItem('ViewAllList')), ...changeViewAllList(getCacheItem('ViewAllList'))])
      setIsLoading(false)
      return
    }

    const json = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      {
        // cms接口地址
        content_type: 'make-2d-ai-designer-styles',
        populate: ['name', 'image', 'style', 'products'],
        // populate: ['name', 'image', 'style'],
        pagination: {
          // 从第几条开始到第几条结束
          start: 0,
          limit: 10000,
        },
        filters: {
          name: {
            $ne: 'default'
          }
        },
        sort: ['name:ASC']
      },
    );
    if (json?.data?.data?.length === 0) {
      return
    }
    // 设置全部未转化前style数据缓存
    setCacheItem('ViewAllList', json?.data?.data);
    setStyleList(filterByCategoryName(filterData?.NowOptions?.str, json?.data?.data)?.List)
    setViewAllList([filterByCategoryName(filterData?.NowOptions?.str, json?.data?.data), ...changeViewAllList(json?.data?.data)])
    setIsLoading(false)
  }

  // 转化底部下拉框数据格式
  function changeQualityOptions(data: any) {
    const result = data.map((item: any) => ({
      str: item?.attributes?.name,
      image: item?.attributes?.icon?.data?.attributes?.url,
      value: item?.id,
    }));

    return result;
  }
  // 获取底部下拉框的数据
  const getQualityOptions = async () => {
    const json = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      {
        // cms接口地址
        content_type: 'make-2d-ai-designer-scales',
        populate: ['name', 'icon'],
        pagination: {
          // 从第几条开始到第几条结束
          start: 0,
          limit: 10000,
        },
      },
    );
    console.log("getQualityOptionsgetQualityOptions", changeQualityOptions(json?.data?.data));
    setQualityOptions(changeQualityOptions(json?.data?.data));
  }

  const CardClick = (item: any) => {
    if (item?.style_id === nowStyle) {
      setNowStyle(null)
      return
    }
    setNowStyle(item?.style_id)
  }

  useEffect(() => {
    getCreateData({ description, selectDown, nowStyle })
  }, [description, selectDown, nowStyle])

  useEffect(() => {
    setDescription(InspirationsData?.title || '');
    setNowStyle(InspirationsData?.styleData?.style_id || '');
    setSelectDown({ value: InspirationsData?.selectDown?.value || 1, str: InspirationsData?.selectDown?.str || [1, 1] })
    // InspirationsData?.styleData存在时才赋值
    InspirationsData?.styleData?.style_id && setStyleList((_: any) => [InspirationsData?.styleData, ..._])
  }, [InspirationsData]);

  useEffect(() => {
    // 切换select时
    if (filterData?.NowOptions) {
      // console.log("filterData.tabs.label", filterData.tabs.label, RenderingData);
      // 当前选中的tab不是Inspirations时，说明是在Create页，可以直接调接口。如果是Inspirations页，需要判断左侧数据是否渲染完成
      if (filterData.tabs.label !== 'Inspirations' || RenderingData) {
        getViewAllList()//调接口获取数据
      }
      setNowStyle('')
      setDescription('')
      setRandomData([])
    }
  }, [filterData?.NowOptions, RenderingData])

  useEffect(() => {
    getKeywordsList()
    getQualityOptions()
    getCreateData(description, selectDown, nowStyle)
  }, [])

  useEffect(() => {
    // 当前选中的ai模块所需积分
    if (!homeState?.nowActiveAiModule) return;
    const costClass = homeState.nowActiveAiModule?.costClass;
    const cost = homeState?.AiModeIntegralData?.[costClass]?.cost;
    if (cost !== undefined) {
      setNowModulIntegral(cost);
    } else {
      console.log("costClass数据为空，请查看cms中class字段以及各模块所需参数值的接口");
    }
  }, [homeState?.nowActiveAiModule]);

  return (
    <div className="Create_box_now">
      <div className="Create_content_box">

        <p className="textarea_title">{getTranslation(TranslationsKeys.Prompt)}</p>
        {/* Keywords侧边弹窗 */}
        <div style={{ display: Suspension === 'Keywords' ? '' : 'none' }} className="Suspension_box">
          <div className="Suspension_close_box">
            <img src={close_icon} className="Suspension_close" onClick={() => { close_click() }} />
          </div>
          <div className="Keywords_list">
            {
              keywordsList?.map((item: any, index: number) => {
                return (
                  <>
                    <p
                      className="keywordsList_title"
                      style={{ 'marginTop': index === 0 ? '0px' : '16px' }}>
                      {item?.title}
                    </p>
                    <div className="keywordsList_data">
                      {
                        item?.List?.map((item: any) => {
                          return (
                            <div className="keywordsList_data_txt" onClick={() => { txt_click(item?.txt) }}>{item?.txt}</div>
                          )
                        })
                      }
                    </div>
                  </>
                )
              })
            }
          </div>
        </div>

        {/* style侧边弹窗 */}
        <div style={{ display: Suspension === 'ViewAll' ? '' : 'none', height: '600px', width: 'auto' }} className="Suspension_box">
          <div className="Suspension_close_box">
            <img src={close_icon} className="Suspension_close" onClick={() => { close_click() }} />
          </div>
          <div className="ViewAllList">
            {
              ViewAllList?.map((item: any, index: number) => {
                return (
                  <>
                    <p
                      className="ViewAllList_title"
                      style={{ 'marginTop': index === 0 ? '0px' : '16px' }}>
                      {item?.title}
                    </p>
                    <div className="ViewAllList_data">
                      {
                        item?.List?.map((item: any) => {
                          return (
                            <div className="ViewAllList_data_card_box" onClick={() => { ViewAllCard_click(item) }}>
                              <img className="ViewAllList_data_card_img" src={item?.style_img} key={item?.style_img} />
                              <div className="ViewAllList_data_box">
                                <p className="ViewAllList_data_title">{item?.style_name}</p>
                              </div>
                            </div>
                          )
                        })
                      }
                    </div>
                  </>
                )
              })
            }
          </div>
        </div>

        <div className="textarea_box"
          // 不需要边缘红框
          style={{
            // border: description.length === 600 || description.length === 0 ? '1px solid red' : ' 1px solid rgba(0, 0, 0, 0.1)'
            border: '1px solid rgba(0, 0, 0, 0.1)'
          }}
        >
          <textarea placeholder={getTranslation(TranslationsKeys.PleaseEnterYourCreativity)}
            className="textarea"
            value={description}
            onChange={(e) => handleDescription(e.target.value)}
            onPaste={(e) => {
              e.preventDefault(); // 阻止默认粘贴行为
              const pasteValue = e.clipboardData.getData('text'); // 获取粘贴的文本
              // 检查是否有文本被全选
              if (window.getSelection()?.toString() === description) {
                // 如果当前文本被全选，直接使用粘贴的文本替换
                handleDescription(pasteValue);
              } else {
                // 如果没有文本被全选，将粘贴的文本添加到当前值的末尾
                const newValue = description + pasteValue;
                handleDescription(newValue);
              }
            }}
          />
          <div className="textarea_line"></div>
          <div className="textarea_down">
            <div className="textarea_down_left">
              <div className="Random_box" onClick={() => { Random_click() }}>
                <img src={random_icon} className="Random_img" />
                <p className="Random">
                  {getTranslation(TranslationsKeys.Random)}
                </p>
              </div>
              {/* 与产品沟通后，暂时不需要这个弹窗，先隐藏 */}
              {/* <div className="keywords_box" onClick={() => { Keywords_click() }}>
              <img src={lowlight} className="keywords_img" />
              <p className="keywords">
                Keywords
              </p>
            </div> */}
            </div>
            <div className="textarea_down_right">
              <p className="Alltxt">{description?.length} / 600</p>
              {
                description?.length > 0 &&
                <>
                  <div style={{ border: '0.5px solid #D9D9D9', margin: '0px 8px' }}></div>
                  <img onClick={() => { setDescription('') }} src={appbar_close_icon} className="Clear_img" />
                </>
              }
            </div>
          </div>
        </div>

        <div className="Style_box">
          <div className="Style_box_top">
            <p className="Style_title">{getTranslation(TranslationsKeys.FORM_STYLE)}</p>
            <p className="Style_viewBtn" onClick={() => { ViewAll_click() }}>{getTranslation(TranslationsKeys.ViewAll)}</p>
          </div>
          {
            isLoading ? <LoadingIcon />
              : <div className="Style_box_down">
                {
                  // 只展示9条数据
                  styleList.slice(0, 9)?.map((item: any) => {
                    return (
                      <div className="Style_card_box" style={{ border: nowStyle === item?.style_id ? '2px solid #33BF5A' : '' }} onClick={() => { CardClick(item) }}>
                        <img className="Style_card" src={item?.style_img} key={item?.style_img} />
                        <div className="Style_card_title_box">
                          <div className="Style_card_title">{item?.style_name}</div>
                        </div>
                      </div>
                    )
                  })
                }
              </div>
          }
        </div>

        <div className="select_down">
          <p className="select_down_title">{getTranslation(TranslationsKeys.AspectRatio)}</p>
          <SelectTop
            values={qualityOptions}
            defaultSelectValue={selectDown?.value}
            callback={handleQualitySelection}
          />
        </div>
      </div>

      <div className="Generate_down">
        <div className="Generate_down_box">
          <div className="Generate_btn_left" onClick={() => { Generate_click() }}>
            <div className="Generate_btn_text">
              {getTranslation(TranslationsKeys.string_generate)}
            </div>
            <img src={Icon_Coins} className="Generate_btn_img" />
            <div>{NowModulIntegral}</div>
          </div>
          {/* <img src={History_img}
            className="History_img"
            onClick={() => { JumpHistory('Create') }}
          /> */}
        </div>

        <div className="MyCredits">
          {getTranslation(TranslationsKeys.MY_CREDITS)}{homeState?.UserIntegral}
        </div>
      </div>

      {
        generating &&
        <div className="Progress_box">
          {/* <img src={login_img} className="Progress_box_img" />
          <div className="Progress_title">Generating...</div> */}
          <div className="load">
            <LottiePlayer
              loop
              play
              className="loadingBox"
              animationData={LoadingAnimation}
            />
          </div>
        </div>
      }

    </div>
  )
}