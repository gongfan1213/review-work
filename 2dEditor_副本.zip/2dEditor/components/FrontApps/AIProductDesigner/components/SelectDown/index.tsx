// start_ai_generated 
import React, { useState, FC, useEffect } from 'react';
import * as classes from './DropdownStyle.module.scss';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import ic_Right from 'src/images/2dEditor/ic_Right.png';

interface ValueItem {
  str: string;
  image?: any,
  value: number;
}

interface DropdownProps {
  values: ValueItem[];
  typeStr?: string;
  defaultSelectValue: number;
  callback: (item: ValueItem) => void;
}

const SelectDown: FC<DropdownProps> = ({ values, defaultSelectValue, callback }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedValue, setSelectedValue] = useState<ValueItem | undefined>();

  useEffect(() => {
    // 设置默认选中的值
    const defaultValue = values.find(item => item.value === defaultSelectValue);
    setSelectedValue(defaultValue);
  }, [defaultSelectValue, values]);

  const handleSelect = (item: ValueItem) => {
    setSelectedValue(item);
    setIsOpen(false);
    callback(item);
  };

  return (
    <div className={classes.dropdownContainer} onBlur={() => setIsOpen(false)} tabIndex={0}>
      <div className={`${classes.dropdownSelected}`} onClick={() => setIsOpen(!isOpen)}>
        <div className={classes.top_box}
          style={{
            paddingLeft: selectedValue?.image ? '0' : '10px'
          }}
        >
          {
            selectedValue?.image &&
            <img src={selectedValue?.image} className={classes.image} />
          }
          <span className={`${BaseStyles.txt16}`}>{selectedValue?.str}</span>
        </div>
        <img className={classes.dropdownIcon} src={ic_Right} />
      </div>
      {isOpen && (
        <div className={classes.dropdownOptions}>
          {values.map((item, index) => (
            <div className={`${classes.dropdownOption} ${classes.values_box}`} onClick={() => handleSelect(item)}>
              {
                item?.image &&
                <img src={item?.image} className={classes.image} />
              }
              <div key={index} className={`${BaseStyles.txt14}`}
                style={{
                  paddingLeft: item?.image ? '0' : '10px'
                }}
              >
                {item.str}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SelectDown;