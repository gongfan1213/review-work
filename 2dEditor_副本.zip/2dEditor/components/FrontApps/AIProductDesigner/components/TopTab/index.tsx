import React, { useState } from 'react';
import './index.scss'

// tabs：标签集合，onTabChange：切换标签时的回调函数
const TopTab = (props: any) => {
  const { tabs, handleTabClick, selectedTab } = props

  return (
    <div className='tab-container'>
      {tabs.map((tab: any, index: any) => (
        <button
          key={index}
          style={{
            backgroundColor: selectedTab === index ? '#FFFFFF' : '#E9E9E9',
            padding: '8px',
            margin: '5px',
            borderRadius: '6px',
            border: 'none',
            cursor: 'pointer',
            color: 'black',
            width: '48%'
          }}
          onClick={() => handleTabClick(index)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
};

export default TopTab;
