import React, { useState, FC, useEffect } from 'react';
import * as classes from './DropdownStyle.module.scss';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
// import ic_down from 'src/assets/svg/ic_down.svg';
import move_icon from '/src/images/2dEditor/Apps_icon/move_icon.svg'

interface ValueItem {
  str: string;
  image: any,
  value: number;
}

interface DropdownProps {
  values: ValueItem[];
  typeStr?: string;
  defaultSelectValue: number;
  callback: (item: ValueItem) => void;
}

const SelectTop: FC<DropdownProps> = ({ values, defaultSelectValue, callback }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedValue, setSelectedValue] = useState<ValueItem | undefined>();

  useEffect(() => {
    // 设置默认选中的值
    const defaultValue = values.find(item => item.value === defaultSelectValue);
    setSelectedValue(defaultValue);
  }, [defaultSelectValue, values]);

  const handleSelect = (item: ValueItem) => {
    setSelectedValue(item);
    setIsOpen(false);
    callback(item);
  };

  return (
    <div className={classes.dropdownContainer} onBlur={() => setIsOpen(false)} tabIndex={0}>
      <div className={`${classes.dropdownSelected}`} onClick={() => setIsOpen(!isOpen)}>
        <div className={classes.top_box}>
          <img src={selectedValue?.image} className={classes.image} />
          <span className={`${BaseStyles.txt16}`}>{selectedValue?.str}</span>
        </div>
        <img className={classes.dropdownIcon} src={move_icon} />
      </div>
      {isOpen && (
        <div className={classes.dropdownOptions}>
          {values.map((item, index) => (
            <div className={`${classes.dropdownOption} ${classes.values_box}`} onClick={() => handleSelect(item)}>
              <img src={item?.image} className={classes.image} />
              <div key={index} className={`${BaseStyles.txt14}`}>
                {item.str}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SelectTop;