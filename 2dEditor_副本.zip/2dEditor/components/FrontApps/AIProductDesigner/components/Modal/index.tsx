import React from "react";
import './index.scss'

// 新的弹窗组件
export default function Modal({ children, onClose }: { children: React.ReactNode, onClose: () => void }) {
  return (
    <div className="modal" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}