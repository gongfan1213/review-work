import React from "react";
import './index.scss'
import LottiePlayer from 'react-lottie-player'
import LoadingAnimation from 'src/images/lottie/loading.json'

export default function LoadingIcon() {

  return (
    <div className="LoadingIcon_load">
      <LottiePlayer
        loop
        play
        className="loadingBox"
        animationData={LoadingAnimation}
      />
    </div>
  )
}