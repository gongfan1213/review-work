import React, { useState, useEffect, useRef } from "react";
import './index.scss'
import return_icon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png'
import TopTab from './components/TopTab'
import SelectDown from './components/SelectDown';
import AIToolsList from './AIToolsList/index'
import Create from './Create/index'
import ResultPage from "./ResultPage";
import History from "../History";
import { get } from 'src/services'
import { getTextImageCreatetask, getTextImageTaskstatus } from '../../../service/2dEditService'
import { useDispatch, useSelector } from 'react-redux'
import { openToast } from 'src/state/reducers/toast'
import InspirationsCreat from "./InspirationsCreat";
import { getImgStr, selectFiles } from 'src/templates/2dEditor/utils/utils';
import { useEvent, useCanvasEditor } from 'src/templates/2dEditor/hooks/context';
import { convertToBase64 } from 'src/common/utils';
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common';
import { AppsDataTYPE } from 'src/templates/2dEditor/components/FrontApps/const'
import {
  selectHome,
  HomeState,
  getUserIntegralData,
} from 'src/state/reducers/home'
import { EditorToastType, editorToastHidden, editorToastShow } from 'src/templates/2dEditor/components/Toast';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";
import { measureExecutionTime } from 'src/common/utils/PublicMethods'

let timeoutId: NodeJS.Timeout | null = null;

export default function AIProductDesigner(props: any) {
  const { JumpStep } = props
  const { getTranslation } = useCustomTranslation();
  const [filterData, setFilterData] = useState<any>({
    tabs: { label: getTranslation(TranslationsKeys.Inspirations), id: 1 },
    // 默认选中的手机壳下拉框，暂时写死，后续通过props传入初始值
    NowOptions: { str: 'PhoneCase', value: 2 }
  });
  const [selectedTab, setSelectedTab] = useState(0);
  const [InspirationsData, setInspirationsData] = useState<any>(null);
  // 进入ResultPage时记录入口
  const [history_page, setHistory_page] = useState(0)
  //进入历史记录时的入口
  const [Entrance, setEntrance] = useState('')
  const [AllSelectData, setAllSelectData] = useState<any>([])
  // Inspirations组件tab数据
  const [AIToolsListTab, setAIToolsListTab] = useState<any>([{}])
  // 保存当前的初始select数据
  const prevNowOptionsRef = useRef(filterData?.NowOptions);
  const [CreateData, setCreateData] = useState<any>(null)
  const dispatch = useDispatch()
  const [generating, setGenerating] = useState(false); // 新增状态变量
  const [SyntheticData, setSyntheticData] = useState<any>([])
  const [Proportion, setProportion] = useState('1:1')//后续设置结果页展示比例
  // 判断左侧table数据是否渲染完成
  const [RenderingData, setRenderingData] = useState(false)
  const [transferData, setTransferData] = useState<any>(null)
  const [GenerateState, setGenerateState] = useState<any>(null)
  const [ActiveData, setActiveData] = useState<any>(null)
  // 保存未修改时的初始数据
  const [OldAllTitleData, setOldAllTitleData] = useState<string[]>([]);
  // 保存当前的title数据
  const [AllTitleData, setAllTitleData] = useState<string[]>([]);
  const canvasEditor = useCanvasEditor();
  const [isInputChanged, setIsInputChanged] = useState<boolean[]>([]);
  const homeState: HomeState = useSelector(selectHome)
  // 当前模块需要的积分
  const [NowModulIntegral, setNowModulIntegral] = useState(1)
  // 用户的总积分
  let UserAllIntegral = homeState?.UserIntegral

  const tabs = [
    { label: getTranslation(TranslationsKeys.Inspirations), id: 1 },
    { label: getTranslation(TranslationsKeys.Create), id: 2 },
  ];

  // 控制顶部tab切换
  const handleTabClick = (index: any, noClear?: string) => {
    setSelectedTab(index);
    TopTabChange(tabs[index]);
    // 在结果页面进入历史页面时，无需清空定时器
    if (noClear !== 'noClear') {
      clearTimeoutId();
    }
  };

  // 切换tab,入参是tab数据
  const TopTabChange = (tabs: any) => {
    if (tabs?.id === filterData?.tabs?.id) return;
    setFilterData((prevData: any) => ({ ...prevData, tabs }))
    // getRenderingState(false)
  };

  //选中下拉框数据
  const handleQualitySelection = (item: any) => {
    setFilterData((prevData: any) => ({ ...prevData, NowOptions: { str: item?.str, value: item?.value } }))
    getRenderingState(false)
    // console.log("handleQualitySelection选中了", item);
  }

  function transSelectData(data: any) {
    return data?.map((item: any, index: any) => {
      // 去除部分不需要的数据，若后续有修改，可在此处完善
      let categoryName = item?.attributes?.categoryName;
      // if (["Coaster", "Keychain", "Wall Painting", "Non standard"].includes(categoryName)) {
      //   return null;
      // }
      let image = item?.attributes?.icon?.data ? item?.attributes?.icon?.data?.attributes?.url : null;
      return {
        str: categoryName,
        image: image,
        value: item?.attributes?.categoryKey
      };
    }).filter(Boolean); // 过滤掉 null 元素
  }
  // 获取下拉框数据
  const getAllSelectData = async () => {
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      // cms接口地址
      content_type: 'make-2d-category-types',
      populate: ['icon'],
      filters: {
        isDesigner: true
      },
      // pagination: {
      //   // 从第几条开始到第几条结束
      //   start: 0,
      //   limit: 10000,
      // },
    })
    setAllSelectData(transSelectData(json?.data?.data));
    getTabclass(transSelectData(json?.data?.data).find((item: any) => item.value === filterData?.NowOptions?.value))
  }


  function transformTabData(data: any) {
    return [
      {
        tabName: 'All',
        tabValue: 999
      },
      ...data.map((item: any) => {
        return {
          tabName: item.attributes.name,
          tabValue: item.id
        };
      })
    ];
  }
  // 获取下拉框下方对应的tab数据
  const getTabclass = async (item: any) => {
    const json = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      {
        // cms接口地址
        content_type: 'make-2d-ai-designer-classes',
        filters: {
          categoryType: {
            categoryName: {
              $eq: item?.str
            }
          }
        }
      },
    );

    setAIToolsListTab(transformTabData(json?.data?.data))
  }

  // 获取Inspirations模块的数据
  const getAiToolData = (data: any) => {
    setInspirationsData(data);
  }

  // 获取Create模块的数据
  const getCreateData = (data: any) => {
    // console.log("nowStylenowStyledata", data);
    setCreateData(data)
  }

  const EnterResultPage = (history: number) => {
    // 暂时隐藏跳转到结果页功能，后续生成多张结果时再开放
    // setSelectedTab(2);
    setHistory_page(history)
  }

  const prevStep = (history: any) => {
    console.log("history", history);
    if (history === 'Create') {
      handleTabClick(1)
    } else if (history === 'ResultPage') {
      handleTabClick(2, 'noClear')
    }
  }

  // 清空定时器
  const clearTimeoutId = () => {
    // console.log("timeoutId111", timeoutId);
    if (timeoutId) {
      // console.log("timeoutId222", timeoutId);
      clearTimeout(timeoutId);
      timeoutId = null;
    }
  }

  // 获取当前的任务状态
  const getTaskStatusData = async (item: string): Promise<any> => {
    return new Promise(async (resolve, reject) => {
      try {
        const data: any = await getTextImageTaskstatus({
          task_id: item
        });
        setGenerateState(data?.data?.status);
        // 任务状态(0:待处理;1:处理中;2:已完成;3:处理失败;4:已取消;)
        // 如果code不为0，或者status不为0或者1（待处理和处理中不能停），停止轮询
        if (data?.code !== 0 || (data?.data?.status !== 0 && data?.data?.status !== 1)) {
          // 清空定时器
          clearTimeoutId();
          // 如果status为3（合成失败的情况）
          if (data?.data?.status === 3) {
            setGenerating(false); // 失败后，修改生成状态
            UserAllIntegral = UserAllIntegral + NowModulIntegral;
            // 总积分 + 所有模块[当前模块].积分 = 剩余积分
            dispatch(getUserIntegralData(UserAllIntegral));
            dispatch(
              openToast({
                message: getTranslation(TranslationsKeys.string_generate_failed),
                severity: 'error',
              }),
            );
            resolve({
              value: '0', // 失败
              templateId: data?.data?.task_id, // 返回 task_id
              type: AppsDataTYPE['5'] //返回类型，用于埋点
            });
          }
          // 只有一张结果页的时候，将结果渲染到画布上，待后续修改
          if (data?.data?.result_list?.length > 0) {
            const fileExtension = data?.data?.result_list[0]?.file_name?.split('.').pop(); // 获取文件后缀
            if (fileExtension === 'svg') {
              const response = await fetch(data?.data?.result_list[0]?.download_url);
              const blob = await response.blob();
              await getImgStr(blob).then((file) => {
                canvasEditor?.addSvgFile(file as string);
              });
            } else {
              const base64 = await convertToBase64(data?.data?.result_list[0]?.download_url);
              canvasEditor?.addImage(base64, {
                importSource: ImportSource.Cloud,
                fileType: fileExtension,
                key_prefix: data?.data?.result_list[0]?.file_name,
              });
            }
          }

          // 数据赋值，放到结果页使用
          setSyntheticData(data?.data?.result_list);
          setGenerating(false); // 成功后，修改生成状态
          resolve({
            value: '1', // 成功
            templateId: data?.data?.task_id, // 返回 task_id
            type: AppsDataTYPE['5'] //返回类型，用于埋点
          });
        } else {
          // 接口调用成功后，再延迟2秒下一次调用（沟通后的需求）
          timeoutId = setTimeout(() => getTaskStatusData(item).then(resolve).catch(reject), 2000);
        }
      } catch (e) {
        setGenerating(false);
        clearTimeoutId();
        editorToastShow({
          tips: getTranslation(TranslationsKeys.NETWORK_ABNORMAL),
          type: EditorToastType.error,
        });
        reject(e);
      }
    });
  };

  // type: 1：点击弹窗生成图片，2：creat中生成图片
  const Generate = async (type: number) => {
    try {
      setGenerating(true); // 清理定时器时隐藏蒙版
      if (type === 0) {
        setProportion(`${InspirationsData?.selectDown?.str[0]}:${InspirationsData?.selectDown?.str[1]}`)
        setTransferData(InspirationsData)
        const data = await getTextImageCreatetask({
          prompt: InspirationsData?.description,
          ratio_width: InspirationsData?.selectDown?.str[0],
          ratio_height: InspirationsData?.selectDown?.str[1],
          style_id: InspirationsData?.style_id || 0
        })
        if (data?.code === 0) {
          // 总积分 - 所有模块[当前模块].积分 = 剩余积分
          UserAllIntegral = UserAllIntegral - NowModulIntegral
          dispatch(getUserIntegralData(UserAllIntegral));
          return await getTaskStatusData(data?.data?.task_id)
        } else {
          setGenerating(false)
          return {
            value: '0', // 失败
            templateId: data?.data?.task_id, // 返回 task_id
            type: AppsDataTYPE['5'] //返回类型，用于埋点
          };
        }
        // create页面与结果页中生成图片
      } else if (type === 1) {
        setProportion(`${CreateData?.selectDown?.str[0]}:${CreateData?.selectDown?.str[1]}`)
        setTransferData(CreateData)
        const data = await getTextImageCreatetask({
          prompt: CreateData?.description,
          ratio_width: CreateData?.selectDown?.str[0],
          ratio_height: CreateData?.selectDown?.str[1],
          style_id: CreateData?.nowStyle || 0
        })

        if (data?.code === 0) {
          // 总积分 - 所有模块[当前模块].积分 = 剩余积分
          UserAllIntegral = UserAllIntegral - NowModulIntegral
          dispatch(getUserIntegralData(UserAllIntegral));
          return await getTaskStatusData(data?.data?.task_id)
        } else {
          setGenerating(false)
          return {
            value: '0', // 失败
            templateId: data?.data?.task_id, // 返回 task_id
            type: AppsDataTYPE['5'] //返回类型，用于埋点
          };
        }
      }
    } catch (e) {
      setGenerating(false)
      editorToastShow({
        tips: getTranslation(TranslationsKeys.NETWORK_ABNORMAL),
        type: EditorToastType.error,
      });
      throw e;
    }
  }

  const measuredNextClick = measureExecutionTime(Generate);

  // 跳转到历史页面
  const JumpHistory = (_: string) => {
    setSelectedTab(3)
    setEntrance(_)
  }

  const getRenderingState = (item: boolean) => {
    console.log("==========>", item);
    setRenderingData(item)
  }

  const InspirationsClick = (data: any, AllTitleData: any, OldAllTitleData: any, isInputChanged: any) => {
    setActiveData(data)
    // console.log("AllTitleData", AllTitleData, "OldAllTitleData", OldAllTitleData);
    setAllTitleData(AllTitleData)
    setOldAllTitleData(OldAllTitleData)
    setIsInputChanged(isInputChanged)
  }

  useEffect(() => {
    // 切换产品类型，清空tab数据
    setAIToolsListTab([{}])
    // 初次进入时，只调用一次接口
    if (filterData?.NowOptions && filterData?.NowOptions !== prevNowOptionsRef.current) {
      getTabclass(filterData?.NowOptions)
    }
    prevNowOptionsRef.current = filterData?.NowOptions;
  }, [filterData?.NowOptions])

  useEffect(() => {
    getAllSelectData()
  }, [])

  useEffect(() => {
    // 当前选中的ai模块所需积分
    if (!homeState?.nowActiveAiModule) return;
    const costClass = homeState.nowActiveAiModule?.costClass;
    const cost = homeState?.AiModeIntegralData?.[costClass]?.cost;
    if (cost !== undefined) {
      setNowModulIntegral(cost);
    } else {
      console.log("costClass数据为空，请查看cms中class字段以及各模块所需参数值的接口");
    }
  }, [homeState?.nowActiveAiModule]);

  return (
    <div className="PopArtify_box">
      {selectedTab !== 2 && selectedTab !== 3 && selectedTab !== 4 &&
        <>
          <div className="PopArtify_box_top">
            <div className="PopArtify_box_top_left">
              <div className="PopArtify_box_top_left_img_box" onClick={() => { JumpStep('', 1, 'prev') }}>
                <img src={return_icon} className="PopArtify_box_top_left_img" />
              </div>
              <div className="PopArtify_box_top_left_title">{getTranslation(TranslationsKeys.AIProductDesigner)}</div>
            </div>
          </div>
          <TopTab tabs={tabs} handleTabClick={handleTabClick} selectedTab={selectedTab} />
          <div style={{ height: '16px' }}></div>
          {
            AllSelectData?.length > 0 &&
            <SelectDown
              values={AllSelectData}
              defaultSelectValue={filterData?.NowOptions?.value}
              callback={handleQualitySelection}
            />
          }
          <div style={{ height: '16px' }}></div>
        </>
      }

      {/* 通过样式控制显隐 */}
      <div style={{ display: selectedTab === 0 ? '' : 'none' }} className="PopArtify_box_AIToolsList">
        <AIToolsList
          filterData={filterData}
          handleTabClick={handleTabClick}
          getAiToolData={getAiToolData}
          EnterResultPage={EnterResultPage}
          AIToolsListTab={AIToolsListTab}
          Generate={measuredNextClick}
          generating={generating}
          getRenderingState={getRenderingState}
          InspirationsClick={InspirationsClick}
        />
      </div>

      <div style={{ display: selectedTab === 1 ? '' : 'none' }}>
        <Create
          filterData={filterData}
          InspirationsData={InspirationsData}
          EnterResultPage={EnterResultPage}
          JumpHistory={JumpHistory}
          getCreateData={getCreateData}
          Generate={measuredNextClick}
          generating={generating}
          RenderingData={RenderingData}
        />
      </div>
      {/* 暂时隐藏，不需要结果页 */}
      {/* <div style={{ display: selectedTab === 2 ? '' : 'none' }}>
        <ResultPage
          history_page={history_page}
          handleTabClick={handleTabClick}
          JumpHistory={JumpHistory}
          Generate={Generate}
          generating={generating}
          SyntheticData={SyntheticData}
          descriptionData={transferData}
          Proportion={Proportion}
          GenerateState={GenerateState}
        />
      </div> */}
      {
        selectedTab === 3 &&
        <div style={{ display: selectedTab === 3 ? '' : 'none' }}>
          <History
            prevStep={prevStep}
            Entrance={Entrance}
            SourcePage={AppsDataTYPE['5']}
          />
        </div>
      }
      {
        selectedTab === 4 &&
        <div style={{ display: selectedTab === 4 ? '' : 'none' }}>
          <InspirationsCreat
            EnterResultPage={EnterResultPage}
            Generate={measuredNextClick}
            handleTabClick={handleTabClick}
            getAiToolData={getAiToolData}
            ActiveData={ActiveData}
            AllTitleData={AllTitleData}
            OldAllTitleData={OldAllTitleData}
            generating={generating}
            isInputChanged={isInputChanged}
          />
        </div>
      }
    </div>
  )
}