import React, { useState, useEffect } from "react";
import './index.scss'
import { Tooltip } from "@mui/material";
import Icon_Coins from 'src/images/2dEditor/Apps_icon/Icon_Coins.png'
import return_icon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png'
import login_img from 'src/images/2dEditor/Apps_icon/login_img.gif'
import LottiePlayer from 'react-lottie-player'
import LoadingAnimation from 'src/images/lottie/loading.json'
import { useDispatch, useSelector } from 'react-redux'
import {
    selectHome,
    HomeState,
    getUserIntegralData,
} from 'src/state/reducers/home'
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

export default function InspirationsCreat(props: any) {
    const { ActiveData, EnterResultPage, Generate, handleTabClick, getAiToolData, OldAllTitleData, AllTitleData, generating, isInputChanged } = props;
    const { getTranslation } = useCustomTranslation();
    // 保存当前的title数据
    const [AllTitleData1, setAllTitleData1] = useState<string[]>(AllTitleData);
    // 跟踪输入框是否已经被修改
    const [isInputChanged1, setIsInputChanged1] = useState<boolean[]>(isInputChanged);
    const homeState: HomeState = useSelector(selectHome)
    // 当前模块需要的积分
    const [NowModulIntegral, setNowModulIntegral] = useState(1)
    // 用户的总积分
    let UserAllIntegral = homeState?.UserIntegral

    const parts = AllTitleData1?.map((part: any, index: any) => {
        // 如果index是奇数，那么这个部分是在<...>标签中的
        if (index % 2 === 1) {
            return (
                <Tooltip
                    title={OldAllTitleData[index]}
                >
                    <input
                        className="input_box"
                        placeholder={OldAllTitleData[index]}
                        style={{ width: `calc(min(${OldAllTitleData[index].length - 1}ch, 100%))` }}
                        value={
                            // 如果未修改则使用空值，否则使用用户输入的值
                            // isInputChanged1[index] ? AllTitleData1[index] : ""
                            AllTitleData1[index]
                        }
                        onChange={(e) => {
                            if (e.target.value.length <= 40) {
                                const newAllTitleData = [...AllTitleData1];
                                newAllTitleData[index] = e.target.value;
                                setAllTitleData1(newAllTitleData);

                                const newIsInputChanged = [...isInputChanged1];
                                newIsInputChanged[index] = true;
                                setIsInputChanged1(newIsInputChanged);
                            }
                        }}
                    />
                </Tooltip>
            );
        } else {
            return <span className="Modal_box_title">{part}</span>;
        }
    });

    const EditFull_click = () => {
        // console.log("EditFull_click", AllTitleData1.join(''), ActiveData);
        // 如果在提交时，未填写input框，那么使用原始数据
        const finalData = AllTitleData1.map((data, index) => data || OldAllTitleData[index]).join('');
        handleTabClick(1)
        getAiToolData({ ...ActiveData, title: finalData })
    }

    const Generate_click = async () => {
        // console.log("Generate_click", AllTitleData1);
        // if (generating === true) return;
        EnterResultPage(0)
        Generate(0)
    }

    // 监听输入框的变化，如果变化了，那么重新赋值数据
    useEffect(() => {
        getAiToolData({
            description: AllTitleData1.join(''),
            selectDown: { str: ActiveData?.selectDown?.str || [1, 1], value: ActiveData?.selectDown?.value || 1 },
            style_id: ActiveData?.styleData?.style_id || 0
        })
    }, [AllTitleData1])

    useEffect(() => {
        // 当前选中的ai模块所需积分
        if (!homeState?.nowActiveAiModule) return;
        const costClass = homeState.nowActiveAiModule?.costClass;
        const cost = homeState?.AiModeIntegralData?.[costClass]?.cost;
        if (cost !== undefined) {
            setNowModulIntegral(cost);
        } else {
            console.log("costClass数据为空，请查看cms中class字段以及各模块所需参数值的接口");
        }
    }, [homeState?.nowActiveAiModule]);

    return (
        <div className="InspirationsCreat_box">
            <div className="PopArtify_box_top">
                <div className="PopArtify_box_top_left">
                    <div className="PopArtify_box_top_left_box" onClick={() => { handleTabClick(0) }}>
                        <img src={return_icon} className="PopArtify_box_top_left_img" />
                    </div>
                    <div className="PopArtify_box_top_left_title">{getTranslation(TranslationsKeys.AIProductDesigner)}</div>
                </div>
            </div>
            <div className="Modal_box">
                <img src={ActiveData?.OriginalImage} className="Modal_box_image" key={ActiveData?.OriginalImage} />
                <div className="Modal_box_border"></div>
                <div className="modal_down">
                    {
                        // 只有当style_name和style_img都存在时才显示
                        !!ActiveData?.styleData?.style_name && !!ActiveData?.styleData?.style_img && (
                            <div className="Modal_box_style">
                                <img src={ActiveData?.styleData?.style_img} className="style_img" key={ActiveData?.styleData?.style_img} />
                                <div className="style_name">{ActiveData?.styleData?.style_name}</div>
                            </div>
                        )
                    }
                    <div className="modal_txt">
                        {parts}
                    </div>
                </div>
            </div>
            <div className="down_box">
                <div className="Generate_btn_left" onClick={() => { Generate_click() }}>
                    <div className="Generate_btn_text">
                        {getTranslation(TranslationsKeys.string_generate)}
                    </div>
                    <img src={Icon_Coins} className="Generate_btn_img" />
                    <div>{NowModulIntegral}</div>
                </div>
                <div className="Generate_credits">{getTranslation(TranslationsKeys.MY_CREDITS)}<span style={{ marginLeft: 4 }}>{UserAllIntegral}</span></div>
                <div className="Modal_box_Edit" onClick={() => { EditFull_click() }}>{getTranslation(TranslationsKeys.EditFullPrompt)}</div>
            </div>
            {
                generating &&
                <div className="Progress_box">
                    {/* <img src={login_img} className="Progress_box_img" />
                    <div className="Progress_title">Generating...</div> */}
                    <div className="load">
                        <LottiePlayer
                            loop
                            play
                            className="loadingBox"
                            animationData={LoadingAnimation}
                        />
                    </div>
                </div>
            }
        </div>
    )
}
