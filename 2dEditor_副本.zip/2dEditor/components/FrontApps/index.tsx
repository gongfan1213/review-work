import React, { useState, useEffect } from "react";
import './index.scss'
import AppsPage from "./AppsPage";
import RoyalPortrait from "./RoyalPortrait";
import Pet from "./Pet";
import History from "./History";
import MainUiLeftUpload from '../MainUi/MainUiLeft/MainUiLeftUpload/MainUiLeftUpload'
import AIProductDesigner from './AIProductDesigner/index'
import PetPortrait from "./PetPortrait/index";
import { AppsDataTYPE } from 'src/templates/2dEditor/components/FrontApps/const'

export default function FrontApps(props: any) {
  const { location } = props;
  const [step, setStep] = useState<any>(1);
  // 标题
  const [title, setTitle] = useState('')
  // 大类
  const [type, setType] = useState('')
  const [history, setHistory] = useState<any>([]); // 保存历史状态
  const [Entrance, setEntrance] = useState('')
  const [Step2Data, setStep2Data] = useState({});
  const [Step4Data, setStep4Data] = useState(null);
  const [Petindex, setPetIndex] = useState<any>(null)
  const [NewHistoryData, setNewHistoryData] = useState<any>([]);// 保存历史数据

  // 返回上一步 StepNumber:步骤数,Data:判断是否需要清空上传的数据,title:人物换脸标题需要变化，而不是使用旧值
  const prevStep = (StepNumber: any, Data: any, title?: any) => {
    // console.log('======', StepNumber, Data)
    // 获取上一个历史状态
    const lastHistory = history[history.length - 2];
    if (title?.length > 0) {
      // console.log("t-----------", title);
      setTitle(title)
    } else {
      // console.log("tlastHistory-----------", lastHistory);
      setTitle(lastHistory?.title);
    }
    setType(lastHistory?.type);
    setHistory(history.slice(0, -1)); // 移除最后一个历史状态
    setEntrance('')
    // 在Pet模块点击返回时，清空上传处的数据
    if (Data === 'Kid') {
      setStep4Data(null)
    } else {
      // setUploadsData({})
    }
    // 有步骤数时，直接跳转到指定步骤（History模块在首页和Pet中都有入口）
    StepNumber && setStep(StepNumber);
    if (!StepNumber && step > 1) {
      setStep(step - 1);
    }
  };

  // title:标题，type：大类，StepNumber：步骤数，StepEntrance：入口（历史记录从home页进入的需要传入）
  const nextStep = (title: string, type: string, StepNumber: number, StepEntrance: string, itemData: any) => {
    setHistory([...history, { title, type }]); // 在进入下一步时，保存当前的状态
    setNewHistoryData([...NewHistoryData, { step: type, data: itemData }]); // 保存当前步骤的数据
    setTitle(title);
    setType(type);
    // Apps模块中的History模块入口
    setEntrance(StepEntrance)
    // 有步骤数时，直接跳转到指定步骤（Pet模块中有两个需要跳转的地方）
    StepNumber && setStep(StepNumber);
    if (!StepNumber && step < 6) {
      setStep(step + 1);
    }
  };

  // 跳转到指定步骤，title:标题，StepComponents：跳转组件的step，StepType：跳转类型,itemData:传递的数据
  const JumpStep = (title: string, StepComponents: string, StepType: any, itemData?: any) => {
    if (StepType === 'next') {
      setHistory([...history, { title, StepComponents }]); // 在进入下一步时，保存当前的状态
      setNewHistoryData([...NewHistoryData, { step: StepComponents, data: itemData }]); // 保存当前步骤的数据
      setStep(StepComponents);
    } else if (StepType === 'prev') {
      setHistory(history.slice(0, -1)); // 移除最后一个历史状态
      setNewHistoryData(NewHistoryData.slice(0, -1)); // 移除最后一项数据
      setStep(StepComponents);
    }
  }

  // 传递到pet模块中展示的数据,data:步骤2(选择模块)的数据,active:当前选中的模块,title用于人脸模块展示标题
  const handlePetData = (data: any, active: string, title: string) => {
    // console.log("--------handlePetData", { data, active });
    setStep2Data({ data, active })
    title && setTitle(title)
  }

  // Step4Data:步骤4(上传模块)的数据
  const handleStep4Data = (data: any) => {
    console.log("handleStep4Data", data);
    setStep4Data(data)
    prevStep('', '')
  }

  // Pet模块传递给MainUiLeftUpload模块的数据
  const PetTransferData = (index: any, item: any, clearUpload: boolean) => {
    setPetIndex({ index, item, clearUpload })
  }

  // 当从其他地方跳转进入第二步或者AIProductDesigner时，清空数据缓存内的数据
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const AiTitle = window.sessionStorage.getItem('AiTitle')
      // const AiToolsAllData = window.sessionStorage.getItem('AiToolsAllData')
      // 判断是否是第二页，文生图页，宠物分身页返回首页时清空缓存
      if ((step == 2 || step == AppsDataTYPE['6'] || step == AppsDataTYPE['5']) && AiTitle) {
        // 若AiTitle，AiToolsAllData，sessionAiModeIntegralData不存在也不会报错
        window?.sessionStorage?.removeItem('AiTitle')
        window?.sessionStorage?.removeItem('AiToolsAllData')
        window?.sessionStorage?.removeItem('sessionAiModeIntegralData')
      }
    }
  }, [step])

  return (
    <div className='FrontApps_box'>
      {step === 1 && <AppsPage nextStep={nextStep} JumpStep={JumpStep} location={location} />}
      {/* 设计优化，使用display控制显示与隐藏，不移出dom元素，保留组件 */}
      <RoyalPortrait step={step} type={type} title={title} nextStep={nextStep} prevStep={prevStep} handlePetData={handlePetData} JumpStep={JumpStep} />
      <Pet type={type} step={step} title={title} nextStep={nextStep} prevStep={prevStep} Step2Data={Step2Data} Step4Data={Step4Data} handlePetData={handlePetData} PetTransferData={PetTransferData} setStep4Data={setStep4Data} />
      {step === 4 && <MainUiLeftUpload isApps={true} handleStep4Data={handleStep4Data} Petindex={Petindex} prevStep={prevStep} />}
      {step === 5 && <History prevStep={prevStep} Entrance={Entrance} />}
      {step === AppsDataTYPE['6'] && <PetPortrait JumpStep={JumpStep} />}
      {step === AppsDataTYPE['5'] && <AIProductDesigner JumpStep={JumpStep} NewHistoryData={NewHistoryData} />}
    </div>
  )
}