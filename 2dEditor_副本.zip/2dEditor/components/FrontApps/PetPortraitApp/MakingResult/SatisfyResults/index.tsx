

import React, {useState} from 'react';

import { Button } from 'src/components/MakeUI';

import "./index.scss";

import goodIcon from 'src/assets/svg/white_good.svg';
import badIcon from 'src/assets/svg/white_bad.svg';
import closeIcon from 'src/assets/svg/close.svg'

export default function SatisfyResult () {

  const [showModalType, setShowModalType] = useState('');
  const [goodCheckLabels, setGoodCheckLabels] = useState([
    {
      id: 1,
      label: "much like my pet",
      checked: false,
    },
    {
      id: 2,
      label: "beautiful and variety template",
      checked: false,
    },
    {
      id: 3,
      label: "looks very natural",
      checked: false,
    },
  ]);

  const [badCheckLabels, setBadCheckLabels] = useState([
    {
      id: 1,
      label: "not like my pet",
      checked: false,
    },
    {
      id: 2,
      label: "don’t like these templates",
      checked: false,
    },
    {
      id: 3,
      label: "looks very unnatural",
      checked: false,
    },
  ]);

  const selectItem = (item: any) => {
    const isGood = showModalType === 'good';
    const checkLabels = isGood ? goodCheckLabels : badCheckLabels;
    const newCheckLabels = checkLabels.map((labelItem) => ({
      ...labelItem,
      checked: labelItem.id == item.id ? !labelItem.checked : labelItem.checked,
    }));
    isGood ? setGoodCheckLabels(newCheckLabels) : setBadCheckLabels(newCheckLabels);
  }

  const submit = () => {
    const reasons = document.getElementById('reasons')?.value;
    console.log('reasons',reasons)
    initModalState()
  }

  const initModalState = () => {
    setShowModalType('');
    const setCheckLabels = showModalType === 'good' ? setGoodCheckLabels : setBadCheckLabels;
    setCheckLabels(prev => prev.map(item => ({ ...item, checked: false })));
  }

  const ModalContent = ({
    title,
    checkLabels,
    otherReasons,
    setOtherReasons,
    submit,
    closeModal
  }: {
    title: string;
    checkLabels: { id: string; label: string; checked: boolean }[];
    submit: () => void;
    closeModal: () => void;
  }) => (
    <div className='result_investigate_modal'>
      <img className='modal_close_icon' onClick={initModalState} src={closeIcon} alt="" />
      <>
        <h3 className='investigate_title'>{title}</h3>
        <ul className='investigate_ui'>
          {checkLabels.map(item => (
            <li key={item.id} className='investigate_li' onClick={() => selectItem(item)}>
              <input type="checkbox" checked={item.checked} readOnly />
              <span>{item.label}</span>
            </li>
          ))}
        </ul>
        <p className='reason_title'>Other Reasons:</p>
        <textarea
          id="reasons"
          className='reason_textarea'
          placeholder="We very appreciate your advice which helps us do better."
        />
        <Button 
          loading={false}
          className='submit_btn'
          onClick={submit}
        >
          <span>Submit</span>
        </Button>
      </>
    </div>
  );

  const ModalSwitch = () => {
    switch (showModalType) {
      case 'good':
        return (
          <ModalContent
            title="Why did you think it's good"
            checkLabels={goodCheckLabels.map(item => ({ ...item, id: item.id.toString() }))}
            submit={submit}
            closeModal={() => setShowModalType('')}
          />
        );
      case 'bad':
        return (
          <ModalContent
            title="Why did you think it's not good"
            checkLabels={badCheckLabels.map(item => ({ ...item, id: item.id.toString() }))}
            submit={submit}
            closeModal={() => setShowModalType('')}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className='__satisfy_result_layout'>
     <div className='result_operator_box'>
        <p className='des'>Stisfied with the result ?</p>
        <div>
          <img src={goodIcon} alt="" onClick={() => setShowModalType('good')}/>
          <img src={badIcon} alt="" onClick={() => setShowModalType('bad')}/>
          <img src={closeIcon} alt="" />
        </div>
     </div>
     <ModalSwitch />
    </div>
  );
}