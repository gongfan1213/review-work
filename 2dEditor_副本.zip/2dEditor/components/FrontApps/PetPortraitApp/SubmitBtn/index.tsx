// 依赖
import React from "react";

// 组件
import { Button } from 'src/components/MakeUI';

// 样式
import './index.scss';

// 图标
import coinsIcon from '/src/images/2dEditor/Apps_icon/Icon_Coins.png';

export default function SubmitBtn(props:any){

  const {text,credits,submitCallBack,disabled=false} = props;

  return (
    <div className="__pet_partrait_submit_btn">
      <Button 
          loading={false}
          className='submit_btn'
          onClick={submitCallBack}
          disabled={disabled}
        >
          <span className="text">{text}</span>
          <img src={coinsIcon} alt="" />
          <span>{20}</span>
        </Button>
        <div className="credits_info">
          my credits：<span>{credits}</span>
        </div>
    </div>
  )
}