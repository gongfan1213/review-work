// 依赖
import React, { useState, useEffect, useRef } from "react";
import { useDispatch } from 'react-redux'
import { convertToBase64 } from 'src/common/utils'
import { useCanvasEditor } from 'src/templates/2dEditor/hooks/context';
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common';

// 组件
import Loading from 'src/components/Loading';
import SubmitBtn from '../SubmitBtn/index';
import { openToast } from 'src/state/reducers/toast';
import CommonImage from "src/components/CommonImage";

// 图标
import returnIcon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png';
import addFileIcon from 'src/assets/svg/add_file.svg';
import loadingIcon from 'src/assets/svg/white_loading.svg';

// service
import {
  petPortraitCreateTask, getModelTrainTaskList, getHistoryList, petPortraitGetTaskStatus
} from 'src/templates/2dEditor/service/2dEditService';

// 样式
import "./index.scss";
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';


export default function PoratraitStyle(props: any) {

  const { isShowPortraitStyle, portraitStyleGoToCreate, portraitStyleGetResult, gotoPageIndex, checkItemData } = props;
  const [isSubmitLoading, setIsSubmitLoading] = useState(false);
  const [isGetDataLoading, setIsGetDataLoading] = useState(false);
  const [clickIndex, setClickIndex] = useState<any>(null);
  const [hasSelect, setHasSelect] = useState(false);
  const [modelId, setModalId] = useState(0);
  const [taskList, setTaskList] = useState([] as any[]);
  const dispatch = useDispatch();
  const canvasEditor = useCanvasEditor();
  const isUpdateRef = useRef(false);
  const { getTranslation } = useCustomTranslation();

  console.log('==props', checkItemData)

  const clickItem = (item: any, index: number) => {
    setModalId(item.id);
    setClickIndex(index);
    setHasSelect(true);
  }

  const submit = async () => {
    setClickIndex(null);
    setIsSubmitLoading(true);
    const params = { style_id: checkItemData.id, model_id: modelId };
    const res = await petPortraitCreateTask(params);
    if (res?.code == 0) {
      // portraitStyleGetResult()
      getDataList(res?.data?.task_id);
      // setIsSubmitLoading(false);
    } else {
      dispatch(
        openToast({
          message: res?.msg || getTranslation(TranslationsKeys.FAILED_GENERATE),
          severity: 'error',
        }),
      )
      setIsSubmitLoading(false);
    }
  }

  // 轮询更新数据状态
  const getTaskStatus = async (taskId: string) => {
    isUpdateRef.current = true;
    const res = await petPortraitGetTaskStatus({ task_id: taskId });
    if (res?.data?.status === 2) {
      const { result_list, task_id, status } = res.data;
      const tempdata = result_list.map(item => ({ ...item, task_id, status }))
      isUpdateRef.current = false;
      console.log('====tempdata', tempdata)
      addToCavas(tempdata[0]);
      setIsSubmitLoading(false);
    } else if ([3, 4].includes(res?.data?.status)) {
      isUpdateRef.current = false;
      dispatch(
        openToast({
          message: getTranslation(TranslationsKeys.FAILED_GENERATE_RESULT),
          severity: 'error',
        }),
      )
      setIsSubmitLoading(false);
    } else {
      console.log('isUpdate', isUpdateRef.current);
      if (isUpdateRef.current) {
        setTimeout(() => getTaskStatus(taskId), 1000); // 假设1秒后重试
      }
    }
  };

  // 获取生成结果数据
  const getDataList = async (id: any) => {
    const params = { task_type: 6, pagination: { page: 1, page_size: 20 } };
    const res = await getHistoryList(params);
    if (res?.code == 0) {
      const taskId = res?.data?.history_list[0]?.task_id;
      if (id) {
        getTaskStatus(id);
      } else {
        setIsSubmitLoading(false);
        dispatch(
          openToast({
            message: getTranslation(TranslationsKeys.FAILED_GENERATE_TASK_ID),
            severity: 'error',
          }),
        )
      }
    }
  }

  // 添加到画布中
  const addToCavas = async (data: any) => {
    // const decodedUrl = decodeURIComponent(data.download_url);
    let decodedUrl =
      data.download_url.indexOf('oss-cn-shenzhen') !== -1
        ? data.download_url
        : decodeURIComponent(data.download_url)
    const fileExtension = data.file_name.split('.').pop(); // 获取文件后缀
    const base64 = await convertToBase64(decodedUrl);
    canvasEditor?.addImage(base64,
      {
        importSource: ImportSource.Cloud,
        fileType: fileExtension,
        key_prefix: data.file_name
      });
    setHasSelect(false);
  }

  // 获取模型列表
  const getTaskList = () => {
    const params = { pagination: { page: 1, page_size: 20 } }
    setIsGetDataLoading(true);
    getModelTrainTaskList(params).then((res) => {
      console.log('===res', res)
      const tasks = res?.data?.list || [];
      const filteredTasks = tasks.filter((item: any) => [0, 1, 2].includes(item.status));
      if (res?.data?.total > 0 && filteredTasks.length > 0) {
        setTaskList(filteredTasks);
      }
      setIsGetDataLoading(false);
    })
  }

  useEffect(() => {
    if (isShowPortraitStyle) {
      getTaskList()
    }
    setHasSelect(false)
  }, [isShowPortraitStyle])

  console.log('=====tasklist', taskList)

  return (
    <div className="__portrait_style_layout" style={{ display: isShowPortraitStyle ? 'flex' : 'none' }}>
      <div className="layout_reback">
        <img src={returnIcon} alt="" onClick={() => gotoPageIndex()} />
        <span>Pet Poratrait</span>
      </div>
      <div className="layout_content">
        <div className="image_box">
          <img src={checkItemData?.attributes?.image?.data?.attributes?.url} alt="" loading="lazy" />
        </div>
        <div className="content_desTitle">make a portrait for:  </div>
        <div className="list_content">
          <div className='upload_file_icon'>
            <img src={addFileIcon} alt="" className='upload_file_icon' onClick={portraitStyleGoToCreate} />
          </div>
          <div className="img_list">
            {
              taskList.map((item: any, index: number) => {
                if (![0, 1, 2].includes(item.status)) return null;
                const isCompleted = item.status === 2;
                return (
                  <div className="list_item" key={item.id}>
                    <CommonImage
                      src={item.thumb_path}
                      style={{ border: clickIndex === index ? '2px solid #33BF5A' : 'none', objectFit: 'cover' }}
                      onClick={() => isCompleted && clickItem(item, index)}
                    />
                    <Loading className='loading' loading={isGetDataLoading} isAbsolute />
                    {!isCompleted && (
                      <div className="laoding_box">
                        <img className="loading_img" src={loadingIcon} alt="" />
                        <span>making...</span>
                      </div>
                    )}
                  </div>
                );
              })
            }
          </div>
        </div>
      </div>
      <SubmitBtn text='Generate' credits={100} disabled={!hasSelect} submitCallBack={() => submit()} />
      <Loading className='loading' loading={isSubmitLoading} isAbsolute />
    </div>
  );
}