// 依赖
import React, {useEffect, useState,useRef} from "react";
import { useDispatch } from 'react-redux';

// 组件
import Loading from 'src/components/Loading';
import MainUiLeftFooterBar from "src/templates/2dEditor/components/MainUiLeftFooterBar/MainUiLeftFooterBar";
import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';
import { Masonry } from 'react-masonry-component2';
import Popover from '@material-ui/core/Popover';
import { openToast } from 'src/state/reducers/toast';
import CommonImage from "src/components/CommonImage";
import CustomCheckbox from "src/components/CustomCheckbox";

// service
import { getModelTrainTaskList, getModelTrainTaskStatus, deleteModelTrainTask } from 'src/templates/2dEditor/service/2dEditService';

// 样式
import './index.scss';
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';

// 图标
import moreIcon from 'src/images/2dEditor/more.png';
import returnIcon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png';
import addFileIcon from 'src/assets/svg/add_file.svg';
import loadingIcon from 'src/assets/svg/white_loading.svg';

import { IResponseBase } from 'src/services';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

// Popover样式
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    paper: {
      width: '80px',
      backgroundColor: '#fff',
      fontSize: 12
    },
    operatorItem: {
      height: '34px',
      lineHeight: "34px",
      paddingLeft: '8px',
      cursor: 'pointer'
    }
  }),
);

export default function MyAvatar(props: any) {
  const { isShowMyAvatar, myAvatarReBack, myAvatarGotoCreate } = props;
  const classess = useStyles();
  const [isLoading, setIsLoading] = useState(false);
  const [selectAll, setSelectAll] = useState(false);
  const [selectedItems, setSelectedItems] = useState<any>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [anchorEl, setAnchorEl] = useState<any>(null);
  const [openedPopoverId, setOpenedPopoverId] = useState<any>(null);
  const [isItemDeleteId, setIsItemDeleteId] = useState<string | null>(null);
  const [isShowFooterbar, setIsShowFooterbar] = useState(false);
  const [dialogConfirmLoading, setDialogConfirmLoading] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [hasIsMaking, setHasIsMaking] = useState(false);
  const isUpdateRef = useRef(false);
  const dispatch = useDispatch()
  const [hoverStates, setHoverStates] = useState<{ [key: string]: boolean }>({});
  const { getTranslation } = useCustomTranslation();

  const [dataList, setDataList] = useState([] as any[]);

  const handleClick = (event: any, id: number): void => {
    setAnchorEl(event.currentTarget);
    setOpenedPopoverId(id);
  };

  const popoverCloseHandle = () => {
    setAnchorEl(null);
    setOpenedPopoverId(null);
  };

  const open = Boolean(anchorEl);
  const popoverId = open ? 'simple-popover' : undefined;

  const clickInputcheck = (item:any) => {
    setSelectAll(false);

    const newSelectedItems = new Set(selectedItems);
    if (newSelectedItems.has(item.id)) {
      newSelectedItems.delete(item.id);
    } else {
      newSelectedItems.add(item.id);
    }

    setSelectedItems(Array.from(newSelectedItems));
    if (Array.from(newSelectedItems).length > 0) {
      console.log(true)
      setIsEditing(true);
    } else {
      console.log(false)
      setIsEditing(false);
    }
  }

  const deleteItemHandle = async (event: any, item: any) => {
    event.stopPropagation(); 
    popoverCloseHandle();
    setSelectedItems([item.id]);
    setOpenDialog(true);
    setIsItemDeleteId(item.id);
  }

  const selectItemHandle = (event: any, item: any) => {
    event.stopPropagation(); 
    popoverCloseHandle();
    setIsEditing(true);
    setSelectedItems([...selectedItems, item.id]);
  }

  const handleSelectAll = () => {
    setSelectAll(!selectAll);
    if (!selectAll) {
      setSelectedItems(dataList.filter(item => item.status == 2).map((item) => item.id));
    } else {
      setSelectedItems([]);
    }
  }

  const handleDeleteSelected = async () => {
    setDialogConfirmLoading(true);
    const res = await deleteModelTrainTask({ ids: selectedItems });
    if (res?.code === 0) {
      setSelectedItems([]);
      setOpenDialog(false);
      setIsItemDeleteId(null);
      setIsShowFooterbar(false);
      const tempDataList = dataList.filter((item: any) => !selectedItems.includes(item.id));
      setDataList([...tempDataList]);
      setDialogConfirmLoading(false);
      dispatch(
        openToast({
          message: getTranslation(TranslationsKeys.DELETE_SUCCESSFULLY),
          severity: 'success',
        }),
      );
      setIsEditing(false);
      setSelectAll(false);
      setSelectedItems([]);
    } else {
      setDialogConfirmLoading(false);
      dispatch(
        openToast({
          message: res?.msg || '',
          severity: 'error',
        }),
      )
    }
  }

  const handleDialogClose = () => {
    setOpenDialog(false);
    setIsItemDeleteId(null);
    setIsShowFooterbar(false);
  }

  const handleSetEditing = () => {
    setIsEditing(false);
    setSelectedItems([]);
    setSelectAll(false);
  }

  const dataListStatus = async (id: string, data: any[]) => {
    let timer = null;
    // isUpdateRef.current = true;
    const hasIsMaking = data.some((item:any) => item.status == 0 || item.status == 1);
    const res = await getModelTrainTaskStatus({ task_id: id });
    if (res?.data?.status === 2) {
      if (timer && !hasIsMaking) clearTimeout(timer);
      data.map((item: any) => item.task_id === res?.data?.task_id && (item.status = 2));
      setDataList([...data]);
      isUpdateRef.current = false
    } else if ([3,4].includes(res?.data?.status)) {
      if (timer && !hasIsMaking) clearTimeout(timer);
      isUpdateRef.current = false
    } else {
      if (hasIsMaking && isUpdateRef.current) {
        timer = setTimeout(() => {
          dataListStatus(id,data);
        }, 2000);
      }
    }
  }

  const getTaskList = (requestType?:string) => {
    console.log('===requestType',requestType)
    setIsLoading(true);
    const params = { pagination: { page: 1, page_size: 20 } };
    getModelTrainTaskList(params).then((res:any) => {
      const { data } = res as IResponseBase<{ list: any[]; total: number; }> || {};
      setHasMore(data.list?.length === 20);
      if (data?.list?.length > 0) {
        const tempdata = data.list.filter((item:any) => [0, 1, 2].includes(item.status));
        const hasIsMaking = tempdata.some((item:any) => item.status == 0 || item.status == 1);
        setHasIsMaking(hasIsMaking)
        if (requestType == 'effectRequest') {
          setDataList([...tempdata]);
        } else {
          setDataList([...dataList, ...tempdata]);
        }
       
        if (hasIsMaking) {
          tempdata.forEach((item:any) => {
            if ([0,1].includes(item.status)) {
              dataListStatus(item.task_id,[...dataList, ...tempdata]);
              isUpdateRef.current = true;
            }
          });
        }
      }
    });
    setIsLoading(false);
  };

  const handleMouseEnter = (id: string) => {
    setHoverStates({});
    setHoverStates(prev => ({ ...prev, [id]: true }));
  };

  const handleMouseLeave = (id: string) => {
    setHoverStates(prev => ({ ...prev, [id]: false }));
  };

  useEffect(() => {
    if (isShowMyAvatar) {
      getTaskList('effectRequest');
      setDataList([]);
    }
    return(() => {
      setDataList([]);
      isUpdateRef.current= false;
      setIsEditing(false);
      setSelectAll(false);
      setSelectedItems([]);
      setHoverStates({});
    })
  },[isShowMyAvatar]);

  return (
    <div className="__my_avatar_layout" style={{ display: isShowMyAvatar ? 'flex' : 'none' } }>
      <div className="layout_reback">
        <img src={returnIcon} alt="" onClick={()=>myAvatarReBack()}/>
        <span>Pet Poratrait</span>
      </div>
      <div className="my_avatar_layout_content">
        <div className="my_avatar_title">My Avatar</div>
        {hasIsMaking && <p className="my_avatar_des">
          Your pet's avatar is  making, it will take some time. Please be patient.
        </p>}
        <div className="my_avatar_list">
          <ScrollMoreView2d
            onLoadMore={getTaskList}
            hasMore={hasMore}
            isLoading={isLoading}
          >
            <Masonry
              className="my_avatar_masonry"
              columnsCountBreakPoints={{ 0: 2 }}
              style={{ gap: 4 }}
            >
              <div className="my_avatar_upload_btn"> 
                <img className='addFileIcon' src={addFileIcon} onClick={myAvatarGotoCreate} />
              </div>
              {
                dataList.map(item => (
                  <div 
                    className="my_avatar_item" 
                    key={item.id} 
                    onMouseEnter={() => handleMouseEnter(item.id)}
                    onMouseLeave={() => handleMouseLeave(item.id)}
                  >
                    <CommonImage src={item.thumb_path} style={{ borderRadius: 8 }} />
                    {((isEditing && item.status == 2) || (hoverStates[item.id] && item.status == 2)) && (
                      <CustomCheckbox 
                        className="check_input"
                        checked={selectAll || selectedItems.includes(item.id)}
                        onClick={() => clickInputcheck(item)}
                      />
                    )}
                    {
                      [0,1].includes(item.status) && <div className="making_div">
                        <img src={loadingIcon} alt="" />
                        <span>making...</span>
                      </div>
                    }
                    <div className="more_operator">
                      {(item.status == 2 && hoverStates[item.id]) && <img 
                        src={moreIcon} 
                        alt=""
                        aria-describedby={popoverId} 
                        onClick={(event) => { 
                          event.stopPropagation(); 
                          handleClick(event, item.id) 
                        }} 
                      />}
                      <Popover
                        id={popoverId}
                        open={openedPopoverId === item.id}
                        anchorEl={anchorEl}
                        onClose={popoverCloseHandle}
                        classes={{ paper: classess.paper }}
                        transformOrigin={{
                          vertical: 'top',
                          horizontal: 'right',
                        }}
                      >
                        <div className={classess.operatorItem} onClick={(event) => { deleteItemHandle(event, item)}}>Delete</div>
                        <div className={classess.operatorItem} onClick={(event) => { selectItemHandle(event, item)}}>Select</div>
                      </Popover>
                    </div>
                  </div>
                ))
              }
            </Masonry>
          </ScrollMoreView2d>
        </div>
        <Loading className='loading' loading={isLoading} isAbsolute />
      </div>

      {
          (((isEditing)) || isItemDeleteId) &&<MainUiLeftFooterBar  
            selectedItems={selectedItems}
            dataList={dataList}
            selectAll={selectAll}
            handleSelectAll={handleSelectAll}
            handleConfirm={handleDeleteSelected}
            isHandleConfirmSuccess={dialogConfirmLoading}
            setIsEditing={handleSetEditing}
            openDialog={openDialog}
            setCloseDialog={handleDialogClose}
            setOpenDialog={()=>setOpenDialog(true)}
            isShowFooterbar={isShowFooterbar}
            isItemDeleteId={isItemDeleteId}
            dialogDes={`Are you sure want to delete ${selectedItems.length > 1 ? 'these' : 'this'} avatar?`}
          />
        }
    
    </div>
  );
}