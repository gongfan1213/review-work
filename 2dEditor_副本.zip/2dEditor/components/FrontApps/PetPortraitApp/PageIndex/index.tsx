
// 依赖
import React, {useState, useEffect, useRef} from "react";

import { isInNativeApp, eufyGoBack,sendAiResult } from 'src/common/jsbridge'

// 组件
import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';
import { Masonry } from 'react-masonry-component2';
import TabSwitcher from "src/templates/2dEditor/common/widget/TabSwitcher/TabSwitcher";
import { Dialog } from '@mui/material';
import CommonImage from "src/components/CommonImage";

// 图标
import returnIcon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png';
import closeIcon from'src/assets/svg/close.svg';
import tipImage1 from './image/tip_image1.svg';
import tipImage2 from './image/tip_image2.svg';

// 样式
import './index.scss';

// services
import { get } from 'src/services'
import { getModelTrainTaskList } from 'src/templates/2dEditor/service/2dEditService';


export default function pageIndex (props: any) {
  const { JumpStep, isShowPageIndex, makeFirstAvatar, gotoMyAvatar, checkPortraitItem } = props;
  const [tabList, setTabList] = useState([]);
  const tabRef = useRef('Magic');
  const dataListRef = useRef({});
  const pageIndexRef = useRef(1);
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState<any>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [hasTaskList, setHasTaskList] = useState(false);
  const [taskList, setTaskList] = useState([] as any[]);
  const [taskListTotal, setTaskListTotal] = useState<any>('');

  // tab栏标题
  const getTabList = async () => {
    try {
      const res = await get<{ data: any }>('/web/cms-proxy/common/content', {
        content_type: 'make-2d-digital-clone-classes',
        pagination: {
          page: 1,
          pageSize: 10000,
        },
      });

      if (res?.data?.data) {
        const tabList = res.data.data.map((item: any) => ({
          tabName: item.attributes?.name,
          tabValue: item.id,
        }));
        setTabList(tabList);
        if (tabList.length > 0) {
          getDataList(tabList[0].tabName);
        }
      }
    } catch (error) {
      console.error('Failed to fetch tab list:', error);
    }
  }

  // 列表数据
  const getDataList = async (pramas?:string) => {
    setIsLoading(true)

    const currentTab = pramas || tabRef.current;
    const currentPageIndex = (dataListRef.current as {[key: string]: any})?.[tabRef.current]?.pageIndex || 1;

    const json = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      {
        content_type: 'make-2d-digital-clone-templates',
        populate: ['image','class','config'],
        filters: {
          class: {
            name: {$eq: currentTab },
          },
        },
        pagination: {
          page: currentPageIndex,
          pageSize: 20,
        },
      },
    );
    const currentData = (dataListRef.current as {[key: string]: any})?.[tabRef.current]?.data || [];
    const newData = json?.data?.data || [];
    const hasMore = newData.length >= 20;
    
    if ((dataListRef.current as {[key: string]: any})?.[tabRef.current]) {
      // 滚动分页加载
      dataListRef.current = {
        ...dataListRef.current as {[key: string]: any}, 
        [tabRef.current]:{ 
          data: [...currentData, ...newData], 
          hasMore: hasMore,
          pageIndex: currentPageIndex + 1
        }
      }
    } else {
      // 首次加载
      dataListRef.current = {
        ...dataListRef.current, 
        [tabRef.current]:{ 
          data: [...json?.data?.data], 
          hasMore: json?.data?.data?.length >= 20,
          pageIndex: pageIndexRef.current + 1
        }
      }
    }
    setIsLoading(false)
  }

  // 获取模型列表
  const getTaskList = () => {
    const params = { pagination: { page: 1, page_size: 20 } };
    getModelTrainTaskList(params).then((res) => {
      console.log('===res', res);
      const { data } = res || {};
      setTaskListTotal(data?.total + 0)
      if (data?.total > 0) {
        setHasTaskList(true);
        const filteredData = data?.list?.filter((item: any) => [0, 1, 2].includes(item.status)) || [];
        setTaskList((prevTaskList) => [...prevTaskList, ...filteredData]);
      } else {
        setHasTaskList(false);
      }
    });
  }

  const tabChangeHandle = (activeTab: string) => {
    tabRef.current = activeTab;
    if ((dataListRef.current as {[key: string]: any})?.[activeTab]?.data) {
      setData((dataListRef.current as {[key: string]: any})?.[activeTab]?.data);
      return;
    } else {
      pageIndexRef.current = 1;
      getDataList(activeTab);
    }
  }

  const titlebarHandle = () => {
    // testAiResult();
    hasTaskList ? gotoMyAvatar() : setOpenDialog(true);
  }

  const clickItem = (item: any) => {
    hasTaskList ? checkPortraitItem(item) : setOpenDialog(true); 
  }

  useEffect(()=> {
    getTabList();
  },[])

  useEffect(() => {
    if (isShowPageIndex) {
      getTaskList()
    }
  },[isShowPageIndex])

  const tempData = (dataListRef.current as { [key: string]: any })?.[tabRef.current]?.data || [];
  const tempHasMore = (dataListRef.current as { [key: string]: any })?.[tabRef.current]?.hasMore || false;


  const goBack = () => {
    if (isInNativeApp()) {
      eufyGoBack();
    } else {
      JumpStep('', 1, 'prev');
    }
  }

  const testAiResult = () => {
    var testImg = "https://gitee.com/huiguzi/res/raw/abc/img/m4.jpg";
    var list = [{ "download_url": testImg, "file_name": '' }];
    sendAiResult(list);
  }

  return (
    <div className="__pet_page_index" style={{ height: '100%', display: isShowPageIndex ? 'block' : 'none' }}>
       <div className="layout_reback">
        <img src={returnIcon} alt="" onClick={goBack}/>
        <span>Pet Poratrait</span>
      </div>
      {/* <div className="lyout_tips" onClick={titlebarHandle}> 
        <span>TEST.Fred</span>
      </div> */}
      <div className="lyout_tips" onClick={titlebarHandle}> 
        <span>{taskListTotal == '' ? '' : !hasTaskList ? 'Make First Pet Avatar' : 'Manage My Avatar'}</span>
      </div>
      <div className="lyout_title">Choose A Style</div>
      <div className="layout_content">
        <TabSwitcher tabs={tabList} onTabChange={(tab)=>{tabChangeHandle(tab.tabName)}} />
        <div className="pet_portrait_list">
          
          <ScrollMoreView2d onLoadMore={getDataList} hasMore={tempHasMore} isLoading={isLoading} key={tabRef.current}>
            <Masonry
              className="my_avatar_masonry"
              columnsCountBreakPoints={{ 0: 2 }}
              style={{ gap: 0 }}
              key={tabRef.current}
            >
              {
                tempData.map((item: any, index: any) => {
                  return (
                    <div className="pet_portrait_item" key={item.id} onClick={() => clickItem(item)}>
                      {/* <CommonImage
                        src={item?.attributes?.image?.data?.attributes?.url || ''}
                        style={{ borderRadius: 8, objectFit: 'cover' }}
                      /> */}
                      <img src={item?.attributes?.image?.data?.attributes?.url} alt="" loading="lazy"
                        style={{ borderRadius: 8,height:'100%', objectFit: 'cover' }} />
                      <span className="item_name">{item?.attributes?.name}</span>
                    </div>
                  );
                })
              }
            </Masonry>
          </ScrollMoreView2d>
        </div>
      </div>
      <Dialog
        className="__pet_partrait_tip_dialog"
        open={openDialog}
        // open={true}
        onClick={(e) => {
          e.stopPropagation();
        }}
      >
        <div className="dialog_loyout">
          <img src={closeIcon} alt="" className="dialog_close_icon" onClick={() => setOpenDialog(false)} />
          <p className="dialog_title">What Is Pet Avatar?</p>
          <p className="dialog_des">
            With just 1-5 photos, our advanced AI-powered app crafts a digital avatar of your beloved pet. This allows you to effortlessly create a variety of chic and stylish portrait photos to celebrate your furry friend.
          </p>
          <div className="dialog_show_img">
            <div className='tip_img'>
              <CommonImage src={tipImage1} />
            </div>
            <span>{'>'}</span>
            <div className='tip_img'>
              <CommonImage src={tipImage2} />
            </div>
          </div>
          <p className="dialog_tip">you don’t have any pet avatar currently, let’s create an avatar for your pet first!</p>
          <div className="dialog_btn" onClick={()=> { makeFirstAvatar(), setOpenDialog(false)}}>
            <button>Make first pet avatar</button>
          </div>
        </div>
      </Dialog>
    </div>
  );
}