import React, { useRef, useEffect } from 'react';
import Cropper from 'cropperjs';
import 'cropperjs/dist/cropper.min.css';
import './index.scss'

interface Props {
  imageUrl: string; // 传入的图片URL
  onCrop: (blob: Blob, index?: any) => void; // 裁剪后的回调函数
  index: number;
  cancelCrop: (index: any) => void;
}

const ImageCropper: React.FC<Props> = ({ imageUrl, onCrop, index = 0, cancelCrop }) => {
  const imageRef = useRef<HTMLImageElement>(null);
  const cropperRef = useRef<Cropper>();
  

  // 初始化CropperJS
  useEffect(() => {
    if (imageRef.current) {
      const cropper = new Cropper(imageRef.current, {
        aspectRatio: 1, // 图片宽高比例
        scalable: true, // 允许缩放图片
        zoomable: true, // 允许缩放图片
        cropBoxResizable: false, // 允许改变裁剪框大小
        cropBoxMovable: false, // 允许拖动裁剪框
        dragMode: 'move', // 裁剪时拖动图片
        viewMode: 0, // 限制裁剪框不超出图片范围 0的话可以缩小到比裁剪区域还小 1缩放图片至裁剪区域大小
        ready: () => {
          const cropBoxData = { width: 218, height: 218, top: 10, left: 78 }; // 设置裁剪区域大小
          cropper.setCropBoxData(cropBoxData);
          cropper.setCanvasData({ top: -20 })
          // cropper.setCanvasData({ width: 230, height: 270 }); // 设置画布区域大小

          // 获取图片的原始大小
          const imageData = cropper.getImageData();
          const originalWidth = imageData.naturalWidth;
          const originalHeight = imageData.naturalHeight;
          // 计算缩放级别
          const zoomLevel = Math.max(cropBoxData.width / originalWidth, cropBoxData.height / originalHeight);

          // 设置图片的缩放级别
          cropper.zoomTo(zoomLevel);
        },
        // 当用户尝试缩放图片时触发的函数
        zoom: (event) => {
          // 获取图片的原始大小
          const imageData = cropper.getImageData();
          const originalWidth = imageData.naturalWidth;
          const originalHeight = imageData.naturalHeight;

          // 设置裁剪框的大小和位置
          const cropBoxData = { width: 218, height: 218, top: 60, left: 120 };

          // 计算最小缩放级别，以确保裁剪框内的图片不会小于裁剪框的大小
          const minZoomLevel = Math.max(cropBoxData.width / originalWidth, cropBoxData.height / originalHeight);

          // 如果当前的缩放级别小于最小缩放级别，那么取消这次的缩放操作
          // 这是为了防止图片缩得太小，无法填满裁剪框
          if (event.detail.ratio < minZoomLevel) {
            event.preventDefault();
          }
        },
        center: true,
      });
      cropperRef.current = cropper;
    }

    return () => {
      // 清理代码
      if (cropperRef.current) {
        cropperRef.current.destroy();
      }
    };
  }, [imageUrl,index]);

  // 裁剪并获取结果
  const handleCrop = () => {
    const cropper = cropperRef.current;
    if (cropper) {
      // 获取裁剪后的Canvas
      const canvas = cropper.getCroppedCanvas({
        width: 678,
        height: 678,
      });
      // 将Canvas转换为Blob
      canvas.toBlob((blob) => {
        if (blob) {
          onCrop(blob,index);
        }
      });
    }
  };

  return (
    <div className='__cropper_box'>
      {/* <button className='crop_btn' onClick={handleCrop}>Crop</button> */}
      <img ref={imageRef} src={imageUrl} alt="Source" className='crop_img' />
      <div className='crop_btns'>
        <button onClick={cancelCrop}>Cancel</button>
        <button onClick={handleCrop}>Crop</button>
      </div>
    </div>
  );
};

export default ImageCropper;
