import React, { useState, useEffect, useRef } from "react";
import { Tabs, Tab, Box, CircularProgress, IconButton } from '@mui/material';
import './index.scss';
import { styled } from '@mui/system';
import return_icon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png'
import empty_data_icon from 'src/images/empty_upload.png';
import { get } from 'src/services'
import ScrollMoreViewTab from 'src/templates/2dEditor/components/FrontApps/RoyalPortrait/ScrollMoreViewTab';
// import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';
import Masonry from 'react-masonry-css';
import CommonImage from 'src/components/CommonImage';
import { useEvent } from 'src/templates/2dEditor/hooks/context';
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';
import RoyalPortrait_left from 'src/images/2dEditor/RoyalPortrait_left.png';
import RoyalPortrait_right from 'src/images/2dEditor/RoyalPortrait_right.png'

const CustomTabs = styled(Tabs)(({ theme }) => ({
  minHeight: '30px', // 设置Tabs的最小高度
  overflowX: 'auto',

  '& .MuiTabs-flexContainer': {
    minHeight: '30px', // 设置Tabs容器的最小高度
    overflowX: 'auto',
    '&::-webkit-scrollbar': {
      display: 'none', // 在Webkit浏览器中隐藏滚动条
    }
  },
  '& .MuiTab-root': {
    minHeight: '30px', // 设置Tab的最小高度
    overflowX: 'auto',
    '&::-webkit-scrollbar': {
      display: 'none', // 在Webkit浏览器中隐藏滚动条
    }
  }
}));

export default function NewRoyalPortrait(props: any) {
  const { type, step, title, nextStep, handlePetData, prevStep, JumpStep } = props;
  const event = useEvent();
  const [tabData, setTabData] = useState<any[]>([]);
  const [selectedMainTab, setSelectedMainTab] = useState('');
  const [selectedSubTab, setSelectedSubTab] = useState('');
  // 用于存储从接口获取的具体数据，并作为缓存。
  const cacheData = useRef<any>({});
  const [totalData, setTotalData] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [subTabState, setSubTabState] = useState<any>({});
  const [tempData, setTempData] = useState<any>([]);
  const [tempHasMore, setTempHasMore] = useState(false);
  const scrollMoreViewRef = useRef<any>(null);
  const subTabsRef = useRef<any>(null);
  const AiTitle = typeof window !== 'undefined'
    ? window.sessionStorage.getItem('AiTitle') || ''
    : '';
  const maxPageSize = 10
  const pageIndexRef = useRef(1);
  // 当前的数据状态，避免一进入页面就显示空数据模块
  const nowDataState = useRef<any>(true);
  const [showLeftIcon, setShowLeftIcon] = useState(false);
  const [showRightIcon, setShowRightIcon] = useState(false);

  // 获取大类和小类数据
  const getBigClass = async () => {
    const json = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      {
        content_type: 'make-2d-royal-portrait-styles',
        populate: ['classes'],
        pagination: {
          start: 0,
          limit: 10000
        },
      }
    );
    const transformedData = ClassTransformData(json?.data?.data);
    setTabData(transformedData);

    // 初始化选中的大类和小类
    if (transformedData.length > 0) {
      setSelectedMainTab(transformedData[0].BigClass);
      setSelectedSubTab(transformedData[0].SmallClass[0].name);
      const initialState: any = {};
      transformedData.forEach((tab: any) => {
        initialState[tab.BigClass] = tab.SmallClass[0].name;
      });
      setSubTabState(initialState);
    }
  };

  // 大类和小类数据转化函数
  function ClassTransformData(originalData: any) {
    const result: any = [];

    originalData?.forEach((item: any) => {
      item?.attributes?.classes?.data.forEach((subItem: any) => {
        let bigClass = result?.find((cls: any) => cls?.BigClass === subItem?.attributes?.name);

        if (!bigClass) {
          bigClass = {
            BigClass: subItem?.attributes?.name,
            SmallClass: []
          };
          result.push(bigClass);
        }

        bigClass?.SmallClass?.push({
          name: item?.attributes?.style,
        });
      });
    });

    return result;
  }

  // 表格数据转化函数
  const TabletransformData = (originalData: any) => {
    return originalData?.map((item: any) => ({
      image: item?.attributes?.faceImage?.data?.attributes?.formats?.small?.url,
      canvas_image: item?.attributes?.faceImage?.data?.attributes?.url,
      id: item?.id,
      // 人脸数量，几个人脸数量就有几个上传模块
      faceNumber: item?.attributes?.faceNumber,
      now: false
    }));
  }

  // 获取表格数据
  const fetchTableData = async () => {
    // 存储当前是哪个大类下哪个小类的数据
    const cacheKey = `${selectedMainTab}-${selectedSubTab}`;
    // console.log("totalData[cacheKey]", totalData[cacheKey]);

    // 所有项目的总数大于当前缓存的总数，说明还有数据未加载，pageIndex+1
    if (totalData[cacheKey] > cacheData.current[cacheKey]?.length) {
      pageIndexRef.current = pageIndexRef.current + 1;
    }

    setLoading(true);
    try {
      const json: any = await get<{ data: any }>(
        '/web/cms-proxy/common/content',
        {
          // cms接口地址
          content_type: 'make-2d-face-templates',
          populate: ['faceImage', 'facePosition', 'type'],
          sort: ['weight:DESC'],
          // 筛选（搜索）条件
          filters: {
            type: {
              name: {
                $eq: selectedMainTab,
              }
            },
            style: {
              style: {
                $eq: selectedSubTab
              }
            }
          },
          pagination: {
            page: pageIndexRef.current,
            pageSize: maxPageSize,
          },
        },
      );
      const transformedData = TabletransformData(json?.data?.data);
      // console.log("json?.datajson?.data:transformedDatatransformedData", transformedData);

      // 缓存加载过的数据
      cacheData.current = {
        ...cacheData.current,
        [cacheKey]: [...(cacheData.current[cacheKey] || []), ...transformedData]
      }

      if (pageIndexRef.current == 1) {
        // 缓存所有数据的total
        setTotalData((prevData: any) => ({
          ...prevData,
          [cacheKey]: json?.data?.meta?.pagination?.total
        }));
      }

      setTempData((oldData: any) => [...oldData, ...transformedData]);
      // 当前数据是否还有更多，如果当前数据长度大于等于maxPageSize并且总数据大于当前缓存数据长度
      setTempHasMore(transformedData.length >= maxPageSize &&
        // 开始时没有缓存数据，所以从接口内获取
        (totalData[cacheKey] > cacheData.current[cacheKey]?.length ||
          json?.data?.meta?.pagination?.total > cacheData.current[cacheKey]?.length
        )
      );

    } catch (error) {
      console.log("Error fetching table data:", error);
    } finally {
      setLoading(false);
      nowDataState.current = false;
    }
  }

  // 点击卡片方法
  const imageClick = (item: any) => {
    // console.log('item----------前期1111', item);
    event?.emitEvent(EventNameCons.EventHiddenCloseIcon, false)
    const nowData =
      tempData.map((dataItem: any) =>
        dataItem.id === item.id ? { ...dataItem, now: true } : { ...dataItem, now: false }
      );
    // console.log('nowData-123---------', nowData);
    setTempData(nowData);
    handlePetData(nowData, selectedSubTab, title)
    nextStep(title, type, '', '', nowData)
  }

  // 返回上一页方法
  const returnClick = () => {
    if (AiTitle) {
      JumpStep('', 1, 'prev')
    } else {
      //此处返回到首页了，清空上传处的数据
      prevStep('', 'Kid')
    }
    handlePetData([], '')
  }

  // 处理当前大类变化的函数
  const handleMainTabChange = (event: React.SyntheticEvent, newValue: string) => {
    setSelectedMainTab(newValue);
    setSelectedSubTab(subTabState[newValue]); // 恢复之前选中的小类
    // 切换大类时，置顶盒子
    if (scrollMoreViewRef.current) {
      scrollMoreViewRef.current.scrollToTop();
    }
  };

  // 处理小类变化的函数
  const handleSubTabChange = (event: React.SyntheticEvent, newValue: string) => {
    setSelectedSubTab(newValue);
    setSubTabState((prevState: any) => ({
      ...prevState,
      [selectedMainTab]: newValue // 更新当前大类对应的小类选中状态
    }));
    // 切换小类时，置顶盒子
    if (scrollMoreViewRef.current) {
      scrollMoreViewRef.current.scrollToTop();
    }
  };

  const handleScrollIcon = (item: string) => {
    const element = document.getElementById('scrollBox');
    if (!element) {
      console.log('Element #scrollBox not found');
      return;
    }

    const subTabElement = element.querySelector('[aria-label="sub tabs"]');
    if (!subTabElement) {
      console.log('Sub tab element not found');
      return;
    }

    const newScrollPosition = item === 'left' ? subTabElement.scrollLeft - 100 : subTabElement.scrollLeft + 100;
    subTabElement.scrollTo({
      left: newScrollPosition,
      behavior: 'smooth'
    });

    const maxScrollLeft = subTabElement.scrollWidth - subTabElement.clientWidth;
    setShowLeftIcon(subTabElement.scrollLeft > 0);
    setShowRightIcon(subTabElement.scrollLeft < maxScrollLeft - 1);
  };

  const handleMouseLeave = () => {
    setShowLeftIcon(false);
    setShowRightIcon(false);
  };

  const handleMouseEnter = () => {
    checkScrollPosition();
  };

  const checkScrollPosition = () => {
    const element = document.getElementById('scrollBox');
    if (!element) {
      console.error('Element #scrollBox not found');
      return;
    }

    const subTabElement = element.querySelector('[aria-label="sub tabs"]');
    if (!subTabElement) {
      console.error('Sub tab element not found');
      return;
    }
    if (subTabElement) {
      const maxScrollLeft = subTabElement.scrollWidth - subTabElement.clientWidth;
      setShowLeftIcon(subTabElement.scrollLeft > 0);
      setShowRightIcon(subTabElement.scrollLeft < maxScrollLeft - 1);
    }
  };

  useEffect(() => {
    // 获取滚动容器,并添加事件监听器
    const element = document.getElementById('scrollBox');
    if (!element) {
      console.log('Element #scrollBox not found');
      return;
    }

    const subTabElement = element.querySelector('[aria-label="sub tabs"]');
    if (!subTabElement) {
      console.log('Sub tab element not found');
      return;
    }

    subTabElement.addEventListener('scroll', checkScrollPosition);

    // 组件卸载时移除事件监听器
    return () => subTabElement.removeEventListener('scroll', checkScrollPosition);
  }, []);

  // 使用useEffect来在组件加载和标签页改变时获取数据
  useEffect(() => {
    const cacheKey = `${selectedMainTab}-${selectedSubTab}`;
    if (selectedMainTab && selectedSubTab) {
      // 如果缓存中已有数据，则直接使用缓存的数据，而不是重新调用接口。
      if (cacheData.current[cacheKey] && totalData[cacheKey]) {
        setTempData(cacheData.current[cacheKey]);
        setTempHasMore(cacheData.current[cacheKey].length < totalData[cacheKey]);
        pageIndexRef.current = Math.ceil(cacheData.current[cacheKey].length / maxPageSize)
      } else {
        // 无缓存数据直接调接口
        setTempData([]);
        pageIndexRef.current = 1;
        fetchTableData();
      }
    }
  }, [selectedMainTab, selectedSubTab]);

  useEffect(() => {
    getBigClass();
  }, [])

  // 获取当前选中的大类和小类的数据
  const currentMainTab = tabData.find(item => item.BigClass === selectedMainTab);
  // const currentSubTabData = currentMainTab?.SmallClass.find((subItem: any) => subItem.name === selectedSubTab)?.data || [];

  return (
    <div className="NewRoyalPortrait" style={{ display: step === 2 ? '' : 'none' }}>
      {/* 顶部返回与标题模块 */}
      <div className="NewRoyalPortrait_Box_top">
        <div className="NewRoyalPortrait_top_left">
          <div className="NewRoyalPortrait_top_left_img_box" onClick={() => { returnClick() }} >
            <img src={return_icon} className="NewRoyalPortrait_top_left_img" />
          </div>
          <div className='NewRoyalPortrait_title'>{title}</div>
        </div>
      </div>

      {/* @ts-ignore */}
      <Box>
        {/* 第一层tab */}
        <CustomTabs
          // @ts-ignore
          value={selectedMainTab}
          onChange={handleMainTabChange}
          aria-label="main tabs"
          className="main-tabs"
        >
          {tabData.map(tab => (
            // @ts-ignore
            <Tab key={tab.BigClass} label={tab.BigClass} value={tab.BigClass} />
          ))}
        </CustomTabs>

        {/* 第二层tab */}
        <div className="sub-tabs-container">
          {
            currentMainTab?.SmallClass?.length > 0 && showLeftIcon &&
            <img src={RoyalPortrait_left}
              className="left_icon"
              alt="left"
              onClick={() => handleScrollIcon('left')}
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            />
          }
          <div className="sub-tabs-wrapper" >
            <CustomTabs
              value={selectedSubTab}
              onChange={handleSubTabChange}
              aria-label="sub tabs"
              className="sub-tabs"
              id='scrollBox'
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            // onScroll={checkScrollPosition}
            >
              {currentMainTab?.SmallClass.map((tab: any) => (
                <Tab key={tab.name}
                  label={tab.name}
                  value={tab.name}
                  disableRipple //去掉点击时波纹效果
                />
              ))}
            </CustomTabs>
          </div>
          {
            currentMainTab?.SmallClass?.length > 0 && showRightIcon &&
            <img
              src={RoyalPortrait_right}
              className="right_icon"
              alt="right"
              onClick={() => handleScrollIcon('right')}
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            />
          }
        </div>

        {
          // 空数据模块
          !nowDataState.current && tempData?.length === 0 && loading === false &&
          <div className="no_data_box">
            <img src={empty_data_icon} className="no_data_icon" />
            <div>No data available at the moment</div>
          </div>
        }

        {/* 内容 */}
        <div className="NewRoyalPortrait_content">
          <ScrollMoreViewTab
            // @ts-ignore
            onLoadMore={fetchTableData}
            hasMore={tempHasMore}
            isLoading={loading}
            ref={scrollMoreViewRef}
          >
            <Masonry breakpointCols={2} className="my-masonry-grid" columnClassName="my-masonry-grid_column">
              {tempData?.map((item: any) => (
                <div className="MyLazyImage_fa" id={item?.image}>
                  <CommonImage
                    src={item?.image}
                    onClick={() => imageClick(item)}
                    style={{ borderRadius: '8px' }}
                  />
                </div>
              ))}
            </Masonry>
          </ScrollMoreViewTab>
        </div>
      </Box>
    </div>


  );
}