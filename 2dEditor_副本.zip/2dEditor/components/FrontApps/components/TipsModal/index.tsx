import React, { useState, useRef, useEffect } from "react"
import './index.scss';
import bad_icon from 'src/images/2dEditor/AIModules/bad_icon.svg'
import good_icon from 'src/images/2dEditor/AIModules/good_icon.svg'
import royal1 from 'src/images/2dEditor/AIModules/royal1.png'
import royal2 from 'src/images/2dEditor/AIModules/royal2.png'
import royal3 from 'src/images/2dEditor/AIModules/royal3.png'
import royal4 from 'src/images/2dEditor/AIModules/royal4.png'
import royal5 from 'src/images/2dEditor/AIModules/royal5.png'
import royal6 from 'src/images/2dEditor/AIModules/royal6.png'
import royal7 from 'src/images/2dEditor/AIModules/royal7.png'
import royal8 from 'src/images/2dEditor/AIModules/royal8.png'
import master1 from 'src/images/2dEditor/AIModules/master1.png'
import master2 from 'src/images/2dEditor/AIModules/master2.png'
import master3 from 'src/images/2dEditor/AIModules/master3.png'
import master4 from 'src/images/2dEditor/AIModules/master4.png'
import master5 from 'src/images/2dEditor/AIModules/master5.png'
import master6 from 'src/images/2dEditor/AIModules/master6.png'
import portrait1 from 'src/images/2dEditor/AIModules/portrait1.png'
import portrait2 from 'src/images/2dEditor/AIModules/portrait2.png'
import portrait3 from 'src/images/2dEditor/AIModules/portrait3.png'
import portrait4 from 'src/images/2dEditor/AIModules/portrait4.png'
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

import close_icon from 'src/assets/svg/close.svg';
import { AppsDataTYPE } from 'src/templates/2dEditor/components/FrontApps/const'

export default function TipsModal(props: any) {
  const { open, handlePopoverClose, title, type } = props
  const modalRef = useRef(null);
  const { getTranslation } = useCustomTranslation();
  const [goodImg, setGoodImg] = useState<any>([]);
  const [badImg, setBadImg] = useState<any>([]);

  // 定义图片数据，避免在组件内部重复创建
  const goodData: any = {
    [AppsDataTYPE['1']]: [
      { image: royal1, txt: 'Frontal Face' },
      { image: royal2, txt: 'No Obstructions' },
      { image: royal3, txt: 'High-Quality' },
      { image: royal4, txt: 'Even Lighting' }
    ],
    [AppsDataTYPE['2']]: [
      { image: master1, txt: 'Landscape' },
      { image: master2, txt: 'High-Quality' },
      { image: master3, txt: 'Even Lighting' }
    ],
    [AppsDataTYPE['3']]: [
      { image: royal1, txt: 'Frontal Face' },
      { image: royal2, txt: 'No Obstructions' },
      { image: royal3, txt: 'High-Quality' },
      { image: royal4, txt: 'Even Lighting' }
    ],
    [AppsDataTYPE['4']]: [
      { image: portrait1, txt: 'Clear Image' },
      { image: portrait2, txt: 'Simple Image' },
    ]
  };

  const badData: any = {
    [AppsDataTYPE['1']]: [
      { image: royal5, txt: 'Angled Face' },
      { image: royal6, txt: 'Obstructions' },
      { image: royal7, txt: 'Low-Quality' },
      { image: royal8, txt: 'Uneven Lighting' }
    ],
    [AppsDataTYPE['2']]: [
      { image: master4, txt: 'Include Person' },
      { image: master5, txt: 'Low-Quality' },
      { image: master6, txt: 'Uneven Lighting' }
    ],
    [AppsDataTYPE['3']]: [
      { image: royal5, txt: 'Angled Face' },
      { image: royal6, txt: 'Obstructions' },
      { image: royal7, txt: 'Low-Quality' },
      { image: royal8, txt: 'Uneven Lighting' }
    ],
    [AppsDataTYPE['4']]: [
      { image: portrait3, txt: 'All-Black' },
      { image: portrait4, txt: 'Complex Image' }
    ]
  };

  useEffect(() => {
    const handleClickOutside = (event: any) => {
      // @ts-ignore
      // 当点击发生时，事件处理器会检查点击的元素是否在弹窗内部。如果不在，那么关闭弹窗
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        handlePopoverClose()
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    // 检查goodData和badData中是否存在title键，如果不存在，则设置为空数组
    const goodImages = goodData[type] ? goodData[type] : [];
    const badImages = badData[type] ? badData[type] : [];

    setGoodImg(goodImages);
    setBadImg(badImages);
  }, [type]);

  // 根据不同的 type 设置 modal 的样式
  const modalStyles = {
    [AppsDataTYPE['1']]: { width: '450px', right: '-462px' },
    [AppsDataTYPE['2']]: { width: '343px', right: '-355px' },
    [AppsDataTYPE['3']]: { width: '450px', right: '-462px' },
    [AppsDataTYPE['4']]: { width: '236px', right: '-248px' },
  };
  const defaultStyle = { width: '236px', right: '-248px' };
  const modalStyle = modalStyles[type] || defaultStyle;

  const gridStyle = {
    gridTemplateColumns:
      `repeat(${type === AppsDataTYPE['1'] ? 4
        : type === AppsDataTYPE['2'] ? 3
          : type === AppsDataTYPE['3'] ? 4
            : type === AppsDataTYPE['4'] ? 2
              : 2
      }, 1fr)`
  };

  return (
    open &&
    <div className="TipsModal_box" ref={modalRef} style={modalStyle}>
      <div className="TipsModal_top">
        <div className="TipsModal_top_title">{getTranslation(TranslationsKeys.ChooseAGoodPhoto)}</div>
        <img src={close_icon} className="close_icon" onClick={handlePopoverClose} />
      </div>
      <div className="good_box" style={gridStyle}>
        {goodImg.map((item: any, index: number) => (
          <div className="good_box_item" key={index}>
            <img src={item.image} className="good_box_image" />
            <div className="good_box_bottom">
              <img src={good_icon} className="good_box_bottom_img" />
              <div className="good_box_txt">{item.txt}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="bad_box" style={gridStyle}>
        {badImg.map((item: any, index: number) => (
          <div className="bad_box_item" key={index}>
            <img src={item.image} className="bad_box_image" />
            <div className="bad_box_bottom">
              <img src={bad_icon} className="bad_box_bottom_img" />
              <div className="bad_box_txt">{item.txt}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
