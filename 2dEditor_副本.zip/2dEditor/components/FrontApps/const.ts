// app-page AppsData-type   对应关系 :type
export const AppsDataTYPE = {
   '1': 'AIPortrait',
   '2': 'MasterLandscape',
   '3': 'MasterPortrait',
   '4': 'PopArtMaker',
   '5': 'AIProductDesigner',
   '6': 'PetPortrait',
   '7': 'DreamPortrait',
   '8': 'ClassicPortrait',
   '9': 'LineArt',
   '10': 'LightPainting',
   '11': 'BrushstrokeMaker',
   '12': 'ReliefMagnet',
   '13': 'TexturePoster',
}

// app-page AppsData-title   对应关系 :title
// AITools中使用，用于跳转到对应的模块
export const AppsTitle = {
   '1': 'AI Portrait',
   '2': 'Master Landscape',
   '3': 'Master Portrait',
   '4': 'Pop Art Maker',
   '5': 'AI Product Designer',
   '6': 'Pet Portrait',
   '7': 'Dream Portrait',
   '8': 'Classic Portrait',
   '9': 'Line Art',
   '10': 'Light Painting'
}

// AiTools与Apps的映射关系，需要id和title对应上
export const titleMapping: any = {
   'AI Portrait': '1',
   'Master Landscape': '2',
   'Master Portrait': '3',
   'Pop Art Maker': '4',
   'AI Product Designer': '5',
   'Pet Poratrait': '6',
   'Dream Portrait': '7',
   'Classic Portrait': '8',
   'Line Art': '9',
   'Light Painting': '10',
};

// 滤镜模块对应标识符
export const FILTER_IDENTIFIERS: any = {
   OLD_PHOTO: 'oldPhoto',
   EMBOSS: 'Emboss',
   HORIZONTAL_BLUR: 'HorizontalBlur',
   HIGHLIGHT: 'Highlight',
   INSET: 'Inset',
   OUTSET: 'Outset',
   EDGE_ENHANCE: 'EdgeEnhance',
   LEVEL_EDGE: 'LevelEdge',
   VERTICAL_EDGE: 'VerticalEdge',
   ENHANCE_CONTRAST: 'EnhanceContrast',
   NEW_EMBOSS: 'NewEmboss',
   HIGH_PASS_FILTER: 'HighPassFilter',
   // 官方滤镜
   BLACKWHITE: 'BlackWhite',
   SEPIA: 'Sepia',
   GRAYSCALE: 'Grayscale',
   INVERT: 'Invert',
   BROWNIE: 'Brownie',
   VINTAGE: 'Vintage',
   KODACHROME: 'Kodachrome',
   TECHNICOLOR: 'Technicolor',
   POLAROID: 'Polaroid',
};

// 不同样式处理
export const STYLE_TYPE: any = {
   '1': 'Photo To Art',
   '2': 'ACGN Craft',
};