

import React, { useEffect, useRef, useState } from 'react';
import { convertToBase64 } from 'src/common/utils'
import { useCanvasEditor } from 'src/templates/2dEditor/hooks/context';
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common';
import { useDispatch } from 'react-redux';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

import SatisfyResult from './SatisfyResults/index';
import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';
import { Masonry } from 'react-masonry-component2';
import { openToast } from 'src/state/reducers/toast';
import CommonImage from 'src/components/CommonImage';

import { getHistoryList, petPortraitGetTaskStatus } from 'src/templates/2dEditor/service/2dEditService';

import returnIcon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png';
import generatingIcon from '/src/images/2dEditor/Apps_icon/Generating_img.png'

import './index.scss';
import { Spa } from '@mui/icons-material';

export default function makingResult(props: any) {

  const dispatch = useDispatch();
  const { isShowMakingResult, makingResultReCallBack } = props;
  const canvasEditor = useCanvasEditor()
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [dataList, setDataList] = useState<any>([]);
  const pageIndexRef = useRef(1);
  const isUpdateRef = useRef(false);
  const dataListRef = useRef<any>([])
  const { getTranslation } = useCustomTranslation();

  // 轮询更新数据状态
  const getTaskStatus = async (taskId: string) => {
    isUpdateRef.current = true;
    const res = await petPortraitGetTaskStatus({ task_id: taskId });
    if (res?.data?.status === 2) {
      const { result_list, task_id, status } = res.data;
      const tempdata = result_list.map(item => ({ ...item, task_id, status }))
      const resultdata = dataListRef.current.filter((item: any) => item.download_url !== "");
      dataListRef.current = [...tempdata, ...resultdata]
      setDataList([...tempdata, ...resultdata]);
      isUpdateRef.current = false;
      console.log('====tempdata', tempdata)
      addToCavas(tempdata[0]);
      setIsLoading(false);
    } else if ([3, 4].includes(res?.data?.status)) {
      isUpdateRef.current = false;
      dispatch(
        openToast({
          message: getTranslation(TranslationsKeys.FAILED_GENERATE_RESULT),
          severity: 'error',
        }),
      )
    } else {
      console.log('isUpdate', isUpdateRef.current);
      if (isUpdateRef.current) {
        setTimeout(() => getTaskStatus(taskId), 1000); // 假设1秒后重试
      }
    }
  };

  // 获取生成结果数据
  const getDataList = async (isLoadingMore?: boolean) => {
    setIsLoading(true);
    const params = { task_type: 6, pagination: { page: pageIndexRef.current, page_size: 20 } };
    const res = await getHistoryList(params);
    if (res?.data?.history_list?.length > 0) {
      pageIndexRef.current++;
      setDataList((dataList: any) => [...dataList, ...res?.data?.history_list]);
      dataListRef.current = [...dataListRef.current, ...res?.data?.history_list];
      setHasMore(res?.data?.history_list.length === 20);
      const taskId = res?.data?.history_list[0]?.task_id;
      if (!isLoadingMore) {
        getTaskStatus(taskId);
      }
      setIsLoading(false);
    }
  }

  useEffect(() => {
    if (isShowMakingResult) {
      getDataList(false);
    }
    return () => {
      pageIndexRef.current = 1;
      setDataList([]);
      isUpdateRef.current = false;
      dataListRef.current = [];
      console.log('=====avatarreault unmount=====')
    }
  }, [isShowMakingResult]);

  // 添加到画布中
  const addToCavas = async (data: any) => {
    // const decodedUrl = decodeURIComponent(data.download_url);
    let decodedUrl =
      data.download_url.indexOf('oss-cn-shenzhen') !== -1
        ? data.download_url
        : decodeURIComponent(data.download_url)
    const fileExtension = data.file_name.split('.').pop(); // 获取文件后缀
    const base64 = await convertToBase64(decodedUrl);
    canvasEditor?.addImage(base64,
      {
        importSource: ImportSource.Cloud,
        fileType: fileExtension,
        key_prefix: data.file_name
      });
    setIsLoading(false);
  }

  return (
    <div
      className="__making_result_layout"
      style={{ display: isShowMakingResult ? 'flex' : 'none' }}
    >
      <div className="layout_reback">
        <img src={returnIcon} alt="" onClick={makingResultReCallBack} />
        <span>{getTranslation(TranslationsKeys.PET_PORTRAIT_TITLE)}</span>
      </div>
      <div className="result_layout_content">
        <div className="layout_title">{getTranslation(TranslationsKeys.YOUR_PET_PORTRAITS)}</div>
        <div className="layout_des">{getTranslation(TranslationsKeys.ADD_PET_AVATAR_TO_CANVA)}</div>
        <div className="data_list">
          <ScrollMoreView2d
            onLoadMore={() => getDataList(true)}
            hasMore={hasMore}
            isLoading={isLoading}
          >
            <Masonry columnsCountBreakPoints={{ 0: 2 }} style={{ gap: 10 }}>
              {dataListRef?.current?.map((item: any) => (
                <div className="list_item">
                  <CommonImage
                    // src={
                    //   decodeURIComponent(item.download_url) || generatingIcon
                    // }
                    src={(item.download_url.indexOf('oss-cn-shenzhen') !== -1 ? item.download_url : decodeURIComponent(item.download_url)) || generatingIcon}
                    onClick={() => addToCavas(item)}
                    style={{ objectFit: 'cover', borderRadius: 8 }}
                  />
                </div>
              ))}
            </Masonry>
          </ScrollMoreView2d>
        </div>
      </div>
      {/* <SatisfyResult/> */}
    </div>
  )
}