

import React, { useState } from 'react';

import { Button } from 'src/components/MakeUI';

import "./index.scss";

import goodIcon from 'src/assets/svg/white_good.svg';
import badIcon from 'src/assets/svg/white_bad.svg';
import closeIcon from 'src/assets/svg/close.svg'

import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

export default function SatisfyResult() {

  const [showModalType, setShowModalType] = useState('');
  const { getTranslation } = useCustomTranslation();
  const [goodCheckLabels, setGoodCheckLabels] = useState([
    {
      id: 1,
      label: getTranslation(TranslationsKeys.MUCH_LIKE_PET),
      checked: false,
    },
    {
      id: 2,
      label: getTranslation(TranslationsKeys.VARIETY_TEMPLATES),
      checked: false,
    },
    {
      id: 3,
      label: getTranslation(TranslationsKeys.LOOK_NUTURAL),
      checked: false,
    },
  ]);

  const [badCheckLabels, setBadCheckLabels] = useState([
    {
      id: 1,
      label: getTranslation(TranslationsKeys.NOTLIKE_PET),
      checked: false,
    },
    {
      id: 2,
      label: getTranslation(TranslationsKeys.NOTLIKE_TEMPLATES),
      checked: false,
    },
    {
      id: 3,
      label: getTranslation(TranslationsKeys.LOOK_UNNATURAL),
      checked: false,
    },
  ]);

  const selectItem = (item: any) => {
    const isGood = showModalType === 'good';
    const checkLabels = isGood ? goodCheckLabels : badCheckLabels;
    const newCheckLabels = checkLabels.map((labelItem) => ({
      ...labelItem,
      checked: labelItem.id == item.id ? !labelItem.checked : labelItem.checked,
    }));
    isGood ? setGoodCheckLabels(newCheckLabels) : setBadCheckLabels(newCheckLabels);
  }

  const submit = () => {
    const reasons = document.getElementById('reasons')?.value;
    console.log('reasons', reasons)
    initModalState()
  }

  const initModalState = () => {
    setShowModalType('');
    const setCheckLabels = showModalType === 'good' ? setGoodCheckLabels : setBadCheckLabels;
    setCheckLabels(prev => prev.map(item => ({ ...item, checked: false })));
  }

  const ModalContent = ({
    title,
    checkLabels,
    otherReasons,
    setOtherReasons,
    submit,
    closeModal
  }: {
    title: string;
    checkLabels: { id: string; label: string; checked: boolean }[];
    submit: () => void;
    closeModal: () => void;
  }) => (
    <div className='result_investigate_modal'>
      <img className='modal_close_icon' onClick={initModalState} src={closeIcon} alt="" />
      <>
        <h3 className='investigate_title'>{title}</h3>
        <ul className='investigate_ui'>
          {checkLabels.map(item => (
            <li key={item.id} className='investigate_li' onClick={() => selectItem(item)}>
              <input type="checkbox" checked={item.checked} readOnly />
              <span>{item.label}</span>
            </li>
          ))}
        </ul>
        <p className='reason_title'>{getTranslation(TranslationsKeys.OTHER_REASONS)}:</p>
        <textarea
          id="reasons"
          className='reason_textarea'
          placeholder="We very appreciate your advice which helps us do better."
        />
        <Button
          loading={false}
          className='submit_btn'
          onClick={submit}
        >
          <span>{getTranslation(TranslationsKeys.BUTTON_SUBMIT)}</span>
        </Button>
      </>
    </div>
  );

  const ModalSwitch = () => {
    switch (showModalType) {
      case 'good':
        return (
          <ModalContent
            title={getTranslation(TranslationsKeys.WHY_IS_GOOD)}
            checkLabels={goodCheckLabels.map(item => ({ ...item, id: item.id.toString() }))}
            submit={submit}
            closeModal={() => setShowModalType('')}
          />
        );
      case 'bad':
        return (
          <ModalContent
            title={getTranslation(TranslationsKeys.WHY_IS_NOTGOOD)}
            checkLabels={badCheckLabels.map(item => ({ ...item, id: item.id.toString() }))}
            submit={submit}
            closeModal={() => setShowModalType('')}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className='__satisfy_result_layout'>
      <div className='result_operator_box'>
        <p className='des'>{getTranslation(TranslationsKeys.STISFIED_RESULT)}?</p>
        <div>
          <img src={goodIcon} alt="" onClick={() => setShowModalType('good')} />
          <img src={badIcon} alt="" onClick={() => setShowModalType('bad')} />
          <img src={closeIcon} alt="" />
        </div>
      </div>
      <ModalSwitch />
    </div>
  );
}