// 依赖
import React from "react";

// 组件
import { Button } from 'src/components/MakeUI';

// 样式
import './index.scss';

// 图标
import coinsIcon from '/src/images/2dEditor/Apps_icon/Icon_Coins.png';

// utils
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

export default function SubmitBtn(props: any) {

  const { text, credits, submitCallBack, disabled = false, ModulIntegral } = props;
  const { getTranslation } = useCustomTranslation();

  return (
    <div className="__pet_partrait_submit_btn">
      <Button
        loading={false}
        className={'submit_btn'}
        onClick={(credits >= ModulIntegral) && submitCallBack}
        disabled={disabled || !(credits >= ModulIntegral)}
        style={{ backgroundColor: (disabled || !(credits >= ModulIntegral)) ? '#abe2aa' : 'rgba(51, 191, 90, 1)' }}
      >
        <span className="text">{text}</span>
        <img src={coinsIcon} alt="" />
        <span>{ModulIntegral}</span>
      </Button>
      <div className="credits_info">
        {getTranslation(TranslationsKeys.MY_CREDITS)}<span>{credits}</span>
      </div>
    </div>
  )
}