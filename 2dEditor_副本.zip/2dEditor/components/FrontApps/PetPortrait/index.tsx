
// 依赖
import React, {useState, useRef} from "react";

// 组件
import PageIndex from './PageIndex/index';
import MyAvatar from "./MyAvatar/index";
import CreateAvatar from "./CreateAvatar/index";
import PoratraitStyle from "./PortraitStyle/index";
import MakingResult from './MakingResult/index';
import Upload from "src/templates/2dEditor/components/MainUi/MainUiLeft/MainUiLeftUpload/MainUiLeftUpload";

// 样式
import './index.scss'
import { dataURItoBlob } from "src/templates/LoginVms/common/utils";

export default function PetPortrait(props: any) {

  const { JumpStep } = props;
  const [isShowPageIndex, setIsShowPage] = useState(true);
  const [isShowCreateAvatar, setIsShowCreateAvatar] = useState(false);
  const [isShowPortraitStyle, setIsShowPortraitStyle] = useState(false);
  const [isShowMakingResult, setIsShowMakingResult] = useState(false);
  const [isShowMyAvatar, setIsShowMyAvatar] = useState(false);
  const [isShowUpload, setIsShowUpload] = useState(false);
  const [myAvatarFromUrl, setMyAvatarFromUrl] = useState('pageIndex');
  const [createAvatarFromUrl, setCreateAvatarFromUrl] = useState('pageIndex');
  const checkItemDataRef = useRef({});
  const [openUploadIndex, setOpenUploadIndex] = useState(0);
  const [isSelectedUpload, setIsSelectedUpload] = useState(false);
  const uploadDataRef = useRef({});
  console.log('===isShowUpload',isShowUpload)
  const makeFirstAvatar = () => {
    setIsShowPage(false);
    setIsShowCreateAvatar(true);
    setCreateAvatarFromUrl('pageIndex');
  }

  const careteAvatarReCallBack = () => {
    setIsShowCreateAvatar(false);
    setIsShowMyAvatar(true);
    setIsSelectedUpload(false);
  }

  const portraitStyleGoToCreate = () => {
    setIsShowPortraitStyle(false);
    setIsShowCreateAvatar(true);
    setCreateAvatarFromUrl('portraitStyle');
  }

  const makingResultReCallBack = () => {
    setIsShowMakingResult(false);
    setIsShowPage(true);
    
  }

  const checkPortraitItem = (itemData: any) => {
    checkItemDataRef.current = itemData;
    setIsShowPage(false);
    setIsShowPortraitStyle(true);
  }

  const portraitStyleGetResult = async () => {
    setIsShowPortraitStyle(false);
    setIsShowMakingResult(true);
  }

  const gotoPageIndex = () => {
    setIsShowPortraitStyle(false);
    setIsShowPage(true);
    setIsShowUpload(false)
  }

  const gotoMyAvatar = () => {
    setIsShowPage(false);
    setIsShowMyAvatar(true);
    setMyAvatarFromUrl('pageIndex');
  }

  const myAvatarReBack = () => {
    setIsShowMyAvatar(false);
    if (myAvatarFromUrl == 'pageIndex') {
      setIsShowPage(true);
    } else {

    }
  }
  
  const createAvatarReBack = () => {
    setIsShowCreateAvatar(false);
    if (createAvatarFromUrl == 'pageIndex') {
      setIsShowPage(true);
    } else if (createAvatarFromUrl == 'myAvatar') {
      setIsShowMyAvatar(true);
    }  else {
      setIsShowPortraitStyle(true);
    }
  }

  const myAvatarGotoCreate = () => {
    setIsShowMyAvatar(false);
    setIsShowCreateAvatar(true);
    setIsSelectedUpload(false);
    setCreateAvatarFromUrl('myAvatar');
  }

  const handlePetPoraData = (data: any) => {
    console.log("handlePetPoraData",data)
    uploadDataRef.current = data;
    setIsShowUpload(false);
    setIsShowCreateAvatar(true);
  }

  const openUpload = (index:number) => {
    setOpenUploadIndex(index);
    setIsShowUpload(true);
    setIsShowCreateAvatar(false);
    setIsSelectedUpload(true)
  }

  return (
    <div className="__pet_portrait_layout">
      <PageIndex 
        JumpStep={JumpStep}
        isShowPageIndex={isShowPageIndex}
        makeFirstAvatar={makeFirstAvatar}
        gotoMyAvatar={gotoMyAvatar}
        checkPortraitItem={checkPortraitItem}
      />
      {/* 创建分身 */}
      <CreateAvatar 
        isShowCreateAvatar={isShowCreateAvatar} 
        careteAvatarReCallBack={careteAvatarReCallBack}
        createAvatarReBack={createAvatarReBack}
        uploadData={uploadDataRef.current}
        openUpload={openUpload}
        openUploadIndex={openUploadIndex}
        isSelectedUpload={isSelectedUpload}
      />
      {/* 分身管理 */}
      <MyAvatar 
        isShowMyAvatar={isShowMyAvatar} 
        myAvatarReBack={myAvatarReBack}
        myAvatarGotoCreate={myAvatarGotoCreate}
      />
      {/* 照片生成 */}
      <PoratraitStyle 
        isShowPortraitStyle={isShowPortraitStyle} 
        portraitStyleGoToCreate={portraitStyleGoToCreate}
        portraitStyleGetResult={portraitStyleGetResult}
        gotoPageIndex={gotoPageIndex}
        checkItemData={checkItemDataRef.current}
      />
      {/* 生成结果 */}
      <MakingResult 
        isShowMakingResult={isShowMakingResult} 
        makingResultReCallBack={makingResultReCallBack}
      />
      {/* {isShowUpload && <Upload isPetPoratrait={true} handlePetPoraData={handlePetPoraData}/>} */}
    </div>
  )
}