
// 依赖
import React, { useEffect, useState, useRef, useCallback, useMemo } from "react";
import { useDispatch, useSelector } from 'react-redux';

// 工具
import { getImgCompress } from 'src/common/utils';
import { selectFiles } from 'src/templates/2dEditor/utils/utils';
import { upload } from 'src/hooks/useUpload';
import { checkFileSize } from 'src/templates/2dEditor/utils/checkFileSize';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { useTranslation } from '@volcengine/i18n';
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

// 组件
import Loading from 'src/components/Loading';
import SubmitBtn from '../SubmitBtn/index';
import { openToast } from 'src/state/reducers/toast';
import ImageCropper from "./ImageCropper/index";

// 服务
import { getModelTrainUploadToken, createModelTrainTask } from 'src/templates/2dEditor/service/2dEditService';

// 样式
import './index.scss';

// 图标
import uploadFileIcon from '/src/images/2dEditor/Apps_icon/appbar_download_icon.png'
import whiteCrossIcon from "src/assets/svg/white_cross.svg";
import isRightIcon from "src/assets/svg/is_right.svg";
import isErrorIcon from "src/assets/svg/is_error.svg";
import return_icon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png';
import image1 from './image/image1.png';
import image2 from './image/image2.png';
import image3 from './image/image3.png';
import image4 from './image/image4.png';

import { blobToBase64 } from 'src/common/utils';
import {
  getAiAllData,
  selectHome,
  HomeState,
  getAiModeIntegralData,
  getNowActiveAiModuleData,
  getUserIntegralData,
} from 'src/state/reducers/home'

export default function CreateAvatar(props: any) {

  const dispatch = useDispatch();
  const { getTranslation } = useCustomTranslation();
  const { t } = useTranslation();
  const { isShowCreateAvatar, careteAvatarReCallBack, createAvatarReBack, uploadData, openUpload, openUploadIndex, isSelectedUpload } = props;
  const [isLoading, setIsLoading] = React.useState(false);
  const [uploadFile, setUploadFile] = React.useState({});
  const uploadFileIndexRef = useRef<number>(0);
  const [tabStep, setTabStep] = React.useState(1);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [upImgSrc, setUpImgSrc] = useState({});
  const cropperRef = useRef(null);
  const [isShowCrop, setIsShowCrop] = useState(false);
  const homeState: HomeState = useSelector(selectHome)
  // 当前模块需要的积分
  const [NowModulIntegral, setNowModulIntegral] = useState(1)
  // 用户的总积分
  let UserAllIntegral = homeState?.UserIntegral

  const [uploadTokenData, setUploadTokenData] = useState({} as { dataset_id: string, thumb: { key_prefix: string, up_token: string }, dataset: string[] });
  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault(); // 阻止默认行为
    event.stopPropagation();
  }, []);
  const handleStepTabChange = (index: number) => {
    setTabStep(index)
  }

  const uploadEditFile = (file: File, index: number) => {
    return upload(uploadTokenData?.dataset?.[index]?.up_token, file)
  }

  const uploadsFile = (index: number) => {
    uploadFileIndexRef.current = index;
    selectFiles({ accept: '.jpeg,.jpg,.png,.webp', multiple: true }).then((fileList: any) => {
      setIsLoading(true);
      const fileData = fileList[0];
      getImgCompressAction(fileData, index)
    });
  }

  const imageToWebp = (file: any, index: number) => {
    if (file) {
      const reader = new FileReader();
      reader.onload = function (readerEvent) {
        const image = new Image();
        image.onload = function (imageEvent) {
          const canvas = document.createElement('canvas');
          canvas.width = image.width;
          canvas.height = image.height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(image, 0, 0, image.width, image.height);
          canvas.toBlob(function (blob) {
            onCrop(blob, index);
          }, 'image/webp');
        };
        // @ts-ignore
        image.src = readerEvent?.target?.result;
      };
      reader.readAsDataURL(file);
    }
  }

  const handleImageChange = async (e: { target: { files: Blob[]; }; }, index: number) => {
    if (!checkFileSize(e.target.files[0])) return;
    setIsShowCrop(true);
    uploadFileIndexRef.current = index;
    const file = e.target.files[0];
    imageToWebp(file, index);

  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, index: number) => {
    e.stopPropagation();
    e.preventDefault();
    if (!checkFileSize(e.dataTransfer.files[0])) return;
    // setIsShowCrop(true);
    uploadFileIndexRef.current = index;
    const file = e.dataTransfer.files[0]; // 仅处理第一个文件
    console.log('====type', file.type)
    // @ts-ignore
    if (!['image/jpeg', 'image/png', 'image/jpg', 'image/webp'].includes(file.type)) {
      dispatch(
        openToast({
          message: getTranslation(TranslationsKeys.UN_FILE_TYPE),
          severity: 'error',
        }),
      );
      return;
    }
    imageToWebp(file, index);
  };

  // 发布创建
  const submitCallBack = async () => {
    setSubmitLoading(true);
    try {
      await uploadImage();
      const params = {
        dataset_id: uploadTokenData.dataset_id,
        thumb_key_prefix: uploadTokenData.thumb.key_prefix,
      };
      const res = await createModelTrainTask(params);
      console.log('===res', res);
      if (res?.code === 0) {
        // 总积分 - 所有模块[当前模块].积分 = 剩余积分
        UserAllIntegral = UserAllIntegral - NowModulIntegral
        dispatch(getUserIntegralData(UserAllIntegral));
        setSubmitLoading(false);
        setUploadFile({});
        careteAvatarReCallBack();
      } else {
        dispatch(
          openToast({
            message: res?.msg || `${getTranslation(TranslationsKeys.FAILED_TASK)}`,
            severity: 'error',
          }),
        );
        setSubmitLoading(false);
      }
    } catch (error) {
      dispatch(
        openToast({
          message: `${getTranslation(TranslationsKeys.FAILED_IMAGE)}`,
          severity: 'error',
        }),
      );
      setSubmitLoading(false);
    }
  };

  // 上传图片
  const uploadImage = async () => {
    const uploadPromises = Object.keys(uploadFile).map(async (item, index) => {
      const blob = await fetch(uploadFile[item]).then(res => res.blob());
      console.log('===blob', blob.type);
      const file = new File([blob], `image${item}.webp`, { type: blob.type, lastModified: Date.now() });
      await getImgCompressAction(file, item);

    });
    await Promise.all(uploadPromises);
  };

  const getImgCompressAction = async (fileData: File, index: number) => {
    const blob = await getImgCompress(fileData, 1000, 0, 1);
    const file = new File([blob], fileData.name, { type: blob.type, lastModified: Date.now() });
    try {
      const resp = await uploadEditFile(file, index);
      console.log('resp==', resp);
      if (resp.statusText === 'OK') {
        if (index === 0) {
          await upload(uploadTokenData.thumb?.up_token, file);
        }
      } else {
        throw new Error('Upload failed');
      }
    } catch (error) {
      setSubmitLoading(false);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // 获取模型训练上传Token
  const getUploadTokenData = async () => {
    try {
      const res = await getModelTrainUploadToken({ dataset_num: 6 });
      setUploadTokenData(res?.data);
    } catch (error) {
      console.error('Failed to fetch upload token:', error);
    }
  }

  useEffect(() => {
    if (isShowCreateAvatar) {
      getUploadTokenData();
    } else {
      if (!isSelectedUpload) {
        setUploadFile({});
        setTabStep(1);
      }
    }
  }, [isShowCreateAvatar])

  useEffect(() => {
    const fetchData = async () => {
      let decodedUrl =
        uploadData.download_url.indexOf('oss-cn-shenzhen') !== -1
          ? uploadData.download_url
          : decodeURIComponent(uploadData.download_url)
      // const decodedUrl = decodeURIComponent(uploadData.download_url);
      const response = await fetch(decodedUrl);
      const blob = await response.blob();
      const base64 = await blobToBase64(blob);
      setUpImgSrc((prevData: any) => ({
        ...prevData,
        [openUploadIndex]: base64
      }));
    };
    if (Object.keys(uploadData).length > 0) {
      fetchData();
    }
  }, [uploadData]);

  const onCrop = async (blob: any, index: number) => {
    setIsLoading(true);
    setUpImgSrc({});
    const base64 = await blobToBase64(blob);
    setUploadFile((prevData: any) => ({
      ...prevData,
      [index]: base64
    }));
    if (index == 0) {
      setTimeout(() => {
        setTabStep(2)
      }, 1000)
    }
    setIsShowCrop(false);
    // getImgCompressAction(file, index);
  }

  const cancelCrop = (index: number) => {
    setUpImgSrc({});
    setUploadFile((prevData: any) => {
      const newData = { ...prevData };
      newData[index] = null;
      return newData;
    });
    setIsShowCrop(false);
  }
  console.log('=uploadFile', uploadFile)
  const TabStep1Box = ({
    tabStep,
    upImgSrc,
    uploadFile,
    setUploadFile,
    handleDrop,
    handleImageChange,
    isLoading,
    whiteCrossIcon,
    uploadFileIcon,
  }: {
    tabStep: number;
    upImgSrc: any;
    uploadFile: any;
    setUploadFile: (data: any) => void;
    handleDrop: (e: React.DragEvent<HTMLDivElement>, index: number) => void;
    handleImageChange: (e: React.ChangeEvent<HTMLInputElement>, index: number) => void;
    isLoading: boolean;
    cropperRef: React.RefObject<any>;
    whiteCrossIcon: any;
    uploadFileIcon: any;
  }) => {
    const isDisplay = useMemo(() => tabStep === 1, [tabStep]);
    const hasUploadFile = useMemo(() => uploadFile && uploadFile[0], [uploadFile]);
    const hasUpImgSrc = useMemo(() => upImgSrc && upImgSrc[0], [upImgSrc]);

    const handleDeleteClick = useCallback(() => {
      setUploadFile((prevData: any) => {
        const newData = { ...prevData };
        newData[0] = null;
        return newData;
      });
    }, [setUploadFile]);
    console.log('===isShowCrop', isShowCrop)
    return (
      <div className={`tab_step1_box`} style={{ display: isDisplay ? 'grid' : 'none' }}>
        <p>
          <span className="font-weight-normal">{t('upload 1')} </span><span className="font-weight-bold">{t('front Photo')}</span>
        </p>
        <p>{getTranslation(TranslationsKeys.UPLOAD_PET_PHOTO_TIP1)}</p>
        <div className="upload_box">
          {hasUploadFile ? (
            <>
              <img className="upload_file_img" src={uploadFile[0]} alt="" />
              <img src={whiteCrossIcon} alt="" className="deleteIcon" onClick={() => handleDeleteClick()} />
            </>
          ) : (
            <div className="upload_btn_box step1_upload_box" onDrop={(e) => handleDrop(e, 0)}>
              <input type="file" className="upload_input" accept=".jpeg,.jpg,.png,.webp" onChange={(e) => handleImageChange(e, 0)} />
              <img className='upload_icon' src={uploadFileIcon} />
              <p>{getTranslation(TranslationsKeys.UPLOAD_PET_PHOTO_BTN)}</p>
            </div>
          )}
        </div>
        <p className="sample_image_des">
          {!isShowCrop && <span>{getTranslation(TranslationsKeys.UPLOAD_PET_PHOTO)}</span>}
        </p>
      </div>
    );
  };

  type UploadFileItemProps = {
    item: any;
    fileData: any;
    upImgSrc: any;
    handleDeleteClick: any;
    handleImageChange: any;
    handleDrop: any;
    uploadFileIcon: any;
  };

  const UploadFileItem: React.FC<UploadFileItemProps> = ({
    item,
    fileData,
    upImgSrc,
    handleDeleteClick,
    handleImageChange,
    handleDrop,
    uploadFileIcon,
  }) => {
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      handleImageChange(e, item);
    };

    const handleFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
      handleDrop(e, item);
    };

    return (
      <div className="upload_file_item">
        {/* {upImgSrc?.[item] && (
          <div className="cropperContainer">
            <ImageCropper imageUrl={upImgSrc?.[item] || ''} onCrop={onCrop} index={item} cancelCrop={() => cancelCrop(item)} />
          </div>
        )} */}
        {fileData ? (
          <div className="fileDataContainer">
            <img className="upload_file_img" src={fileData} alt="" />
            <img src={whiteCrossIcon} alt="" className="deleteIcon" onClick={() => handleDeleteClick()} />
          </div>
        ) : (
          <div className="upload_btn_box" onDrop={handleFileDrop}>
            <input type="file" className="upload_input" accept={'.jpeg,.jpg,.png,.webp'} onChange={handleFileChange} />
            <img className='upload_icon' src={uploadFileIcon} />
            {/* <p onClick={() => openUpload(item)}>upload</p> */}
          </div>
        )}
      </div>
    );
  };

  const TabStep2Box = ({ tabStep, uploadFile, upImgSrc, setUploadFile, uploadsFile, handleImageChange, handleDrop, uploadFileIcon, isLoading, uploadFileIndexRef }: {
    tabStep: number,
    uploadFile: any,
    upImgSrc: any,
    setUploadFile: any,
    uploadsFile: any,
    handleImageChange: any,
    handleDrop: any,
    uploadFileIcon: any,
    isLoading: any,
    uploadFileIndexRef: any
  }) => {
    const handleDeleteClick = (item: any) => {
      setUploadFile((prevData: any) => ({
        ...prevData,
        [item]: null
      }));
    };

    return (
      <div className="tab_step2_box" style={{ display: tabStep === 2 ? 'grid' : 'none' }}>
        <p className="step_des1">{getTranslation(TranslationsKeys.UPLOAD_PET_PHOTO_TIP2)}</p>
        <p className="step_des2">{getTranslation(TranslationsKeys.UPLOAD_PET_PHOTO_TIP3)}</p>
        <div className="upload_file_list">
          {[1, 2, 3, 4, 5].map(item => (
            <UploadFileItem
              key={item}
              item={item}
              fileData={uploadFile[item]}
              upImgSrc={upImgSrc}
              handleDeleteClick={() => handleDeleteClick(item)}
              handleImageChange={handleImageChange}
              handleDrop={handleDrop}
              uploadFileIcon={uploadFileIcon}
            />
          ))}
        </div>
        <p className="sample_image_des">
          {!isShowCrop && <span>{getTranslation('string_upload_petPhoto')}</span>}
        </p>
      </div>
    );
  };

  const sampleImages = [
    { icon: image1, des: getTranslation(TranslationsKeys.SAMPLE_IMAGES_ITEM1) },
    { icon: image1, des: getTranslation(TranslationsKeys.SAMPLE_IMAGES_ITEM2) },
    { icon: image1, des: getTranslation(TranslationsKeys.SAMPLE_IMAGES_ITEM3) },
  ];
  const errorSampleImage = [
    { icon: image2, des: getTranslation(TranslationsKeys.ERROR_SAMPLE_IMAGES_ITEM1) },
    { icon: image3, des: getTranslation(TranslationsKeys.ERROR_SAMPLE_IMAGES_ITEM2) },
    { icon: image4, des: getTranslation(TranslationsKeys.ERROR_SAMPLE_IMAGES_ITEM3) },
  ];

  useEffect(() => {
    // 当前选中的ai模块所需积分
    if (!homeState?.nowActiveAiModule) return;
    const costClass = homeState.nowActiveAiModule?.costClass;
    const cost = homeState?.AiModeIntegralData?.[costClass]?.cost;
    if (cost !== undefined) {
      setNowModulIntegral(cost);
    } else {
      console.log("costClass数据为空，请查看cms中class字段以及各模块所需参数值的接口");
    }
  }, [homeState?.nowActiveAiModule]);


  const uploadFileList = Object.entries(uploadFile).filter(([key, value]) => value !== null) || [];

  const SampleImageLayout: React.FC = React.memo(() => {
    return (
      <>
        <div className="sample_image_layout">
          <div className="sample_image_title">{getTranslation(TranslationsKeys.SAMPLE_IMAGE)}</div>
          <div className="sample_image_list">
            {sampleImages.map((item, index) => (
              <div key={index} className='sample_item'>
                <img className="image_item" src={item.icon} alt="" loading="lazy" />
                <div className="item_tip_box">
                  <img className="item_icon" src={isRightIcon} alt="" />
                  <span>{item.des}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="sample_image_layout">
          <div className="sample_image_title" style={{ marginTop: 0 }}>{getTranslation('string_error_sample')}</div>
          <div className="sample_image_list">
            {errorSampleImage.map((item, index) => (
              <div key={index} className='sample_item'>
                <img className="image_item" src={item.icon} alt="" loading="lazy" />
                <div className="item_tip_box">
                  <img className="item_icon" src={isErrorIcon} alt="" />
                  <span>{item.des}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </>
    );
  });

  return (
    <div className="__create_avatar_layout" style={{ display: isShowCreateAvatar ? '' : 'none' }} >
      <div className="layout_reback">
        <img src={return_icon} alt="" onClick={createAvatarReBack} />
        <span>{getTranslation(TranslationsKeys.CREATE_PET_AVATAR)}</span>
      </div>
      <div className="layout_content" onDragOver={handleDragOver}>
        <p className="title_tip">{getTranslation(TranslationsKeys.CREATE_ONCE_TIP)}</p>
        <div className="upload_file_box">
          <div className="tab_box">
            <div onClick={() => handleStepTabChange(1)} >
              <span className="step1_number">1</span>
              <span>{getTranslation(TranslationsKeys.STEP1)}</span>
            </div>
            <span className="step_icon">{'>'}</span>
            <div onClick={() => { uploadFile && uploadFile[0] ? handleStepTabChange(2) : undefined }} >
              <span style={{ background: tabStep == 2 ? '#33BF5A' : '#0000001A' }}>2</span>
              <span style={{ color: tabStep == 2 ? "#000" : "#00000080" }}>{getTranslation(TranslationsKeys.STEP2)}</span>
            </div>
          </div>
          <TabStep1Box
            tabStep={tabStep}
            upImgSrc={upImgSrc}
            uploadFile={uploadFile}
            setUploadFile={setUploadFile}
            handleDrop={handleDrop}
            // @ts-ignore
            handleImageChange={handleImageChange}
            isLoading={isLoading}
            cropperRef={cropperRef}
            whiteCrossIcon={whiteCrossIcon}
            uploadFileIcon={uploadFileIcon}
          />
          <TabStep2Box
            tabStep={tabStep}
            uploadFile={uploadFile}
            upImgSrc={upImgSrc}
            setUploadFile={setUploadFile}
            uploadsFile={uploadsFile}
            handleImageChange={handleImageChange}
            handleDrop={handleDrop}
            uploadFileIcon={uploadFileIcon}
            isLoading={isLoading}
            uploadFileIndexRef={uploadFileIndexRef}
          />
          <SampleImageLayout />
        </div>
        <div className='submit_operator' style={{ display: tabStep == 2 ? 'block' : 'none' }}>
          <SubmitBtn text='Start To Create' disabled={uploadFileList.length <= 3} credits={UserAllIntegral} submitCallBack={submitCallBack} ModulIntegral={NowModulIntegral} />
        </div>
      </div>
      <Loading className='loading' loading={submitLoading} isAbsolute />
    </div>
  );
}