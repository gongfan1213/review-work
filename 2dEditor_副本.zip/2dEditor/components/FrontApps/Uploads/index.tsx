import React from "react";
import './index.scss';
import appbar_download_icon from '../../../../../images/2dEditor/Apps_icon/appbar_download_icon.png'
import { getImgStr, selectFiles } from 'src/templates/2dEditor/utils/utils';
import dog_img from '../../../../../images/2dEditor/Apps_icon/dog_img.png'

export default function Uploads(props: any) {
  const { prevStep } = props;

  const Uploads_click = () => {
    const supportImageTypes = '.jpeg,.png,.jpg,.webp,.svg';
    selectFiles({ accept: supportImageTypes, multiple: true }).then((fileList) => {
      Array.from(fileList as FileList).forEach((item) => {
        const fileExtension = item.name.split('.').pop()?.toLowerCase(); // 获取文件后缀并转换为小写
        console.log("---->》《", item);
        //后期对照updateFile方法进行修改 
      });
    });
  }

  const tabelData = [
    { image: dog_img, title: 'Dog1', id: 1 },
    { image: dog_img, title: 'Dog1', id: 2 },
    { image: dog_img, title: 'Dog1', id: 3 },
    { image: dog_img, title: 'Dog1', id: 4 },
    { image: dog_img, title: 'Dog1', id: 5 },
  ]

  const imageClick = (item: any) => {
    console.log('imageClick', item)
    prevStep('', item)
  }

  return (
    <div className="Uploads_box">
      <div className="Uploads_click" onClick={() => { Uploads_click() }}>
        <img src={appbar_download_icon} className="Uploads_click_img" />
        <div className="Uploads_click_title">
          Upload (PNG, JPG, SVG, WEBP)
        </div>
      </div>
      <div className="Choose_title">Choose one</div>
      <div className="tabel_card">
        {
          tabelData?.map((item: any) => {
            return (
              <div className="tabelimage_box" onClick={() => { imageClick(item) }}>
                <img src={item?.image} className="tabelimage" />
              </div>
            )
          })
        }
      </div>
    </div>
  );
}