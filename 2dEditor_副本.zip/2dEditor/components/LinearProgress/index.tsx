import * as React from 'react'
import Box from '@mui/material/Box'
import LinearProgress from '@mui/material/LinearProgress'

export default function LinearDeterminate(props: any) {
  let { loading } = props
  const [progress, setProgress] = React.useState(0)
  // 优化了定时器的使用，避免了不必要的内存泄漏和重复设置状态
  React.useEffect(() => {
    let timer: NodeJS.Timeout | null = null

    if (loading) {
      setProgress(0)
      timer = setInterval(() => {
        setProgress((oldProgress) => {
          const diff = Math.random() * 50
          return Math.min(oldProgress + diff, 90)
        })
      }, 500)
    } else {
      setProgress(100)
    }

    return () => {
      if (timer) clearInterval(timer)
    }
  }, [loading])

  return (
    <div>
      <Box
        sx={{ width: '100%' }}
        style={{ position: 'fixed', width: '100vw', top: '0', left: '-470px' }}
      >
        <LinearProgress variant="determinate" value={progress} />
      </Box>
    </div>
  )
}
