import React, { useEffect, useState } from 'react';
import Popover from '@mui/material/Popover';
import './index.scss';
import ButtonPublic from '../ButtonPublic';
import clsx from 'clsx';
import { get } from 'src/services'
import useDataCache from '../../utils/DataCache';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

export default function TemplatesPopover(props: any) {
  const { getCacheItem, setCacheItem } = useDataCache();
  const { getTranslation } = useCustomTranslation();
  const { defaultValues, open, anchorEl, onClose, ConfirmClick, ClearnAllClick } = props
  // 已经选中的状态（回显与操作）
  const [activeForm, setActiveForm] = useState({ product: [], tags: [] } as any)
  // 过滤器内的全部数据
  const [filterData, setFilterData] = useState({ product: [], tags: [] } as any)

  const transformData = async (url: string, params: any, key: string) => {
    const json = await get<{ data: any }>(url, params);
    const transformed = json?.data?.data.map((item: any) => {
      if (key === 'tags') {
        return {
          value: item.id,
          label: item.attributes.tag_name,
        };
      } else {
        return {
          value: item.attributes.categoryKey,
          label: item.attributes.categoryName,
        }
      }
    });
    // @ts-ignore
    setFilterData(prevFilterData => ({
      ...prevFilterData,
      [key]: transformed,
    }));
    const cacheData = getCacheItem('TemplatesFilterData') || {};
    setCacheItem('TemplatesFilterData', {
      ...cacheData,
      [key]: transformed
    })
  };

  // console.log("getCacheItem", getCacheItem('TemplatesFilterData'), "getCacheItem('TemplatesFilterData')?.product?.length", getCacheItem('TemplatesFilterData')?.product?.length);

  // 获取筛选器顶部数据
  const ProductData = () => {
    transformData(
      '/web/cms-proxy/common/content',
      {
        // cms接口地址
        content_type: 'make-2d-category-types',
        pagination: {
          page: 1,
          pageSize: 10000,
        },
      },
      'product',
    )
  }

  // 获取筛选器底部数据
  const TagsData = () => {
    transformData(
      '/web/cms-proxy/common/content',
      {
        // cms接口地址
        content_type: 'make-2d-tag-names',
        populate: ['tag_name'],
        pagination: {
          page: 1,
          pageSize: 10000,
        },
      },
      'tags'
    );
  }

  const handleSelect = (type: any, value: any) => {
    setActiveForm({
      ...activeForm,
      [type]: activeForm[type]?.includes(value)
        ? activeForm[type]?.filter((v: any) => v !== value)
        : [...(activeForm[type] || []), value],
    })
  }

  useEffect(() => {
    if (getCacheItem('TemplatesFilterData')?.product?.length !== undefined
      || getCacheItem('TemplatesFilterData')?.tags?.length !== undefined) {
      setFilterData(getCacheItem('TemplatesFilterData'))
      return
    }
    ProductData()
    TagsData()
  }, [])

  useEffect(() => {
    const activeForm = getCacheItem('templatesMenu')?.['activeForm'];
    if (activeForm) {
      setActiveForm(activeForm);
    }
  }, [])

  const renderItem = (group: any, type: any) => {
    return (
      <div className='Filter_itemWrapper'>
        <div className='Filter_lineWrapper'>
          {group?.map((g: any) => {
            const isActive = activeForm[type]?.includes(g?.value);
            return (
              <span
                key={g?.label}
                onClick={() => handleSelect(type, g?.value)}
                className={clsx(
                  isActive ? 'activeG' : '',
                )}
              >
                {g.label}
              </span>
            )
          })}
        </div>
      </div>
    )
  }

  return (
    <Popover
      open={open}
      anchorReference="anchorPosition"
      anchorPosition={anchorEl}
      onClose={onClose}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'left',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'right',
      }}
    >
      <div className='popover_Filter_box'>
        <div className='Filter_top'>
          {renderItem(filterData?.product, 'product')}
        </div>
        <div className='Filter_border_top'></div>
        <div className='Filter_down'>
          {renderItem(filterData?.tags, 'tags')}
        </div>
        <div className='Filter_border_down'></div>
        <div className='Filter_down_box'>
          <ButtonPublic
            variant='greenBlack'
            style={{ width: '49%' }}
            disabled={activeForm.product.length === 0 && activeForm.tags.length === 0}
            onClick={() => { ClearnAllClick(setActiveForm({ product: [], tags: [] }), { product: [], tags: [] }) }}
          >
            {getTranslation(TranslationsKeys.Clearall)}
          </ButtonPublic>
          <ButtonPublic
            variant='greenWhite'
            style={{ width: '49%' }}
            // disabled={activeForm.product.length === 0 && activeForm.tags.length === 0}
            onClick={() => { ConfirmClick(activeForm) }}
          >
            {getTranslation(TranslationsKeys.BUTTON_CONFIRM)}
          </ButtonPublic>
        </div>
      </div>
    </Popover>
  );
}