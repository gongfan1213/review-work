import React from 'react'
import { useCanvasEditor } from '../../hooks/context';
import { Button } from '@mui/material';

function ClearButton() {
  const canvasEditor = useCanvasEditor();
  const confirm = () => {
    canvasEditor.clear();
  }
  return (
    <div>
      <Button onClick={confirm}>清空</Button>
    </div>
  )
}

export default ClearButton