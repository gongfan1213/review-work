/**
 * layer;
 */
import layer from 'src/assets/svg/layer.svg';
import down_triangle from 'src/assets/svg/down_triangle.svg';
import textureIcon from 'src/assets/img/smart fill.png';
import text from 'src/assets/svg/text.svg';
import image from 'src/assets/svg/image.svg';
import vector from 'src/assets/svg/vector.svg';
import unlock from 'src/assets/svg/unlock.svg';
import layer_lock from 'src/assets/svg/layer_lock.svg';
import eye from 'src/assets/svg/eye.svg';
import close_eye from 'src/assets/svg/close_eye.svg';
import { useCanvasEditor, useFabric, useProjectData, useEvent } from '../../hooks/context';
import React, { useState, useEffect, useRef } from 'react';
import * as classes from './index.module.scss';
import { EDITOR_JSON_KEY, EventNameCons, FabricObjectType, WorkspaceID } from '../../cons/2dEditorCons';
import { LayerType, CustomKey, CustomObjectType } from '../../cons/2dEditorCons';
import {
  BezierControlId,
  CircleControlId,
  AngleControlId,
} from 'src/templates/2dEditor/core/plugin/ArcTextPlugin/types';
import { DisableLayerId } from './types';
import { TempPatternID } from 'src/templates/2dEditor/core/plugin/PatternPlugin/types';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { LayerStatus, RenderLayer } from 'src/templates/2dEditor/core/eventbus/types/layer';
import { HistoryEvent } from 'src/templates/2dEditor/core/eventbus/types/history';
// import { ArcText } from 'src/templates/2dEditor/core/plugin/ArcTextPlugin/ArcText';
// import { Image } from 'src/templates/2dEditor/core/plugin/ImagePlugin/Image';
import debounce from 'lodash/debounce';
import { throttle } from 'lodash-es';
import DOMPurify from 'dompurify';
import _, { get } from 'lodash';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import useCustomTranslation from 'src/hooks/useCustomTranslation';

export function Layer(props: any) {
  const { onShowLayer } = props;
  const canvasEditor = useCanvasEditor();
  const fabric = useFabric();
  const projectModel = useProjectData();
  const event = useEvent();
  // whether to render layer;
  const isRenderLayer = useRef<boolean>(true);
  // <react> render flag;
  const [renderFlag, setRenderFlag] = useState<boolean>(false);
  const [allObjects, setAllObjects] = useState<any[]>([]);
  const [selectedIds, setSelectedIds] = useState<any[]>([]);
  const [showLayers, setShowLayers] = useState<boolean>(false);
  const [hoverLayerId, setHoverLayerId] = useState<string>('');
  const [renameLayerId, setRenameLayerId] = useState<string>('');
  const layerUlRef = useRef<HTMLUListElement>(null);
  const layerText = useRef(''); //实时获取画布名称
  const selectItemCloneRef = useRef<fabric.Object | null>(null);
  const { getTranslation } = useCustomTranslation();
  const layerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!!layerUlRef.current) {
      layerUlRef.current!.oncontextmenu = (e: any) => e.preventDefault();
    }
    canvasEditor?.canvas.on('object:added', handleObject);
    canvasEditor?.canvas.on('object:removed', handleObjectRemove);
    canvasEditor?.canvas.on('selection:created', handleSelection);
    canvasEditor?.canvas.on('selection:updated', handleSelection);
    canvasEditor?.canvas.on('selection:cleared', handleSelection);
    event?.on('rightMenuClickLock', handleLock);
    event?.on('rightMenuClickZIndex', handleRightClickZIndexChange);
    eventBus?.on(LayerStatus.RenderStatus, handleIsLayerRender);
    eventBus?.on(HistoryEvent.Rendering, handleHistoryRenderingEvent);
    event?.on(EventNameCons.EventHideLayerTreeList, () => setShowLayers(false));
    eventBus?.on(EventNameCons.EventToBottom, handleToBottom);
    eventBus?.on(EventNameCons.EventToTop, handleToTop);
    eventBus?.on(EventNameCons.EventHanlederLock, handleLock);
    eventBus?.on(EventNameCons.EventUpdateLayer, updateLayerUI);

    return () => {
      canvasEditor?.canvas.off('object:added', handleObject);
      canvasEditor?.canvas.off('object:removed', handleObjectRemove);
      canvasEditor?.canvas.off('selection:created', handleSelection);
      canvasEditor?.canvas.off('selection:updated', handleSelection);
      canvasEditor?.canvas.off('selection:cleared', handleSelection);
      event?.off('rightMenuClickLock', handleLock);
      event?.off('rightMenuClickZIndex', handleRightClickZIndexChange);
      eventBus?.off(LayerStatus.RenderStatus, handleIsLayerRender);
      eventBus?.off(HistoryEvent.Rendering, handleHistoryRenderingEvent);
      event?.off(EventNameCons.EventHideLayerTreeList, () => setShowLayers(false));
      eventBus?.off(EventNameCons.EventToBottom, handleToBottom);
      eventBus?.off(EventNameCons.EventToTop, handleToTop);
      eventBus?.off(EventNameCons.EventHanlederLock, handleLock);
      eventBus?.off(EventNameCons.EventUpdateLayer, updateLayerUI);
    };
  }, [canvasEditor]);

  const getObjectDeep = (objects: fabric.Object[], id: string) => {
    let object = null;
    objects.forEach((obj: any) => {
      if (obj.id === id) {
        object = obj;
      } else if (obj.type === 'group') {
        const group = obj._objects;
        object = getObjectDeep(group, id);
      }
    });
    return object;
  };

  const handleToBottom = (object: fabric.Object) => {
    setAllObjects((prevAllObject) => {
      let tempAllObject = [...prevAllObject];

      //处理当前元素是从编组中克隆出来的情况
      if (object._parentId) {
        const group = getObjectDeep(tempAllObject, object._parentId);
        if (group) tempAllObject = group.getObjects();
        const currentIndex = tempAllObject.findIndex((item: any) => item.id === object._cloneId);
        tempAllObject.push(tempAllObject.splice(currentIndex, 1)[0]);
        handleZIndex(tempAllObject);
        return prevAllObject;
      } else {
        const currentIndex = tempAllObject.findIndex((item: any) => item.id === object.id);
        tempAllObject.splice(currentIndex, 1);
        tempAllObject.push(object);
        handleZIndex(tempAllObject);
        return tempAllObject;
      }
    });
  };

  const handleToTop = (object: fabric.Object) => {
    setAllObjects((prevAllObject) => {
      let tempAllObject = [...prevAllObject];
      //处理当前元素是从编组中克隆出来的情况
      if (object._parentId) {
        const group = getObjectDeep(tempAllObject, object._parentId);
        if (group) tempAllObject = group.getObjects();
        const currentIndex = tempAllObject.findIndex((item: any) => item.id === object._cloneId);
        tempAllObject.unshift(tempAllObject.splice(currentIndex, 1)[0]);
        handleZIndex(tempAllObject);
        return prevAllObject;
      } else {
        const currentIndex = tempAllObject.findIndex((item: any) => item.id === object.id);
        tempAllObject.splice(currentIndex, 1);
        tempAllObject.unshift(object);
        handleZIndex(tempAllObject);
        return tempAllObject;
      }
    });
  };

  const handleToDown = (object: fabric.Object) => {
    setAllObjects((prevAllObject) => {
      let tempAllObject = [...prevAllObject];
      //处理当前元素是从编组中克隆出来的情况
      if (object._parentId) {
        const group = getObjectDeep(tempAllObject, object._parentId);
        if (group) tempAllObject = group.getObjects();
        const currentIndex = tempAllObject.findIndex((item: any) => item.id === object._cloneId);
        tempAllObject.splice(currentIndex + 1, 0, tempAllObject.splice(currentIndex, 1)[0]);
        handleZIndex(tempAllObject);
        return prevAllObject;
      } else {
        const currentIndex = tempAllObject.findIndex((item: any) => item.id === object.id);
        tempAllObject.splice(currentIndex, 1);
        tempAllObject.splice(currentIndex + 1, 0, object);
        handleZIndex(tempAllObject);
        return tempAllObject;
      }
    });
  };

  const handleToUp = (object: fabric.Object) => {
    setAllObjects((prevAllObject) => {
      let tempAllObject = [...prevAllObject];
      if (object._parentId) {
        const group = getObjectDeep(tempAllObject, object._parentId);
        if (group) tempAllObject = group.getObjects();
        const currentIndex = tempAllObject.findIndex((item: any) => item.id === object._cloneId);
        tempAllObject.splice(currentIndex - 1, 0, tempAllObject.splice(currentIndex, 1)[0]);
        handleZIndex(tempAllObject);
        return prevAllObject;
      } else {
        const currentIndex = tempAllObject.findIndex((item: any) => item.id === object.id);
        tempAllObject.splice(currentIndex, 1);
        tempAllObject.splice(currentIndex - 1, 0, object);
        handleZIndex(tempAllObject);
        return tempAllObject;
      }
    });
  };

  const updateLayerUI = () => {
    setAllObjects(getAllObjects());
  };

  const handleIsLayerRender = (e: number | boolean) => {
    isRenderLayer.current = !!e;
  };
  // get all obejcts;
  const getAllObjects = () => {
    return (
      canvasEditor?.canvas.getObjects().filter(
        (item) =>
          !!item.id &&
          !~item.id?.indexOf(WorkspaceID.WorkspaceCavas) &&
          item.id !== BezierControlId.ControlCircle &&
          item.id !== BezierControlId.ControlLine &&
          item.id !== CircleControlId.ControlCircle &&
          item.id !== AngleControlId.ControlCircle &&
          item.id !== AngleControlId.ControlLine &&
          item.id !== DisableLayerId.ClonedForMoveId &&
          item.id !== TempPatternID.ID &&
          item.id !== 'imageCropMask', // image crop mask;
      ) || []
    );
  };
  // 处理画布元素增删改更新;
  const handleObject = () => {
    if (!isRenderLayer.current) return;
    if (isShiftKeydown) return;
    const allObjects = getAllObjects();
    allObjects.forEach((item: any) => {
      if (item.type === FabricObjectType.Image) {
        item.set({
          [CustomKey.ImageResolution]: imageResolution(item),
        });
        item.on('scaling', debounce(handleObject, 500));
      }
    });
    // ;
    // 始终将透明bg置顶;
    canvasEditor?.canvas.getObjects().forEach((item: any) => {
      if (item.id === WorkspaceID.WorkspaceBG) {
        // console.log('始终将透明bg置顶;');
        canvasEditor?.canvas.bringToFront(item);
        canvasEditor?.canvas.renderAll();
      }
    });
    // ;
    allObjects.sort((a: any, b: any) => b[CustomKey.ZIndex] - a[CustomKey.ZIndex]);
    setAllObjects(allObjects);
  };
  // 处理历史操作动作;
  const historyRendering = useRef<boolean>(false);
  const handleHistoryRenderingEvent = (e: { value: boolean; history: any }) => {
    historyRendering.current = e.value;
    if (e.value) {
      // 当前历史 image keyprefix;
      const currentHistoryObjectsImages = e.history?.data[e.history?.currentIndex]?.objects.filter(
        (object) => !!object.id && !~object.id.indexOf(WorkspaceID.WorkspaceCavas),
      );

      // 上一次的历史 image keyprefix;
      const lastHistoryObjectsImages = e.history?.data[e.history?.lastIndex]?.objects.filter(
        (object) => !!object.id && !~object.id.indexOf(WorkspaceID.WorkspaceCavas),
      );
      if (!currentHistoryObjectsImages || !lastHistoryObjectsImages) return;

      const currentHistoryObjectsImageKeyprefixs = [
        ...new Set(
          currentHistoryObjectsImages.map((object) => {
            if (object.type === FabricObjectType.Image) return object['key_prefix'];
          }),
        ),
      ];
      const lastHistoryObjectsImageKeyprefixs = [
        ...new Set(
          lastHistoryObjectsImages.map((object) => {
            if (object.type === FabricObjectType.Image) return object['key_prefix'];
          }),
        ),
      ];
      // ;
      if (currentHistoryObjectsImageKeyprefixs.length < lastHistoryObjectsImageKeyprefixs.length) {
        const differenceKeyprefix = lastHistoryObjectsImageKeyprefixs
          .filter((x) => !currentHistoryObjectsImageKeyprefixs.includes(x))
          .concat(currentHistoryObjectsImageKeyprefixs.filter((x) => !lastHistoryObjectsImageKeyprefixs.includes(x)));
        console.log('differenceKeyprefix;', differenceKeyprefix);
        differenceKeyprefix.forEach((key_prefix) => {
          if (!currentHistoryObjectsImageKeyprefixs.includes(key_prefix)) {
            const targetObject = [...currentHistoryObjectsImages, ...lastHistoryObjectsImages].find(
              (object) => object['key_prefix'] === key_prefix,
            );
            !!targetObject && event?.emitEvent(EventNameCons.Event2dObjectRemove, targetObject);
          }
        });
      }
    }
  };
  const handleObjectRemove = (e: any) => {
    handleObject();
    const object: fabric.Object = e.target;
    !historyRendering.current && event?.emitEvent(EventNameCons.Event2dObjectRemove, object);
  };
  // 处理图层层级;
  const handleZIndex = (allObjects: fabric.Object[]) => {
    const allObjectLength = allObjects.length;
    allObjects.forEach((item: any, index: number) => {
      const zIndex = allObjectLength - index;
      item.set({
        [CustomKey.ZIndex]: zIndex,
      });
      item.sendToBack();
    });

    canvasEditor?.workspaceSendToBack();
    canvasEditor?.canvas.renderAll();
  };
  // 处理右键菜单层级变化;
  const handleRightClickZIndexChange = (type: string, object: fabric.Object) => {
    switch (type) {
      // 置顶;
      case 'toTop':
        handleToTop(object);
        break;
      // 置上一层;
      case 'toUp':
        handleToUp(object);
        break;
      // 置下一层;
      case 'toDown':
        handleToDown(object);
        break;
      // 置底;
      case 'toBottom':
        handleToBottom(object);
        break;
    }
  };
  // 处理选中元素;
  const handleSelection = (e: any) => {
    if (isShiftKeydown) return;
    if (!!e.deselected && !e.selected) {
      setSelectedIds([]);
      return;
    } else if (!!e.selected) {
      let selectedObjectsId = e.selected.map((item: any) => item.id);
      setSelectedIds(selectedObjectsId);
    }
  };
  const objectTypeImg = (type: string, layerName: LayerType) => {
    if (type === FabricObjectType.Group) {
      return layerName === LayerType.Group ? down_triangle : vector;
    }
    if (type === FabricObjectType.Image) {
      return image;
    } else if (type === FabricObjectType.Text || type === FabricObjectType.TextI || type === FabricObjectType.TextBox) {
      return text;
    } else {
      return vector;
    }
  };
  // handle workspace inch size;
  const workspaceInchSize = () => {
    if (!projectModel) return;
    const printParam = JSON.parse(projectModel?.canvases[projectModel.canvasesIndex].print_param);
    const MMSize = {
      width: printParam.format_size_w,
      height: printParam.format_size_h,
    };
    const inchSize = {
      width: MMSize.width / 25.4,
      height: MMSize.height / 25.4,
    };
    return inchSize;
  };
  enum ImageResolution {
    High = 'High Resolution',
    Medium = 'Medium Resolution',
    Low = 'Low Resolution',
  }
  const imageResolution = (object: any) => {
    if (object.type === FabricObjectType.Image) {
      const _workspacePXSize = {
        width: projectModel?.canvases[projectModel.canvasesIndex].base_map_width,
        height: projectModel?.canvases[projectModel.canvasesIndex].base_map_height,
      };
      const _workspaceInchSize = workspaceInchSize();
      const imageWidth = object.width;
      const imageHeight = object.height;
      const imageInchWidth = _workspaceInchSize?.width * ((imageWidth * object.scaleX) / _workspacePXSize.width);
      const imageInchHeight = _workspaceInchSize?.height * ((imageHeight * object.scaleY) / _workspacePXSize.height);
      const imageDPi = imageWidth / imageInchWidth;
      // console.log(imageDPi);
      const result =
        imageDPi < 200 ? ImageResolution.Low : imageDPi > 300 ? ImageResolution.High : ImageResolution.Medium;
      return result;
    }
  };
  // click show/hide layers;
  const handleShowLayers = () => {
    if (!allObjects || allObjects.length === 0) return;
    setShowLayers(!showLayers);
    onShowLayer(!showLayers);
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (
      layerUlRef.current &&
      !layerUlRef.current.contains(event.target as Node) &&
      layerRef.current &&
      !layerRef.current.contains(event.target as Node)
    ) {
      setShowLayers(false);
      onShowLayer(false);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  // layer hover;
  const handleLayerHover = (event: any, id: string) => {
    setHoverLayerId(id);
  };
  // #region shift keydown;
  const [isShiftKeydown, setIsShiftKeydown] = useState<boolean>(false);
  const multSelectedObjects = useRef<any[]>([]);
  const handleShiftKeyDown = (e: any) => {
    if (e.key === 'Shift') {
      setIsShiftKeydown(true);
    }
  };
  const handleShiftKeyUp = (e: any) => {
    if (e.key === 'Shift') {
      multSelectedObjects.current = [];
      setIsShiftKeydown(false);
    }
  };
  useEffect(() => {
    // onShowLayer(showLayers);
    document.addEventListener('keydown', handleShiftKeyDown);
    document.addEventListener('keyup', handleShiftKeyUp);
    return () => {
      document.removeEventListener('keydown', handleShiftKeyDown);
      document.removeEventListener('keyup', handleShiftKeyUp);
    };
  });
  // #endregion ;
  // #region css style;
  const ulMaxHeight = 253;
  const liHeight = 30;
  // #endregion ;
  const handleLock = (item: fabric.Object, flag: boolean) => {
    item.set({
      [CustomKey.IsLock]: flag,
      selectable: !flag,
      selection: !flag,
      evented: !flag,
      hasControls: item.textureType ? false : !flag,
      hasBorders: !flag,
      hasRotatingPoint: !flag,
      lockRotation: flag,
      lockScalingFlip: flag,
      lockScalingX: flag,
      lockScalingY: flag,
      lockUniScaling: flag,
      lockMovementX: flag,
      lockMovementY: flag,
    });
    canvasEditor?.canvas.requestRenderAll();
    canvasEditor?.historySave();
    setRenderFlag(!renderFlag);
  };

  return (
    <section className={classes.layer_container}>
      <ul
        ref={layerUlRef}
        className={classes.layer_ul}
        style={
          !!allObjects && allObjects.length > 0 && showLayers ? { maxHeight: `${ulMaxHeight}px` } : { maxHeight: 0 }
        }
      >
        <TreeList data={allObjects} />
      </ul>
      {/* // ; */}
      <div className={classes.layer_trigger} onClick={handleShowLayers}>
        <img src={layer} alt="" />
        <p>{getTranslation(TranslationsKeys.string_layers)}</p>
      </div>
    </section>
  );

  // 树拖拽结构;
  function TreeList(props: any) {
    const { data } = props;
    const [groupFoldFlag, setGroupFoldFlag] = useState(false);
    const layerLiRef = useRef<HTMLLIElement>(null);
    // #region 处理Layer Item 点击交互;
    // select click layer item;
    const handleLayerClick = throttle((item: fabric.Object) => {
      // hidden can not select;
      if (
        !item ||
        // @ts-ignore;
        item[CustomKey.IsLock] ||
        // @ts-ignore;
        !item.visible ||
        // @ts-ignore;
        selectedIds.includes(item.id)
      )
        return;
      // if item is lock, item control border active;
      if (!!item[CustomKey.IsLock]) {
        item.set('hasBorders', true);
        canvasEditor?.canvas.renderAll();
      }

      if (selectItemCloneRef.current) {
        canvasEditor?.canvas.discardActiveObject();
        canvasEditor?.canvas.requestRenderAll();
      }
      handleLayerClickRelease(item);
    }, 500);

    function getCanvasObjLayerNameParams(targetObj: fabric.Object, objects?: any[]): any {
      if (!objects) return null;
      var id = (targetObj as any).id;
      for (let i = 0; i < objects.length; i++) {
        const object = objects[i];
        if ((object as any).id === id) {
          return object[CustomKey.LayerNameCus];
        } else if ((object as any)._objects || (object as any).objects) {
          const foundObject = getCanvasObjLayerNameParams(
            targetObj,
            (object as any)._objects || (object as any).objects,
          );
          if (foundObject) {
            return foundObject;
          }
        }
      }
      return null;
    }

    const handleLayerClickRelease = (selectedObject: fabric.Object) => {
      // 群组内元素;
      if (!!selectedObject.group) {
        const selectedGroup = selectedObject.group;
        const topLevelGroup = findTopLevelGroup(selectedObject);
        if (!topLevelGroup) return;
        handleIsLayerRender(false);

        const options = {
          id: selectedObject.id,
          width: selectedObject.width,
          height: selectedObject.height,
          scaleX: selectedObject.calcTransformMatrix()[0],
          scaleY: selectedObject.calcTransformMatrix()[3],
          left: selectedObject.calcTransformMatrix()[4],
          top: selectedObject.calcTransformMatrix()[5],
          angle: selectedObject[CustomKey.RelativeAngle],
          originX: 'center',
          originY: 'center',
        };

        selectedObject.clone(async (cloned: fabric.Object) => {
          if (cloned.type === FabricObjectType.Image) {
            const ImageMoudel = await import('src/templates/2dEditor/core/plugin/ImagePlugin/Image');
            const imageCloned = await ImageMoudel.Image.fromURL(cloned.src, {
              ...selectedObject.toJSON(EDITOR_JSON_KEY),
              ...options,
            });
            cloned = imageCloned;
          } else if (cloned.type === FabricObjectType.Text) {
            const ArcTextMoudel = await import('src/templates/2dEditor/core/plugin/ArcTextPlugin/ArcText');
            var pathObj =
              selectedObject.path && selectedObject.path.path
                ? new fabric.Path(selectedObject.path.path, selectedObject.path)
                : null;
            const transformTextObject = new ArcTextMoudel.ArcText(selectedObject.text || '', {
              ...selectedObject.toJSON(EDITOR_JSON_KEY),
              ...options,
              path: pathObj,
            });
            cloned = transformTextObject;
          } else if (cloned.type === FabricObjectType.TextBox) {
            //统一创建成ArcText，防止编辑的时候需要重新new一个新的类，会丢失事件监听
            const ArcTextMoudel = await import('src/templates/2dEditor/core/plugin/ArcTextPlugin/ArcText');
            const textboxCloned = new ArcTextMoudel.ArcText(selectedObject.text || '', {
              ...selectedObject.toJSON(EDITOR_JSON_KEY),
              ...options,
              path: null,
            });
            cloned = textboxCloned;
          } else {
            // 使用set方法将所有属性应用到克隆对象上
            cloned.set(selectedObject.toJSON(EDITOR_JSON_KEY));
            cloned.set(options);
          }
          selectedObject.set('opacity', 0);

          cloned.set({
            _parentId: selectedGroup.id,
            _cloneId: selectedObject.id,
          });

          canvasEditor.doDisabled({ value: true });
          canvasEditor.canvas.add(cloned);
          canvasEditor.canvas.setActiveObject(cloned);

          // 取消cloned选择状态;
          // @ts-ignore;
          cloned.on('deselected', (e) => {
            const clonedObject = e.target;

            if (!clonedObject) {
              selectedGroup.removeWithUpdate(selectedObject);
            } else {
              var layerName = getCanvasObjLayerNameParams(clonedObject!, canvasEditor?.canvas.getObjects());
              (clonedObject as any).set({ [CustomKey.LayerNameCus]: layerName });

              const active = canvasEditor.canvas.getActiveObject();
              const id = active ? active.id : '';
              if (!clonedObject.selectable || id.indexOf('ControlCircle') !== -1) {
                return;
              }
              clonedObject.set({
                _parentId: '',
                _cloneId: '',
              });
              selectedGroup?.addWithUpdate(clonedObject);
              const itemIndex = selectedGroup.getObjects().indexOf(selectedObject);
              clonedObject.moveTo(itemIndex);

              selectedGroup.removeWithUpdate(selectedObject);
              clonedObject.off('deselected');
              clonedObject.setCoords();
              // selectedGroup.addWithUpdate(clonedObject);
              // updateCanvasObj(clonedObject, canvasEditor?.canvas.getObjects());
            }

            let padding = 0;
            let width = selectedGroup.width;
            let height = selectedGroup.height;
            selectedGroup.getObjects().forEach((obj) => {
              if (obj.padding) {
                padding = Math.max(obj.padding, padding);
              }
            });
            selectedGroup.set({ width: width + padding * 2, height: height + padding * 2 });
            canvasEditor.doDisabled({ value: false });
            canvasEditor?.canvas.renderAll();
            canvasEditor?.canvas.remove(cloned);
            // 操作群组内子元素结束 开启图层模块的渲染;
            eventBus.emit(LayerStatus.RenderStatus, RenderLayer.ON);
            updateLayerUI();
            canvasEditor.startSaveHistory(true);
            canvasEditor.event?.emitEvent(EventNameCons.EventProjectChangeState, false);
          });
        });
      } else {
        // 个体元素;
        canvasEditor?.canvas.setActiveObject(selectedObject);
      }
      canvasEditor?.canvas.renderAll();
    };
    // find the top group;
    function findTopLevelGroup(object: fabric.Object) {
      // 当前对象的直接群组
      let currentGroup = object.group;
      // 如果当前对象不属于任何群组，返回null
      if (!currentGroup) {
        return null;
      }
      // 向上遍历群组层级，直到找到最顶层的群组
      while (currentGroup.group) {
        currentGroup = currentGroup.group;
      }
      // 返回最顶层的群组
      return currentGroup;
    }
    // #endregion ;
    // #region mouseup and show right click menu;
    const onMouseup = (ev: any, object: fabric.Object) => {
      // right click;
      if (ev.button === 2) {
        handleLayerClick(object);
        event?.emitEvent('showRightclickMenu', ev.clientX, ev.clientY);
      }
    };
    // #endregion ;
    // dbclick layer item for edit layer name;
    const handleLayerDBClick = (item: fabric.Object) => {
      if (!item) return;
      setRenameLayerId(item.id);
    };
    // handle layer item rename;
    const handleLayerRename = (e: any, objectEdit: fabric.Object, isKeyDown: boolean) => {
      layerText.current = DOMPurify.sanitize(e.target.value);

      if (isKeyDown) {
        // objectEdit.set({ [CustomKey.LayerNameCus]: e.target.value });
        const data = _.cloneDeep(allObjects); // 使用 lodash 进行深拷贝
        console.log('======setAllObjects==handleLayerRename', objectEdit.id, data);
        function findObjectById(objects?: any[], id?: string): any {
          if (!objects) return null;
          for (let i = 0; i < objects.length; i++) {
            const object = objects[i];
            console.log('======setAllObjects==object', object.id, id, object);
            if (object.id === id) {
              objects[i].set({ [CustomKey.LayerNameCus]: e.target.value });
              return object;
            }
            if (object._objects || object.objects) {
              const foundObject = findObjectById(object._objects || object.objects, id);
              if (foundObject) {
                return foundObject;
              }
            }
          }
          return null;
        }

        const selctObject = findObjectById(data, (objectEdit as any).id);
        if (selctObject) {
          console.log('======setAllObjects==handleLayerRename22222', data, selctObject);
          setAllObjects(data);
        }

        console.log('======setAllObjects==handleLayerRename update ===', canvasEditor?.canvas.getActiveObjects());
        findObjectById(canvasEditor?.canvas.getObjects(), (objectEdit as any).id);
        canvasEditor?.canvas.requestRenderAll();
        console.log('======setAllObjects==handleLayerRename end ===', canvasEditor?.canvas.getActiveObjects());
        canvasEditor?.historySave();
      }
    };
    // lock/unlock layer item;

    // show/hidden layer item;
    const handleView = (item: fabric.Object, flag: boolean) => {
      item.set({
        visible: flag,
      });
      canvasEditor?.canvas.discardActiveObject().renderAll();
      canvasEditor?.historySave();
      setRenderFlag(!renderFlag);
    };
    // handle group layer fold&unfold;
    const handleGroupFold = (e: any, groupObject: fabric.Group) => {
      e.stopPropagation();
      groupObject.set({
        //@ts-ignore;
        [CustomKey.IsLayerFold]: !groupObject[CustomKey.IsLayerFold],
      });
      setGroupFoldFlag(!groupFoldFlag);
    };
    // #region 拖拽相关;
    const targetIds = {
      dragId: '',
      dragOverId: '',
    };
    const dragStartPoint = {
      x: 0,
      y: 0,
    };
    const onDrag = (ev: any) => {
      targetIds.dragId = ev.target.id;
      if (!dragStartPoint.y) dragStartPoint.y = ev.clientY;
    };
    const onDragEnter = (ev: any) => {
      const nodes = ev.target.parentNode.childNodes;
      const currentY = ev.clientY;
      nodes.forEach((item: any) => {
        targetIds.dragOverId = ev.target.id;
        if (item.nodeName === 'P') return;
        if (!dragStartPoint.y) return;
        if (currentY >= dragStartPoint.y) {
          item.style.borderBottom = '2px dashed #63ce69';
        } else {
          item.style.borderTop = '2px dashed #63ce69';
        }
      });
    };
    const onDragLeave = (ev: any) => {
      const nodes = ev.target.parentNode.childNodes;
      nodes.forEach((item: any) => {
        item.style.border = '';
      });
    };
    const onDrop = (ev: any) => {
      ev.preventDefault();
      let dragObject = allObjects.find((item: any) => item.id === targetIds.dragId);
      let dragOverObject = allObjects.find((item: any) => item.id === targetIds.dragOverId);
      // 拖拽和放置的目标都在最外层;
      if (!!dragObject && !!dragOverObject) {
        const dragIndex = allObjects.findIndex((item: any) => item.id === targetIds.dragId);
        const drawOverIndex = allObjects.findIndex((item: any) => item.id === targetIds.dragOverId);
        const data = [...allObjects];
        const item = data.splice(dragIndex, 1); // 移除
        data.splice(drawOverIndex, 0, item[0]); // 插入
        setAllObjects(data);
        handleZIndex(data);
      } else {
        /** 可能出现的情况:
         * 1. 拖拽目标为group内的item, 放置到最外层;
         * 2. 拖拽目标为最外层, 放置到group内;
         * 3. 拖拽目标与放置目标都在同一个group内;
         * 4. 拖拽目标为group内的item, 放置到group内; (存在多层嵌套的group;)
         */
        // 情况1: 拖拽目标为group内的item, 放置到最外层;
        if (!dragObject && !!dragOverObject) {
          dragObject = findIdObject(allObjects, targetIds.dragId);
          if (!!dragObject) {
            const drawOverIndex = allObjects.findIndex((item: any) => item.id === targetIds.dragOverId);
            canvasEditor?.canvas.add(dragObject);
            dragObject.group.removeWithUpdate(dragObject);
            const data = [...allObjects];
            data.splice(drawOverIndex, 0, dragObject);
            setAllObjects(data);
            handleZIndex(data);
          }
        }
        // 情况2: 拖拽目标为最外层, 放置到group内;
        if (!!dragObject && !dragOverObject) {
          dragOverObject = findIdObject(allObjects, targetIds.dragOverId);
          if (!!dragOverObject) {
            canvasEditor?.canvas.remove(dragObject);
            dragOverObject.group.addWithUpdate(dragObject);
            const dragObjectIndex = dragObject.group._objects.findIndex((item: any) => item.id === targetIds.dragId);
            const dragOverObjectIndex = dragObject.group._objects.findIndex(
              (item: any) => item.id === targetIds.dragOverId,
            );
            const currentY = ev.clientY;
            dragObject.group._objects.splice(dragObjectIndex, 1);
            dragObject.group._objects.splice(
              currentY > dragStartPoint.y ? dragOverObjectIndex + 1 : dragOverObjectIndex,
              0,
              dragObject,
            );
            dragObject.group.setCoords();
            ev.stopPropagation();
          }
        }
        // 情况3 & 情况4;
        if (!dragObject && !dragOverObject) {
          dragObject = findIdObject(allObjects, targetIds.dragId);
          dragOverObject = findIdObject(allObjects, targetIds.dragOverId);
          if (!dragObject || !dragOverObject) return;
          // 情况3: 拖拽目标与放置目标都在同一个group内;
          if (dragObject.group.id === dragOverObject.group.id) {
            ev.stopPropagation();
            const dragObjectIndex = dragObject.group._objects.findIndex((item: any) => item.id === targetIds.dragId);
            const dragOverObjectIndex = dragObject.group._objects.findIndex(
              (item: any) => item.id === targetIds.dragOverId,
            );
            dragObject.group._objects.splice(dragObjectIndex, 1);
            dragObject.group._objects.splice(dragOverObjectIndex, 0, dragObject);
            dragObject.group.setCoords();
            canvasEditor?.canvas.requestRenderAll();
          }
          // 情况4: 拖拽目标为group内的item, 放置到group内; (存在多层嵌套的group)
          else {
            dragObject.group.removeWithUpdate(dragObject);
            dragOverObject.group.addWithUpdate(dragObject);
            const dragObjectIndex = dragObject.group._objects.findIndex((item: any) => item.id === targetIds.dragId);
            const dragOverObjectIndex = dragObject.group._objects.findIndex(
              (item: any) => item.id === targetIds.dragOverId,
            );
            const currentY = ev.clientY;
            dragObject.group._objects.splice(dragObjectIndex, 1);
            dragObject.group._objects.splice(
              currentY > dragStartPoint.y ? dragOverObjectIndex + 1 : dragOverObjectIndex,
              0,
              dragObject,
            );
            dragObject.group.setCoords();
            ev.stopPropagation();
          }
        }
      }
      // init drag start ponit;
      dragStartPoint.x = 0;
      dragStartPoint.y = 0;

      // ;
      console.log('on drop;', canvasEditor?.canvas.getObjects());
      canvasEditor?.canvas.getObjects().forEach((object: fabric.Object) => {
        if (object.type === FabricObjectType.Group && !!object._objects && object._objects.length === 0) {
          console.log('object;', object);
          canvasEditor.canvas.remove(object);
        }
      });
    };
    const onDragOver = (ev: any) => {
      ev.preventDefault();
    };
    // find group inner object;
    const findIdObject = (nestedArray: any[], id: string) => {
      let result: any = null;
      function search(array: any[]) {
        for (const item of array) {
          if (item.id === id) {
            result = item;
            return;
          }
          if (!!item._objects && Array.isArray(item._objects)) {
            search(item._objects);
            if (result) return;
          }
        }
      }
      search(nestedArray);
      return result;
    };
    // #endregion ;
    // #region shift key select multiple layer;
    const handleLayerShiftClick = (item: fabric.Object) => {
      // 如果是群组内元素 block;
      if (!!item.group) return;
      canvasEditor?.canvas.discardActiveObject();
      multSelectedObjects.current.push(item);
      // 单选;
      if (multSelectedObjects.current.length === 1) {
        canvasEditor?.canvas.setActiveObject(item);
        canvasEditor?.canvas.renderAll();
      }
      // 多选;
      else {
        const activeSelection = new fabric.ActiveSelection(multSelectedObjects.current, {
          canvas: canvasEditor?.canvas,
        });
        canvasEditor?.canvas.setActiveObject(activeSelection);
        canvasEditor?.canvas.renderAll();
      }
    };
    // #endregion ;
    const getLeftIcon = (item) => {
      if (item[CustomKey.LayerName] === LayerType.Group) {
        return (
          <img
            src={down_triangle}
            alt=""
            style={{ transform: `rotate(${item[CustomKey.IsLayerFold] && '-90deg'})`, transition: '0.2s' }}
            onClick={(e) => {
              handleGroupFold(e, item);
            }}
          />
        );
      } else if (
        item[CustomKey.LayerName] === LayerType.TextureImage ||
        item[CustomKey.LayerName] === LayerType.ReliefImage
      ) {
        return <img src={textureIcon} />;
      } else {
        return <img src={objectTypeImg(item.type, item[CustomKey.LayerName])} alt="" />;
      }
    };

    return (
      <>
        {!!data &&
          data.map((item: any) => {
            return (
              <li
                ref={layerLiRef}
                id={item.id}
                className={`${item.type === FabricObjectType.Group ? classes.group_div : classes.layer_li} ${
                  item.id !== renameLayerId && classes.draggable
                }`}
                draggable={item.selectable && item.id !== renameLayerId}
                onDrag={(e) => {
                  item.selectable && onDrag(e);
                }}
                onDragEnter={(e) => {
                  item.selectable && onDragEnter(e);
                }}
                onDragOver={(e) => {
                  item.selectable && onDragOver(e);
                }}
                onDragLeave={(e) => {
                  item.selectable && onDragLeave(e);
                }}
                onDrop={(e) => {
                  item.selectable && onDrop(e);
                }}
              >
                <div
                  id={item.id}
                  style={{ height: `${liHeight}px` }}
                  className={`${classes.group_div_inner} ${selectedIds.includes(item.id) && classes.selected_layer}`}
                  onClick={() => {
                    isShiftKeydown ? handleLayerShiftClick(item) : handleLayerClick(item);
                  }}
                  onMouseUp={(e) => onMouseup(e, item)}
                  onMouseOver={(e) => {
                    handleLayerHover(e, item.id);
                  }}
                  onMouseOut={(e) => {
                    handleLayerHover(e, '');
                  }}
                >
                  <span className={classes.li_left}>
                    {getLeftIcon(item)}
                    {item.id === renameLayerId ? (
                      <input
                        // type="text"
                        className={classes.rename_input}
                        defaultValue={layerText.current}
                        onChange={(e) => {
                          if (item.selectable) {
                            handleLayerRename(e, item, false);
                          }
                        }}
                        onBlur={() => {
                          if (item.selectable) {
                            setRenameLayerId('');
                          }
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && item.selectable) {
                            handleLayerRename(e, item, true);
                            setRenameLayerId('');
                          }
                        }}
                        autoFocus
                      />
                    ) : (
                      // 字体模块
                      <span
                        className={classes.layername_span}
                        onDoubleClick={(e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          handleLayerDBClick(item);
                          layerText.current = item[CustomKey.LayerNameCus] || item[CustomKey.LayerName];
                        }}
                      >
                        <p className={classes.layername_p}>
                          {item[CustomKey.LayerNameCus] || item[CustomKey.LayerName] || 'Other Layer'}
                        </p>
                        {item.type === FabricObjectType.Image &&
                          item[CustomKey.ImageResolution] !== ImageResolution.High &&
                          item[CustomKey.ImageResolution] !== ImageResolution.High && (
                            <p
                              className={classes.image_sharpness}
                              style={{
                                color:
                                  item[CustomKey.ImageResolution] === ImageResolution.High
                                    ? 'green'
                                    : item[CustomKey.ImageResolution] === ImageResolution.Medium
                                    ? 'orange'
                                    : 'red',
                              }}
                            >
                              {item[CustomKey.ImageResolution]}
                            </p>
                          )}
                      </span>
                    )}
                  </span>
                  <span className={classes.li_right}>
                    {
                      <>
                        {item[CustomKey.LayerName] === LayerType.TextureImage ||
                        item[CustomKey.LayerName] === LayerType.ReliefImage ? (
                          <span className={classes.textureTab}>2.5D</span>
                        ) : null}

                        {!item.selectable ? (
                          <img
                            src={layer_lock}
                            alt=""
                            style={!!item.group ? { opacity: 0 } : { opacity: 1 }}
                            onClick={() => {
                              !item.group && handleLock(item, false);
                            }}
                          />
                        ) : (
                          <img
                            alt=""
                            src={unlock}
                            style={!!item.group || hoverLayerId !== item.id ? { opacity: 0 } : { opacity: 1 }}
                            onClick={() => {
                              !item.group && handleLock(item, true);
                            }}
                          />
                        )}
                        {item.visible ? (
                          hoverLayerId === item.id && (
                            <img
                              src={eye}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleView(item, false);
                              }}
                            />
                          )
                        ) : (
                          <img
                            alt=""
                            src={close_eye}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleView(item, true);
                            }}
                          />
                        )}
                      </>
                    }
                  </span>
                </div>
                {item.type === FabricObjectType.Group && !item[CustomKey.IsLayerFold] && (
                  <div className={classes.tree_list_div}>
                    <TreeList data={item._objects} />
                  </div>
                )}
              </li>
            );
          })}
      </>
    );
  }
}

export default Layer;
