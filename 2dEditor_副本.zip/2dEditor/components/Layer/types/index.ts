import { BezierControlId, CircleControlId, AngleControlId } from 'src/templates/2dEditor/core/plugin/ArcTextPlugin/types';


export enum DisableLayerId {
  ClonedForMoveId = 'ClonedForMoveId'
}