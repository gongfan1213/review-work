import React from 'react';
import Dialog from '@mui/material/Dialog';
import './index.less'
import { IconButton } from '@mui/material'
import { Close } from '@mui/icons-material'

// 参数说明：open：弹窗打开与否状态，
// onClose：关闭弹窗的回调函数，
// title：弹窗标题，
// children：弹窗内容，
// actions：弹窗底部操作按钮
function SideDialog(props: any) {
  const { open, onClose, title, children, actions } = props

  return (
    <Dialog
      open={open}
      onClose={onClose}
      className='side-dialog'
    >
      <div className='select-dialog-header'>
        {title}
        <IconButton onClick={onClose}>
          <Close />
        </IconButton>
      </div>
      <div className='select-dialog-body'>{children}</div>
      <div className='select-dialog-footer'>
        {actions}
      </div>
    </Dialog>
  );
}


export default SideDialog;