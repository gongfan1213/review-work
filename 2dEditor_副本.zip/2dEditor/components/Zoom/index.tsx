/**
 * Zoom;
 */
import React, { useState, useEffect, useRef } from 'react';
import * as classes from './index.module.scss';
import zoom_in from 'src/assets/svg/zoom_in.svg';
import zoom_out from 'src/assets/svg/zoom_out.svg';
import { useCanvasEditor, useFabric, useProjectData } from 'src/templates/2dEditor/hooks/context';
import gripper from 'src/assets/svg/gripper.svg';
import { useEvent } from 'src/templates/2dEditor/hooks/context';
import { EventNameCons, CanvasCategory } from 'src/templates/2dEditor/cons/2dEditorCons';
import switch3d from 'src/assets/img/2d1.png';
import { useDispatch } from 'react-redux';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import { toast } from 'src/templates/2dEditor/components/Toast';

export default function Zoom(props: any) {
  const { onShowZoom, isShowLayer, setShowTextureView } = props;
  const canvasEditor = useCanvasEditor();
  const fabric = useFabric();
  const [zoom, setZoom] = useState(1);
  const [showZoomSelect, setShowZoomSelect] = useState(false);
  const projectModel: any = useProjectData();
  const projectModelRef = useRef(projectModel);
  const { getTranslation } = useCustomTranslation();
  const dispatch = useDispatch();

  const event = useEvent();

  const zoomOptions = [
    { name: '10%', value: 0.1 },
    { name: '25%', value: 0.25 },
    { name: '50%', value: 0.5 },
    { name: '75%', value: 0.75 },
    { name: '100%', value: 1 },
    { name: '125%', value: 1.25 },
    { name: '150%', value: 1.5 },
    { name: '175%', value: 1.75 },
    { name: '200%', value: 2 },
    { name: '250%', value: 2.5 },
    { name: '300%', value: 3 },
    { name: '350%', value: 3.5 },
    { name: '400%', value: 4 },
    { name: '500%', value: 5 },
  ];
  enum ZoomType {
    Shrink,
    Enlarge,
  }
  //;
  const handleZoom = (type: ZoomType) => {
    type === ZoomType.Shrink && canvasEditor?.small();
    type === ZoomType.Enlarge && canvasEditor?.big();
    setZoom(canvasEditor!.canvas.getZoom());
  };
  // ;
  const handleZoomSelectClick = () => {
    setShowZoomSelect(!showZoomSelect);
    onShowZoom(!showZoomSelect);
  };
  // ;
  const handleZoomOptionClick = (value: number) => {
    const workspaceCenterPoint = canvasEditor?.getWorkspaces()[0].getCenterPoint();
    const center = canvasEditor?.canvas.getCenter();
    // @ts-ignore
    canvasEditor?.zoomToPoint(new fabric.Point(center.left, center.top), value);
    canvasEditor?.setViewportTransform([value, 0, 0, value, workspaceCenterPoint.x, workspaceCenterPoint.y]);
    setZoom(value);
    setShowZoomSelect(false);
  };
  const handleMouseWheel = () => {
    if (!canvasEditor) return;
    setZoom(canvasEditor.canvas.getZoom());
  };
  const handleMouseDown = () => {
    setShowZoomSelect(false);
  };

  const handleStartDring = () => {
    setDragFlag(true);
  };
  const handleEndDring = () => {
    setDragFlag(false);
  };

  useEffect(() => {
    if (!canvasEditor) return;
    setZoom(canvasEditor.canvas.getZoom());

    canvasEditor.canvas.on('mouse:wheel', handleMouseWheel);
    canvasEditor.canvas.on('mouse:down', handleMouseDown);

    canvasEditor.on('startDring', handleStartDring);
    canvasEditor.on('endDring', handleEndDring);

    event?.on(EventNameCons.EventHideZoomSelect, handleMouseDown);

    return () => {
      canvasEditor.canvas.off('mouse:wheel', handleMouseWheel);
      canvasEditor.canvas.off('mouse:down', handleMouseDown);
      canvasEditor.off('startDring', handleStartDring);
      canvasEditor.off('endDring', handleEndDring);

      event?.off(EventNameCons.EventHideZoomSelect, handleMouseDown);
    };
  }, [canvasEditor]);

  const [dragFlag, setDragFlag] = useState<boolean>(false);
  const handleDragClick = () => {
    const currentFlag = !dragFlag;
    if (currentFlag) {
      canvasEditor?.startDring();
    } else {
      canvasEditor?.endDring();
    }
    setDragFlag(currentFlag);
  };

  return (
    <div className={classes.zoom_div}>
      <div className={classes.zoon_box}>
        <span onClick={() => handleZoom(ZoomType.Shrink)}>
          <img src={zoom_out} />
        </span>
        <p className={classes.zoom_p} onClick={handleZoomSelectClick}>
          {(zoom * 100).toFixed(0)}%
        </p>
        <span onClick={() => handleZoom(ZoomType.Enlarge)}>
          <img src={zoom_in} />
        </span>
        <span
          style={{ display: 'inline-block', margin: '0 16px', width: '1px', height: '12px', background: '#ccc' }}
        ></span>
        <img
          className={classes.zoom_active}
          style={{ backgroundColor: dragFlag ? '#e9e9e9' : undefined }}
          src={gripper}
          onClick={handleDragClick}
        />
        {/*  */}
        <ul
          className={classes.zoom_select_ul}
          style={{
            height: showZoomSelect ? '406px' : 0,
          }}
        >
          {zoomOptions.map((item, index) => {
            return (
              <li className={classes.zoom_select_li} key={index} onClick={() => handleZoomOptionClick(item.value)}>
                {item.name}
              </li>
            );
          })}
        </ul>
      </div>

      <div className={classes.switch3D}>
        <img
          src={switch3d}
          onClick={() => {
            if (canvasEditor?.getLoadingElements().length === 0) {
              setShowTextureView(true);
            } else {
              toast.current?.show();
              toast.current?.type('warning');
              toast.current?.tips(getTranslation(TranslationsKeys.VIEW3D_LOAD));
            }
          }}
        />
      </div>
    </div>
  );
}
