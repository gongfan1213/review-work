/**
 * right click menu;
 */
import { useCanvasEditor, useEvent, useProjectData } from '../../hooks/context';
import React, { useState, useRef, useEffect } from 'react';
import * as classes from './index.module.scss';
import overlapped_rect from 'src/assets/svg/overlapped_rect.svg';
import command from 'src/assets/svg/command.svg';
import up_arrow from 'src/assets/svg/up_arrow.svg';
import right_arrow from 'src/assets/svg/right_arrow.svg';
import flip_horizontal from 'src/assets/svg/flip_horizontal.svg';
import flip_vertical from 'src/assets/svg/flip_vertical.svg';
import layer from 'src/assets/svg/layer.svg';
import align_left from 'src/assets/svg/align_left.svg';
import align_center from 'src/assets/svg/align_center.svg';
import align_right from 'src/assets/svg/align_right.svg';
import align_top from 'src/assets/svg/align_top.svg';
import align_middle from 'src/assets/svg/align_middle.svg';
import align_bottom from 'src/assets/svg/align_bottom.svg';
import layer_to_top from 'src/assets/svg/layer_to_top.svg';
import layer_to_bottom from 'src/assets/svg/layer_to_bottom.svg';
import layer_to_up from 'src/assets/svg/layer_to_up.svg';
import layer_to_down from 'src/assets/svg/layer_to_down.svg';
import lock from 'src/assets/svg/layer_lock.svg';
import delete_icon from 'src/assets/svg/delete.svg';
import group from 'src/assets/svg/group.svg';
import canvas_icon from 'src/assets/img/canvas.png';
import { CustomKey, FabricObjectType, WorkspaceID } from '../../cons/2dEditorCons';
import { BaseMapChangeManager } from 'src/templates/2dEditor/components/BaseMapChange/logic/BaseMapChangeManager';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

function RightclickMenu() {
  const event = useEvent();
  const canvasEditor = useCanvasEditor();
  const projectModel = useProjectData();
  const activeObject = canvasEditor?.canvas?.getActiveObject();
  const { getTranslation } = useCustomTranslation();
  enum MenuOptionId {
    Copy,
    Paste,
    Duplicate,
    RemoveEffect,
    Delete,
    FlipHorizontal,
    FlipVertical,
    // Layer child⬇;
    Layer,
    ToTop,
    ToUp,
    ToDown,
    ToBottom,
    // Layer child⬆;
    // Align child⬇;
    Align,
    Left,
    Center,
    Right,
    Top,
    Middle,
    Bottom,
    // Align child⬆;
    Group,
    UnGroup,
    Lock,
    Unlock,
    ConvertToCanvas,
  }

  let isWindows: boolean = navigator.userAgent.toLowerCase().includes('win');

  const generateMenuOptions = (): any => {
    return {
      [MenuOptionId.Copy]: {
        id: MenuOptionId.Copy,
        label: getTranslation(TranslationsKeys.string_copy),
        headIcon: <img className={classes.headicon_img} src={overlapped_rect} />,
        labelTips: (
          <span className={classes.labeltips_span}>
            {isWindows ? 'Ctrl' : <img src={command} />}
            <span className={classes.add_icon}>+</span>C
          </span>
        ),
        disabled: false,
      },
      [MenuOptionId.Paste]: {
        id: MenuOptionId.Paste,
        label: getTranslation(TranslationsKeys.string_paste),
        headIcon: <img className={classes.headicon_img} src={overlapped_rect} />,
        labelTips: (
          <span className={classes.labeltips_span}>
            {isWindows ? 'Ctrl' : <img src={command} />}
            <span className={classes.add_icon}>+</span>V
          </span>
        ),
        disabled: false,
      },
      [MenuOptionId.Duplicate]: {
        id: MenuOptionId.Duplicate,
        label: getTranslation(TranslationsKeys.string_duplicate),
        headIcon: <img className={classes.headicon_img} src={overlapped_rect} />,
        labelTips: (
          <span className={classes.labeltips_span}>
            {isWindows ? 'Ctrl' : <img src={command} />}
            <span className={classes.add_icon}>+</span>
            <img src={up_arrow} />
            <span className={classes.add_icon}>+</span>V
          </span>
        ),
        disabled: false,
      },
      [MenuOptionId.RemoveEffect]: {
        id: MenuOptionId.RemoveEffect,
        label: getTranslation(TranslationsKeys.string_remove_effect),
        headIcon: <img className={classes.headicon_img} src={delete_icon} />,
        disabled: false,
      },
      [MenuOptionId.Delete]: {
        id: MenuOptionId.Delete,
        label: getTranslation(TranslationsKeys.string_delete),
        headIcon: <img className={classes.headicon_img} src={delete_icon} />,
        labelTips: <span className={classes.labeltips_span}>{getTranslation(TranslationsKeys.string_backspace)}</span>,
        borderBottom: true,
        disabled: false,
      },
      [MenuOptionId.FlipHorizontal]: {
        id: MenuOptionId.FlipHorizontal,
        label: getTranslation(TranslationsKeys.string_flip_horizontal),
        headIcon: <img className={classes.headicon_img} src={flip_horizontal} />,
        disabled: false,
      },
      [MenuOptionId.FlipVertical]: {
        id: MenuOptionId.FlipVertical,
        label: getTranslation(TranslationsKeys.string_flip_vertical),
        headIcon: <img className={classes.headicon_img} src={flip_vertical} />,
        disabled: false,
      },
      [MenuOptionId.Layer]: {
        id: MenuOptionId.Layer,
        label: getTranslation(TranslationsKeys.string_layer),
        headIcon: <img className={classes.headicon_img} src={layer} />,
        labelTips: (
          <span className={classes.labeltips_span}>
            <img src={right_arrow} />
          </span>
        ),
        disabled: false,
        showChild: false,
        showStyle: { top: 0, left: 0 },
        childs: {
          [MenuOptionId.ToTop]: {
            id: MenuOptionId.ToTop,
            label: getTranslation(TranslationsKeys.string_to_top),
            headIcon: <img className={classes.headicon_img} src={layer_to_top} />,
          },
          [MenuOptionId.ToBottom]: {
            id: MenuOptionId.ToBottom,
            label: getTranslation(TranslationsKeys.string_to_bottom),
            headIcon: <img className={classes.headicon_img} src={layer_to_bottom} />,
          },
          [MenuOptionId.ToUp]: {
            id: MenuOptionId.ToUp,
            label: getTranslation(TranslationsKeys.string_to_up),
            headIcon: <img className={classes.headicon_img} src={layer_to_up} />,
          },
          [MenuOptionId.ToDown]: {
            id: MenuOptionId.ToDown,
            label: getTranslation(TranslationsKeys.string_to_down),
            headIcon: <img className={classes.headicon_img} src={layer_to_down} />,
          },
        },
      },
      [MenuOptionId.Align]: {
        id: MenuOptionId.Align,
        label: getTranslation(TranslationsKeys.string_align),
        headIcon: <img className={classes.headicon_img} src={align_left} />,
        labelTips: (
          <span className={classes.labeltips_span}>
            <img src={right_arrow} />
          </span>
        ),
        disabled: false,
        showChild: false,
        showStyle: { top: 0, left: 0 },
        childs: {
          [MenuOptionId.Left]: {
            id: MenuOptionId.Left,
            label: getTranslation(TranslationsKeys.string_left),
            headIcon: <img className={classes.headicon_img} src={align_left} />,
          },
          [MenuOptionId.Center]: {
            id: MenuOptionId.Center,
            label: getTranslation(TranslationsKeys.string_center),
            headIcon: <img className={classes.headicon_img} src={align_center} />,
          },
          [MenuOptionId.Right]: {
            id: MenuOptionId.Right,
            label: getTranslation(TranslationsKeys.string_right),
            headIcon: <img className={classes.headicon_img} src={align_right} />,
          },
          [MenuOptionId.Top]: {
            id: MenuOptionId.Top,
            label: getTranslation(TranslationsKeys.string_top),
            headIcon: <img className={classes.headicon_img} src={align_top} />,
          },
          [MenuOptionId.Middle]: {
            id: MenuOptionId.Middle,
            label: getTranslation(TranslationsKeys.string_middle),
            headIcon: <img className={classes.headicon_img} src={align_middle} />,
          },
          [MenuOptionId.Bottom]: {
            id: MenuOptionId.Bottom,
            label: getTranslation(TranslationsKeys.string_bottom),
            headIcon: <img className={classes.headicon_img} src={align_bottom} />,
          },
        },
      },
      [MenuOptionId.Group]: {
        id: MenuOptionId.Group,
        label: getTranslation(TranslationsKeys.string_group),
        headIcon: <img className={classes.headicon_img} src={group} />,
        labelTips: (
          <span className={classes.labeltips_span}>
            {isWindows ? getTranslation(TranslationsKeys.string_ctrl) : <img src={command} />} +{' '}
            {getTranslation(TranslationsKeys.string_g)}
          </span>
        ),
        hidden: false,
        disabled: false,
        borderBottom: true,
      },
      [MenuOptionId.UnGroup]: {
        id: MenuOptionId.UnGroup,
        label: getTranslation(TranslationsKeys.string_ungroup),
        headIcon: <img className={classes.headicon_img} src={group} />,
        labelTips: (
          <span className={classes.labeltips_span}>
            {isWindows ? getTranslation(TranslationsKeys.string_ctrl) : <img src={command} />} +{' '}
            {getTranslation(TranslationsKeys.string_shift)} + {getTranslation(TranslationsKeys.string_g)}
          </span>
        ),
        hidden: true,
        disabled: false,
        borderBottom: true,
      },
      [MenuOptionId.Lock]: {
        id: MenuOptionId.Lock,
        label: getTranslation(TranslationsKeys.string_lock),
        headIcon: <img className={classes.headicon_img} src={lock} />,
        hidden: true,
        disabled: false,
      },
      [MenuOptionId.Unlock]: {
        id: MenuOptionId.Unlock,
        label: getTranslation(TranslationsKeys.string_unlock),
        headIcon: <img className={classes.headicon_img} src={overlapped_rect} />,
        hidden: false,
        disabled: false,
      },
      [MenuOptionId.ConvertToCanvas]: {
        id: MenuOptionId.ConvertToCanvas,
        label: getTranslation(TranslationsKeys.string_convert_to_canvas),
        headIcon: <img className={classes.headicon_img} src={canvas_icon} />,
        hidden: false,
        disabled: false,
      },
    };
  };
  const [menuOptions, setMenuOptions] = useState(generateMenuOptions());

  const menuRef = useRef(null);
  const [menuStyle, setMenuStyle] = useState();
  let menuWidth = 0;
  let menuHeight = 0;

  const init = () => {
    // 屏蔽dom默认右键事件;
    menuRef.current!.oncontextmenu = (e: any) => e.preventDefault();
    if (!!canvasEditor?.canvas) {
      canvasEditor?.canvas.on('mouse:down', handleMouseUp);
    } else {
      hideMenu();
    }
  };
  useEffect(() => {
    if (menuRef.current) {
      menuWidth = menuRef.current.offsetWidth;
      menuHeight = menuRef.current.offsetHeight;
      menuRef.current.addEventListener('click', hideMenu);
      event?.on('showRightclickMenu', showMenu);
      init();
    }
    // document.addEventListener('mousedown', handleClickOutside);
    return () => {
      canvasEditor?.canvas.off('mouse:down', handleMouseUp);
      menuRef?.current?.removeEventListener('click', hideMenu);
      event?.off('showRightclickMenu', showMenu);
      // document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [canvasEditor]);
  // const handleClickOutside = (event: MouseEvent) => {
  //   if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
  //     hideMenu();
  //   }
  // };
  useEffect(() => {
    const tmpMenuOptions = { ...menuOptions };
    // able & disable;
    tmpMenuOptions[MenuOptionId.Copy].disabled = !activeObject;
    tmpMenuOptions[MenuOptionId.Duplicate].disabled = !activeObject;
    tmpMenuOptions[MenuOptionId.Delete].disabled = !activeObject;
    tmpMenuOptions[MenuOptionId.FlipHorizontal].disabled = !activeObject;
    tmpMenuOptions[MenuOptionId.FlipVertical].disabled = !activeObject;
    tmpMenuOptions[MenuOptionId.Layer].disabled = !activeObject;
    tmpMenuOptions[MenuOptionId.Align].disabled = !activeObject;
    tmpMenuOptions[MenuOptionId.Lock].disabled = !activeObject;
    tmpMenuOptions[MenuOptionId.Unlock].disabled = !activeObject;
    tmpMenuOptions[MenuOptionId.Group].disabled = !activeObject;
    tmpMenuOptions[MenuOptionId.UnGroup].disabled = !activeObject;

    // show & hide;
    if (!!activeObject) {
      // group;
      if (activeObject.type === FabricObjectType.Group && isGroupCanUngroup(activeObject as fabric.Group)) {
        tmpMenuOptions[MenuOptionId.UnGroup].hidden = false;
        tmpMenuOptions[MenuOptionId.Group].hidden = true;
        tmpMenuOptions[MenuOptionId.ConvertToCanvas].hidden = true;
      } else if (activeObject.type === FabricObjectType.ActiveSelection) {
        tmpMenuOptions[MenuOptionId.UnGroup].hidden = true;
        tmpMenuOptions[MenuOptionId.Group].hidden = false;
      } else {
        tmpMenuOptions[MenuOptionId.ConvertToCanvas].hidden = false;
      }
      // @ts-ignore;
      if (activeObject._isTextureGroup) {
        tmpMenuOptions[MenuOptionId.UnGroup].hidden = true;
        tmpMenuOptions[MenuOptionId.Group].hidden = true;
      }

      // @ts-ignore;
      if (activeObject._isTextureGroup || activeObject.textureType) {
        tmpMenuOptions[MenuOptionId.RemoveEffect].hidden = false;
      } else {
        tmpMenuOptions[MenuOptionId.RemoveEffect].hidden = true;
      }

      // lock;
      // @ts-ignore;
      if (activeObject[CustomKey.IsLock]) {
        tmpMenuOptions[MenuOptionId.Lock].hidden = true;
        tmpMenuOptions[MenuOptionId.Unlock].hidden = false;
        tmpMenuOptions[MenuOptionId.Delete].disabled = true;
      } else {
        tmpMenuOptions[MenuOptionId.Lock].hidden = false;
        tmpMenuOptions[MenuOptionId.Unlock].hidden = true;
        tmpMenuOptions[MenuOptionId.Delete].disabled = false;
      }
    }

    setMenuOptions(tmpMenuOptions);
  }, [activeObject, menuStyle]);
  // check the group can be ungroup;
  const isGroupCanUngroup = (group: fabric.Group) => {
    const groupObjects = group.getObjects();
    const hasGroup = groupObjects.some((item) => item.type === FabricObjectType.Group);
    const hasImage = groupObjects.some((item) => item.type === FabricObjectType.Image);
    const hasText = groupObjects.some(
      (item) =>
        item.type === FabricObjectType.TextI ||
        item.type === FabricObjectType.TextBox ||
        item.type === FabricObjectType.Text,
    );
    return hasGroup || hasImage || hasText;
  };

  const menuShowPosition = useRef({ x: -999, y: -999 });
  const leftbarWidth = 470;
  const topbarHeight = 50;
  const showMenu = (x: number, y: number) => {
    const active = canvasEditor?.canvas.getActiveObject();

    if (active && active[CustomKey.DisableRightClick]) return;
    // if no selection;
    else if (!active) {
      const allObject = canvasEditor?.canvas
        .getObjects()
        .filter((item) => !!item.id && !~item.id.indexOf(WorkspaceID.WorkspaceCavas));
      if (allObject.length === 0) return;
      let nearestObject: any;
      allObject?.forEach((object: fabric.Object) => {
        if (!nearestObject) {
          nearestObject = object;
        } else {
          if (
            calculateDistance({ left: x - leftbarWidth, top: y - topbarHeight }, object) <
            calculateDistance({ left: x - leftbarWidth, top: y - topbarHeight }, nearestObject)
          ) {
            nearestObject = object;
          }
        }
      });

      if (!!nearestObject) canvasEditor?.canvas.setActiveObject(nearestObject);
    }

    //;
    if (menuHeight + y > document.documentElement.clientHeight) {
      y -= menuHeight + y - document.documentElement.clientHeight;
    }
    if (menuWidth + x > document.documentElement.clientWidth) {
      x -= menuWidth + x - document.documentElement.clientWidth;
    }
    menuShowPosition.current = { x, y };
    const showMenuStyle = {
      visibility: 'visible',
      left: `${x}px`,
      top: `${y}px`,
      zIndex: 999,
    };

    setMenuStyle(showMenuStyle);
  };
  // // 计算欧几里得距离的函数;
  // @ts-ignore;
  function calculateDistance(point1, point2) {
    const dx = point1.left - point2.left;
    const dy = point1.top - point2.top;
    return Math.sqrt(dx * dx + dy * dy);
  }
  const hideMenu = () => {
    const hideMenuStyle = {
      visibility: 'hidden',
      left: -999,
      top: -999,
      zIndex: -999,
    };
    menuShowPosition.current = { x: -999, y: -999 };
    setMenuStyle(hideMenuStyle);
  };

  const handleMouseUp = (opt: any) => {
    try {
      if (opt.button === 3) {
        // 相对浏览器位置;
        let clientX = opt.e.clientX;
        let clientY = opt.e.clientY;
        showMenu(clientX, clientY);
      } else {
        hideMenu();
      }
    } catch (error) {
      console.log(error);
    }
  };
  // handle menu child show and hidden;
  const layerChildDocSize = {
    width: 175,
    height: 152,
  };
  const alignChildDocSize = {
    width: 175,
    height: 218,
  };
  // left value 1: 232px; 2: -177px;
  const handleChildShow = (id: string, flag: boolean) => {
    const tmpMenuOptions = { ...menuOptions };
    const browserWidth = document.documentElement.clientWidth;
    const browserHeight = document.documentElement.clientHeight;
    const menuWidth = menuRef.current.offsetWidth;
    const menuHeight = menuRef.current.offsetHeight;
    if (id == MenuOptionId.Layer) {
      const layerChildTop = menuShowPosition.current.y + 208;
      // ;
      if (menuShowPosition.current.x + menuWidth + layerChildDocSize.width > browserWidth) {
        tmpMenuOptions[id].showStyle = {
          top: 0,
          left: -175,
        };
      } else {
        tmpMenuOptions[id].showStyle = {
          top: 0,
          left: 247,
        };
      }
      if (layerChildTop + layerChildDocSize.height > browserHeight) {
        tmpMenuOptions[id].showStyle.top = browserHeight - (layerChildTop + layerChildDocSize.height);
      }
    } else if (id == MenuOptionId.Align) {
      const alignChildTop = menuShowPosition.current.y + 242;
      // ;
      if (menuShowPosition.current.x + menuWidth + alignChildDocSize.width > browserWidth) {
        tmpMenuOptions[id].showStyle = {
          top: 0,
          left: -175,
        };
      } else {
        tmpMenuOptions[id].showStyle = {
          top: 0,
          left: 247,
        };
      }
      if (alignChildTop + alignChildDocSize.height > browserHeight) {
        tmpMenuOptions[id].showStyle.top = browserHeight - (alignChildTop + alignChildDocSize.height);
      }
    }
    tmpMenuOptions[id].showChild = flag;
    setMenuOptions(tmpMenuOptions);
  };

  const hanlderRemoveEffect = () => {
    canvasEditor?.stopSaveHistory();
    const active = canvasEditor?.canvas.getActiveObject() as any;
    if (active.isCanvasTexture) {
      active.hanlderRemoveEffect();
    } else if (active._isTextureGroup) {
      const originalObject = active._objects[0];
      const textureObject = active._objects[1];
      originalObject.set({
        opacity: 1,
      });
      canvasEditor?.ungroup(true);
      canvasEditor?.canvas.remove(textureObject);
    }
    canvasEditor?.startSaveHistory(true);
    canvasEditor?.canvas.renderAll();
  };

  // handle menu click;
  const handleMenuClick = (id: MenuOptionId) => {
    const active = canvasEditor?.canvas.getActiveObject();
    switch (id) {
      case MenuOptionId.Copy:
        canvasEditor?.copy();
        break;
      case MenuOptionId.Paste:
        canvasEditor?.paste();
        break;
      case MenuOptionId.Duplicate:
        canvasEditor?.duplicate();
        break;
      case MenuOptionId.Delete:
        canvasEditor?.delete();
        break;
      case MenuOptionId.FlipHorizontal:
        canvasEditor?.flipHorizontal();
        break;
      case MenuOptionId.FlipVertical:
        canvasEditor?.flipVertical();
        break;
      case MenuOptionId.ToTop:
        canvasEditor?.toTop();
        event?.emit('rightMenuClickZIndex', 'toTop', activeObject);
        break;
      case MenuOptionId.ToBottom:
        canvasEditor?.toBottom();
        event?.emit('rightMenuClickZIndex', 'toBottom', activeObject);
        break;
      case MenuOptionId.ToUp:
        canvasEditor?.toUp();
        event?.emit('rightMenuClickZIndex', 'toUp', activeObject);
        break;
      case MenuOptionId.ToDown:
        canvasEditor?.toDown();
        event?.emit('rightMenuClickZIndex', 'toDown', activeObject);
        break;
      case MenuOptionId.Left:
        canvasEditor?.alignLeft();
        break;
      case MenuOptionId.Center:
        canvasEditor?.alignCenter();
        break;
      case MenuOptionId.Right:
        canvasEditor?.alignRight();
        break;
      case MenuOptionId.Top:
        canvasEditor?.alignTop();
        break;
      case MenuOptionId.Middle:
        canvasEditor?.alignMiddle();
        break;
      case MenuOptionId.Bottom:
        canvasEditor?.alignBottom();
        break;
      case MenuOptionId.Group:
        canvasEditor?.group();
        break;
      case MenuOptionId.UnGroup:
        canvasEditor?.ungroup();
        break;
      case MenuOptionId.Lock:
        canvasEditor?.lock();
        event?.emit('rightMenuClickLock', active, true);
        break;
      case MenuOptionId.Unlock:
        canvasEditor?.unlock();
        event?.emit('rightMenuClickLock', active, false);
        break;
      case MenuOptionId.ConvertToCanvas:
        const canvas = canvasEditor?.canvas;
        BaseMapChangeManager.getInstance().selectImgToCanvas(active, canvas, projectModel);
        break;
      case MenuOptionId.RemoveEffect:
        hanlderRemoveEffect();
        break;
    }
  };
  return (
    <div className={classes.menu_div} ref={menuRef} style={menuStyle}>
      <ul>
        {Object.keys(menuOptions).map(
          (key) =>
            !menuOptions[key].hidden && (
              <li
                key={menuOptions[key].id}
                style={{
                  ...(menuOptions[key].borderBottom ? { borderBottom: '1px solid #f5f5f5' } : {}),
                  ...(menuOptions[key].disabled ? { opacity: 0.5, cursor: 'not-allowed' } : {}),
                }}
                onMouseEnter={() => {
                  !!menuOptions[key].childs && handleChildShow(key, true);
                }}
                onMouseLeave={() => {
                  !!menuOptions[key].childs && handleChildShow(key, false);
                }}
                onClick={() => {
                  handleMenuClick(menuOptions[key].id);
                }}
              >
                <div className={classes.lefttip_div}>
                  {menuOptions[key].headIcon}
                  {menuOptions[key].label}
                </div>
                {menuOptions[key].labelTips}
                {!!menuOptions[key].childs && !menuOptions[key].disabled && menuOptions[key].showChild && (
                  <ul
                    className={classes.child_ul}
                    style={{
                      left: `${menuOptions[key].showStyle.left}px`,
                      top: `${menuOptions[key].showStyle.top}px`,
                    }}
                    onMouseEnter={() => handleChildShow(key, true)}
                    onMouseLeave={() => handleChildShow(key, false)}
                  >
                    {Object.keys(menuOptions[key].childs).map((childKey) => (
                      <li
                        key={menuOptions[key].childs[childKey].id}
                        onClick={() => {
                          handleMenuClick(menuOptions[key].childs[childKey].id);
                        }}
                      >
                        <div className={classes.lefttip_div}>
                          {menuOptions[key].childs[childKey].headIcon}
                          {menuOptions[key].childs[childKey].label}
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ),
        )}
      </ul>
    </div>
  );
}

export default RightclickMenu;
