import React from "react"
import Popover from '@mui/material/Popover';
import './index.scss';
import popover_img1 from '../../../../images/2dEditor/Apps_icon/popover_img1.png'
import popover_img2 from '../../../../images/2dEditor/Apps_icon/popover_img2.png'
import popover_img3 from '../../../../images/2dEditor/Apps_icon/popover_img3.png'

export default function TipsPopover(props: any) {
  const { data, open, anchorEl, onClose, onSelect } = props

  const PopoverImage = [{
    image: popover_img1
  }, {
    image: popover_img2
  }, {
    image: popover_img3
  }]

  return (
    <Popover
      open={open}
      anchorEl={anchorEl}
      onClose={onClose}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'left',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'left',
      }}
    >
      <div className="Pet_Popover_box">
        <div className="Pet_Popover_title">
          What is a good photo？
        </div>
        <div className="Pet_Popover_border"></div>
        <div className="Pet_Popover_img_box">
          {PopoverImage?.map((_: any) => {
            return (
              <img src={_?.image} className="Pet_Popover_img" />
            )
          })}
        </div>
        <div className="Pet_Popover_text">
          If the photo(s) you send us isn't quite right,don't worry - weIlli
          reach out to you. Just keep in mind that if we need to request
          another photo, it may take a bit longer to complete your orde٢٢.
          We want to make sure your furry friend looks their absolutFr6
          best in the final illustration, so thank you for your patience!
        </div>
      </div>
    </Popover>
  )
}