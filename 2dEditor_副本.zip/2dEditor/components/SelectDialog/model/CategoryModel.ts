export type CategoryModel = {
  bleedingLine?: any;
  orientation: string;
  isEditCanvas: boolean;
  cupTopDiameter?: number;
  cupBottomDiameter?: number;
  cupHeight?: number;
  handleHeight?: number;
  canvasShape: string;
  defaultUnit: string;
  isAnkerMake: any;
  baseMaterialX: any;
  baseMaterialY: any;
  dec: string;
  id: any;
  attributes: any;
  categorySubImg: any;
  categoryType: any;
  isStandardProduct: boolean;
  title: string;
  categoryImg: any;
  options: CategorySubModel[];    // 标品有options
  scenes: CategoryScenesModel[]; //非标品有scenes
  baseMapWidth: number;          //非标品底图width
  baseMapHeight: number;          //非标品底图height
  materials: string[];      //材质图片
}

export type CategorySubModel = {
  title: string;
  categorySubImg: any;
  scenes: CategoryScenesModel[];
  baseMapWidth: number;
  baseMapHeight: number;
  modelUrl: string;
}

export type CategoryScenesModel = {
  scenesImg: string[];     //场景图
  scenesImgSelect: number;     //场景图
  width: number;
  height: number;
  positionX?: number;
  positionY?: number;
  curvature: number; // 曲度
  angle?: number;
  skewData?: string;
}

export type CategoryScenesSkewData = {
  rectPerspective: number[];     //场景图
}

export type CategoryMaterialsModel = {
  productColorName: string;
  productColorID: number;
  productColorTitle?: string;

  // materialsImg?: string;
  // width?: number;
  // height?: number;
  // positionX?: number;
  // positionY?: number;
  // curvature?: number; // 曲度
  // angle?: number;
}

export type CyRetData = {
  cyCutLeft: number;
  cyCutTop: number;
  cyCutWidth: number;
  cyCutHeight: number;
  srcPoints: number[];
  amplitude: number;
  length: number;
}

