
export type ProjectInfo = {
  parents_works_id?: string;
  root_works_id?: string;
  project_name: string;
  project_desc?: string;
  category: number;          // 项目类型
  sub_category: number;      // 项目子类型
  is_standard_product: number;   //是否是标品
}

export type CanvasesInfo = {
  canvas_name: string;
  category: number;          // 项目类型
  sub_category: number;      // 项目子类型
  is_standard_product: number;   //是否是标品
  scenes: string;  //场景信息
  materials?: string;          //材料
  base_map: string;              //底图
  base_map_width: number;
  base_map_height: number;
  print_param: string;          //打印参数信息
  model_link: string;
  extra?: string;
}

export type ProjectCreateRequestModel = {
  project_info: ProjectInfo;
  canvases?: CanvasesInfo[];
  canvasesIndex?: number;
}

export type ProjecDetailtRequestModel = {
  project_id: string;
}

export type ProjecDeleteRequestModel = {
  project_ids: string[];
}

export type ProjectUpdateRequestModel = {
  project_id: string;
  project_name?: string;
  category?: number;          // 项目类型
  sub_category?: number;      // 项目子类型
  is_standard_product?: number;   //是否是标品
  sort_order?: string[];

  print_param?: string;          //打印参数信息
  add_materials?: string[];
  del_materials?: string[];
}

export type ProjectCavasUpdateRequestModel = {
  project_id: string;
  canvases: ProjectCavasItemUpdateRequestModel[];
}

export type ProjectCavasItemUpdateRequestModel = {
  canvas_id: string;
  canvas_name?: string;
  category?: number;          // 项目类型
  sub_category?: number;      // 项目子类型
  is_standard_product?: number;   //是否是标品
  scenes?: string;  //场景信息
  materials?: string;          //材料
  base_map?: string;              //底图
  base_map_width?: number;
  base_map_height?: number;
  print_param?: string;          //打印参数信息
  model_link?: string;
  extra?: string;
  add_materials?: string[];
  del_materials?: string[];
}

export type ProjectModelList = {
  project_list: ProjectResInfo[];
  total: number;
}

export type ProjectResInfo = {
  project_id: string;
  project_name: string;
  project_desc?: string;
  category: number;          // 项目类型
  sub_category: number;      // 项目子类型
  is_standard_product: number;   //是否是标品
  parents_works_id?: string;
  root_works_id?: string;
  thumb_file: ProjectResFile,
  sort_order?: string[];
  create_time: number;
  update_time: number;
  img_blob?: string;
}

export type ProjectResFile = {
  file_name: string;
  upload_url: string;
  download_url: string;
}

export type CanvasesResInfo = {
  canvas_id: string;
  project_id: string;
  project_name: string;
  category: number;          // 项目类型
  sub_category: number;      // 项目子类型
  is_standard_product: number;   //是否是标品
  scenes: string;  //场景信息
  materials?: string;          //材料
  base_map: string;              //底图
  base_map_width: number;
  base_map_height: number;
  print_param: string;          //打印参数信息
  model_link: string;
  extra?: string;
  create_time: number;
  update_time: number;
  project_file: ProjectResFile;
  thumb_file: ProjectResFile;
  output_file: ProjectResFile;
  print_file: ProjectResFile;
  effect_file: ProjectResFile;
  material_list?: ProjectMaterialModel[]
}


export type ProjectModel = {
  project_info: ProjectResInfo;
  canvases: CanvasesResInfo[];
  canvasesIndex: number;
}

export type ProjectCutDataModel = {
  cutX?: number;
  cutY?: number;
  cutWidth?: number;
  cutHeight?: number;
}

export type ProjectMaterialModel = {
  key_prefix: string;
  download_url: string;
}


export type ProjectUploadModel = {
  project_path: string;     // 项目json信息上传路径
  thumb_path: string;       // 项目缩略图上传路径
  print_path: string;       //项目打印文件
  share_path: string;        // 分享链接
  publish_path: string;     // 发布链接
}

export type ProjectDownModel = {
  project_path: string;
  thumb_path: string;
  print_path: string;
  share_path: string;
  publish_path: string;
}

export type MaterialEditDataList = {
  material_list: MaterialEditData[];
  total: number;
}

export type MaterialEditData = {
  material_id: number;
  file_name: string;
  file_size: number;
  create_time: number;
  share_path: string;
  download_url: string;
}

export type MaterialCreateRequestModel = {
  file_name: string;
}

export type MaterialDeleteRequestModel = {
  material_ids: number[];
}

export type ProjectDownUrlRequestModel = {
  project_id: string;
  canvas_id: string;
  key_prefix: string[];
}

export type ProjectDownUrlResponseModel = {
  download_url: string[];
}

export type RemoveImageBackgroundRequestModel = {
  src_image: string;
}

export type RemoveImageBackgroundResponseModel = {
  mask_data: string;
}

export type CreateScalerImageRequestModel = {
  project_id?: string | number;
  canvas_id?: string | number;
  src_image: string;
  out_scale: number;
}

export type CreateScalerImageResponseModel = {
  task_id: string;
}

export type GetScalerImageRequestModel = {
  task_id: string;
}

export type GetScalerImageResponseModel = {
  task_id: string;
  status: number;
  progress: number;
  result_list: any;
}

export type EndScalerImageRequestModel = {
  task_id: string;
}

export type EndScalerImageResponseModel = {
  task_id: any;
}

export type StartCreate_taskRequestModel = {
  template_id: string;
  src_images: string[];
}

export type StartCreate_taskRequestModel_post = {
  task_id: any;
}

export type TaskStatus_RequestModel = {
  task_id: string;
}

export type TaskStatus_RequestModel_post = {
  status: any;
  progress: number;
  result_list: any;
}

export type HistoryLists_RequestModel = {
  task_type: number;
  pagination: {
    page: number;
    page_size: number;
  }
}

export type HistoryLists_RequestModel_post = {
  total: number;
  task_id: number;
  status: number;
  history_list: any
}

export type GetWorksList_RequestModel = {
  filters: {
    product_name: any
    tags: any
    category: any,
    style_type: any
  },
  scene: number
  pagination: {
    page: number;
    page_size: number;
  }
}

export type GetWorksList_RequestModel_post = {
  total: number;
  works_list: any;
}

export type getCollectOfficialt_RequestModel = {
  official_material_id: number,
  type: number
}

export type getCollectOfficialt_RequestModel_post = {
  official_material_id: number
}

export type getLikeWorks_RequestModel = {
  works_id: string,
}

export type getLikeWorks_RequestModel_post = {
  official_material_id: number
}

export type getFficialMaterialStatus_RequestModel = {
  ids: number[],
  type: number
}

export type getFficialMaterialStatus_post = {
  status_map: any
}

export type PopArtify_taskRequestModel = {
  template_id: string | number;
  src_image: string;
  type?: string;
}

export type PopArtify_taskRequestModel_post = {
  task_id: string;
}

export type getTextImageCreate_task = {
  prompt: string;
  ratio_width: any;
  ratio_height: any;
  style_id: number;
}

export type getTextImageCreate_task_post = {
  task_id: string;
}

export type getTextImageTaskStatus = {
  task_id: string;
}

export type getTextImageTaskStatus_post = {
  status: number;
  progress: number;
  result_list: {
    file_name: string;
    file_size: number;
    download_url: string;
  }
}

export type delete_history = {
  ids: number[];
}

export type delete_history_post = {

}

// #region Publish;
interface IPrintMakeInfos {
  image: string;
  works_id: string;
  name: string;
  user: {
    user_id: string;
    avatar: string;
    nickname: string;
    description: string;
    email: string;
    is_following: boolean;
    is_following_by: boolean;
  };
  create_time: number;
}
interface IWorksCanvasInfo {
  canvas_id: string;
  canvas_name: string;
  print_param: string;
  category: number;
  sub_category: number;
  is_standard_product: number;
  scenes: string;
  materials: string;
  base_map: string;
  base_map_width: number;
  base_map_height: number;
  model_link: string;
  extra: string;
  project_template_path: string;
}
export type PublishRequestModel = {
  project_id: string;
  works_type?: number;
  with_make?: number;
  render_3d_pic?: string;
  category: number;
  ai_category?: number[];
  file_key: string;
  tags?: string[];
  tag_ids?: number[];
  name: string;
  print_images?: string[];
  description?: string;
  license?: string;
  allow_remix: number;
  cover_tiny: string;
  images: string[];
  print_make_infos: IPrintMakeInfos;
  print_image_tiny: string;
  print_image_link: string;
  works_canvas_info: IWorksCanvasInfo[];
  scenes_image: string;
  thumb_image: string;
  hd_image: string;
}
export type PublishResponseModel = {
  works_id: string;
}

// 创建宠物肖像任务请求参数
export type GetPetPortraitCreateTaskReqModal = {
  style_id: number;
  model_id: number
}

// 获取宠物肖像进度及结果返回结构
export type GetPetPortraitTaskStatusResModal = {
  task_id: string; // 任务id
  status: number; // 任务状态
  progress: number; // 任务进度
  result_list: [ // 任务结果列表
    {
      file_name: string; // 文件名
      file_size: number; // 文件大小
      download_url: string; // 下载地址
      create_time: number; // 创建时间
    }
  ];
}

// 创建模型训练任务
export type CreateModelTrainTaskReqModal = {
  model_name?: string; // 模型名称
  dataset_id: string; // 数据集id
  thumb_key_prefix: string; // 缩略图路径
}

// 获取模型训练进度及结果返回值结构
export type GetModelTrainTaskStatusResModal = {
  task_id: string; // 任务id
  status: number; // 任务状态 0:待处理;1:处理中;2:已完成;3:处理失败;4:已取消;
  progress: number; // 任务进度
  model_name: string; // 模型名称
  model_id: string; // 模型id
  thumb_path: string; // 缩略图路径
  create_time: number; // 创建时间
}

export type RotaryParams = {
  // rotary_params 
  baseMapWidth?: number;
  baseMapHeight?: number;
  handleHeight?: number;

  // 保存到后台数据
  cupHeight?: number;
  hasHandle?: boolean;
  upperD?: number;
  bottomD?: number;
  horizontalProhibited?: number // 水平禁止线
  verticalRecommandedBlanklen?: number // 垂直推荐空白长度
}



// #endregion ;
