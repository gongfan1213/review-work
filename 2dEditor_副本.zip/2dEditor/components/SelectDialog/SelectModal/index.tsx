import React, { useEffect, useState } from 'react'
import * as classes from './index.module.scss'

import unit_up_arrow from 'src/assets/svg/unit_up_arrow.svg'
import clsx from 'clsx'

export default function SelectUnit({
  setUnit,
  isDisabled,
  defaultValue
}: {
  label?: string
  width?: number
  isDisabled?: boolean
  defaultValue?: string
  setUnit?: (unit: string) => void
}) {
  const [defaultUnit, setDefaultUnit] = useState<string>('mm')

  useEffect(() => {
    defaultValue && setDefaultUnit(defaultValue)
  }, [defaultValue])

  const moduleData = [
    {
      label: 'mm',
      value: 'mm',
    },
    {
      label: 'in',
      value: 'in',
    },
    // {
    //   label: 'px',
    //   value: 'px',
    // },
  ]

  const handleChangeItem = (item: { label: string; value: string }) => {
    if (!isDisabled) return
    setDefaultUnit(item.label)
    setUnit && setUnit(item.value)
  }

  return (
    <div className={classes.unitSelect}>
      <div className={classes.language}>
        <div
          className={classes.title}
          style={{
            background: !isDisabled ? '#dedede' : '#f7f7f7',
            cursor: !isDisabled ? 'not-allowed' : 'pointer',
            border: !isDisabled ? '1px solid #c4c4c4' : '1px solid #c4c4c4',
            borderRadius: '4px'
          }}
        >
          <span className={classes.defaultName}>{defaultUnit}</span>
          {/* {isDisabled && <img className={classes.arrow_down} src={unit_up_arrow} />} */}
        </div>
        {/* {isDisabled && <div className={classes.selectProps}>
          <div className={classes.selectGroupBox}>
            <i className={classes.triangleUp}></i>
          </div>
          <ul className={classes.selectGroup}>
            {moduleData.map((item, index) => {
              return (
                <li
                  className={classes.ulLi}
                  key={index}
                  onClick={() => handleChangeItem(item)}
                >
                  {item?.label || ''}
                </li>
              )
            })}
          </ul>
        </div>} */}
      </div>
    </div>
  )
}

