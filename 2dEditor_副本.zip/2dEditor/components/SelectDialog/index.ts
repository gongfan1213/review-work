import { SelectDialog } from "./SelectDialog";
import "./index.less";

export default SelectDialog;