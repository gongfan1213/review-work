import React, { useState, useMemo, useEffect, useCallback } from 'react'
import clsx from 'clsx'
import { Form, Input } from 'src/components/MakeUI'
import Button from '@mui/material/Button'
import InputAdornment from '@mui/material/InputAdornment'
import { Dialog, IconButton } from '@mui/material'
import close from 'src/assets/svg/popover_close.svg'
import { CategoryModel, CategoryScenesModel } from './model/CategoryModel'
import { CanvasesInfo, ProjectCreateRequestModel, ProjectInfo, ProjectModel, RotaryParams } from './model/ProjectModel'
// import { createProject } from '../../service/2dEditService'
import { get } from 'src/services'
import LottiePlayer from 'react-lottie-player'
import LoadingAnimation from 'src/images/lottie/loading.json'
import Loading from 'src/components/Loading'
import { Blank } from 'src/components/icon'
// import { getLocalStorage,setLocalStorage } from 'src/common/storage'
// import {
//   PrintLayerModel,
//   PrintModel,
//   PrintQuality,
// } from '../MainUi/MainUiRight/PrintLayer/model/PrintLayerModel'
// import StringUtil from 'src/common/utils/stringUtil'
import { useTranslation } from '@volcengine/i18n'
import { Modal } from 'src/components/MakeUI'
import ProjectManager from '../../utils/ProjectManager'
import { useCanvasEditor, useProjectData } from '../../hooks/context'
// import { openToast } from 'src/state/reducers/toast'
import { useDispatch } from 'react-redux'
// import { editorToastShow } from '../Toast'
// import navigate from 'src/common/route'
import TemplatesUtilsFn from 'src/templates/utils'
import { createProjectRequest, handleError } from '../../utils/utils'
import { handleLink2dEditor } from 'src/templates/2dEditor/utils/utils'
import StringUtil from 'src/common/utils/stringUtil'
import { From2dEditorType } from 'src/templates/2dEditor/utils/event/types'
import MyLazyImage from 'src/components/LazyLoadImage';
import { isPc, sendCommandToPc } from 'src/common/jsbridge'
import Select from './SelectModal'
import AnkerMake from 'src/assets/svg/AnkerMake.svg'
import handle from 'src/assets/svg/handle.svg'
import handle_no from 'src/assets/svg/handle_no.svg'
import horizontally from 'src/assets/svg/horizontally.svg'
import vertically from 'src/assets/svg/vertically.svg'
import { openToast } from 'src/state/reducers/toast'
import { isLogined } from 'src/common/storage'
import { log } from 'util'
import { CanvasCategory, CanvasParams, CustomPcAction } from '../../cons/2dEditorCons'
import { getHorizontalProhibited } from '../../common/cavasUtil'
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

export interface SelectDialogProps {
  open: boolean
  isTipsOff?: boolean
  isOff?: boolean
  onCreate?: (projectModel: ProjectModel, fromSource?: string) => void
  onReplace?: (projectModel: ProjectModel) => void
  onClose?: () => void
  setSelectDialogVisible?: (data: boolean) => void
  setItemNameData?: (data: any) => void
  isClose?: boolean
  project_id?: any
  editUrl?: boolean;
  location?: any;
}

export enum TabEnum {
  AnkermakeMaterial = 1,
  BlankArtboard = 2,
}

interface TabItem {
  title: string
  value: TabEnum
}

interface TabProps {
  value: TabEnum
  onChange?: (v: TabEnum) => void
  tabList: TabItem[]
}

export function SelectDialog(props: SelectDialogProps) {
  const { open, onClose, onCreate, onReplace, editUrl, location } = props
  const [selectedOption, setSelectedOption] = useState<any>()
  const [selectedCreate, setSelectedCreate] = useState<any>()
  const [loading, setLoading] = useState(false)
  const [createloading, setCreateLoading] = useState(false)
  const [mockMaterialData, setMockMaterialData] = useState<CategoryModel[]>([])
  const [firstOptions, setFirstOptions] = useState<CategoryModel[]>([])
  const [optionList, setPtionList] = useState<CategoryModel[]>([])
  const [itemData, setItemData] = useState<CategoryModel>()
  const [categoryData, setCategoryData] = useState<CategoryModel>()
  const [submitDisabled, setSubmitDisabled] = useState<boolean>(true)
  const [isHover, setIsHover] = useState<boolean>(false)
  const [width, setWidth] = useState<number>(1)
  const [height, setHeight] = useState<number>(1)
  const [drinkware, setDrinkware] = useState<number>(0)
  const [anyway, setAnyway] = useState<number>(0)
  const [unit, setUnit] = useState<string>('mm')
  const [editPath, setEditPath] = useState<boolean>(false)
  const projectModel = useProjectData();
  const canvasEditor = useCanvasEditor();
  const dispatch = useDispatch()
  const [form] = Form.useForm()
  const { t } = useTranslation()
  const { getTranslation } = useCustomTranslation();
  const [btnName, setBtnName] = useState<string>(getTranslation(TranslationsKeys.Create))
  

  // 获取所有小类
  const fetchSonClass = async (value?: number) => {
    setLoading(true)
    ProjectManager.getInstance().fetchSonClass((data: any, mockMaterialData: any[], mockBlankData: []) => {
      setLoading(false)
      setFirstOptions(mockMaterialData)
      setMockMaterialData(mockMaterialData)
      setPtionList(mockMaterialData?.[0]?.attributes?.options)
      setCategoryData(mockMaterialData?.[0]?.attributes)
      setSelectedOption(mockMaterialData?.[0]?.id)
    })
  }

  useEffect(() => {
    setSelectedCreate(null)
    fetchSonClass()
  }, [])

  const handleSave = (values: RotaryParams) => {
    const canvasData: any = {}
    var baseMapWidthNew = 0;
    var baseMapHeightNew = 0;

    var rotary_params: RotaryParams | null = null;
    if (drinkware === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL) {
      let circle: number =
        Number(values?.baseMapWidth) >= Number(values?.baseMapHeight)
          ? Number(values?.baseMapWidth)
          : Number(values?.baseMapHeight);
      // 得到禁止打印区域
      let horizontalProhibited = getHorizontalProhibited(circle / 2, values.handleHeight!);

      //CanvasParams.verticalRecommandedBlanklen
      let verticalRecommandedBlanklen = CanvasParams.verticalRecommandedBlanklen >= values.cupHeight! / 4 ? values.cupHeight! / 10 : CanvasParams.verticalRecommandedBlanklen;
      canvasData.width = Math.floor(Math.PI * circle);
      canvasData.height = Number(values?.cupHeight)
      rotary_params = {
        cupHeight: Number(values?.cupHeight),
        horizontalProhibited: horizontalProhibited,
        hasHandle: values.hasHandle,
        upperD: Number(values?.baseMapWidth),
        bottomD: Number(values?.baseMapHeight),
        verticalRecommandedBlanklen: verticalRecommandedBlanklen,
      }
    } else {
      canvasData.width = Number(values?.baseMapWidth)
      canvasData.height = Number(values?.baseMapHeight)
    }
    baseMapWidthNew = Number(canvasData.width)
    baseMapHeightNew = Number(canvasData.height)

    let widthHeight: any = {}
    let bleedingSite: any = {}
    if (unit === 'mm') {
      widthHeight = StringUtil.scaleToWidth(
        Number(canvasData?.width) || 0,
        Number(canvasData?.height) || 0,
        CanvasParams.canvas_dpi_def,
      )
      bleedingSite =
        itemData?.bleedingLine &&
        StringUtil.mmToPixelBleedingLine(itemData?.bleedingLine, CanvasParams.canvas_dpi_def)
    } else if (unit === 'in') {
      widthHeight = StringUtil.inchToPixelwh(
        Number(canvasData?.width) || 0,
        Number(canvasData?.height) || 0,
        CanvasParams.canvas_dpi_def,
      )
      bleedingSite.top =
        itemData?.bleedingLine &&
        StringUtil.inchToPixelBleedingLine(itemData?.bleedingLine, CanvasParams.canvas_dpi_def)
    }
    // else if (unit === 'px') {
    //   widthHeight = {
    //     width: Number(canvasData?.width) || 0,
    //     height: Number(canvasData?.height) || 0,
    //   }
    // }

    const newProjectModel = {
      ...categoryData,
      ...itemData,
      ...widthHeight,
      is_standard_product: itemData?.isEditCanvas ? 2 : 1,
      rotary_params: rotary_params,
      baseMapWidth: baseMapWidthNew,
      baseMapHeight: baseMapHeightNew,
    }

    if (
      itemData?.bleedingLine &&
      typeof itemData?.bleedingLine === 'object' &&
      Object.values(bleedingSite)?.length
    ) {
      newProjectModel.bleedingLine = bleedingSite
    }
    return newProjectModel
  }

  useEffect(() => {
    if (editUrl) {
      setEditPath(true)
    } else {
      setEditPath(false)
    }
    if (typeof window === 'undefined') return
    const params = new URLSearchParams(window?.location?.search)
    const fromSource = params.get('type') || location?.state?.EditorParmas?.data?.type || ''

    if (fromSource && window?.location?.pathname === '/apps/2dEditor/') {
      setBtnName(t('Confirm'))
      setEditPath(true)
    } else {
      setEditPath(false)
      setBtnName(getTranslation(TranslationsKeys.Create))
    }
  }, [window?.location?.pathname, window?.location?.search, editUrl, open])

  const handleSubmit = (e: any) => {
    e.preventDefault()
    e.stopPropagation()
    if (TemplatesUtilsFn.redirectLogin()) return
    const values: RotaryParams = form.getFieldsValue([
      'baseMapWidth',
      'baseMapHeight',
      'cupHeight',
      'handleHeight',
      'hasHandle',
    ])

    if (!values?.baseMapWidth || !values?.baseMapHeight) return
    if (editPath) {
      Modal.confirm({
        content: getTranslation(TranslationsKeys.CAVAS_DIALOG_LAB),
        okText: getTranslation(TranslationsKeys.BTN_MAKE),
        cancelText: getTranslation(TranslationsKeys.STR_COMMON_REPLACE),
        closable: true,
        closeIconColor: '#000',
        onOk: async (callBack: () => void) => {
          const projectRequest: any = createProjectRequest(handleSave(values))
          if (projectRequest instanceof Promise) {
            projectRequest.then((newProjectModle: any) => {
              const result: any = handleError(
                newProjectModle,
                dispatch,
                t,
                onClose,
              )
              if (result) {
                const params = new URLSearchParams(location.search)
                const fromSource = params.get('type') || ''
                if (
                  !fromSource ||
                  fromSource === From2dEditorType.NewProject ||
                  fromSource === From2dEditorType.Replace
                ) {
                  // canvasEditor?.clearHistory()
                  onClose?.()
                  onCreate?.({ ...result, canvasesIndex: 0 }, '')
                  if (isPc()) {
                    TemplatesUtilsFn.beforeHomeToCreated(result?.project_info?.project_id, From2dEditorType.CustomizeDesign, '2dStudio')
                  } else {
                    const params = {
                      project_id: result?.project_info?.project_id,
                      type: From2dEditorType.NewProject,
                    }
                    const queryString = new URLSearchParams(params).toString()
                    history.pushState({}, '', `/apps/2dEditor/?${queryString}`)
                  }
                } else {
                  onClose?.()
                  handleLink2dEditor(
                    result?.project_info?.project_id,
                    From2dEditorType.NewProject,
                  )
                }
              }
              callBack()
            })
          }
        },
        onCancel: async (callBack: () => void) => {
          const projectRequest: any = createProjectRequest(
            handleSave(values),
            true,
          )
          if (projectRequest && 'project_info' in projectRequest) {
            await replaceProject(projectRequest)
            callBack()
          }
        },
      })
    } else {
      setCreateLoading(true)
      setEditPath(true)
      const projectRequest: any = createProjectRequest(handleSave(values))
      if (projectRequest instanceof Promise) {
        projectRequest.then((newProjectModle: any) => {
          const result: any = handleError(newProjectModle, dispatch, t, onClose)
          setCreateLoading(false)
          if (result) {
            const params = new URLSearchParams(location?.search)
            const fromSource = params.get('type') || ''
            if (
              !fromSource ||
              fromSource === From2dEditorType.NewProject ||
              fromSource === From2dEditorType.Replace
            ) {
              canvasEditor?.clearHistory()
              onClose?.()
              onCreate?.({ ...result, canvasesIndex: 0 }, '')
              if (isPc()) {
                console.log(projectModel, 'projectModelprojectModelprojectModel')
                const flag = TemplatesUtilsFn.beforeHomeToCreated(
                  result?.project_info?.project_id || '',
                  From2dEditorType.CustomizeDesign,
                  '2dStudio',
                )
                if (flag) return
              }
              const params = {
                project_id: result?.project_info?.project_id || "",
                type: From2dEditorType.NewProject,
              }
              const queryString = new URLSearchParams(params).toString()
              const newUrl = `/apps/2dEditor/?${queryString}`;
              if (window.location.pathname.includes('apps/2dEditor')) {
                history.pushState({}, '', newUrl);
              } else {
                window.open(newUrl, '_blank');
              }
            } else {
              onClose?.()
              if (isPc()) {
                onCreate?.({ ...result, canvasesIndex: 0 }, '')
                return
              }
              handleLink2dEditor(
                result?.project_info?.project_id,
                From2dEditorType.NewProject,
              )
            }
          }
        })
      }
    }
  }

  const replaceProject = async (projectCreateRequestModel: ProjectCreateRequestModel) => {
    await ProjectManager.getInstance().chageProjectCategory(projectCreateRequestModel, projectModel!).then(newMpdel => {
      if (newMpdel) {
        const newProject: any = { ...newMpdel }
        if (newProject && newProject.project_info) {
          newProject.project_info.project_name = itemData?.title || '';
          newProject.project_info.category =
            categoryData?.categoryType?.data?.attributes?.categoryKey || '';
        }
        newProject.canvases.bleedingLine = itemData?.bleedingLine
        newProject.canvases.canvasShape = itemData?.canvasShape
        newProject.canvasesIndex = 0;
        onReplace?.(newProject)
        canvasEditor?.clearHistory();
        const params = {
          project_id: newMpdel?.project_info?.project_id,
          type: From2dEditorType.Replace,
        }
        const queryString = new URLSearchParams(params).toString()
        history.pushState({}, '', `/apps/2dEditor/?${queryString}`)
      }
      setCreateLoading(false)
    });
  }

  const handleHover = (e: any) => {
    e.preventDefault()
    e.stopPropagation()
    setIsHover(!isHover)
  }

  const handleClose = () => {
    onClose?.()
    setPtionList(mockMaterialData?.[0]?.attributes?.options)
    setSelectedOption(mockMaterialData?.[0]?.id)
    setCategoryData(mockMaterialData?.[0]?.attributes)
    setSubmitDisabled(true)
  }

  return (
    <>
      <Dialog
        className="select-dialog"
        open={open}
        onClick={(e) => {
          e.stopPropagation()
          e.preventDefault()
        }}
      >
        <div className="select-dialog-body">
          <div className="select-dialog-header">
            {props.isOff && (
              <div onClick={handleClose} className="close-right">
                <img src={close} alt="" />
              </div>
            )}
          </div>
          <div className="select-dialog-tab">
            <div className={clsx('select-dialog-tab-item')}>
            {getTranslation(TranslationsKeys.STR_SELECT_CANVAS)}
            </div>
          </div>
          {!loading ? (
            <div>
              <div className="select-dialog-top-label">
                {firstOptions.map((item: any, index: number) => {
                  return (
                    <div>
                      <div
                        key={item.id}
                        className={clsx('select-dialog-top-label-class', {
                          'option-selected': selectedOption === item.id,
                        })}
                        onClick={() => {
                          setCategoryData(item?.attributes)
                          setSelectedOption(item.id)
                          setPtionList(item?.attributes?.options)
                          setSelectedCreate(null)
                          setSubmitDisabled(true)
                          setDrinkware(item?.attributes?.categoryType?.data?.attributes?.categoryKey)
                          form.setFieldsValue({
                            baseMapWidth: 0,
                            baseMapHeight: 0,
                            cupHeight: 0,
                          })
                        }}
                      >
                        {item?.attributes?.categoryType?.data?.attributes?.categoryName || ''}
                      </div>
                      {selectedOption === item.id && (
                        <div className="select-dialog-top-label-line">
                          <i></i>
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
              <div className="dialog-content">
                <div className="select-dialog-content">
                  {optionList?.length ? (
                    <div className="select-dialog-top-options">
                      {optionList.map((item, index) => {
                        return (
                          <div
                            key={item.id}
                            className={clsx('select-dialog-top-options-item', {
                              'option-selected': selectedCreate === item.id,
                            })}
                            onClick={(e) => {
                              e.preventDefault()
                              e.stopPropagation()
                              setSelectedCreate(item.id)
                              setItemData(item)
                              setUnit(item.defaultUnit)
                              setAnyway(
                                item.orientation === 'horizontally' ||
                                  item.orientation === 'handle'
                                  ? 0
                                  : 1,
                              )
                              if (drinkware === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL) {
                                var size: RotaryParams = {
                                  baseMapWidth: item?.cupTopDiameter || 0,
                                  baseMapHeight: item?.cupBottomDiameter || 0,
                                  cupHeight: item?.cupHeight || 0,
                                  handleHeight: item?.handleHeight || CanvasParams.canvas_handle_height_def,
                                  hasHandle: false,
                                }
                                form.setFieldsValue(size)
                              } else {
                                var size: RotaryParams = {
                                  baseMapWidth: item?.baseMapWidth || 0,
                                  baseMapHeight: item?.baseMapHeight || 0,
                                }
                                form.setFieldsValue(size)
                              }
                              setWidth(item?.baseMapWidth)
                              setHeight(item?.baseMapHeight)
                              setSubmitDisabled(false)
                            }}
                          >
                            <div
                              // className="select-dialog-AnkerMake"
                              style={{
                                position: 'relative',
                                display: 'flex',
                                flexDirection: 'column',
                                justifyContent: 'center',
                              }}
                            >
                              {item.isAnkerMake && (
                                <p
                                  style={{
                                    position: 'absolute',
                                    top: '4px',
                                    left: '4px',
                                    display: 'flex',
                                    backgroundColor: '#ebf9ef',
                                    padding: '2px 4px',
                                    border: '1px solid #c6edd1',
                                    borderRadius: '4px',
                                  }}
                                >
                                  <span
                                    style={{
                                      color: '#33bf5a',
                                      fontFamily: 'Poppins',
                                      fontSize: '12px',
                                      zoom: 1,
                                      marginRight: '4px',
                                    }}
                                  >
                                    {getTranslation(TranslationsKeys.STR_ANKE_MAKE)}
                                  </span>
                                  <img
                                    alt=""
                                    loading="lazy"
                                    crossOrigin="anonymous" //设置跨域属性
                                    src={AnkerMake}
                                  />
                                </p>
                              )}
                              <img
                                alt=""
                                loading="lazy"
                                crossOrigin="anonymous" //设置跨域属性
                                className="selectImg1"
                                src={
                                  item?.categorySubImg?.data?.attributes?.url
                                }
                              />
                              <p
                                className="anonymous_title"
                                style={{ marginTop: !item?.dec ? '14px' : '' }}
                              >
                                {item?.title || ''}
                              </p>
                              <p
                                className="anonymous_dec"
                                style={{
                                  color: 'rgba(0, 0, 0, 0.6)',
                                  fontSize: '12px',
                                  margin: '4px 27px 8px 27px',
                                }}
                              >
                                {item?.dec || ''}
                              </p>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  ) : (
                    <div className="empty">
                      <div className="no_data">
                        <Blank />
                        <p>{getTranslation(TranslationsKeys.NO_DATA)}</p>
                      </div>
                    </div>
                  )}
                </div>
                <div className="dialog-form">
                  <div>
                    <div className="title">{getTranslation(TranslationsKeys.STR_SIZE)}</div>
                    <div className="form-size">
                      <Form
                        form={form}
                        layout="horizontal"
                        className="select-dialog-form"
                        scrollToFirstError
                      >
                        <div className="item-unit">
                          <Form.Item
                            name="baseMapWidth"
                            className="str_width"
                            label={
                              drinkware === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL
                                ? `${getTranslation(TranslationsKeys.STR_TOP)}`
                                : `${getTranslation(TranslationsKeys.STR_WIDTH)}`
                            }
                          >
                            <Input
                              autoComplete="off"
                              disabled={!itemData?.isEditCanvas}
                              style={{
                                cursor: itemData?.isEditCanvas
                                  ? 'text'
                                  : 'not-allowed',
                              }}
                              onChange={(event: any) => {
                                setSelectedCreate(0)
                                if (!/^[1-9]\d*$/.test(event?.target?.value)) {
                                  var size: RotaryParams = {
                                    baseMapWidth: 0,
                                  }
                                  form.setFieldsValue(size)
                                }
                                if (
                                  itemData?.isAnkerMake &&
                                  event?.target?.value &&
                                  Number(event?.target?.value) > width
                                ) {
                                  var size: RotaryParams = {
                                    baseMapWidth: width,
                                  }
                                  form.setFieldsValue(size)
                                }
                                if (
                                  event?.target?.value &&
                                  Number(event?.target?.value) < 1
                                ) {
                                  var size: RotaryParams = {
                                    baseMapWidth: 1,
                                  }
                                  form.setFieldsValue(size)
                                }
                              }}
                            />
                          </Form.Item>
                          <Select
                            setUnit={setUnit}
                            defaultValue={itemData?.defaultUnit}
                            isDisabled={itemData?.isEditCanvas}
                          />
                        </div>
                        <Form.Item
                          name="baseMapHeight"
                          label={
                            drinkware === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL
                              ? `${getTranslation(TranslationsKeys.STR_BOTTOM)}`
                              : `${getTranslation(TranslationsKeys.STR_HEIGHT)}`
                          }
                        >
                          <Input
                            autoComplete="off"
                            disabled={!itemData?.isEditCanvas}
                            onChange={(event: any) => {
                              setSelectedCreate(0)
                              if (!/^[1-9]\d*$/.test(event?.target?.value)) {
                                var size: RotaryParams = {
                                  baseMapHeight: 0,
                                }
                                form.setFieldsValue(size)
                              }
                              if (
                                itemData?.isAnkerMake &&
                                event?.target?.value &&
                                Number(event?.target?.value) > height
                              ) {
                                var size: RotaryParams = {
                                  baseMapHeight: height,
                                }
                                form.setFieldsValue(size)
                              }
                              if (
                                event?.target?.value &&
                                Number(event?.target?.value) < 1
                              ) {
                                form.setFieldsValue({
                                  baseMapHeight: 1,
                                })
                              }
                            }}
                          />
                        </Form.Item>
                        <Form.Item
                          name="cupHeight"
                          label={`${getTranslation(TranslationsKeys.STR_HEIGHT)}`}
                          style={{
                            display: drinkware === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL ? 'block' : 'none',
                          }}
                        >
                          <Input
                            autoComplete="off"
                            disabled={!itemData?.isEditCanvas}
                            onChange={(event: any) => {
                              setSelectedCreate(0)
                              if (!/^[1-9]\d*$/.test(event?.target?.value)) {
                                form.setFieldsValue({
                                  baseMapHeight: 0,
                                })
                              }
                              if (
                                itemData?.isAnkerMake &&
                                event?.target?.value &&
                                Number(event?.target?.value) > height
                              ) {
                                form.setFieldsValue({
                                  baseMapHeight: height,
                                })
                              }
                              if (
                                event?.target?.value &&
                                Number(event?.target?.value) < 1
                              ) {
                                form.setFieldsValue({
                                  baseMapHeight: 1,
                                })
                              }
                            }}
                          />
                        </Form.Item>
                        {itemData?.isEditCanvas && <Form.Item
                          label={
                            drinkware === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL
                              ? `${getTranslation(TranslationsKeys.STR_HANDLE)}`
                              : `${getTranslation(TranslationsKeys.STR_ORIENTATION)}`
                          }
                        >
                          <div
                            style={{
                              display: 'flex',
                              gap: 8,
                            }}
                          >
                            <img
                              src={drinkware === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL ? handle : horizontally}
                              alt=""
                              style={{
                                cursor: 'pointer',
                                border: '1px solid #dfdfdf',
                                borderRadius: '4px',
                                backgroundColor: anyway === 1 ? '#dfdfdf' : '',
                              }}
                              onClick={() => {
                                setAnyway(1)
                                const values = form.getFieldsValue([
                                  'baseMapWidth',
                                  'baseMapHeight',
                                ])
                                values?.baseMapWidth &&
                                  values?.baseMapHeight &&
                                  form.setFieldsValue({
                                    baseMapWidth: values?.baseMapHeight,
                                    baseMapHeight: values?.baseMapWidth,
                                    hasHandle: true,
                                  })
                              }}
                            />
                            <img
                              src={drinkware === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL ? handle_no : vertically}
                              alt=""
                              style={{
                                cursor: 'pointer',
                                border: '1px solid #dfdfdf',
                                borderRadius: '4px',
                                backgroundColor: anyway === 0 ? '#dfdfdf' : '',
                              }}
                              onClick={() => {
                                setAnyway(0)
                                const values = form.getFieldsValue([
                                  'baseMapWidth',
                                  'baseMapHeight',
                                ])
                                values?.baseMapWidth &&
                                  values?.baseMapHeight &&
                                  form.setFieldsValue({
                                    baseMapWidth: values?.baseMapHeight,
                                    baseMapHeight: values?.baseMapWidth,
                                    hasHandle: false,
                                  })
                              }}
                            />
                          </div>
                        </Form.Item>}
                      </Form>
                    </div>
                  </div>
                  <Button
                    variant="contained"
                    className={clsx('createBtn', {
                      'createBtn-hover': isHover,
                    })}
                    onMouseEnter={handleHover}
                    onMouseLeave={handleHover}
                    onClick={(e: any) => handleSubmit(e)}
                    disabled={submitDisabled}
                  >
                    {btnName}
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="loadingBox">
              <div className="loadingBg">
                <LottiePlayer
                  loop
                  play
                  className="loadingAnimation"
                  animationData={LoadingAnimation}
                />
              </div>
            </div>
          )}
        </div>
        <Loading loading={createloading} />
      </Dialog>
    </>
  )
}

