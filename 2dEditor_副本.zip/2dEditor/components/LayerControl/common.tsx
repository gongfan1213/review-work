import React, { useEffect, useState, useRef } from 'react';
import * as classes from './common.module.scss';
import three_circle from 'src/assets/svg/three_circle.svg';
import overlapped_rect from 'src/assets/svg/overlapped_rect.svg';
import delete_icon from 'src/assets/svg/delete.svg';
import { useCanvasEditor, useEvent } from '../../hooks/context';
import { CustomKey, FabricObjectType, TextureType, EventNameCons } from '../../cons/2dEditorCons';
import {
  BezierControlId,
  CircleControlId,
  AngleControlId,
} from 'src/templates/2dEditor/core/plugin/ArcTextPlugin/types';
import { DisableLayerId } from 'src/templates/2dEditor/components/Layer/types';
import { UnSaveId, AddJsonTempID } from 'src/templates/2dEditor/core/plugin/HistoryPlugin/types';
import { TempPatternID } from 'src/templates/2dEditor/core/plugin/PatternPlugin/types';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { ImageStatus } from 'src/templates/2dEditor/core/eventbus/types/image';
import { TextStatus } from 'src/templates/2dEditor/core/eventbus/types/text';
import Slider from '@mui/material/Slider';
import { WorkspaceID, CanvasParams } from 'src/templates/2dEditor/cons/2dEditorCons';
import StringUtil from 'src/common/utils/stringUtil';

export default function CommonControl(props: any) {
  const canvasEditor = useCanvasEditor();
  const event = useEvent();
  const [activeObject, setActiveObject] = useState<fabric.Object | null | undefined>(null);
  const noShowIds = [
    UnSaveId.Id,
    BezierControlId.ControlCircle,
    BezierControlId.ControlLine,
    CircleControlId.ControlCircle,
    AngleControlId.ControlCircle,
    AngleControlId.ControlLine,
    DisableLayerId.ClonedForMoveId,
    TempPatternID.ID,
    AddJsonTempID.ID,
  ];
  // #region position and show;
  const commonControlWidth = 112;
  const commonControlHeight = 32;
  const angleControlWidth = 30;
  const headerHeight = 50;
  const leftbarWidth = 392 + 77;
  const accordAngleTopOffset = 20;
  const [show, setShow] = useState(false);
  const [showCommon, setShowCommon] = useState(false);
  const [showTextTransform, setShowTextTransform] = useState(false);
  const [isTextUnderTransform, setIsTextUnderTransform] = useState(false);
  const [bounding, setBounding] = useState<any>();
  const [pointer, setPointer] = useState({ x: 0, y: 0 });
  const [showPosition, setShowPosition] = useState(false);
  const [showWidthHeight, setShowWidthHeight] = useState(false);
  const [showRotate, setShowRotate] = useState(false);
  const [activePosition, setActivePosition] = useState({ left: 0, top: 0 });
  const [rotateAngle, setRotateAngle] = useState(0);
  const [sliderMax, setSliderMax] = useState(15);
  const [zoom, setZoom] = useState(0);
  const [objectOption, setObjectOption] = useState({});
  const minAngle = 0;
  const maxAngle = 360;

  const startDringHandler = () => handleCanvasDragMode(true);
  const endDringHandler = () => handleCanvasDragMode(false);

  useEffect(() => {
    if (!canvasEditor) return;
    // 绑定事件
    canvasEditor?.canvas.on('selection:created', handleSelectionChange);
    canvasEditor?.canvas.on('selection:updated', handleSelectionChange);
    canvasEditor?.canvas.on('selection:cleared', handleSelectionCleared);
    canvasEditor?.canvas.on('object:moving', handleObjectMoving);
    canvasEditor?.canvas.on('object:scaling', handleObjectScaling);
    canvasEditor?.canvas.on('mouse:wheel', handleCanvasZoomChange);
    canvasEditor?.canvas.on('object:rotating', handleObjectRotating);
    canvasEditor?.canvas.on('mouse:up', handleCanvasMouseup);
    eventBus.on(EventNameCons.EventHanlederSliderMax, hanlderSliderMax);

    // 优化事件监听器的添加和移除，避免内存泄漏
    canvasEditor.on('startDring', startDringHandler);
    canvasEditor.on('endDring', endDringHandler);

    return () => {
      // 移除事件监听器时，确保传递正确的回调函数引用
      canvasEditor?.canvas.off('selection:created', handleSelectionChange);
      canvasEditor?.canvas.off('selection:updated', handleSelectionChange);
      canvasEditor?.canvas.off('selection:cleared', handleSelectionCleared);
      canvasEditor?.canvas.off('object:moving', handleObjectMoving);
      canvasEditor?.canvas.off('object:scaling', handleObjectScaling);
      canvasEditor?.canvas.off('mouse:wheel', handleCanvasZoomChange);
      canvasEditor?.canvas.off('object:rotating', handleObjectRotating);
      canvasEditor?.canvas.off('mouse:up', handleCanvasMouseup);
      eventBus.off(EventNameCons.EventHanlederSliderMax, hanlderSliderMax);

      canvasEditor.off('startDring', startDringHandler);
      canvasEditor.off('endDring', endDringHandler);
    };
  }, [canvasEditor]);

  const [canvasDragMode, setCanvasDragMode] = useState<boolean>(false);
  const handleCanvasDragMode = (flag: boolean) => {
    setActiveObject(null);
    setCanvasDragMode(flag);
  };

  useEffect(() => {
    if (!!activeObject && !!(activeObject as any).id && !noShowIds.includes((activeObject as any).id)) {
      // image 去背/超分辨率加载中时，不显示;
      if (
        activeObject.type === FabricObjectType.Image &&
        ((activeObject as any)['rbLoading'] || (activeObject as any)['upscalerLoading'])
      )
        return;

      setShow(true);
      setShowCommon(true);
    }
    setRotateAngle(activeObject?.angle || 0);
    // ;
    eventBus.on(ImageStatus.Cropping, handleImageStatus);
    eventBus.on(ImageStatus.Upscaling, handleImageStatus);
    eventBus.on(ImageStatus.RemovingBackground, handleImageStatus);
    eventBus.on(TextStatus.UnderTransform, handleTextStatus);

    hanlderSliderMax(activeObject);

    return () => {
      setRotateAngle(0);
      eventBus.off(ImageStatus.Cropping, handleImageStatus);
      eventBus.off(ImageStatus.Upscaling, handleImageStatus);
      eventBus.off(ImageStatus.RemovingBackground, handleImageStatus);
      eventBus.off(TextStatus.UnderTransform, handleTextStatus);
    };
  }, [activeObject]);

  // 处理image status;
  const handleImageStatus = (e: any) => {
    setShow(!e.value);
    setShowCommon(!e.value);
  };
  // 处理文字 status;
  const handleTextStatus = (flag: boolean) => {
    setIsTextUnderTransform(flag);
  };

  const hanleBounding = (activeObject: any) => {
    activeObject.setCoords();
    let tempBounding;
    if (activeObject._original) {
      tempBounding = activeObject._original.getBoundingRect();
    } else {
      tempBounding = activeObject.getBoundingRect();

      const originalBounding = canvasEditor?.canvas
        ?.getObjects()
        .find((item) => item.id?.includes(WorkspaceID.WorkspaceCavas))
        ?.getBoundingRect();
      if (activeObject.angle && activeObject.angle > 170 && activeObject.angle < 190) {
        tempBounding.top -= accordAngleTopOffset;
      }
      //@ts-ignore
      if (originalBounding.top > tempBounding.top) {
        tempBounding.top = originalBounding.top;
      }
    }
    setBounding(tempBounding);
  };

  const handleSelectionChange = () => {
    const currentActiveObject = canvasEditor?.canvas.getActiveObject();
    if (!currentActiveObject) return;
    setActiveObject(currentActiveObject);
    setPosition(currentActiveObject);
    hanleBounding(currentActiveObject);
  };

  const handleSelectionCleared = () => {
    setActiveObject(null);
    setBounding(null);
    setShow(false);
    setShowCommon(false);
  };

  const isTexture = (activeObject: any) => {
    return !!(activeObject.textureType || activeObject._isTextureGroup);
  };

  const handleObjectMoving = (e: any) => {
    const target = e.target;
    if (!target) return;
    setActiveObject(e.target);
    setShowPosition(true);
    setPointer({
      x: e.e.clientX - leftbarWidth,
      y: e.e.clientY - headerHeight,
    });
    // const tempBounding = target.getBoundingRect();
    // // 旋转角度在 170 - 190 之间时，需要调整位置 遮挡问题;
    // if (target.angle && target.angle > 170 && target.angle < 190) tempBounding.top -= accordAngleTopOffset;
    // setBounding(tempBounding);
    // setShowCommon(false);
    hanleBounding(e.target);
    setPosition(e.target);
  };

  const handleObjectScaling = (e: any) => {
    const target = e.target;
    if (!target) return;
    setShowWidthHeight(true);
    setPointer({
      x: e.e.clientX - leftbarWidth,
      y: e.e.clientY - headerHeight,
    });
    setActiveObject(e.target);
    // const tempBounding = target.getBoundingRect();

    // // 旋转角度在 170 - 190 之间时，需要调整位置 遮挡问题;
    // if (target.angle && target.angle > 170 && target.angle < 190) tempBounding.top -= accordAngleTopOffset;
    // setBounding(tempBounding);
    // setShowCommon(false);
    hanleBounding(e.target);
    setPosition(e.target);
  };

  const handleCanvasZoomChange = () => {
    const currentActiveObject = canvasEditor?.canvas.getActiveObject();
    if (currentActiveObject) {
      // const tempBounding = currentActiveObject.getBoundingRect();

      // if (currentActiveObject.angle && currentActiveObject.angle > 170 && currentActiveObject.angle < 190) {
      //   tempBounding.top -= accordAngleTopOffset;
      // }
      // setBounding(tempBounding);
      hanleBounding(currentActiveObject);
    }
  };
  const handleObjectRotating = (e: any) => {
    const target = e.target;
    if (!target) return;
    setPointer({
      x: e.e.clientX - leftbarWidth,
      y: e.e.clientY - headerHeight,
    });
    setRotateAngle(e.target?.angle || 0);
    setShowRotate(true);
    // const tempBounding = target.getBoundingRect();
    // // 旋转角度在 170 - 190 之间时，需要调整位置 遮挡问题;
    // if (target.angle && target.angle > 170 && target.angle < 190) {
    //   tempBounding.top -= accordAngleTopOffset;
    // }
    // setBounding(tempBounding);
    hanleBounding(e.target);
    setShowCommon(false);
    setPosition(e.target);
    canvasEditor?.canvas.requestRenderAll();
  };
  const handleCanvasMouseup = (e: any) => {
    setPointer({ x: 0, y: 0 });
    setShowRotate(false);
    setShowWidthHeight(false);
    setShowPosition(false);
    !!e.target && setShowCommon(true);
  };

  const handleAngleinput = (angle: number | string) => {
    if (!activeObject) return;
    if (Number(angle) > maxAngle) angle = 360;
    if (Number(angle) < minAngle) angle = 0;
    setRotateAngle(Number(angle));
    activeObject?.rotate(Number(angle));
    canvasEditor?.canvas.renderAll();
    // const tempBounding = activeObject.getBoundingRect();
    // // 旋转角度在 170 - 190 之间时，需要调整位置 遮挡问题;
    // if (activeObject.angle && activeObject.angle > 170 && activeObject.angle < 190)
    //   tempBounding.top -= accordAngleTopOffset;
    // setBounding(tempBounding);
    hanleBounding(activeObject);
  };

  const setScale = (value) => {
    if (!activeObject) return;
    let scale = value;
    let original;
    //@ts-ignore
    if (activeObject.isCanvasTexture && activeObject.isPublish && activeObject.textureType !== TextureType.RELIEF) {
      original = canvasEditor?.canvas?.getObjects().find((item) => item.id?.includes(WorkspaceID.WorkspaceCavas));
      //@ts-ignore
      const width = original.width * original.scaleX;
      //@ts-ignore
      const height = original.height * original.scaleY;
      //@ts-ignore
      const limitScale = Math.max(width / activeObject?.width, height / activeObject?.height);

      if (scale < limitScale) {
        scale = limitScale;
      }
      //@ts-ignore
    } else if (!activeObject.isCanvasTexture && activeObject.textureType) {
      original = activeObject?._original;
      const width = original.width * original.scaleX;
      const height = original.height * original.scaleY;
      const limitScale = Math.max(width / activeObject?.width, height / activeObject?.height);

      if (scale < limitScale) {
        scale = limitScale;
      }
    }
    activeObject?.set({
      scaleX: scale,
      scaleY: scale,
    });
    setPosition(activeObject);

    canvasEditor?.canvas.renderAll();
  };

  const hanlderSliderMax = (activeObject: any) => {
    if (!activeObject) {
      return 0;
    }
    const workspace = canvasEditor?.canvas.getObjects().find((item) => item.id?.includes(WorkspaceID.WorkspaceCavas));
    //@ts-ignore
    const workspaceWidth = workspace?.width * workspace?.scaleX;
    //@ts-ignore
    const workspaceHeight = workspace?.height * workspace?.scaleY;

    const scale = Math.max(workspaceWidth / activeObject.width, workspaceHeight / activeObject.height);

    setSliderMax(scale * 6);
  };

  const setPosition = (activeObject: any) => {
    if (!activeObject) return;
    const left = (
      activeObject.originX === 'center'
        ? activeObject.left - (activeObject.width / 2) * activeObject.scaleX
        : activeObject?.left
    ) as number;
    const top = (
      activeObject.originY === 'center'
        ? activeObject.top - (activeObject.height / 2) * activeObject.scaleY
        : activeObject.top
    ) as number;

    setActivePosition({ left, top });
  };

  return (
    // 文字变形交互过程中不显示;
    // 画布拖拽模式时不显示;
    // active object lock 不显示;
    show &&
    !!bounding &&
    !!activeObject &&
    // @ts-ignore;
    !activeObject[CustomKey.IsLock] &&
    !isTextUnderTransform &&
    !canvasDragMode && (
      <>
        {showCommon && (
          <div
            className={classes.angle_div}
            style={{
              height: '25px',
              left: bounding.left + bounding.width / 2 - 40 / 2,
              top: bounding.top - commonControlHeight - 10,
            }}
          >
            <input
              type="number"
              style={{
                width: `${angleControlWidth}px`,
              }}
              value={rotateAngle.toFixed(0)}
              onInput={(e) => handleAngleinput((e.target as HTMLInputElement).value)}
            />
            <span className={classes.angle_char}>°</span>
          </div>
        )}
        <div className={classes.object_option} style={isTexture(activeObject) ? { top: '5px' } : { top: '45px' }}>
          <span className={classes.tabName}>Position(mm)</span>
          <span className={classes.optionName}>X：</span>
          <input
            type="number"
            value={StringUtil.pixelToMm(activePosition.left, CanvasParams.canvas_dpi_def).toFixed(2)}
            onChange={(e) => {
              const pixel = StringUtil.mmToPixel(Number(e.target.value), CanvasParams.canvas_dpi_def);
              const left =
                activeObject?.originX === 'center' ? pixel + (activeObject.width / 2) * activeObject.scaleX : pixel;

              activeObject.set({ left: left });
              canvasEditor?.canvas.renderAll();
              setPosition({ left: pixel, top: activePosition.top });
            }}
          />
          <span className={classes.optionName}>Y：</span>
          <input
            type="number"
            value={StringUtil.pixelToMm(activePosition.top, CanvasParams.canvas_dpi_def).toFixed(2)}
            onChange={(e) => {
              const pixel = StringUtil.mmToPixel(Number(e.target.value), CanvasParams.canvas_dpi_def);
              const top =
                activeObject?.originY === 'center' ? pixel + (activeObject.height / 2) * activeObject.scaleY : pixel;
              activeObject.set({ top: top });
              canvasEditor?.canvas.renderAll();
              setPosition({ left: activePosition.left, top: pixel });
            }}
          />

          <span className={classes.tabName}>Size(mm)</span>
          <span className={classes.optionName}>W：</span>
          <input
            type="number"
            value={StringUtil.pixelToMm(activeObject.width * activeObject.scaleX, CanvasParams.canvas_dpi_def).toFixed(
              2,
            )}
            onChange={(e) => {
              const pixel = StringUtil.mmToPixel(Number(e.target.value), CanvasParams.canvas_dpi_def);
              const scaleX = pixel / activeObject.width;
              activeObject.set({ scaleX: scaleX });
              canvasEditor?.canvas.renderAll();
              setObjectOption({ scaleX: scaleX });
            }}
          />
          <span className={classes.optionName}>H：</span>
          <input
            type="number"
            value={StringUtil.pixelToMm(activeObject.height * activeObject.scaleY, CanvasParams.canvas_dpi_def).toFixed(
              2,
            )}
            onChange={(e) => {
              const pixel = StringUtil.mmToPixel(Number(e.target.value), CanvasParams.canvas_dpi_def);
              const scaleY = pixel / activeObject.height;
              activeObject.set({ scaleY: scaleY });
              canvasEditor?.canvas.renderAll();
              setObjectOption({ scaleY: scaleY });
            }}
          />
        </div>
        {activeObject.textureType && (
          <div
            className={classes.sliderBox}
            style={{
              left: bounding.left + bounding.width / 2 - 40 / 2,
              top: bounding.top - commonControlHeight - 20,
            }}
          >
            <span className={classes.zoomtitle}>zoom:</span>
            <Slider
              className={classes.slider}
              step={0.01}
              min={0.01} //0
              max={sliderMax}
              value={activeObject.scaleX}
              onChange={(e, value) => {
                setScale(value);
                // const scale = value / 5;
                // activeObject.set({
                //   scaleX: scale,
                //   scaleY: scale
                // })
                // canvasEditor?.canvas.renderAll();
                setZoom(value);
              }}
            />
          </div>
        )}

        {/* rotation angle; */}
        {showRotate && (
          <div
            className={classes.b_div}
            style={{
              top: `${pointer.y + 10}px`,
              left: `${pointer.x + 10}px`,
            }}
          >
            {rotateAngle.toFixed(0) + '°'}
          </div>
        )}
        {/* width height; */}
        {showWidthHeight && (
          <div
            className={classes.b_div}
            style={{
              top: `${pointer.y + 10}px`,
              left: `${pointer.x + 10}px`,
            }}
          >
            W: {activeObject ? (activeObject.width! * (activeObject.scaleX || 1)).toFixed(0) : '0'}
            H: {activeObject ? (activeObject.height! * (activeObject.scaleY || 1)).toFixed(0) : '0'}
          </div>
        )}
        {/* position; */}
        {showPosition && (
          <div
            className={classes.b_div}
            style={{
              top: `${pointer.y + 10}px`,
              left: `${pointer.x + 10}px`,
            }}
          >
            {`(${activeObject?.left?.toFixed(0) || '0'}, ${activeObject?.top?.toFixed(0) || '0'})`}
          </div>
        )}
      </>
    )
  );
}
