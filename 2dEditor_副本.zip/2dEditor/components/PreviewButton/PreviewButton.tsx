import { useCanvasEditor } from '../../hooks/context';
import React from 'react'
import { Button } from '@mui/material'
import Dialog from '@mui/material/Dialog';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';

function PreviewButton() {
  const canvasEditor = useCanvasEditor();

  const [visible, setVisible] = React.useState(false);

  const [imgSrc, setImgSrc] = React.useState('');

  const preview = () => {
    canvasEditor.preview1().then((data: any) => {
      setImgSrc(data.dataUrl);
      setVisible(true);
    });
  };
  return (
    <div>
      <Button onClick={preview}>
        预览
      </Button>
      {/* <Image
        style={{ display: 'none' }}
        preview={{
          visible,
          src: imgSrc,
          onVisibleChange: (value) => {
            setVisible(value);
          },
        }}
      /> */}
      <Dialog
        open={visible}
        onClose={() => setVisible(false)}
        aria-labelledby="image-preview-dialog"
        sx={{ display: 'none' }} // 根据需要调整样式
      >
        <img src={imgSrc} alt="Preview" />
        <IconButton
          onClick={() => setVisible(false)}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      </Dialog>
    </div>
  )
}

export default PreviewButton