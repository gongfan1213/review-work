import React, { useRef, useEffect } from 'react';
import Cropper from 'cropperjs';

// component
import { Dialog } from '@mui/material'

// style
import 'cropperjs/dist/cropper.min.css';
import './index.scss'

// icon
import CloseIcon from 'src/assets/svg/close.svg';

// utils
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

const ImageCropper = (props: any) => {
  const { imageUrl = null, onCrop, index = 0, isOpen, setOpen } = props;
  const imageRef = useRef<HTMLImageElement>(null);
  const cropperRef = useRef<Cropper>();
  const { getTranslation } = useCustomTranslation();

  // 初始化CropperJS
  useEffect(() => {
    setTimeout(() => {
      if (imageRef.current) {
        const cropper = new Cropper(imageRef.current, {
          aspectRatio: 1, // 裁剪框的宽高比
          scalable: true, // 允许缩放图片
          zoomable: true, // 允许缩放图片
          cropBoxResizable: false, // 允许改变裁剪框大小
          cropBoxMovable: false, // 允许拖动裁剪框
          dragMode: 'move', // 裁剪时拖动图片
          viewMode: 1, // 限制裁剪框不超出图片范围
          center: true, // 确保裁剪框在画布中居中
          autoCropArea: 1, // 自动裁剪区域的大小
          // ready: () => {

          //   const cropper = cropperRef.current;
          //   if (cropper) {
          //     const canvasData = cropper.getCanvasData();
          //     const cropBoxWidth = 470;
          //     const cropBoxHeight = 470;
          //     const cropBoxData = {
          //       width: cropBoxWidth,
          //       height: cropBoxHeight,
          //       top: (canvasData.height - cropBoxHeight) / 2 + canvasData.top,
          //       left: (canvasData.width - cropBoxWidth) / 2 + canvasData.left
          //     };
          //     cropper.setCropBoxData(cropBoxData);

          //     // 获取图片的原始大小
          //     const imageData = cropper.getImageData();
          //     const originalWidth = imageData.naturalWidth;
          //     const originalHeight = imageData.naturalHeight;
          //     // 计算缩放级别
          //     const zoomLevel = Math.max(cropBoxData.width / originalWidth, cropBoxData.height / originalHeight);

          //     // 设置图片的缩放级别
          //     cropper.zoomTo(zoomLevel);
          //   }
          // },
          ready: () => {
            // 获取容器（cropper-container）的数据
            const containerData = cropper.getContainerData();

            // 设置裁剪区域大小
            const cropBoxSize = 470;
            // 计算裁剪框居中的 top 和 left 值
            const cropBoxData = {
              width: cropBoxSize,
              height: cropBoxSize,
              top: (containerData.height - cropBoxSize) / 2,
              left: (containerData.width - cropBoxSize) / 2
            };

            // 设置裁剪框
            cropper.setCropBoxData(cropBoxData);

            // 如果需要，可以调整画布（cropper-canvas）的位置，使其与裁剪框居中对齐
            const canvasData = cropper.getCanvasData();
            const canvasCenteredData = {
              ...canvasData,
              top: (containerData.height - canvasData.height) / 2,
              left: (containerData.width - canvasData.width) / 2
            };
            cropper.setCanvasData(canvasCenteredData);
          },
        });
        cropperRef.current = cropper;
      }
    }, 100)

    return () => {
      // 清理代码
      if (cropperRef.current) {
        cropperRef.current.destroy();
      }
    };
  }, [isOpen]);

  // 裁剪并获取结果
  const handleCrop = () => {
    const cropper = cropperRef.current;
    if (cropper) {
      // 获取裁剪后的Canvas
      const canvas = cropper.getCroppedCanvas({
        width: 460,
        height: 460,
      });
      // 将Canvas转换为Blob
      canvas?.toBlob((blob) => {
        if (blob) {
          onCrop(blob, index);
        }
      }, 'image/webp');
    }
  };

  return (
    <Dialog
      className='published_photo_cropper'
      open={isOpen}
    >
      <div className='__cropper_layout'>
        <div className='crop_title'>
          <p>{getTranslation(TranslationsKeys.COVERPHOTO)}</p>
          <img src={CloseIcon} onClick={() => setOpen()} alt="" />
        </div>
        <div className='crop_box'>
          {imageUrl && <img ref={imageRef} src={imageUrl} alt="Source" className='crop_img' />}
        </div>

        <div className='crop_btns'>
          <p className='cancel_btn' onClick={() => setOpen()}>{getTranslation(TranslationsKeys.BUTTON_CANCEL)}</p>
          <p className='crop_btn' onClick={handleCrop}>{getTranslation(TranslationsKeys.STRINGOK)}</p>
        </div>
      </div>
    </Dialog>
  );
};

export default ImageCropper;
