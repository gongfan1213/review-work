import React, { useEffect, useState, useCallback } from 'react';
import { blobToBase64 } from 'src/common/utils';
import { checkFileSize } from 'src/templates/2dEditor/utils/checkFileSize';
import { useDispatch } from 'react-redux';
import ImageCropper from './ImageCrop';
import { openToast } from 'src/state/reducers/toast';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import './index.scss';
import photoCropIcon from 'src/assets/svg/photo_crop.svg';

export default function Index(props: any) {
  const { setPrintImages, designDetalis, isClickSubmit } = props;
  const dispatch = useDispatch();
  const { getTranslation } = useCustomTranslation();

  const [cropImage, setCropImage] = useState<string | null>(null);
  const [cropImageFile, setCropImageFile] = useState<string | null>(null);
  const [isOpen, setOpen] = useState(false);
  const [uploadFile, setUploadFile] = useState(null as any);

  const handleUploadChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadFile(file)
    const fileSize = file.size;
    const defaultSize = 50 * 1024 * 1024;
    if (fileSize > defaultSize) {
      dispatch(openToast({
        message: getTranslation(TranslationsKeys.IMAGRLIMITSZIETIP),
        severity: 'error',
      }));
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      compressImage(result, (compressedBlob) => {
        const compressedUrl = URL.createObjectURL(compressedBlob);
        setCropImage(compressedUrl);
        setOpen(true);
      });
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const compressImage = (dataUrl: string, callback: (blob: Blob) => void) => {
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const maxWidth = 800;
      const maxHeight = 800;
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width *= maxHeight / height;
          height = maxHeight;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);

      canvas.toBlob((blob) => {
        if (blob) {
          callback(blob);
        }
      }, 'image/jpeg', 0.7);
    };
  };

  const onCrop = async (blob: any) => {

    const defaultSize = 50 * 1024 * 1024;
    const fileSize = uploadFile.size;

    if (uploadFile?.name && uploadFile?.name.split('.')[0].length > 50) {
      dispatch(openToast({
        message: getTranslation(TranslationsKeys.LIMIT_IMAGE_NAMELENGTH),
        severity: 'error',
      }))
      return;
    }

    if (fileSize > defaultSize) {
      dispatch(openToast({
        message: getTranslation(TranslationsKeys.IMAGRLIMITSZIETIP),
        severity: 'error',
      }));
      return;
    }

    setCropImage(null);
    const fileName = uploadFile?.name || 'upload.webp';
    const base64 = await blobToBase64(blob);
    setCropImageFile(base64);
    const file = new File([blob], fileName, { type: blob.type, lastModified: Date.now() });
    setPrintImages([file]);
    setOpen(false);
  };

  const cancelCrop = () => {
    setCropImage(null);
    setCropImageFile(null);
  };

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  }, []);

  const handleDrop = useCallback((action: React.DragEvent<HTMLDivElement>) => {
    action.stopPropagation();
    action.preventDefault();
    const file = action.dataTransfer.files[0];
    if (!file) return;

    const fileExtension = file.name.split('.').pop()?.toLowerCase() ?? '';
    if (!['jpg', 'png', 'webp', 'gif'].includes(fileExtension)) {
      dispatch(openToast({
        message: getTranslation(TranslationsKeys.UNSUPPORTED_IMAGE_TYPE),
        severity: 'error',
      }));
      return;
    }

    const fileSize = file.size;
    const defaultSize = 50 * 1024 * 1024;
    if (fileSize > defaultSize) {
      dispatch(openToast({
        message: getTranslation(TranslationsKeys.IMAGRLIMITSZIETIP),
        severity: 'error',
      }));
      return;
    }

    const reader = new FileReader();
    reader.onload = (event: ProgressEvent<FileReader>) => {
      const result = event.target?.result as string;
      compressImage(result, (compressedBlob) => {
        const compressedUrl = URL.createObjectURL(compressedBlob);
        setCropImage(compressedUrl);
        setOpen(true);
      });
    };
    reader.readAsDataURL(file);
  }, [dispatch, getTranslation]);

  useEffect(() => {
    if (designDetalis?.pictures) {
      setCropImageFile(designDetalis?.pictures[0]);
    }
  }, [designDetalis]);

  return (
    <>
      <div className='__crop_photo_layout'>
        {
          !cropImageFile
            ? <div
              className="upload_content"
              onDragOver={handleDragOver}
              onDrop={handleDrop}>
              <img className="bg_img" src={photoCropIcon} alt="" />
              <p className="upload_title">Cover Photo  <span>*</span></p>
              <span className="upload_des">Drag The Image Here</span>
              <p className='upload_des upload_des1'>OR</p>
              <div className="uplaod_btn">
                <input type="file" className="upload_input" accept=".jpg,.png,.webp,.gif" onChange={handleUploadChange} />
                <p>Browse</p>
              </div>
            </div>
            : <>
              <img src={cropImageFile} className='crop_image' alt="" />
              <input type="file" className="replace_upload_input" accept=".jpg,.png,.webp,.gif" onChange={handleUploadChange} />
              <p className='replace'>Replace</p>
            </>
        }
        {!cropImageFile && isClickSubmit && <p className='red_text_p'>{getTranslation(TranslationsKeys.PROJECT_UPLOAD_IMAGE)}</p>}
      </div>
      <ImageCropper
        index={0}
        imageUrl={cropImage}
        onCrop={onCrop}
        cancelCrop={cancelCrop}
        isOpen={isOpen}
        setOpen={() => setOpen(false)}
      />
    </>
  );
}
