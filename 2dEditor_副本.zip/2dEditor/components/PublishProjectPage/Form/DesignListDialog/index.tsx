import React, { useState, useEffect, useRef } from "react";

//component
import { Dialog } from '@mui/material';
import LottiePlayer from 'react-lottie-player'
import LoadingAnimation from 'src/images/lottie/loading.json';
import { openToast } from 'src/state/reducers/toast';
import CreateForm from 'src/templates/Home/component/CreateForm'
import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';

// service
import { fetchProjectList } from 'src/templates/Home/services';
import { get } from 'src/services';

// utils
import { ACTION_MAGICK, } from 'src/templates/2dEditor/cons/2dEditorCons';
import navigator from 'src/common/route'

// @ts-ignore
import IMagickWorker from 'src/templates/2dEditor/core/worker/imagick.worker';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import { useDispatch } from 'react-redux';

// icon
import loadingIcon from 'src/assets/svg/loading_white.svg';
import emptyIcon from "src/images/empty_progress.png";
import closeIcon from 'src/assets/svg/close.svg';

// style
import './index.scss';


export default function Index(props: any) {

  const { open, cancelClick, handleNext } = props;
  const [choseIndex, setChoseIndex] = useState<number>(0);
  const [selectProject, setSelectProject] = useState({} as any);
  const [projectList, setProjectList] = useState([]);
  const [originProjectList, setOriginProjectList] = useState<any>([]);
  const [laoding, setLoading] = useState(true);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [openComfirmTipDialog, setOpenComfirmTipDialog] = useState(false);
  const [createFormVisible, setFormVisible] = useState(false);
  const [fabric, setFabric] = useState<any>();
  let canvasJson = useRef<any[]>([]);
  const dispatch = useDispatch()

  const { getTranslation } = useCustomTranslation();
  const [requestError, setRequestError] = useState(false);
  const [themeId, setThemeId] = useState<number>(40);
  const [style_type, setStyleType] = useState<number>(21);
  const designType = ['My Designs', 'Printed Designs'];
  const [typeIndex, setTypeIndex] = useState('My Designs');
  const [pageIndex, setPageIndex] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const typeIndexMap: { [key: string]: number | null } = {
    'My Designs': null,
    'Printed Designs': 1,
  };
  const typetagMap: { [key: number]: string } = {
    2: 'Light Panting',
    3: 'Brushstroke Maker',
    4: 'Relief Magnet',
    5: 'Texture Poster'
  }

  useEffect(() => {
    import('fabric').then(res => {
      setFabric(res.fabric);
    });
    getFetchFilters();
  }, []);

  const getFetchFilters = async () => {
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-home-filters',
      populate: [
        'icon',
        'subTitle.subIcon',
        'subTitle.itemTitle.itemIcon',
        'positions',
      ],
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'], // 按weight降序排列
    });
    const data = json?.data?.data;

    const themes = data?.filter((item: any) => item.attributes.name === "Themes");
    themes[0]?.attributes.subTitle.map((item: any, index: number) => {
      if (item.itemTitle.length > 0) {
        const data = item.itemTitle[0]?.id;
        console.log('--themeid----1', data)
        setThemeId(data);
        return true;
      }
      return false;
    });

    const styleTypes = data?.filter((item: any) => item.attributes.name === "Styles");
    styleTypes[0]?.attributes.subTitle.find((item: any, index: number) => {
      if (index === 0) {
        setStyleType(item.id);
        console.log('--style_type----1', item.id)
        return true;
      }
      return false;
    });
  }

  const onDialogClose = () => {
    setSubmitLoading(false);
  }

  const nextClick = () => {
    if (!selectProject?.works_id) {
      setOpenComfirmTipDialog(true);
    } else {
      handleNext(selectProject, false);
      cancelClick();
    }
  }

  const comfirm = () => {
    setOpenComfirmTipDialog(false);
    if (selectProject?.works_id) {
      setOpenComfirmTipDialog(true);
    } else {
      handleNext(selectProject, true);
      cancelClick();
    }
    return
  }


  // @ts-ignore;
  const mergeSceneImages = (scene, dataUrl: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      fabric.Image.fromURL(scene.scenesImg[scene.scenesImgSelect!], (sceneImg: any) => {
        const canvas = new fabric.StaticCanvas(null, { width: sceneImg.width, height: sceneImg.height });
        // 设置 scenesImg 图片的位置和大小
        sceneImg.scaleToWidth(sceneImg.width!);
        sceneImg.scaleToHeight(sceneImg.height!);
        sceneImg.set({
          left: 0,
          top: 0,
        });
        let skewData;
        if (scene.skewData && scene.skewData.length > 0) {
          skewData = JSON.parse(scene.skewData!)
        }
        if (skewData && skewData.rectPerspective) {
          let worker = new IMagickWorker();
          worker.onmessage = function (e: { data: any; }) {
            // 使用处理后的图像数据
            const base64 = e.data;
            fabric.Image.fromURL(base64, (dataImg: any) => {
              var left: number = scene.positionX!;
              var top: number = scene.positionY!;
              // 设置 dataUrl 图片的位置和大小
              dataImg.set({
                left: left * 100 / 100,
                top: top * 100 / 100,
                scaleX: scene.width / dataImg.width!,
                scaleY: scene.height / dataImg.height!,
                angle: scene.angle,
              });
              // 先添加 scenesImg，然后添加 dataUrl 图片
              canvas.add(sceneImg);
              canvas.add(dataImg);
              // 导出合成后的图片
              const mergedUrl = canvas.toDataURL();
              resolve(mergedUrl);
              // 清理画布
              canvas.dispose();
            }, {
              crossOrigin: 'anonymous',
              onError: (error: any) => {
                reject(error);
              }
            });
            worker.terminate();
            worker = null;
          };
          worker.postMessage({
            action: ACTION_MAGICK.ACTION_TYPE_DISTORT,
            data: {
              dataUrl: dataUrl, // 原始图像数据
              params: skewData.rectPerspective // 透视变换参数,
            }
          });
        }
        // ;
        else {
          // @ts-ignore;
          fabric.Image.fromURL(dataUrl, (dataImg) => {
            var left: number = scene.positionX!;
            var top: number = scene.positionY!;
            // 设置 dataUrl 图片的位置和大小
            dataImg.set({
              left: left * 100 / 100,
              top: top * 100 / 100,
              scaleX: scene.width / dataImg.width!,
              scaleY: scene.height / dataImg.height!,
              angle: scene.angle,
            });
            // 先添加 scenesImg，然后添加 dataUrl 图片
            canvas.add(sceneImg);
            canvas.add(dataImg);
            // 导出合成后的图片
            const mergedUrl = canvas.toDataURL();
            resolve(mergedUrl);
            // 清理画布
            canvas.dispose();
          }, {
            crossOrigin: 'anonymous',
            onError: (error: any) => {
              reject(error);
            }
          });
        }
      }, {
        crossOrigin: 'anonymous',
        onError: (error: any) => {
          reject(error);
        }
      });
    });
  }

  const timeAgo = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;

    const minute = 60 * 1000;
    const hour = 60 * minute;
    const day = 24 * hour;
    const year = 365 * day;

    if (diff < minute) {
      return `${Math.floor(diff / 1000)} seconds ago`;
    } else if (diff < hour) {
      return `${Math.floor(diff / minute)} minutes ago`;
    } else if (diff < day) {
      return `${Math.floor(diff / hour)} hours ago`;
    } else if (diff < year) {
      return `${Math.floor(diff / day)} days ago`;
    } else {
      return `${Math.floor(diff / year)} years ago`;
    }
  }

  const cancel = () => {
    if (!submitLoading) {
      cancelClick();
      setSubmitLoading(false);
    }
    setTypeIndex('My Designs');
    setChoseIndex(0);
    setSelectProject({});
  }

  const filterProjects = (projects: any) => {
    const filteredProjects = projects.filter((project: any) => {
      // 如果 is_edited 是 0 且 parent_works_id 不为空的话保留
      if (project.is_edited === 0) {
        return !["", null].includes(project.parents_works_id);
      }
      // 如果 is_edited 不是 0，则保留
      return true;
    }).filter((project: any) => {
      // 过滤 is_published 为 1 且 works_status 不为 1 的数据
      return !(project.is_published === 1 && project.works_status !== 1);
    });

    return filteredProjects;
  };

  // 获取设计数据
  const getFetchList = async () => {
    setLoading(true);
    const params = { pagination: { page: pageIndex, page_size: 20 }, 'is_get_works_status': true };
    const res = await fetchProjectList(params);
    setRequestError(false);
    if (res.code == 0) {
      if (res.data.project_list.length > 0) {
        setHasMore(res.data.project_list.length >= 20)
        if (res.data.project_list.length >= 20) {
          setPageIndex(pageIndex + 1);
        }
        const data = [...originProjectList, ...res.data.project_list];
        setOriginProjectList(data)
        // works_status 发布作品状态(1:上线 2:审核中 3:审核失败) 
        // 先过滤is_edited为0的数据 在这基础上如果is_published为1且works_status不为1的数据也过滤掉
        const dataList = filterProjects(data);
        setSelectProject(dataList[0]);
        setProjectList(dataList || []);
      }
      setLoading(false);
    } else {
      setRequestError(true);
      setLoading(false);
      dispatch(
        openToast({
          message: res.msg || getTranslation(TranslationsKeys.GET_DESIGN_LIST_FAILED),
          severity: 'error',
        }),
      )
    }

    setLoading(false)
  }

  useEffect(() => {
    open && originProjectList.length == 0 && getFetchList();
  }, [open])



  const getFirstDesign = () => {
    if (typeIndex == 'My Designs') {
      window.open('/apps/2dEditor/?popover=off', '_blank')
    } else {
      navigator('/');
    }
  }

  const selectProjectType = (type: string) => {
    const tempData = projectList.filter((item: any) => item.project_type == typeIndexMap[type]);
    setTypeIndex(type);
    setChoseIndex(0);
    setSelectProject(tempData[0]);
  }

  // 1:先过滤is_edited为0的数据 2:然后如果is_published为1且works_status不为1的数据也过滤掉
  const showData = typeIndexMap[typeIndex] === null
    ? projectList
    : projectList.filter((item: any) => item.parents_works_id !== '');
  console.log('---showData', showData)
  return (
    <>
      <Dialog
        className='__design_list_dialog'
        open={open}
        onClose={cancel}
      >
        <div className='formBox'>
          <p className='titleLine'>
            <span>{getTranslation(TranslationsKeys.CHOOSE_DESIGN)}</span>
            <img onClick={() => { setSubmitLoading(false); cancelClick(); }} src={closeIcon} alt="" />
          </p>
          {!laoding && <div className="designType">
            {designType.map(item => {
              return (
                <span
                  key={item}
                  onClick={() => selectProjectType(item)}
                  className={item === typeIndex ? 'activeTab' : 'defaultTab'}
                >
                  {item}
                </span>
              )
            })}
          </div>}
          {
            laoding && originProjectList.length == 0
              ?
              <div className="loading_div">
                <LottiePlayer
                  loop
                  play
                  style={{ width: 40, height: 40 }}
                  animationData={LoadingAnimation}
                />
              </div>

              :
              (showData || []).length == 0
                ?
                <div className="no_data_layout">
                  {
                    !requestError
                      ?
                      <>
                        <img src={emptyIcon} alt="" className="tip_icon" />
                        <p className='tip_des'>
                          {
                            typeIndex == 'My Designs' && originProjectList.length == 0 // 没有创建设计
                              ?
                              getTranslation(TranslationsKeys.HAVE_NO_DESIGN)
                              :
                              typeIndex == 'My Designs' && showData.length == 0 && originProjectList.length > 0 // 创建了设计但是没有编辑
                                ?
                                getTranslation(TranslationsKeys.HAVENT_ORIGN_DESIGN)
                                :
                                typeIndex == 'Printed Designs' && showData.length == 0 // 没有二创项目
                                  ?
                                  getTranslation(TranslationsKeys.HAVENT_DESIGN)
                                  :
                                  ''
                          }
                        </p>
                        <p className="btn" onClick={() => getFirstDesign()}>
                          {
                            typeIndex == 'My Designs' && originProjectList.length == 0 // 没有创建设计
                              ?
                              getTranslation(TranslationsKeys.UPLOAD_A_DESIGN)
                              :
                              typeIndex == 'My Designs' && showData.length == 0 && originProjectList.length > 0 // 创建了设计但是没有编辑
                                ?
                                getTranslation(TranslationsKeys.UPLOAD_A_DESIGN)
                                :
                                typeIndex == 'Printed Designs' && showData.length == 0 // 没有二创项目
                                  ?
                                  getTranslation(TranslationsKeys.GO_TO_PRINT)
                                  :
                                  ''
                          }
                        </p>
                      </>
                      :
                      <div>{getTranslation(TranslationsKeys.GET_DESIGN_FAILED)}</div>
                  }
                </div>
                :
                <ScrollMoreView2d
                  onLoadMore={() => getFetchList()}
                  hasMore={hasMore}
                  isLoading={laoding}
                >
                  <div className='proWrapper'>
                    {showData?.map((p, i) => {
                      return (
                        <div
                          key={p.project_id || i}
                          className={
                            'proItem' +
                            (i === choseIndex ? ' active' : '')
                          }
                          onClick={() => {
                            setChoseIndex(i);
                            setSelectProject(p);
                          }}
                        >
                          {p?.project_type !== 1 && <div className="typeTag">{typetagMap[p?.project_type]}</div>}
                          <img src={p?.thumb_file?.download_url || ''} />
                          <div className='desInfo'>
                            {p?.project_type !== 1 ? <p>{p?.project_name} <span className="projectIndex">{i + 1}</span></p> : <p>{p?.project_name}</p>}
                            <span>edited {timeAgo(p.create_time * 1000)}</span>
                          </div>
                        </div>
                      )
                    })
                    }
                  </div >
                </ScrollMoreView2d>
          }

          <div className='btnLine'>
            {/* <div className="bottom_des">If you choose an unpublished design, we will automatically create a design link for you, which you can manage in My Creation.</div> */}
            <div className="btn_group">
              <p onClick={() => cancel()} style={{ cursor: submitLoading ? '' : 'pointer' }} className="cancel_btn">{'Cancel'}</p>
              <p
                onClick={
                  ((showData.length > 0 && !submitLoading) || (showData.length > 0 && !requestError)) ? nextClick : () => { console.log(1) }
                }
                className="next_btn"
                style={{ backgroundColor: showData.length == 0 ? 'rgb(51 191 90 / 51%)' : '#33BF5A' }}
              >
                {!submitLoading ? getTranslation(TranslationsKeys.BUTTON_NEXT) : <img className="loading_img" src={loadingIcon} alt="" />}
              </p>
            </div >
          </div >
        </div >
      </Dialog >
      <Dialog
        className='__comfirm_tip_dialog'
        open={openComfirmTipDialog}
        onClose={onDialogClose}
      >
        <div className="dialog_box">
          <p className="tip_des">{getTranslation(TranslationsKeys.AUTO_PUBLISH_TIP)}</p>
          <div className="tip_btn">
            <p className="cancel" onClick={() => { setOpenComfirmTipDialog(false); }}>{getTranslation(TranslationsKeys.BUTTON_CANCEL)}</p>
            <p className="comfirm" onClick={() => comfirm()}>{getTranslation(TranslationsKeys.BUTTON_CONFIRM)}</p>
          </div>
        </div>
      </Dialog>
      <CreateForm
        visible={createFormVisible}
        toggleVisible={() => {
          setFormVisible(false)
        }}
      />
    </>
  );
}