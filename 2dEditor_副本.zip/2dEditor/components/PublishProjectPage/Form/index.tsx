
import React, { useEffect, useState, useImperativeHandle, forwardRef, useRef } from 'react';
import axios from 'axios';

// component
import { Form } from 'src/components/MakeUI';
import CustomMutiSelect from 'src/components/CustomMutiSelect';
import Loading from 'src/components/Loading';
import EditText from './RichTextEditor/index';
import DesignListDialog from './DesignListDialog/index';
import CustomTagInput from 'src/components/CustomTagInput';
import { openToast } from 'src/state/reducers/toast'
import { useDispatch } from "react-redux"

// utils
import DOMPurify from 'dompurify';
import { blobToBase64 } from 'src/common/utils';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import { dataURItoFile, compressorImage } from 'src/common/utils';
import { getCanvasThumbnail } from 'src/templates/2dEditor/common/cavasUtil';
import { jsonToZipFile } from "src/common/utils";
import { upload2dEditFile } from "src/hooks/useUpload";
import { v4 as uuid } from 'uuid';
import { CanvasesResInfo, ProjectModel } from 'src/templates/2dEditor/components/SelectDialog/model/ProjectModel';
import { useCanvasEditor, useProjectData, useFabric } from 'src/templates/2dEditor/hooks/context';
import ProjectManager from 'src/templates/2dEditor/utils/ProjectManager';
// @ts-ignore
import IMagickWorker from 'src/templates/2dEditor/core/worker/imagick.worker';
import { FabricObjectType, WorkspaceID, ACTION_MAGICK, } from 'src/templates/2dEditor/cons/2dEditorCons';
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';

// services
import { get } from 'src/services';
import { fetchProjectList } from 'src/templates/Home/services';
import { getLpProjectDetail } from 'src/templates/LightPainting/services';
import { publish, getProjectDetail } from 'src/templates/2dEditor/service/2dEditService';
import { GetUpTokenFileTypeEnum } from 'src/services';
import { getCraftProjectDetail } from 'src/templates/FridgeMagnet/GenerateAndPrint/services';

// style
import './index.scss';

// icon
import addFileIcon from 'src/assets/svg/zoom_in.svg';
import rubbishIcon from 'src/assets/svg/rubbish.svg';
import dropdownIcon from 'src/assets/svg/arrow_down.svg';


const Index = forwardRef((props: any, ref) => {
  const { designDetalis, disabeld } = props;

  const dispatch = useDispatch()

  const [form] = Form.useForm();
  const [doSubmitFlag, setDoSubmitFlag] = useState(false);
  const [projectName, setProjectName] = useState('');
  const [materialSelectData, setMaterialSelectData] = useState([] as any[]);
  const [themesSelectData, setThemesSelectData] = useState([] as any[]);
  const [printImages, setPrintImages] = useState<any[]>([]);
  const [picture, setPicture] = useState<any[]>([]);
  const [relatedWorks, setRelatedWorks] = useState<any>(''); // 4158fde16ad870251c82c4626485cda2
  const [uploadFile, setUploadFile] = useState<any>([]);
  const [tags, setTags] = useState<any[]>([]);
  const [designLinkFile, setDesignLinkFile] = useState<any>(null);
  const [designLinkName, setDesignLinkName] = useState<any>(null);
  const [description, setDescription] = useState<any>('');
  const [showMaterialSelectOptions, setShowMaterialSelectOptions] = useState(false);
  const [showThemesSelectOptions, setShowThemesSelectOptions] = useState(false);
  const [openDesignList, setOpenDesignList] = useState(false);
  const [materialOption, setMaterialOption] = useState([]);
  const [categoriesOption, setCategoriesOption] = useState([]);
  const [themesOption, setThemesOption] = useState([]);
  const [showCategoriesSelectOptions, setShowCategoriesSelectOptions] = useState(false);
  const { getTranslation } = useCustomTranslation();
  const [subCategory, setSubCategory] = useState('');
  const [subCategoryName, setSubCategoryName] = useState('');
  const [categoryType, setCategoryType] = useState();
  const [selectDesginFile, setSelectDesginFile] = useState({} as any);
  const [style_type, setStyleType] = useState<number>(21);
  let canvasJson = useRef<any[]>([]);
  let canvasEditor: any = useRef<any>(useCanvasEditor());
  let projectData = useRef<ProjectModel | null>(useProjectData());
  const [fabric, setFabric] = useState<any>();
  const [isAutoPublish, setIsAutoPublished] = useState(false);

  // 点击空白处隐藏下拉框
  const handleFromDocClick = () => {
    setShowMaterialSelectOptions(false);
    setShowThemesSelectOptions(false);
    setShowCategoriesSelectOptions(false);
  }

  // 供父组件调用
  useImperativeHandle(ref, () => ({
    submitFormData: async () => {
      const { project_type, project_id, project_name } = selectDesginFile;
      setDoSubmitFlag(true);
      console.log('--isAutoPublish', isAutoPublish)
      if (isAutoPublish) { // 需要自动发布设计
        const getdetail = project_type === 1 ? getProjectDetail : project_type == 2 ? getLpProjectDetail : getCraftProjectDetail;
        const res = await getdetail({ project_id });
        if (res?.code == 0) {
          if ([2, 3, 4, 5].includes(project_type)) { // 自动发布工艺设计 -- 灯光画/笔触画/冰箱贴/海报

            const _tempThemeDataName = themesSelectData.map((item: any) => item.label).join(',');
            const _tempMaterialDataName = materialSelectData.map((item: any) => item.label).join(',');

            let params = {
              works_type: 1,
              works_canvas_infos: [{
                canvas_id: '1',
                category: categoryType?.id || 0,
                is_standard_product: 2,
                sub_category: subCategory,
                scenes_images: [],
                project_template_path: '',
                thumb_image: ''
              }],
              cover_tiny: '',
              project_id,
              name: project_name,
              category: categoryType?.id,
              sub_category: subCategory,
              theme: themesSelectData.map(item => item.id),
              style_type: [style_type],
              allow_remix: 1,
              commercial: 3,
              license: 9,
              description: '',
              tags: [],
              ai_category: [],
              exclusive: 1,
              category_value: `${categoryType?.label},${subCategoryName},${_tempMaterialDataName},${_tempThemeDataName}`
            } as any;

            const imageUrl = [
              res?.data?.project_info?.thumb_file?.download_url,
              res?.data?.project_info?.thumb_file?.download_url,
              // res?.data?.canvas?.project_file?.download_url
            ];
            const downloadUrl = res?.data?.canvas?.project_file?.download_url;
            const projectFileName = res?.data?.canvas?.project_file?.file_name;

            try {
              const result = await downloadAndUploadFile(downloadUrl, projectFileName);
              console.log('Process completed:', result);
              if (result) {
                params.works_canvas_infos[0].project_template_path = result;
              }
            } catch (error) {
              console.error('Error processing file:', error);
            }
            const thumbFileName = res?.data?.project_info?.thumb_file?.file_name;
            const imageResults = await Promise.all(imageUrl.map((url) => getCoverTiny(url, thumbFileName)));
            imageResults.forEach((item, index) => {
              if (index === 0) {
                params.cover_tiny = item;
              } else if (index === 1) {
                params.works_canvas_infos[0].thumb_image = item;
              }
            });
            // 发布设计
            const publishRes = await publish(params);
            if (publishRes && publishRes.code !== 0) {
              dispatch(openToast({
                message: publishRes.msg,
                severity: 'error',
              }));
              return null;
            } else {
              const projectListRes = await fetchProjectList({ pagination: { page: 1, page_size: 20 }, 'is_get_works_status': true });
              if (projectListRes.code !== 0) {
                dispatch(openToast({
                  message: projectListRes.msg,
                  severity: 'error',
                }));
                return;
              }
              const indexId = project_id;
              const list = projectListRes.data.project_list.filter(item => item.project_id == indexId);

              const _tempThemeDataName = themesSelectData.map((item: any) => (item.itemName || item.label)).join(',');
              const _tempMaterialDataName = materialSelectData.map((item: any) => item.label).join(',');

              // 发布project参数
              const finalParams = {
                'works_type': 2, // 1是design，2是project
                'name': projectName,
                'material': materialSelectData.map(item => item.id),
                'theme': themesSelectData.map(item => item.id),
                'tags': tags,
                'description': description,
                'related_works': list[0]?.works_id,
                'uploadFile': uploadFile,
                'category': categoryType?.id || '',
                'sub_category': subCategory,
                'category_value': `${categoryType?.label},${subCategoryName},${_tempMaterialDataName},${_tempThemeDataName}`
              };
              if (!projectName || materialSelectData.length == 0 || themesSelectData.length == 0 || uploadFile.length == 0 || !description || !subCategory || !list[0]?.works_id) {
                return null;
              }
              return finalParams;
            }

          } else {
            // 自动发布普通设计（2d编辑器的项目）
            try {
              //  @ts-ignore
              projectData.current = res?.data;
              //  @ts-ignore
              const data = res?.data?.canvases;
              console.log('---data -- canvases', data);

              const workCanvasInfo = await Promise.all(data.map((canvasData: any, index: number) => getWorkCanvasInfo(canvasData, index)));
              console.log('---workCanvasInfo', workCanvasInfo);

              const workCanvasInfoResult = await fillWorkCanvasInfo(workCanvasInfo);
              console.log('--workCanvasInfoResult', workCanvasInfoResult);
              const fileUrl = data[0]?.thumb_file?.download_url;
              const fileName = data[0]?.thumb_file?.file_name;
              const coverTiny = await getCoverTiny(fileUrl, fileName);

              const _tempThemeDataName = themesSelectData.map((item: any) => item.label).join(',');
              const _tempMaterialDataName = materialSelectData.map((item: any) => item.label).join(',');

              const params = {
                works_type: 1,
                works_canvas_infos: workCanvasInfoResult,
                project_id,
                name: project_name,
                category: categoryType?.id,
                theme: themesSelectData.map(item => item.id),
                style_type: [style_type],
                cover_tiny: coverTiny,
                allow_remix: 1,
                commercial: 3,
                license: 9,
                description: '',
                tag_ids: [],
                ai_category: [],
                sub_category: subCategory,
                exclusive: 1,
                category_value: `${categoryType?.label},${subCategoryName},${_tempMaterialDataName},${_tempThemeDataName}`
              } as any;
              // 发布设计
              const publishRes = await publish(params);
              // @ts-ignore
              if (publishRes.code !== 0) {
                dispatch(openToast({
                  message: publishRes?.msg || getTranslation(TranslationsKeys.IS_ERROR),
                  severity: 'error',
                }));
                return null;
              }

              const projectListRes = await fetchProjectList({ pagination: { page: 1, page_size: 20 }, 'is_get_works_status': true });
              if (projectListRes.code !== 0) return null;

              const indexId = project_id;
              const list = projectListRes.data.project_list.filter((item: any) => item.project_id == indexId);
              console.log('---list', list);

              // 发布project参数
              const finalParams = {
                'works_type': 2, // 1是design，2是project
                'name': projectName,
                'material': materialSelectData.map(item => item.id),
                'theme': themesSelectData.map(item => item.id),
                'tags': tags,
                'description': description,
                'related_works': list[0]?.works_id,
                'uploadFile': uploadFile,
                'category': categoryType?.id || '',
                'sub_category': subCategory,
                'category_value': `${categoryType?.label},${subCategoryName},${_tempMaterialDataName},${_tempThemeDataName}`
              };


              if (!projectName || materialSelectData.length == 0 || themesSelectData.length == 0 || uploadFile.length == 0 || !description || !subCategory || !list[0]?.works_id) {
                return null;
              }

              return finalParams;
            } catch (err) {
              dispatch(openToast({
                message: err?.msg || getTranslation(TranslationsKeys.ERROR_OCCURRED),
                severity: 'error',
              }));
              return null;
            }
          };
        }
      } else {
        // 发布project参数
        const _tempThemeDataName = themesSelectData.map((item: any) => (item.itemName || item.label)).join(',');
        const _tempMaterialDataName = materialSelectData.map((item: any) => item.label).join(',');

        const params = {
          'works_type': 2, // 1是design，2是project
          'name': projectName,
          'material': materialSelectData.map(item => item.id),
          'theme': themesSelectData.map(item => item.id),
          'tags': tags,
          'description': description,
          'related_works': relatedWorks,
          'uploadFile': uploadFile,
          'category': categoryType?.id || '',
          'sub_category': subCategory,
          'category_value': `${categoryType?.label},${subCategoryName},${_tempMaterialDataName},${_tempThemeDataName}`
        };

        // return
        if (!projectName || materialSelectData.length == 0 || themesSelectData.length == 0 || uploadFile.length == 0 || !description || !subCategory || !relatedWorks) {
          return null;
        }
        console.log('---params', params)
        return params
      }
    },
    handleFromDocClick: handleFromDocClick,
    handlePrintPhotoUpload: handlePrintPhotoUpload,
  }));

  const getCoverTiny = async (url: string, fileName: string) => {
    // const url = data?.thumb_file?.download_url || data;
    // if (!url) return '';
    // console.log('---url', data)
    console.log('-----url', url, 'fileName', fileName)
    try {
      const getFile = await fetch(url);
      const blob = await getFile.blob() as any;
      const compressedBlob = await compressorImage(blob);
      console.log('---compressedBlob.name', compressedBlob.name)
      const imageType = compressedBlob?.type?.indexOf('/') !== -1 ? compressedBlob?.type?.slice(compressedBlob?.type?.indexOf('/') + 1) : 'webp';

      let fileToUpload: File;
      if (compressedBlob instanceof Blob) {
        fileToUpload = new File([compressedBlob], (compressedBlob.name || fileName), { type: compressedBlob.type });
      } else {
        fileToUpload = compressedBlob;
      }
      const uploadResult = await upload2dEditFile(fileToUpload, GetUpTokenFileTypeEnum.PublishProject);
      console.log('---uploadResult', uploadResult)
      return uploadResult?.key_prefix;
    } catch (error) {
      console.error(error);
      return '';
    }
  };

  const getWorkCanvasInfo = (canvasData: CanvasesResInfo, index: number) => {
    return new Promise((resolve, reject) => {
      getMergeImages(canvasData, index)
        .then((data: any) => {
          if (!data) {
            reject();
          };
          return getMergeImagesUploadData(data);
        })
        .then((data: any) => {
          if (!data) {
            reject();
          };
          getCanvasThumbnail(data.tempCanvas).then((dataRet: any) => {
            const imageFile = dataURItoFile(dataRet.dataUrl, uuid());
            return upload2dEditFile(imageFile, 1020)
          })
            .then((thumbUploadImage) => {
              const workCanvasInfo = {
                canvas_id: canvasData.canvas_id,
                category: canvasData.category,
                sub_category: canvasData.sub_category,
                scenes_images: data!.margeImages ? (data!.margeImages as string[]).map((item: any) => item.key_prefix) : [],
                is_standard_product: canvasData.is_standard_product,
                thumb_image: thumbUploadImage.key_prefix,
                // project_template_path,
              };
              resolve(workCanvasInfo);
            });
        }).catch(err => {
          // setSubmitLoading(false);
        })
    })
  }

  const getMergeImages = (canvasData: CanvasesResInfo, index: number) => {
    return new Promise((resolve, reject) => {
      const scenes: any[] = [];
      canvasJson.current = [];
      try {
        if (canvasEditor.current && projectData.current?.canvasesIndex == index) {
          const dataJson = JSON.stringify(canvasEditor.current.getJson());
          canvasJson.current.push(dataJson);
          getMergeImagesGenerate(canvasData, scenes, dataJson).then(resolve).catch(reject);
        } else {
          ProjectManager.getInstance().getProjectJson(projectData.current!, index).then((json: any) => {
            if (!json) return;
            canvasJson.current.push(json);
            getMergeImagesGenerate(canvasData, scenes, json).then(resolve).catch(reject);
          }).catch(err => {
            console.log('=====getProjectJson', err)
            // setSubmitLoading(false);
          });
        }
      } catch (error) {
        console.log('handlePublish mergeImage; ERROR 2:', error);
        reject();
      }
    });
  }

  const getMergeImagesGenerate = (canvasData: CanvasesResInfo, scenes: any[], json: any) => {
    return new Promise((resolve, reject) => {
      if (!json) return;
      const tempCanvas = new fabric.StaticCanvas(null, {
        width: canvasData.base_map_width || 0,
        height: canvasData.base_map_height || 0
      });
      tempCanvas.loadFromJSON(json, () => {
        tempCanvas.renderAll.bind(tempCanvas);
        preview(false, tempCanvas)
          .then((base64: any) => {
            Promise.all(scenes.map((scene: any) => {
              scene['scenesImgSelect'] = 0;
              return mergeSceneImages(
                scene,
                base64
              )
            })).then(margeImages => {
              console.log('margeImages;', margeImages);
              var data = {
                margeImages: margeImages,
                tempCanvas: tempCanvas,
              }
              resolve(data);
            }).catch(error => {
              console.log(error);
              reject();
            });
          })
          .catch(error => {
            console.log(error);
          })
      });
    });
  }

  const mergeSceneImages = (scene: any, dataUrl: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      fabric.Image.fromURL(scene.scenesImg[scene.scenesImgSelect!], (sceneImg: any) => {
        const canvas = new fabric.StaticCanvas(null, { width: sceneImg.width, height: sceneImg.height });
        // 设置 scenesImg 图片的位置和大小
        sceneImg.scaleToWidth(sceneImg.width!);
        sceneImg.scaleToHeight(sceneImg.height!);
        sceneImg.set({
          left: 0,
          top: 0,
        });
        let skewData;
        if (scene.skewData && scene.skewData.length > 0) {
          skewData = JSON.parse(scene.skewData!)
        }
        if (skewData && skewData.rectPerspective) {
          let worker = new IMagickWorker();
          worker.onmessage = function (e: { data: any; }) {
            // 使用处理后的图像数据
            const base64 = e.data;
            fabric.Image.fromURL(base64, (dataImg: any) => {
              var left: number = scene.positionX!;
              var top: number = scene.positionY!;
              // 设置 dataUrl 图片的位置和大小
              dataImg.set({
                left: left * 100 / 100,
                top: top * 100 / 100,
                scaleX: scene.width / dataImg.width!,
                scaleY: scene.height / dataImg.height!,
                angle: scene.angle,
              });
              // 先添加 scenesImg，然后添加 dataUrl 图片
              canvas.add(sceneImg);
              canvas.add(dataImg);
              // 导出合成后的图片
              const mergedUrl = canvas.toDataURL();
              resolve(mergedUrl);
              // 清理画布
              canvas.dispose();
            }, {
              crossOrigin: 'anonymous',
              onError: (error: any) => {
                reject(error);
              }
            });
            worker.terminate();
            worker = null;
          };
          worker.postMessage({
            action: ACTION_MAGICK.ACTION_TYPE_DISTORT,
            data: {
              dataUrl: dataUrl, // 原始图像数据
              params: skewData.rectPerspective // 透视变换参数,
            }
          });
        }
        // ;
        else {
          // @ts-ignore;
          fabric.Image.fromURL(dataUrl, (dataImg) => {
            var left: number = scene.positionX!;
            var top: number = scene.positionY!;
            // 设置 dataUrl 图片的位置和大小
            dataImg.set({
              left: left * 100 / 100,
              top: top * 100 / 100,
              scaleX: scene.width / dataImg.width!,
              scaleY: scene.height / dataImg.height!,
              angle: scene.angle,
            });
            // 先添加 scenesImg，然后添加 dataUrl 图片
            canvas.add(sceneImg);
            canvas.add(dataImg);
            // 导出合成后的图片
            const mergedUrl = canvas.toDataURL();
            resolve(mergedUrl);
            // 清理画布
            canvas.dispose();
          }, {
            crossOrigin: 'anonymous',
            onError: (error: any) => {
              reject(error);
            }
          });
        }
      }, {
        crossOrigin: 'anonymous',
        onError: (error: any) => {
          reject(error);
        }
      });
    });
  }

  const preview = (is3dPre: boolean, canvas: fabric.Canvas) => {
    return new Promise((resolve, reject) => {
      const currentCanvas = canvas;
      console.log('currentCanvas;', currentCanvas);
      const workspace = currentCanvas.getObjects().find((item) => item.id === WorkspaceID.WorkspaceCavas);
      var bgWidth = workspace?.width;
      var bgHeight = workspace?.height;
      const baseLayer = workspace;
      // 检查baseLayer是否为fabric.Image类型
      if (baseLayer) {
        // 获取底图的DataURL
        const baseImageDataUrl = baseLayer.toDataURL({
          format: 'png',
          left: 0,
          top: 0,
          width: bgWidth,
          height: bgHeight
        });

        // 创建一个离屏Canvas
        const offscreenCanvas = document.createElement('canvas');
        offscreenCanvas.width = bgWidth!;
        offscreenCanvas.height = bgHeight!;
        const offscreenCtx = offscreenCanvas.getContext('2d');
        // 确保离屏Canvas的上下文存在
        // 手动绘制除底层以外的图层
        currentCanvas.getObjects().forEach((obj, index) => {
          if (obj.id && !(obj.id as string).includes(WorkspaceID.WorkspaceCavas)) {
            obj.render(offscreenCtx!);
          } else if (!obj.id) {
            obj.render(offscreenCtx!);
          }
        });
        // 导出离屏Canvas的图像数据
        const otherLayersDataUrl = offscreenCanvas.toDataURL('image/png');

        // 创建一个新的canvas元素
        const finalCanvas = document.createElement('canvas');
        finalCanvas.width = bgWidth!;
        finalCanvas.height = bgHeight!;
        const ctx = finalCanvas.getContext('2d');

        if (ctx) {
          // 加载底图
          const baseImage = new Image();
          baseImage.onload = () => {
            // 绘制底图
            ctx.drawImage(baseImage, 0, 0, bgWidth!, bgHeight!);
            // 设置合成模式为source-in
            ctx.globalCompositeOperation = 'source-in';
            // 加载其他图层的图像
            const otherLayersImage = new Image();
            otherLayersImage.onload = () => {
              // 在底图上绘制其他图层的图像
              ctx.drawImage(otherLayersImage, 0, 0, bgWidth!, bgHeight!);

              setTimeout(() => {
                // 导出最终的图片
                var dataURL: unknown;
                if (is3dPre && bgWidth && bgHeight) {
                  const tempCanvas = document.createElement('canvas');
                  tempCanvas.width = bgWidth;
                  tempCanvas.height = bgHeight;
                  const ctx = tempCanvas.getContext('2d');
                  // 设置背景为白色，填充整个 Canvas
                  if (!ctx) return;
                  ctx.fillStyle = 'white';
                  ctx.fillRect(0, 0, bgWidth, bgHeight);
                  // 将原始 Canvas 绘制到临时 Canvas 上
                  ctx.drawImage(finalCanvas, 0, 0, bgWidth, bgHeight);
                  // 导出最终的图片
                  dataURL = tempCanvas.toDataURL('image/jpeg');
                } else {
                  dataURL = finalCanvas.toDataURL();
                }
                // 输出最终的图片
                resolve(dataURL);
              }, 0);
            };
            otherLayersImage.src = otherLayersDataUrl;
          };
          baseImage.src = baseImageDataUrl;
        }
      }
    });
  }

  const getMergeImagesUploadData = (dataRet: any) => {
    var mergeImages: string[] = dataRet.margeImages;
    return new Promise((resolve, reject) => {
      if (!mergeImages || mergeImages.length === 0) {
        resolve(dataRet);
        return;
      }
      const uploadData = mergeImages.map((imageBase64) => {
        const imageFile = dataURItoFile(imageBase64, uuid());
        return upload2dEditFile(imageFile, 1020)
      });
      Promise.all(uploadData).then((uploadResults) => {
        var data = {
          margeImages: uploadResults,
          tempCanvas: dataRet.tempCanvas,
        }
        resolve(data);
      }).catch(error => {
        reject();
      });
    })
  }

  const fillWorkCanvasInfo = (workCanvasInfos: any[]) => {
    return new Promise((resolve, reject) => {
      resolve(Promise.all(workCanvasInfos.map((workCanvasInfo, index: number) => {
        var json = canvasJson.current[index]
        const removeKeyprefixJson = removeJsonKeyprefix(json);
        return jsonToZipFile(removeKeyprefixJson, 'project.json', 'project.zip')
          .then((zipFile: File) => {
            // console.log('zipFile;', zipFile);
            // 1020 发布作品;
            return upload2dEditFile(zipFile, 1020).then((uploadResult) => {
              console.log('uploadResult;', uploadResult);
              workCanvasInfo.project_template_path = uploadResult.key_prefix;
              console.log('workCanvasInfo;', workCanvasInfo);
              return workCanvasInfo;
            })
          })
      })));
    });
  }

  const removeJsonKeyprefix = (json: string) => {
    const tempJson = JSON.parse(json);
    const deleteKeyprefix = (object: any) => {
      if (object.type === FabricObjectType.Group) {
        object.objects.forEach((item: any) => {
          deleteKeyprefix(item);
        })
      } else {
        if (object.key_prefix) delete object.key_prefix;
      }
    };
    tempJson.objects.forEach((object: any) => {
      deleteKeyprefix(object);
    });
    console.log('tempJson;', tempJson);
    return JSON.stringify(tempJson);
  }

  const handlePrintPhotoUpload = async (files: FileList, index: number, e?: React.ChangeEvent<HTMLInputElement>) => {

    const file = files[0];
    const fileSize = file?.size || 0;
    const defaultSize = 50 * 1024 * 1024;

    if (file.name && file.name.split('.')[0].length > 50) {
      dispatch(openToast({
        message: getTranslation(TranslationsKeys.LIMIT_IMAGE_NAMELENGTH),
        severity: 'error',
      }))
      if (e) { // 避免input多次上传同一张图片的时候不显示
        e.target.value = '';
      }
      return;
    }
    if (fileSize > defaultSize) {
      dispatch(openToast({
        message: getTranslation(TranslationsKeys.IMAGRLIMITSZIETIP),
        severity: 'error',
      }));
      if (e) {
        e.target.value = '';
      }
      return;
    }
    console.log('==1111', file)
    if (!file) return;
    if (index == 0) {
      const newUploadFile = [...uploadFile];
      newUploadFile[0] = files[0];
      setUploadFile(newUploadFile);
    } else {
      setUploadFile((prev: any) => {
        const newUploadFile = [...prev];
        newUploadFile[index] = files[0];
        return newUploadFile;
      });
    }

    await blobToBase64(file).then(res => {
      if (index == 0) {
        printImages[0] = res;
        setPrintImages([...printImages]);
      } else {
        setPrintImages([...printImages, res]);
      }
    })

    if (e) {
      e.target.value = '';
    }
  }

  const deletePrintImage = (item: any, index: number) => {
    const _index = index + 1;
    const tempImage = printImages.filter((_, i) => i !== _index);
    setPrintImages(tempImage);
    const tempPicture = picture.filter((_, i) => i !== _index);
    setPicture(tempPicture);
    const tempUplaodFile = uploadFile.filter((_, i) => i !== _index);
    setUploadFile(tempUplaodFile);
  }

  const sanitizeInput = (value: string) => {
    // 允许的字符：字母、数字、空格和中文字符
    const allowedChars = /^[a-zA-Z0-9\s\u4e00-\u9fa5]*$/;
    return value.split('').filter(char => allowedChars.test(char)).join('');
  }

  const handleProjectName = (value: string, maxLength = 50) => {
    // let _value = value.replace(/\s/g, '')
    const sanitizedInput = sanitizeInput(value);
    const tempVlaue = sanitizedInput.slice(0, maxLength);
    console.log('==tempVlaue', tempVlaue)
    setProjectName(tempVlaue);
  }

  // 点击选项展示下拉框
  const handleInputClick = (formIndex?: string) => {
    setShowMaterialSelectOptions(formIndex == 'material');
    setShowCategoriesSelectOptions(formIndex == 'categories')
    setShowThemesSelectOptions(formIndex == 'themes');
  }

  // 多选框删除选中值
  const deleteItem = (formIndex: string, data: any) => {
    const formMap: Record<string, React.Dispatch<React.SetStateAction<any[]>>> = {
      'material': setMaterialSelectData,
      // 'categories': setCategoriesSelectData,
      'themes': setThemesSelectData,
    };

    const setData = formMap[formIndex];
    if (setData) {
      setData(prevData => prevData.filter((item: any) => item.id !== data.id));
    }
  }

  // 设置选中值
  const handleMutiSelectItem = (formIndex: string, data: any) => {

    const toggleSelectData = (selectData: any[], setSelectData: (data: any[]) => void) => {
      const index = selectData.findIndex((i: any) => i.id === data.id);
      if (index !== -1) {
        const newSelectData = [...selectData];
        newSelectData.splice(index, 1);
        setSelectData(newSelectData);
      } else {
        setSelectData([...selectData, data]);
      }
    };

    switch (formIndex) {
      case 'material':
        toggleSelectData(materialSelectData, setMaterialSelectData);
        // 事件埋点
        StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.project_material, data.id);
        break;
      case 'categories':
        // toggleSelectData(categoriesSelectData, setCategoriesSelectData);
        break;
      case 'themes':
        toggleSelectData(themesSelectData, setThemesSelectData);
        // 事件埋点
        StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.project_theme, data.id);
        break;
      default:
        break;
    }
  }

  const handlerCategoriesSelect = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    e.stopPropagation();
    !disabeld && setShowCategoriesSelectOptions(!showCategoriesSelectOptions);
    setShowThemesSelectOptions(false);
  }

  const richTextEdit = (data: any) => {
    setDescription(data)
  }

  const getFetchFilters = async () => {
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-home-filters',
      populate: [
        'icon',
        'subTitle.subIcon',
        'subTitle.itemTitle.itemIcon',
        'positions',
      ],
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'],
    });
    const data = json?.data?.data;

    const categorys = data?.filter((item: any) => item.attributes.name === "Categories");
    const tempCategorys = categorys[0]?.attributes.subTitle.map((item: any) => {
      let child = item?.itemTitle?.map((i: any) => {
        return {
          id: i.id,
          label: i.itemName,
        }
      })
      return {
        id: item.id,
        label: item.subName,
        children: child || []
      }
    });
    setCategoriesOption(tempCategorys);

    const themes = data?.filter((item: any) => item.attributes.name === "Themes");
    console.log('--themes', themes)
    const tempThemes = themes[0]?.attributes.subTitle.map((item: any) => {
      let child = item?.itemTitle?.map((i: any) => {
        return {
          id: i.id,
          label: i.itemName,
        }
      })
      return {
        id: item.id,
        label: item.subName,
        children: child || []
      }
    });
    setThemesOption(tempThemes);

    const material = data?.filter((item: any) => item.attributes.name === "Materials");
    const tempMaterial = material[0]?.attributes.subTitle.map((item: any) => {
      return {
        id: item.id,
        label: item.subName,
      }
    });
    setMaterialOption(tempMaterial);

    const styleTypes = data?.filter((item: any) => item.attributes.name === "Styles");
    styleTypes[0]?.attributes.subTitle.find((item: any, index: number) => {
      if (index === styleTypes[0]?.attributes.subTitle.length - 1) {
        setStyleType(item.id);
        console.log('--style_type----1', item)
        return true;
      }
      return false;
    });

    // 详情编辑的时候用到
    if (designDetalis && Object.keys(designDetalis).length > 0) {
      const { name, pictures, category, sub_category, theme, material, tags, description } = designDetalis;
      setProjectName(name);
      setDescription(description);
      setPrintImages(pictures);

      if (pictures.length > 0) {
        pictures.map(item => {
          getUrlToFile(item).then(file => {
            // @ts-ignore
            setUploadFile((prev: any) => [...prev, file]);
          })
        });
      }

      const categoryType = tempCategorys?.find((item: any) => item.id === category);
      console.log('categoryType', categoryType)
      setCategoryType(categoryType);
      setSubCategory(sub_category);
      const subCategoryType = categoryType?.children?.find((item: any) => item.id == sub_category)
      console.log('==subCategoryType', subCategoryType)
      setSubCategoryName(subCategoryType?.label || '')

      if (theme.length > 0) {
        const tempThemes = themes[0]?.attributes?.subTitle || [];
        let tempThemeName: any[] = [];
        const themeSet = new Set(theme);
        tempThemes.forEach((subTheme: any) => {
          subTheme.itemTitle.forEach((item: any) => {
            if (themeSet.has(item.id)) {
              console.log('======', item)
              tempThemeName.push(item);
            }
          });
        });
        setThemesSelectData(tempThemeName);

      }
      if (material.length > 0) {
        let tempMaterialName: any[] = [];
        material.forEach((i: any) => {
          const foundMaterial = tempMaterial?.find((item: any) => item.id === i);
          if (foundMaterial) tempMaterialName.push(foundMaterial);
        });
        setMaterialSelectData(tempMaterialName);
      }

      if (tags.length > 0) {
        // 过滤掉空字符串的值
        const tempTags = tags.filter((item: any) => item !== '');
        setTags(tempTags);
      }
    }
  }

  const getUrlToFile = async (url: string) => {
    let fileType = 'png', fileName = `uplaodFile.png`;
    // jpg,.png,.webp,.gif
    const regex = /\/([^\/?#]+)\.(png|webp|gif|jpg)(?=[?#]|$)/i;
    const match = url.match(regex);
    console.log('==match', match)
    if (match) {
      fileName = match[0].split('/')[1];
      fileType = match[2];
    }
    console.log('----url', url)
    console.log('==fileType', fileType, 'fileName', fileName)
    try {
      const response = await fetch(url);
      if (!response.ok) {
        // throw new Error(`HTTP error! status: ${response.status}`);
        console.log(`HTTP error! status: ${response.status}`);
      }
      const blob = await response.blob();
      const file = new File([blob], fileName, { type: fileType });
      return file;
    } catch (error) {
      console.error('Fetch error:', error);
    }
  }

  async function downloadAndUploadFile(downloadUrl: any, fileName: string) {
    try {
      if (!downloadUrl) {
        throw new Error('Download URL not found');
      }

      // 下载文件
      const response = await axios.get(downloadUrl, { responseType: 'blob' });
      const file = new File([response.data], fileName, { type: response.headers['content-type'] });
      console.log('--file', file)
      const uploadResponse = await upload2dEditFile(file, 1020);
      console.log('File uploaded successfully:', uploadResponse);
      return uploadResponse?.key_prefix;

    } catch (error) {
      console.error('Error downloading or uploading file:', error);
      throw error;
    }
  }


  const selectFileHandle = (data: any, isAutoPublished: boolean) => {
    setDesignLinkFile(data?.thumb_file?.download_url);
    setDesignLinkName(data?.project_name);
    setSelectDesginFile(data)
    setIsAutoPublished(isAutoPublished)
    // 发布设计后获取到的works_id
    data?.works_id && setRelatedWorks(data?.works_id)
  }

  const deleteFileLink = () => {
    setDesignLinkFile(null);
    setDesignLinkName(null);
  }

  useEffect(() => {
    getFetchFilters();
    if (Object.keys(designDetalis).length > 0) {
      getProjectList()
    }
  }, [designDetalis])

  useEffect(() => {
    import('fabric').then(res => {
      setFabric(res.fabric);
    });
  }, [])

  const getProjectList = async () => {
    fetchProjectList({ pagination: { page: 1, page_size: 20 }, 'is_get_works_status': true }).then((res: any) => {
      if (res?.data?.project_list) {
        const list = res?.data?.project_list.filter((item: any) => item.works_id == designDetalis?.related_works);
        const data = {
          thumb_file: list[0]?.thumb_file,
          project_name: list[0]?.project_name,
          works_id: designDetalis?.related_works
        }
        selectFileHandle(data, false);
      }
    })
  }

  //categories 下拉选项
  const renderOptions = (options: any[], level = 1, parentItem = null) => {
    return options.map((item: any) => (
      <React.Fragment key={`${level}-${item.id}`}>
        <li
          className={subCategory === item.id ? 'bgc_gray' : ''}
          onClick={(e) => {
            e.stopPropagation();
            if (level !== 1) {
              setSubCategoryName(item.label);
              setSubCategory(item?.id);
              parentItem && setCategoryType(parentItem);
              setShowCategoriesSelectOptions(false);
            }
          }}
          style={{ paddingLeft: `${level * 20}px` }}
        >
          <p>{item.label}</p>
        </li>
        {item.children && renderOptions(item.children, level + 1, level === 1 ? item : parentItem)}
      </React.Fragment>
    ));
  };

  const tempPrintImages = printImages.filter((item, index) => index > 0); // 第一张是左侧的裁剪图 过滤掉

  return (
    <>
      <Form
        className='__publish_project_form'
        form={form}
        onClick={handleFromDocClick}
        layout="vertical"
      >
        <Form.Item
          className='form_item'
          name='upload_file'
          // @ts-ignore
          label={<div className='required'>{getTranslation(TranslationsKeys.ADD_PROJECT)}</div>}
        >
          <div className='add_file_container'>
            {
              (tempPrintImages && tempPrintImages.length > 0) &&
              tempPrintImages.map((item, index) => (
                <div className='add_file_div' key={item.key_prefix}>
                  <span>
                    <img
                      className='add_file_base64'
                      src={item}
                      crossOrigin="anonymous"
                    />
                  </span>
                  <img
                    className='add_file_close_icon'
                    src={rubbishIcon}
                    onClick={() => !disabeld && deletePrintImage(item, index)}
                    crossOrigin="anonymous"
                  />
                </div>
              ))
            }
            {tempPrintImages.length < 10 && <div className='add_file_div' >
              <span>
                <img className='add_file_plu_icon' src={addFileIcon} />
              </span>
              <input
                type="file"
                // multiple
                accept=".jpg,.png,.webp,.gif"
                onChange={(e) => {
                  // @ts-ignore
                  handlePrintPhotoUpload(e.target.files, printImages.length, e);
                }}
              />
            </div>}
          </div>
          {doSubmitFlag && tempPrintImages.length == 0 && <p className='red_text_p'>{getTranslation(TranslationsKeys.PROJECT_UPLOAD_IMAGE)}</p>}
        </Form.Item>

        {/* @ts-ignore */}
        <Form.Item
          className='form_item'
          name="project_name"
          // @ts-ignore
          label={<div className='required'>{getTranslation(TranslationsKeys.FORM_PROJECT_NAME)}</div>}
        >
          <input
            className='project_name_input'
            type="text"
            value={projectName}
            maxLength={50}
            onChange={(e) => { !disabeld && handleProjectName(DOMPurify.sanitize(e.target.value)) }}
          />
          {doSubmitFlag && !projectName && <p className='red_text_p'>{getTranslation(TranslationsKeys.PROJECT_NAME_REQUIRED)}</p>}
        </Form.Item>

        <Form.Item
          className='form_item'
          name="designFile"
        >
          {
            designLinkFile
              ?
              <div className='select_design_file'>
                <img src={designLinkFile} className='file_img' alt="" />
                <p className='file_name'>{designLinkName}</p>
                <img src={rubbishIcon} className='rubbishIcon' alt="" onClick={() => !disabeld && deleteFileLink()} />
              </div>
              :
              <>
                <div className='upload_design_file' onClick={() => !disabeld && setOpenDesignList(true)}>
                  <img src={addFileIcon} className='add_file_icon' alt="" />
                  <p>{getTranslation(TranslationsKeys.UPLOAD_DESIGN)}</p>
                </div>
                {doSubmitFlag && !designLinkFile && <p className='red_text_p'>{getTranslation(TranslationsKeys.UPLOAD_DESIGN_FILE_REQUIRED)}</p>}
              </>
          }
        </Form.Item>

        <Form.Item
          className='form_item'
          name="categories"
          // @ts-ignore
          label={<div className='required'>{getTranslation(TranslationsKeys.FORM_CATEGORY)}</div>}
        >
          <div className='__select_div'>
            {
              <>
                <div className='__select_inputdiv' onClick={(e) => {
                  handlerCategoriesSelect(e)
                }}>
                  <p className={'select_value_p'}>
                    {subCategoryName}
                  </p>
                  <img className="drop_down_icon" src={dropdownIcon} alt="" />
                </div>
                {doSubmitFlag && !subCategoryName && <p className='red_text_p'>{getTranslation(TranslationsKeys.CATEGORY_REQUIRED)}</p>}
              </>
            }
            <ul className={showCategoriesSelectOptions ? 'showSelectOption' : 'disableSelectOption'}>
              {renderOptions(categoriesOption) || []}
            </ul>
          </div>
        </Form.Item>

        <Form.Item
          className='form_item'
          name="Themes"
          // @ts-ignore
          label={<div className='required'>{getTranslation(TranslationsKeys.FORM_THEMES)}</div>}
        >
          <CustomMutiSelect
            formIndex='themes'
            handleInputClick={handleInputClick}
            deleteItem={deleteItem}
            showOption={showThemesSelectOptions}
            optionData={themesOption}
            handleSelectItem={handleMutiSelectItem}
            selectData={themesSelectData}
            doSubmitFlag={doSubmitFlag}
            disabeld={disabeld}
            hasChild={true}
          />
        </Form.Item>

        <Form.Item
          className='form_item'
          name="Material Used"
          // @ts-ignore
          label={<div className='required'>{getTranslation(TranslationsKeys.FORM_MATERIAL)}</div>}
        >
          <CustomMutiSelect
            formIndex='material'
            handleInputClick={handleInputClick}
            deleteItem={deleteItem}
            showOption={showMaterialSelectOptions}
            optionData={materialOption}
            handleSelectItem={handleMutiSelectItem}
            selectData={materialSelectData}
            doSubmitFlag={doSubmitFlag}
            disabeld={disabeld}
          />
        </Form.Item>

        <Form.Item
          className='form_item'
          name="Description"
          // @ts-ignore
          label={<div className='required'>{getTranslation(TranslationsKeys.FORM_DESCRIPTION)}</div>}
        >
          <div style={{ marginTop: 10 }}>
            <EditText richTextEdit={richTextEdit} initialContent={designDetalis?.description} disabeld={disabeld} />
            {doSubmitFlag && !description && <p className='red_text_p'>{getTranslation(TranslationsKeys.DESCRIPTION_REQUIRED)}</p>}
          </div>
        </Form.Item>

        <Form.Item
          className='form_item'
          name="Tags"
          label={getTranslation(TranslationsKeys.FORM_TAGS)}
        >
          <CustomTagInput
            tags={tags}
            setTags={setTags}
            disabled={disabeld}
          />
        </Form.Item>
      </Form>

      <DesignListDialog
        open={openDesignList}
        cancelClick={() => setOpenDesignList(false)}
        handleNext={selectFileHandle}
      />
    </>
  );
})

export default Index;