// import React, { useState, Suspense, useEffect } from 'react';
// // import { CKEditor } from '@ckeditor/ckeditor5-react';
// // import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
// import loadable from '@loadable/component';

// // @ts-ignore
// // const CKEditor = loadable(() => import('@ckeditor/ckeditor5-react'), { ssr: false });
// // @ts-ignore
// // const ClassicEditor = loadable(() => import('@ckeditor/ckeditor5-build-classic'), { ssr: false });


// const CKEditor = React.lazy(() => import('@ckeditor/ckeditor5-react').then(mod => ({ default: mod.CKEditor })));
// const ClassicEditor = React.lazy(() => import('@ckeditor/ckeditor5-build-classic'));


// const MyEditor: React.FC = () => {
//   const [editorData, setEditorData] = useState<string>('');
//   const [isClient, setIsClient] = useState(false);

//   useEffect(() => {
//     setIsClient(true);
//   }, []);

//   if (!isClient) {
//     return <div>11</div> // 在服务器端渲染时不渲染 CKEditor
//   }

//   console.log('CKEditor', CKEditor);
//   console.log('ClassicEditor', ClassicEditor)

//   return (
//     <div>
//       {/* @ts-ignore */}
//       <Suspense fallback={<div>Loading...</div>}>
//         <CKEditor
//           // @ts-ignore
//           editor={ClassicEditor}
//           config={{
//             toolbar: [
//               'bold', 'italic', 'underline', 'fontColor', 'fontBackgroundColor',
//               'alignment:left', 'alignment:center', 'alignment:right', 'alignment:justify',
//               'bulletedList', 'numberedList', 'outdent', 'indent',
//               'imageUpload', 'mediaEmbed'
//             ],
//             image: {
//               toolbar: [
//                 'imageStyle:full', 'imageStyle:side', '|', 'imageTextAlternative'
//               ]
//             }
//           }}
//         />
//       </Suspense>
//     </div>
//   );
// };

// export default MyEditor;



import React, { useState, useEffect } from 'react';

const CKEditor = typeof window !== 'undefined' ? require('@ckeditor/ckeditor5-react').CKEditor : () => <div>Loading...</div>;
const ClassicEditor = typeof window !== 'undefined' ? require('@ckeditor/ckeditor5-build-classic') : null;

const MyEditor = () => {
  const [editorLoaded, setEditorLoaded] = useState(false);

  useEffect(() => {
    setEditorLoaded(true);
  }, []);

  return (
    <div>
      {editorLoaded ? (
        <CKEditor
          editor={ClassicEditor}
          data="<p>Hello from CKEditor 5!</p>"
          onReady={editor => {
            console.log('Editor is ready to use!', editor);
          }}
          onChange={(event, editor) => {
            const data = editor.getData();
            console.log({ event, editor, data });
          }}
          onBlur={(event, editor) => {
            console.log('Blur.', editor);
          }}
          onFocus={(event, editor) => {
            console.log('Focus.', editor);
          }}
        />
      ) : (
        <div>Loading...</div>
      )}
    </div>
  );
};

export default MyEditor;