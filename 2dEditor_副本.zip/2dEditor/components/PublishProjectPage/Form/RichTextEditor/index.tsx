import React, { useState, useRef, useMemo, useEffect } from 'react';
import loadable from '@loadable/component';
import Compressor from 'compressorjs';
import 'react-quill/dist/quill.snow.css';
import './index.scss';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

// 动态导入 ReactQuill，只在客户端渲染时加载
// @ts-ignore
const ReactQuill = loadable(() => import('react-quill'), { ssr: false });

const MyEditor = (props: any) => {
  const { richTextEdit, initialContent, disabeld } = props;
  const [editorHtml, setEditorHtml] = useState('');
  const [wordCount, setWordCount] = useState(0);
  const quillRef = useRef(null);
  const { getTranslation } = useCustomTranslation();

  useEffect(() => {
    if (initialContent) {
      setEditorHtml(initialContent);
    }
  }, [initialContent]);

  const handleChange = (content, delta, source, editor) => {
    if (editor.getLength() - 1 <= 3000) {
      setEditorHtml(content);
      richTextEdit(content);
      setWordCount(editor.getLength() - 1);
    } else {
      // 如果超过了最大长度，截取前 3000 个字符
      const quill = quillRef?.current?.getEditor();

      // 更新编辑器内容
      const truncatedContent = editor.getText(0, 3000);
      quill.setText(truncatedContent);
      setEditorHtml(truncatedContent);
      richTextEdit(truncatedContent);
      setWordCount(3000);

      // 设置光标位置到最后
      setTimeout(() => {
        quill.setSelection(3000, 3000);
      }, 0);
    }
  };

  const handleImageUpload = (file: any) => {
    new Compressor(file, {
      quality: 0.6, // 压缩质量，0 到 1 之间
      maxWidth: 400, // 最大宽度
      maxHeight: 400, // 最大高度
      success(result) {
        const reader = new FileReader();
        reader.readAsDataURL(result);
        reader.onload = () => {
          const base64 = reader.result;
          //  @ts-ignore
          const quill = quillRef?.current?.getEditor();
          const range = quill.getSelection();
          quill.insertEmbed(range.index, 'image', base64);
        };
      },
      error(err) {
        console.error('Error compressing image:', err);
      },
    });
  };

  const modules = useMemo(() => ({
    toolbar: {
      container: [
        // [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        // [{ 'size': ['small', false, 'large', 'huge'] }],
        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
        [{ 'align': [] }],
        ['bold', 'italic', 'underline'],
        [{ 'indent': '-1' }, { 'indent': '+1' }], // 缩进选项
        [{ 'color': [] }, { 'background': [] }],
        ['image'], // video
      ],
      handlers: {
        image: () => {
          const input = document.createElement('input');
          input.setAttribute('type', 'file');
          input.setAttribute('accept', 'image/*');
          input.click();

          input.onchange = () => {
            const file = input?.files?.[0];
            if (file) {
              handleImageUpload(file);
            }
          };
        }
      }
    },
    clipboard: {
      matchVisual: false,
    },
  }), []);

  return (
    <div className="my-editor">
      {/* @ts-ignore */}
      <ReactQuill
        //  @ts-ignore
        ref={quillRef}
        value={editorHtml}
        // onChange={(content: string) => !disabeld && handleChange}
        onChange={handleChange}
        modules={modules}
        placeholder={getTranslation(TranslationsKeys.ABOUT_PROJECT)}
        theme="snow"
      />
      <div className='wordCount'>{wordCount}/3000</div>
    </div>
  );
};

export default MyEditor;