import React, { useEffect, useRef, useState } from 'react';

// utils
import { useDispatch, useSelector } from 'react-redux';
import { updateTopPageTab, HomeState, selectHome } from 'src/state/reducers/home';
import { homePage } from 'src/components/Layout/const'
import { getDetailFromUrl } from 'src/state/reducers/home';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

// component
import CropPhoto from './CropPhoto/index';
import CustomForm from './Form/index';
import { Dialog } from '@mui/material';
import { EditorToastType, editorToastShow } from 'src/templates/2dEditor/components/Toast';
import { openToast } from 'src/state/reducers/toast'

// service
import { upload2dEditFile } from 'src/hooks/useUpload';
import { GetUpTokenFileTypeEnum } from 'src/services';
import { publish } from 'src/templates/2dEditor/service/2dEditService';
import { fetchWorkDetail, updateWorks } from 'src/templates/Home/services';

// style
import './index.scss';

// icon
import dropdownIcon from 'src/assets/svg/ic_down.svg';
import loadingIcon from 'src/assets/svg/loading_white.svg';

export default function Index() {

  const dispatch = useDispatch()

  const customFormRef = useRef();
  const { getTranslation } = useCustomTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [isSubmit, setIsSubmit] = useState(false);
  const [isSave, setIsSave] = useState(false);
  const homeState: HomeState = useSelector(selectHome)
  const [designDetalis, setDesignDetalis] = useState({} as any);
  const queryParams = new URLSearchParams(location.search);
  const [workdId, setWorkId] = useState('');
  const [isClickSubmit, setIsClickSubmit] = useState(false);
  const [isEdit, setIsEdit] = useState(false);

  const handleFromDocClick = () => {
    if (customFormRef.current) {
      // @ts-ignore
      customFormRef?.current?.handleFromDocClick();
    }
  }

  const save = () => { }

  const getImageFileInfo = async (files: any, index: number) => {
    const result = await upload2dEditFile(files, GetUpTokenFileTypeEnum.PublishProject);
    return { result, index };
  }

  const submit = async () => {
    if (customFormRef.current) {
      setIsSubmit(true);
      // @ts-ignore
      const formdata = await customFormRef.current?.submitFormData();
      // let cover_tiny = '', pictures: any[] = [];
      console.log('====formdata', formdata);
      setIsClickSubmit(false)
      if (!formdata) {
        setIsClickSubmit(true);
        setIsSubmit(false);
        return;
      };
      // return
      const files = formdata.uploadFile;
      const chunkSize = 5;
      const chunks = [];
      for (let i = 0; i < files.length; i += chunkSize) {
        chunks.push(files.slice(i, i + chunkSize));
      }
      try {
        let cover_tiny = '';
        let pictures = [] as any;
        let globalIndex = 0;
        console.log('---chunk', chunks)
        for (const chunk of chunks) {
          console.log('-----11', chunk)
          const res = await Promise.all(chunk.map((file: any, index: number) => getImageFileInfo(file, globalIndex + index)));
          res.forEach((i: any) => {
            console.log('------res', i)
            if (i.index == 0 && !cover_tiny) {
              cover_tiny = i.result.key_prefix;
            }
            pictures.push(i.result.key_prefix);
          });
          globalIndex += chunk.length;
        }

        delete formdata['uploadFile'];
        const params = {
          ...formdata,
          cover_tiny,
          pictures,
          description: formdata.description,
        };
        console.log('---params', params);
        // return;
        const submitPromise = (homeState.GoDetailFromUrl == 'projectDetail' || isEdit)
          ? updateWorks({ ...params, works_id: workdId })
          : publish(params);

        const submitRes = await submitPromise;

        if (submitRes?.code == 0) {
          dispatch(openToast({
            message: getTranslation(TranslationsKeys.PUBLISH_SUCCESS),
            severity: 'success',
          }));
          if (window.location.pathname.indexOf('PublishedProject') > -1) {
            history.back();
          }
          homeState.GoDetailFromUrl == 'projectDetail'
            ? dispatch(updateTopPageTab(homePage['11']))
            : dispatch(updateTopPageTab('Explore'));
          dispatch(getDetailFromUrl(''));
        } else {
          dispatch(openToast({
            message: getTranslation(TranslationsKeys.PUBLISH_FAILED),
            severity: 'error',
          }));
        }
        // }
      } catch (error) {
        console.log('---err', error);
      } finally {
        setIsSubmit(false);
      }
    }
  }

  const setPrintImages = (blob: any) => {
    if (customFormRef.current) {
      // @ts-ignore
      customFormRef?.current?.handlePrintPhotoUpload(blob, 0);
    }
  }

  useEffect(() => {
    const PROJECT_ID = queryParams.get('project_detail_id');
    if (!PROJECT_ID) return
    setIsEdit(true)
    setWorkId(PROJECT_ID);
    fetchWorkDetail(PROJECT_ID).then(res => {
      console.log('----res?.data?.works_info', res?.data?.works_info)
      setDesignDetalis(res?.data?.works_info)
    });
    return () => {
      setDesignDetalis({} as any);
      setIsEdit(false);
    }
  }, [])

  return (
    <div className='__publish_project_page_layout' onClick={() => handleFromDocClick()}>
      <div className='__layout_top'>
        <div className='top_layout'>
          <div className='top_left' onClick={() => setIsOpen(true)}>
            <img src={dropdownIcon} alt="" />
            <p>{getTranslation(TranslationsKeys.PUBLISH_PROJECT)}</p>
          </div>
          <div className='top_right'>
            {/* <p onClick={() => submit()}>{getTranslation(TranslationsKeys.BUTTON_SAVE)}</p> */}
            <p onClick={() => submit()}>{!isSubmit ? getTranslation(TranslationsKeys.BUTTON_PUBLISH) : <img className='loading_img' src={loadingIcon} />}</p>
          </div>
        </div>
      </div>
      <div className='__layout_content'>
        <div className='content_box'>
          <CropPhoto
            setPrintImages={setPrintImages}
            designDetalis={designDetalis}
            disabeld={isSubmit}
            isClickSubmit={isClickSubmit}
          />
          <CustomForm ref={customFormRef} designDetalis={designDetalis} disabeld={isSubmit} />
        </div>
      </div>
      <Dialog
        className='leave_tip_dialog'
        open={isOpen}
      >
        <div className='leave_tip_layout'>
          <p className='tip_des'>{getTranslation(TranslationsKeys.LEAVE_PROJECT)}</p>
          <div className='btn_group'>
            <p className='cancel' onClick={() => setIsOpen(false)}>{getTranslation(TranslationsKeys.BUTTON_CANCEL)}</p>
            <p className='leave' onClick={() => {
              if (window.location.pathname.indexOf('PublishedProject') > -1) {
                history.back();
              } else {
                setIsOpen(true);
                dispatch(updateTopPageTab('Explore'))
              }
            }}>{getTranslation(TranslationsKeys.BUTTON_LEAVE)}</p>
          </div>
        </div>
      </Dialog>
    </div >
  )
}