

import React, { useState, useRef, useEffect } from 'react';

// components
import PageIndex from './PageIndex/index';
import TextureLib from '../TextureEdit/TextureLib';
import CreateTexture from '../TextureEdit/CreateTexture';

import eventBus from '../../core/eventbus';
import {
  GetShowPage,
} from 'src/state/reducers/home'
import { useDispatch, useSelector } from 'react-redux'

export default function Craft(props: any) {
  const dispatch = useDispatch()
  const { allRight_state, handleShowTab, AiTitle, craftList, defaultCraft } = props;
  const [showPage, setShowPage] = useState<string>('pageIndex');
  const [dimensionTypes, setDimensionTypes] = useState<string>('');
  const [textureTabs, setTextureTabs] = useState<any>(null);
  const [textureStyle, setTextureStyle] = useState<any>(null);
  const [createImgObj, setCreateImgObj] = useState<any>();

  const nextClick = (info: any) => {
    console.log('==item-- info', info)
    handleShowTab(info?.title)
    setDimensionTypes(info?.title);
    info?.tabMenuData && setTextureTabs(info?.tabMenuData);
    info?.imgObj ? setCreateImgObj(info?.imgObj) : setCreateImgObj(null);
    setTextureStyle(info?.textureStyle);
    setShowPage(info?.pageTag);
    dispatch(GetShowPage(info?.pageTag))
  }

  const previewClick = () => {
    setShowPage('pageIndex');
    dispatch(GetShowPage('pageIndex'))
    setCreateImgObj(null)
  }

  useEffect(() => {
    if (AiTitle && craftList.includes(AiTitle) && defaultCraft) {
      nextClick(defaultCraft);
    }
    return (() => {
      if (typeof window !== 'undefined') {
        window?.sessionStorage?.removeItem('AiTitle');
      }
    })
  }, [defaultCraft]);

  useEffect(() => {
    const handleTriggerNextClick = (info: any) => {
      nextClick(info);
    };
    eventBus.on('triggerNextClick', handleTriggerNextClick);
    return () => {
      eventBus.off('triggerNextClick', handleTriggerNextClick);
    };
  }, []);
  return ( 
    <>
      {showPage == 'pageIndex' && <PageIndex nextClick={nextClick} />}
      {showPage == 'TextureLib' && <TextureLib previewClick={previewClick} nextClick={nextClick} allRight_state={allRight_state} dimensionTypes={dimensionTypes || null} />}
      {showPage == 'ReliefMaker' && <TextureLib previewClick={previewClick} nextClick={nextClick} allRight_state={allRight_state} dimensionTypes={dimensionTypes || null} />}
      {showPage == 'createTextureLib' && <CreateTexture previewClick={previewClick} nextClick={nextClick} textureTabs={textureTabs} textureStyle={textureStyle} createImgObj={createImgObj} dimensionTypes={dimensionTypes || null}></CreateTexture>}
    </>
  );
}