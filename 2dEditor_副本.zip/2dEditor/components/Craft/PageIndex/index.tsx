

import React, { useState, useEffect } from 'react';

// components
import LottiePlayer from 'react-lottie-player';
import LoadingAnimation from 'src/images/lottie/loading.json';

// utils
import useDataCache from 'src/templates/2dEditor/utils/DataCache';

// css
import './index.scss';

// services
import { get } from 'src/services';

import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";
//埋点
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';


export default function PageIndex(props: any) {

  const { nextClick } = props;

  // 每新增一个卡片，就给每个页面添加一个标签，用与判断当前卡片切换的是哪个页面 在以下文件会用到
  // src/templates/2dEditor/components/MainUi/MainUiLeft/index.tsx
  // src/templates/2dEditor/components/Craft/index.tsx

  const [loading, setLoading] = useState(false);
  const { setCacheItem, getCacheItem, } = useDataCache();
  const [dataList, setDataList] = useState<any>([]);
  const { getTranslation } = useCustomTranslation();
  const getList = async () => {
    setLoading(true)
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-all-tools',
      populate: [
        'image',
        'toolClass.class_name',
        'frontType.frontName',
      ],
      filters: { toolClass: { class_name: { $eq: 'fractalDimension' } } },
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'], // 按weight降序排列
    });
    let tempTab = [] as any;
    if (json?.data?.data?.length > 0) {
      json.data.data.map((item: any, index: number) => {
        const fontName=item.attributes.frontType.data.attributes.fontName
        console.log('---index', index, fontName)
        const { title, description, image } = item.attributes;
        const obj = { img: image.data?.attributes?.url, title, description, pageTag: fontName };
        tempTab.push(obj)
      });
      setDataList(tempTab);
      setCacheItem('craft', { data: tempTab });
      setLoading(false)
    } else {
      setLoading(false)
    }
  }

  useEffect(() => {
    const cacheData = getCacheItem('craft');
    if (cacheData?.data?.length > 0) {
      setDataList(cacheData.data);
    } else {
      getList();
    }
  }, []);

  return (
    <div>
      <div className='craft_top'>
        <p className='craft_title'>{getTranslation(TranslationsKeys.CRAFT)}</p>
      </div>
      <div className='craft_notice'>
        <p><strong>{getTranslation(TranslationsKeys.NOTICE)} </strong>{getTranslation(TranslationsKeys.FLAT_FORMAT)}</p>
      </div>
      {
        loading
          ?
          <div className='loadContainer'>
            <div className="loadIcon">
              <LottiePlayer
                loop
                play
                className="loadingBox"
                animationData={LoadingAnimation}
              />
            </div>
          </div>
          :
          <div className="craft_item_box">
            {
              dataList?.map((item: any, index: any) => {
                console.log('---item', item)
                // if(item?.title=='Relief Maker')return
                return (
                  <div className="craft_item"
                    onClick={() => { nextClick(item);StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.reliefMaker_textureLib_card_click,item?.pageTag==='ReliefMaker'?1:0) }}
                    key={index}
                  >
                    <div className="craft_item_left">
                      <div className="craft_item_title">{item?.title}</div>
                      <div className="craft_item_text">{item?.description}</div>
                    </div>
                    {
                      <img
                        src={item?.img}
                        className='item_image'
                      />
                    }
                  </div>
                )
              })
            }
          </div>
      }
      <div>
      </div>
    </div>
  );
}