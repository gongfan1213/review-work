import React, { useState } from 'react'
import { selectFiles, getImgStr } from '../../utils/utils';
import { useCanvasEditor, useEvent, useFabric } from '../../hooks/context';
import { v4 as uuid } from 'uuid';
import { Menu, MenuItem, Button } from '@mui/material'
import { ImportSource } from '../../core/plugin/ImagePlugin/types/common';
import Loading from 'src/components/Loading';

function ImportFileButton() {
  const canvasEditor = useCanvasEditor();
  const fabric = useFabric()
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const [loading, setLoading] = useState(false)
  const event = useEvent();

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleMenuClick = (key: string) => {
  };

  return (
    <React.Fragment>
      <Button
        aria-controls="simple-menu"
        aria-haspopup="true"
        onClick={handleClick}
      >
        插入
      </Button>
      <Menu
        id="simple-menu"
        anchorEl={anchorEl}
        keepMounted
        open={open}
        onClose={handleClose}
      >
        <MenuItem onClick={() => handleMenuClick('1')}>插入图片</MenuItem>
        <MenuItem onClick={() => handleMenuClick('2')}>插入SVG图标</MenuItem>
      </Menu>
      <Loading loading={loading} />
    </React.Fragment>
  );
}

export default ImportFileButton;
