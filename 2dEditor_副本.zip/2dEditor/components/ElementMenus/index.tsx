import React, { useEffect, useState, useRef } from 'react'
import './index.scss'
import SearchInput from '../SearchInput'
import SideTable from '../SideTable'
import TabSwitcher from 'src/templates/2dEditor/common/widget/TabSwitcher/TabSwitcher'
import FilterPopover from '../FilterPopover'
import { get } from 'src/services'
import { useCanvasEditor, useProjectData, useFabric } from '../../hooks/context'
import { convertToBase64 } from 'src/common/utils'
import { getImgStr, selectFiles } from 'src/templates/2dEditor/utils/utils'
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common'
// import { TextureImage, TextureType } from 'src/templates/2dEditor/core/plugin/ImagePlugin/TextureImage'
import Loading from 'src/components/Loading'
import { getFficialMaterialStatus } from '../../service/2dEditService'
import useDataCache from '../../utils/DataCache'
import { MaterialEditData } from '../SelectDialog/model/ProjectModel'
import { useEvent } from 'src/templates/2dEditor/hooks/context'
import { CustomKey, EventNameCons, WorkspaceID } from '../../cons/2dEditorCons'
import { useDispatch } from 'react-redux'
import DataCache from 'src/templates/2dEditor/components/MainUi/MainUiLeft/MainUiLeftUpload/cache'
import empty_data_icon from 'src/images/empty_upload.png'
import {
  appendListToDataA,
  replaceGraphicData,
} from 'src/templates/2dEditor/utils/utils'
import ProjectManager from '../../utils/ProjectManager'
// @ts-ignore
import Base64Worker from '../../core/worker/base64.worker'
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

function ElementMenus(props: any) {
  const { setCacheItem, getCacheItem, cacheData, cachePageSize, cacheHasMore } =
    useDataCache()
  const { getTranslation } = useCustomTranslation();
  const [active, setActive] = useState<any>('Graphic')
  const [DialogState, setDialogState] = useState(false)
  // 打搜索框的状态
  const [FilterPopoverState, setFilterPopoverState] = useState(false)
  // 筛选框的位置
  const [anchorEl, setAnchorEl] = useState(null)
  const [sideData, setSideData] = useState<any>([])
  const [seeAllData, setSeeAllData] = useState<any>([])
  const [searchValue, SetSearchValue] = useState<any>('')
  const [filterValue, setFilterValue] = useState<any>([])
  const canvasEditor = useCanvasEditor()
  const projectModel = useProjectData()
  const [isNetLoading, setNetLoading] = useState(false)
  const [isLoading, setLoading] = useState(false)
  const [hasLoading, setHasLoading] = useState(false) //加载更多模块的loading
  const [hasMore, setHasMore] = useState(false)
  const pageIndex = useRef(2)
  const SeeAllref = useRef(null)
  const PAGE_SIZE = 20

  const [ListLoading, setListLoading] = useState(false) //加载更多模块的loading
  const [ListMore, setListMore] = useState(false)
  const List_PAGE_SIZE = 5
  const currentIndex = useRef(0)

  const [isSeeAll, setIsSeeAll] = useState<any>('')
  const activeRef = useRef('Graphic') //最新的tab值
  const event = useEvent()
  const refdata = useRef<any>()
  const refInput = useRef<any>()
  const [RefreshLoading, setRefreshLoading] = useState<any>([])
  const [isError, setIsError] = useState(false)
  const [AllTypeData, setAllTypeData] = useState<any>([
    { tabName: 'Graphic', tabValue: 0 },
    { tabName: 'Images', tabValue: 1 },
    { tabName: 'Shape', tabValue: 2 },
    { tabName: 'Pattern', tabValue: 3 },
  ])
  const interface_loading = useRef(false)
  const dispatch = useDispatch()
  const activeTabRef = useRef<any>('Graphic')
  const refRightState = useRef<Boolean>(false)

  const editClick = (event: any) => {
    const rect = event.currentTarget.getBoundingClientRect()
    // 打开弹窗
    setDialogState(true)
    //@ts-ignore
    setAnchorEl({ left: rect.left + 36, top: rect.bottom + 15 })
    setFilterPopoverState(true)
  }
  // 清除当前数据
  const CloseState = () => {
    // setDialogState(false)
    setSideData([])
    setListMore(false)
    currentIndex.current = 0
  }

  // 关闭筛选框
  const onClose = () => {
    setFilterPopoverState(false)
  }

  const tabs = [
    { tabName: 'Graphic', tabValue: 0 },
    { tabName: 'Images', tabValue: 1 },
    { tabName: 'Shape', tabValue: 2 },
    { tabName: 'Pattern', tabValue: 3 },
  ]

  const ConfirmClick = (props: any) => {
    setCacheItem('elementMenus', {
      ...getCacheItem('elementMenus'),
      activeForm: props,
    })
    // console.log('confirm', active)
    CloseState()
    clearSeeAllState()
    // setLoading(true);
    onClose()
    setFilterValue(props)

    if (
      props?.product?.length === 0 &&
      props?.tags?.length === 0 &&
      searchValue === ''
    ) {
      fetchSonClass()
      // alert('111')
    } else {
      getSearchData(props, '', 'confirm')
      // alert('222')
    }
  }

  const ClearnAllClick = (props: any, activeForm: any) => {
    // onClose();
    // CloseState();
    clearSeeAllState()
    setCacheItem('elementMenus', {
      ...getCacheItem('elementMenus'),
      activeForm: { product: [], tags: [] },
    })
    setFilterValue([])
    if (searchValue === '') {
      // fetchSonClass()
    } else {
      setFilterValue([])
      getSearchData(activeForm, '', 'clean')
    }
  }

  // 获取tags展示数组
  const getTags = (data: []) => {
    return data?.map((item: any) => item.attributes.tag_name)
  }

  // 获取收藏状态
  const getStatus = async (ids: number[]) => {
    // 2字体模块 3元素模块
    const res = await getFficialMaterialStatus({
      ids: ids,
      type: 3,
    })
    return res
  }
  // 加载更多数据切换
  const MoreDataChange = async (AllData: any, datas: any[]) => {
    let Ids: any[] = []
    try {
      const result = Object.entries(AllData).map(([key, value]: [any, any]) => {
        const matchingClass = datas.find((_: any) => {
          return _.label === key
        })
        //抽离出所有的id，用于调接口获取最新的收藏状态
        AllData[matchingClass?.label]?.data?.map((_: any) => {
          Ids.push(_?.id)
        })
        return {
          label: key,
          id: matchingClass?.id || null,
          total: AllData[matchingClass?.label]?.meta?.pagination?.total,
          list: value?.data?.map((item: any) => ({
            image:
              item?.attributes?.element_image?.data?.attributes?.formats
                ?.thumbnail?.url ||
              item?.attributes?.element_image?.data?.attributes?.url,
            canvas_image:
              item?.attributes?.element_image?.data?.attributes?.url,
            rules: {
              title: item?.attributes?.title,
              username: item?.attributes?.author,
              CategoryList: getTags(item?.attributes?.tags?.data || []),
              id: item?.id || null,
              // like_status: item?.like_status,//1:已收藏 2:未收藏
            },
          })),
        }
      })
      // 通过所有的id获取最新的收藏状态
      if (Ids.length > 0) {
        const status = await getStatus(Ids) // 在所有 Ids 都获取后调用getStatus
        // 遍历 result，将 like_status 设置为 status 对象中对应的值
        result?.forEach((item: any) => {
          item?.list?.forEach((subItem: any) => {
            if (status && subItem && subItem.rules) {
              // @ts-ignore
              subItem.rules.like_status =
                status?.data?.status_map[subItem.rules.id]
            }
          })
        })
      }
      // interface_loading.current = false;
      return result
    } catch (error) {
      console.log('MoreDataChange方法错误', error)
      interface_loading.current = false
      return []
    }
  }

  // 初始数据的转化，AllData：接口返回的未处理数据。datas：所有的小类
  const DataChange = (AllData: any, datas: any[]) => {
    const result = Object.entries(AllData).map(([key, value]: [any, any]) => {
      const matchingClass = datas.find((_: any) => {
        return _.label === key
      })

      return {
        label: key,
        id: matchingClass?.id || null,
        total: AllData[matchingClass?.label]?.meta?.pagination?.total || null,
        list:
          value?.data?.map((item: any) => ({
            image:
              item?.attributes?.element_image?.data?.attributes?.formats
                ?.thumbnail?.url ||
              item?.attributes?.element_image?.data?.attributes?.url,
            canvas_image:
              item?.attributes?.element_image?.data?.attributes?.url,
            rules: {
              title: item?.attributes?.title,
              username: item?.attributes?.author,
              CategoryList: getTags(item?.attributes?.tags?.data || []),
              id: item?.id || null,
              // like_status: item?.like_status,//1:已收藏 2:未收藏
            },
          })) || [],
      }
    })
    return result
  }

  // 统一获取收藏状态并组装进数组内
  const GetCollectionStatus = async (AllData: any) => {
    let Ids: any[] = []

    AllData?.map((item: any) => {
      item?.list?.map((subItem: any) => {
        subItem?.rules?.id && Ids.push(subItem?.rules?.id)
      })
    })

    if (Ids.length > 0) {
      const status = await getStatus(Ids) // 在所有 Ids 都获取后调用getStatus
      // 遍历 result，将 like_status 设置为 status 对象中对应的值
      const newData = AllData?.map((item: any) => {
        item.list = item?.list?.map((subItem: any) => {
          if (status && subItem && subItem.rules) {
            // @ts-ignore
            subItem.rules.like_status =
              status?.data?.status_map[subItem.rules.id] || null
          }
          return subItem
        })
        return item
      })
      // console.log("newData", newData);
      interface_loading.current = false
      return newData
    }
  }

  // 筛选后数据转化
  const transformData = async (data: any) => {
    let Ids: any[] = []
    let list = data?.data?.map((item: any) => {
      Ids.push(item?.id)
      const imageUrl =
        item?.attributes?.element_image?.data?.attributes?.formats?.thumbnail
          ?.url
      const canvas_image =
        item?.attributes?.element_image?.data?.attributes?.url
      return {
        image: imageUrl,
        canvas_image: canvas_image,
        rules: {
          title: item?.attributes?.title,
          username: item?.attributes?.author,
          CategoryList: item?.attributes?.tags?.data.map(
            (tag: any) => tag.attributes.tag_name,
          ),
          id: item?.id || null,
        },
      }
    })

    if (Ids.length > 0) {
      const status = await getStatus(Ids) // 在所有 Ids 都获取后调用getStatus
      // 遍历 list，将 like_status 设置为 status 对象中对应的值
      list = list.map((item: any) => {
        if (status) {
          // @ts-ignore
          item.rules.like_status = status?.data?.status_map?.[item.rules.id]
        }
        return item
      })
    }

    return [
      {
        label: 'All',
        id: 9999,
        total: data?.meta?.pagination?.total,
        list: list,
      },
    ]
  }

  // 页面获取全部子项数据（无筛选条件状态）
  const fetchData = async (datas: any, pramasActive?: string) => {
    // console.log("调接口获取全部数据", datas, pramasActive);
    // SSR 时返回空数组
    if (typeof window === 'undefined') return []
    setLoading(false)
    interface_loading.current = true
    let ItemId = ''
    const delay = (ms: number) =>
      new Promise((resolve) => setTimeout(resolve, ms))
    const promises = datas?.map(async (item: any, index: number) => {
      ItemId = item?.id
      await delay(20 * index)
      return get<{ data: any }>('/web/cms-proxy/common/content', {
        // cms接口地址
        content_type: 'make-2d-element-menus',
        populate: ['element_class', 'element_image', 'tags'],
        // 筛选条件
        filters: {
          // 大类
          type: {
            $eq: pramasActive || active,
          },
          // 一：进入时
          // 父级表格字段名称
          element_class: {
            // 关联子级表格字段名称
            class_name: {
              $eq: item?.label,
            },
          },
        },
        pagination: {
          page: 1,
          pageSize: 20,
        },
      })
        .then((result) => {
          const newData = { [item?.label]: result.data || [] }
          const processedData = DataChange(newData, datas)
          // console.log("------laile222", processedData);
          if (Array.isArray(processedData)) {
            // 检查 processedData 是否是数组
            setSideData((prevData: any) => {
              // console.log("--------prevData", prevData);
              // 确保 prevData 是数组
              prevData = Array.isArray(prevData) ? prevData : []
              // 创建一个新的数组，用于存储更新后的数据
              let newData = [...prevData]

              processedData.forEach((newItem: any) => {
                // 在旧数据中找到与新数据具有相同 id 的项的索引
                const index = prevData.findIndex(
                  (oldItem: any) => oldItem.id === newItem.id,
                )
                // 如果找到了匹配的项，就用新数据替换旧数据
                if (index !== -1) {
                  newData[index] = newItem
                }
              })
              // 返回更新后的数据
              // console.log("newData--第一次设置------<", newData);
              return newData
            })
          }
          return processedData
        })
        .catch((error) => {
          console.log('fetchData获取数据时出错:', error)
          return []
        })
    })
    const results = await Promise.all(promises)
    // 数据转化，铺平
    let flatArray = results.flatMap((innerArray) => innerArray)
    // console.log('results-----', flatArray);
    if (datas && flatArray.length > 0) {
      currentIndex.current = currentIndex.current + 5
    }
    const tempActive = pramasActive || active
    GetCollectionStatus(flatArray)
      .then((result) => {
        let newAllData: any[]
        // 如果当前tab和执行方法的tab不是同一个，则说明是切换tab操作，不需要设置数据
        if (tempActive === activeRef.current) {
          setSideData((prevData: any) => {
            newAllData = [...prevData]
            // 确保 prevData 是数组
            prevData = Array.isArray(prevData) ? prevData : []
            // console.log("prevData-=-=-=-==--=-==-", prevData);
            // 创建一个新的数组，用于存储更新后的数据
            result?.forEach((newItem: any) => {
              // 在旧数据中找到与新数据具有相同 id 的项的索引
              const index = prevData.findIndex(
                (oldItem: any) => oldItem.id === newItem.id,
              )
              // 如果找到了匹配的项，就用新数据替换旧数据
              if (index !== -1) {
                newAllData[index] = newItem
              }
            })
            const cacheMunedata = cacheData('elementMenus') || {}
            setCacheItem('elementMenus', {
              ...getCacheItem('elementMenus'),
              pageData: {
                ...cacheMunedata,
                [tempActive]: { data: newAllData },
              },
              tabKey: tempActive,
              activeForm: getCacheItem('elementMenus')?.['activeForm'] || {
                product: [],
                tags: [],
              },
            })
            const foundItem = AllTypeData.find(
              (item: any) => item?.tabName === active,
            )
            const nowItem =
              foundItem && foundItem.label
                ? foundItem
                : getCacheItem('elementMenus')?.AllTypeData.find(
                  (item: any) => item?.tabName === active,
                )
            // 当前数据大于缓存数据时，且返回的数据大于List_PAGE_SIZE条数时，加载更多
            setListMore(
              datas.length >= List_PAGE_SIZE &&
              nowItem?.label?.length > newAllData.length,
            )
            setListLoading(false)
            // console.log("newAllData----=-=-", newAllData);
            // 返回更新后的数据
            return newAllData
          })
          // 获取收藏状态成功后，再去除刷新的loading状态
          setRefreshLoading((prevIds: any) =>
            prevIds.filter((id: string) => id !== ItemId),
          )
        } else {
          if (!!cacheData('elementMenus')?.[activeRef.current]?.data) {
            setLoading(false)
            setSideData(cacheData('elementMenus')?.[activeRef.current]?.data)
          }
        }
        interface_loading.current = false
      })
      .catch((error) => {
        console.log('获取收藏状态时出错:', error)
      })
      .finally(() => {
        console.log('finally允许点击侧边')
        interface_loading.current = false
      })
    setLoading(false)
    interface_loading.current = false
  }

  // 加载更多数据以及点击seeAll时调用，nowItemClass：当前点击的小类，clear：清空数据状态,NewTotal：最新的页码
  async function fetchDataMore(
    nowItemClass: any,
    clear: string,
    NewPage: number,
  ) {
    // console.log("NewPage====>111111111", nowItemClass);
    setLoading(false)
    if (NewPage) {
      pageIndex.current = NewPage
    }
    console.log(
      '是否需要加载更多',
      nowItemClass?.list?.length,
      nowItemClass?.total,
    )
    // 当前的数据大于等于总数时，就不跑加加载跟多的方法
    if (nowItemClass?.list?.length >= nowItemClass?.total) {
      setHasLoading(false)
      setHasMore(false)
      interface_loading.current = false
      return
    }
    interface_loading.current = true
    if (clear === 'clear') {
      setSeeAllData([])
      pageIndex.current = 2
    }

    let ret: any = []
    setHasLoading(true)
    const item = { label: nowItemClass?.label, id: nowItemClass?.id }

    const filters: any = {
      type: {
        $eq: active,
      },
    }
    // 搜索框数据
    if (!!searchValue) {
      if (searchValue?.length === 1) {
        // 一个字符的时候，精准搜索
        filters.title = {
          $eq: searchValue,
        }
      } else {
        filters.title = {
          $contains: searchValue,
        }
      }
    }

    // product筛选数据
    if (filterValue?.product?.length > 0) {
      filters.producrt = {
        // 关联子级表格字段名称
        id: {
          $eq: filterValue?.product,
        },
      }
    }

    // tags筛选数据
    if (filterValue?.tags?.length > 0) {
      // console.log("----->w", FilterValue, filterValue);
      filters.tags = {
        // 关联子级表格字段名称
        id: {
          $eq: filterValue?.tags,
        },
      }
    }

    const result = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      // 判断是否是All时的请求
      nowItemClass?.id !== 9999
        ? {
          // cms接口地址
          content_type: 'make-2d-element-menus',
          populate: ['element_class', 'element_image', 'tags'],
          // 筛选条件
          filters: {
            // 大类
            type: {
              $eq: active,
            },
            // 一：进入时
            // 父级表格字段名称
            element_class: {
              // 关联子级表格字段名称
              class_name: {
                $eq: item?.label,
              },
            },
          },
          pagination: {
            page: pageIndex.current,
            pageSize: PAGE_SIZE,
          },
        }
        : {
          // cms接口地址
          content_type: 'make-2d-element-menus',
          populate: ['element_class', 'element_image', 'tags'],
          // 筛选条件
          filters,
          pagination: {
            page: pageIndex.current,
            pageSize: PAGE_SIZE,
          },
        },
    )

    const AllData = { [item?.label]: result.data || [] }
    // console.log("AllData", AllData);
    // 转化展示数据格式，获取数据收藏状态
    MoreDataChange(AllData, [item])
      .then((result: any) => {
        if (result[0] && result[0]?.list?.length > 0) {
          ret = result[0]?.list
          pageIndex.current++
        }

        setSeeAllData((oldData: any) => {
          // 创建一个新的数组，包含旧的sideData和新的list数据
          const newData = [...oldData]
          const newItem = result[0]
          const existingItem = newData.find(
            (data: any) => data.id === newItem.id,
          )
          // console.log("-------------result[0]", result[0], "existingItem", existingItem);

          if (existingItem) {
            // 如果item已经存在于sideData中，那么更新它的list
            existingItem.list = [...existingItem.list, ...newItem.list]
          } else {
            // 如果item不存在于sideData中，那么添加它，需要加入第一页的数据
            newData.push({
              ...nowItemClass,
              list: [...nowItemClass?.list, ...newItem.list],
            })
          }
          // console.log("SeeAllref.current", SeeAllref.current);
          // 返回新的sideData
          if (SeeAllref.current) {
            // 此处设置的是点击SeeAll后的单独一页的展示数据
            setSideData(newData)
            // 更新缓存内的数据，使得在首页横向滚动的数据是最新的
            setCacheItem(
              'elementMenus',
              replaceGraphicData(newData, getCacheItem('elementMenus'), active),
            )
          }
          // console.log("newData----->", newData);

          return newData
        })
        setHasLoading(false)
        setHasMore(ret.length >= PAGE_SIZE)
        interface_loading.current = false
      })
      .catch((error) => {
        interface_loading.current = false
      })
  }

  // 往右侧滚动加载跟多方法
  const RightMoreData = async (nowItemClass: any) => {
    // console.log("nowItemClassnowItemClass", nowItemClass?.total, nowItemClass?.list.length);
    if (refRightState.current === true) {
      return
    }
    let nextPage = 1
    // 计算当前页数
    const currentPage = Math.ceil(nowItemClass?.list.length / PAGE_SIZE)
    // 判断是否有下一页
    if (nowItemClass?.list.length >= nowItemClass?.total) {
      // console.log("不需要调用接口，已加载所有数据。");
      return
    } else {
      // 计算下一次调用接口的页数
      nextPage = currentPage + 1
      refRightState.current = true
    }

    const item = { label: nowItemClass?.label, id: nowItemClass?.id }
    const filters: any = {
      type: {
        $eq: active,
      },
    }
    // 搜索框数据
    if (!!searchValue) {
      if (searchValue?.length === 1) {
        // 一个字符的时候，精准搜索
        filters.title = {
          $eq: searchValue,
        }
      } else {
        filters.title = {
          $contains: searchValue,
        }
      }
    }
    // product筛选数据
    if (filterValue?.product?.length > 0) {
      filters.producrt = {
        id: {
          $eq: filterValue?.product,
        },
      }
    }
    // tags筛选数据
    if (filterValue?.tags?.length > 0) {
      filters.tags = {
        id: {
          $eq: filterValue?.tags,
        },
      }
    }
    const result = await get<{ data: any }>(
      '/web/cms-proxy/common/content',
      // 判断是否是All时的请求
      nowItemClass?.id !== 9999
        ? {
          // cms接口地址
          content_type: 'make-2d-element-menus',
          populate: ['element_class', 'element_image', 'tags'],
          // 筛选条件
          filters: {
            // 大类
            type: {
              $eq: active,
            },
            // 一：进入时
            // 父级表格字段名称
            element_class: {
              // 关联子级表格字段名称
              class_name: {
                $eq: item?.label,
              },
            },
          },
          pagination: {
            page: nextPage,
            pageSize: PAGE_SIZE,
          },
        }
        : {
          // cms接口地址
          content_type: 'make-2d-element-menus',
          populate: ['element_class', 'element_image', 'tags'],
          // 筛选条件
          filters,
          pagination: {
            page: nextPage,
            pageSize: PAGE_SIZE,
          },
        },
    )

    const AllData = { [item?.label]: result.data || [] }
    // 转化展示数据格式，获取数据收藏状态
    try {
      const result = await MoreDataChange(AllData, [item])
      const newItem = result[0]
      const newData = appendListToDataA(sideData, newItem)
      setSideData(newData)
      return 'success' // 只有在这里返回成功
    } catch (error) {
      console.error('处理更多数据时出错:', error)
      return 'error' // 处理失败返回错误
    } finally {
      refRightState.current = false
    }
  }

  // 获取所有小类
  const fetchSonClass = async (pramasActive?: string) => {
    if (typeof window === 'undefined') return
    // setIsSeeAll('')
    // setSideData([])
    setIsError(false)
    setListLoading(true)
    // 一进入页面时，判断AllTypeData内是否存在label，如果没有就调接口，如果存在就直接取值
    const hasLabel = AllTypeData?.some((_: any) => {
      if (_.tabName === pramasActive && _.label) {
        const newData = _.label.slice(
          currentIndex.current,
          currentIndex.current + 5,
        )
        // console.log("----------->newData进入获取小类", newData);
        setSideData(newData)
        fetchData(newData, pramasActive)
        return true
      }
      return false
    })
    // 如果AllTypeData内不存在label，那么就调接口获取数据
    if (hasLabel) return
    interface_loading.current = true
    try {
      const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
        // cms接口地址
        content_type: 'make-2d-class-names',
        sort: ['weight:DESC'],
        pagination: {
          page: 1,
          pageSize: 10000,
          // start: 0,
          // limit: -1
        },
      })
      // console.log('---json-----', json.data?.data)
      let data = [] as any
      json.data?.data?.map((_: any) => {
        data.push({
          label: _?.attributes?.class_name,
          id: _?.id,
          type: _.attributes?.type,
        })
      })
      // console.log('======jsoandata', data)
      // 第一次进来时，获取所有类型数据（大类+小类）
      setAllTypeData((oldData: any) => {
        // console.log("oldData", oldData);
        const newData = oldData?.map((oldItem: any) => {
          const matchingItems = data?.filter(
            (newItem: any) => newItem?.type === oldItem?.tabName,
          )
          // console.log('matchingItems', matchingItems)
          if (matchingItems.length > 0) {
            return { ...oldItem, label: matchingItems }
          }
          return oldItem
        })
        console.log('newData', newData)
        data = newData
        setCacheItem('elementMenus', {
          ...getCacheItem('elementMenus'),
          AllTypeData: data,
        })
        return newData
      })
      // console.log("datamap", data);
      data?.map((_: any) => {
        if (_.tabName === activeTabRef.current) {
          // 存放五项数据，超出高度就加载后面五项
          const newData = _.label?.slice(
            currentIndex.current,
            currentIndex.current + 5,
          )
          if (!newData) {
            setListLoading(false)
            setSideData([])
            interface_loading.current = false
          } else {
            // 率先展示小类，然后再调接口填充值
            setSideData(newData)
            fetchData(newData, pramasActive)
          }
        }
      })
    } catch (error) {
      console.log('fetchSonClass获取所有小类错误')
      setListLoading(false)
      interface_loading.current = false
      setIsError(true)
      return
    }
  }

  //  首页加载更多数据
  const fetchListMore = () => {
    if (interface_loading.current === true) {
      // 给个提示
      // dispatch(
      //   openToast({
      //     message: 'The data source is loading, please wait',
      //     severity: 'warning',
      //   }),
      // )
      // 延迟一秒再跑一次
      setTimeout(fetchListMore, 1000)
      return
    }
    let newData: any[] = []
    const cachePageData = cacheData('elementMenus') || {}
    const foundItem = AllTypeData.find((item: any) => item?.tabName === active)
    const nowItem =
      foundItem && foundItem.label
        ? foundItem
        : getCacheItem('elementMenus')?.AllTypeData.find(
          (item: any) => item?.tabName === active,
        )

    // console.log("---->12333===========", cachePageData?.[active]?.data, "nowItem?.label?.length", nowItem?.label?.length);

    // 只有所有数据大于缓存数据时才加载更多
    if (nowItem?.label?.length <= cachePageData?.[active]?.data.length) {
      setListMore(false)
      return
    }

    if (isSeeAll === true) return
    AllTypeData?.map((_: any) => {
      if (_.tabName === active && interface_loading.current === false) {
        // 存放五项数据，超出高度就加载后面五项
        newData = _?.label?.slice(
          currentIndex.current,
          currentIndex.current + 5,
        )
        // 率先展示小类，然后再调接口填充值
        setSideData((item: any) => {
          return [...item, ...newData]
        })
        fetchData(newData)
      }
    })
  }

  // 搜索时调用的方法
  const getSearchData = async (
    FilterValue: any,
    SearchData: any,
    operatorType?: string,
    pramasActive?: string,
  ) => {
    // alert(operatorType)
    setSideData([])
    setListMore(false)
    // console.log('搜索时调用的方法',active,pramasActive)
    FilterValue = getCacheItem('elementMenus')?.['activeForm'] || FilterValue
    if (typeof window === 'undefined') return []
    setLoading(true)
    const filters: any = {
      type: {
        $eq: pramasActive || active,
      },
    }
    // 搜索框数据
    if (SearchData !== 'clear') {
      if (!!searchValue) {
        // console.log("----->ss搜索条件", searchValue?.length);
        if (searchValue?.length === 1) {
          // 一个字符的时候，精准搜索
          filters.title = {
            $eq: searchValue,
          }
        } else {
          filters.title = {
            $contains: searchValue,
          }
        }
      }
    }

    // product筛选数据
    if (FilterValue?.product?.length > 0 || filterValue?.product?.length > 0) {
      filters.producrt = {
        // 关联子级表格字段名称
        id: {
          $eq: FilterValue?.product || filterValue?.product,
        },
      }
    }

    // tags筛选数据
    if (FilterValue?.tags?.length > 0 || filterValue?.tags?.length > 0) {
      // console.log("----->w", FilterValue, filterValue);
      filters.tags = {
        // 关联子级表格字段名称
        id: {
          $eq: FilterValue?.tags || filterValue?.tags,
        },
      }
    }
    try {
      const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
        // cms接口地址
        content_type: 'make-2d-element-menus',
        populate: ['element_class', 'element_image', 'tags'],
        // 筛选条件
        filters,
        pagination: {
          page: 1,
          pageSize: 20,
        },
      })
      // console.log("filtersfilters", filters);

      const data = json.data || []
      const tempActive = pramasActive || active
      transformData(data).then((result) => {
        // 后续需要判断是否是切换tab操作，如果是，则取最后一次的搜索值
        setSideData(result)
        // console.log("---------------chufa");

        // const cacheMunedata = cacheData('elementMenus') || {};
        // // 如果有过滤条件 或者 是更改过滤条件操作就清空数据
        // if (operatorType !== '' || searchValue !== '' || FilterValue?.product?.length > 0 || FilterValue?.tags?.length > 0 || filterValue?.tags?.length > 0 || filterValue?.product?.length > 0) {
        //   Object.keys(cacheMunedata).forEach((key) => {
        //     // console.log('--1-1',key,active,cacheMunedata[key] ,tempActive)
        //     if (key !== tempActive) {
        //       // console.log('------Object.keys',tempActive+'-------'+key)
        //       cacheMunedata[key].data = [];
        //     }
        //   })
        // }
        setLoading(false)
      })
    } catch (error) {
      console.log('getSearchData搜索时调用的方法错误')
      setLoading(false)
    }
  }

  const SearchValue = (value: any) => {
    // 搜索框数据
    setCacheItem('elementMenus', {
      ...getCacheItem('elementMenus'),
      searchValue: value,
    })
    SetSearchValue(value)
  }

  const IconClick = () => {
    // 搜索按钮
    // getSearchData([], '');
  }

  const addSvgToCanvas = async (data: any) => {
    const response = await fetch(data?.canvas_image)
    const blob = await response.blob()
    getImgStr(blob).then((file) => {
      canvasEditor?.addSvgFile(file as string)
    })
    // setNetLoading(false);
  }

  const addImageToCanvas = async (data: any, fileExtension: string) => {
    canvasEditor?.stopSaveHistory()
    const base64 = await convertToBase64(data?.image)

    canvasEditor?.addImage(
      base64,
      {
        importSource: ImportSource.Cloud,
        fileType: fileExtension,
        [CustomKey.skip_upload]: true,
      },
      async (imageElement: fabric.Image) => {
        // setNetLoading(false);
        if (imageElement) {
          let worker = new Base64Worker()
          worker.postMessage(data)
          worker.onmessage = async (e: any) => {
            await replaceThumbnailWithOriginal(e.data, imageElement)
            worker.terminate()
            worker = null;
          }
        }
      }
    )
  }

  const replaceThumbnailWithOriginal = async (
    base64Original: any,
    imageElement: any,
  ) => {
    // const base64Original = await convertToBase64(data?.canvas_image);

    if (base64Original) {
      // 获取画布的缩放因子
      const zoom = imageElement.group ? 1 : canvasEditor?.canvas.getZoom()
      // 考虑缩放因子计算原始尺寸
      const originalWidth = imageElement.width! * imageElement.scaleX! * zoom!
      const originalHeight = imageElement.height! * imageElement.scaleY! * zoom!
      //@ts-ignore
      imageElement.set(CustomKey.key_prefix, '')
      //@ts-ignore
      imageElement.set(CustomKey.skip_upload, false)

      // imageElement.set('src', base64Original)
      imageElement.setSrc(
        base64Original,
        () => {
          imageElement.scaleToWidth(originalWidth)
          imageElement.scaleToHeight(originalHeight)
          canvasEditor?.canvas.renderAll()
          canvasEditor?.startSaveHistory(true)
          // ProjectManager?.getInstance()?.atOnceSave();
        },
        { crossOrigin: 'anonymous' },
      )
    } else {
      canvasEditor?.startSaveHistory(true)
    }
  }

  const CardClick = async (data: any) => {
    console.log('-------CardClick-------element---------', data)
    // 获取文件后缀;
    const fileExtension = data?.canvas_image?.split('.')?.pop()
    // setNetLoading(true);
    if (fileExtension === 'svg') {
      if (active === 'Pattern') {
        handlePatternImport(data)
      } else {
        await addSvgToCanvas(data)
      }
    } else {
      await addImageToCanvas(data, fileExtension)
    }
  }
  // handle pattern click;
  const handlePatternImport = async (data: any) => {
    setNetLoading(false)
    console.log('handlePatternImport; data', data)
    const response = await fetch(data?.canvas_image)
    const blob = await response.blob()
    const workspace = canvasEditor?.canvas
      .getObjects()
      .find((item: any) => !!~item.id.indexOf(WorkspaceID.WorkspaceCavas))
    // @ts-ignore
    const patternWidth = !!workspace
      // @ts-ignore
      ? workspace.width * workspace.scaleX
      : projectModel?.canvases[projectModel.canvasesIndex].base_map_width
    // @ts-ignore
    const patternHeight = !!workspace
      // @ts-ignore
      ? workspace.height * workspace.scaleY
      : projectModel?.canvases[projectModel.canvasesIndex].base_map_height
    // const patternLeft = !!workspace ? workspace.left : 0;
    // const patternTop = !!workspace ? workspace.top + patternWidth / 2 : 0;
    getImgStr(blob).then((base64) => {
      canvasEditor?.addPattern(base64, {
        width: patternWidth,
        height: patternHeight,
        left: 0,
        top: 0,
      })
    })
  }

  const handleTabChange = (tab: any) => {
    // 切换tab时清空上一次loading状态
    if (tab.tabName === active) {
      return
    }
    setListMore(false)
    currentIndex.current = 0
    setSeeAllData([]) //清空旧的seeAll数据
    setSideData([]) //清空表格数据
    setLoading(false) // 清空搜索时loading状态
    setListLoading(false) // 清空加载更多loading状态
    setIsSeeAll('') // 清空seeAll状态
    setCacheItem('elementMenus', {
      ...getCacheItem('elementMenus'),
      tabKey: tab.tabName,
    })
    setActive(tab.tabName) // 切换tab时设置当前tab
    activeTabRef.current = tab.tabName
    // 切换tab时设置数据
    requestData(tab.tabName, 'changeTab')
    activeRef.current = tab.tabName
  }

  // 清空seeAll状态
  const clearSeeAllState = () => {
    refdata.current.resetExpandedStates()
  }

  useEffect(() => {
    // setFilterValue(getCacheItem('elementMenus')?.['activeForm'] || [])
    // SetSearchValue(getCacheItem('elementMenus')?.['searchValue'] || '');
    setFilterValue([])
    SetSearchValue('')
    refInput.current.resetExpandedStates()
    // 初始时不存在AllTypeData，当切换了侧边tab后从缓存中取
    setAllTypeData((item: any) => {
      const cacheData = getCacheItem('elementMenus')?.AllTypeData || []
      return item.map((oldItem: any) => {
        const newItem = cacheData.find(
          (cacheItem: any) =>
            cacheItem.tabName === oldItem.tabName && cacheItem.label,
        )
        return newItem || oldItem
      })
    })
    const cacheActive = getCacheItem('elementMenus')?.['tabKey']
    if (cacheActive) {
      setActive(cacheActive)
      activeTabRef.current = cacheActive
    }
  }, [])

  useEffect(() => {
    const cacheActive = getCacheItem('elementMenus')?.['tabKey']
    const tempActive = cacheActive ? cacheActive : active // 初次进来取默认值；有缓存取缓存值
    requestData(tempActive)
  }, [])

  useEffect(() => {
    // @ts-ignore
    DataCache.getInstance().updateMaterialtEmitter(event)
    return () => {
      DataCache.getInstance().removeUpdateMaterialtEmitter()
    }
  }, [])

  // console.log("cacheData('elementMenus')缓存数据", cacheData('elementMenus'));

  const requestData = (tempActive: string, changeTab?: string) => {
    setSideData([])
    const cachePageData = cacheData('elementMenus') || {}
    const paramsActive = tempActive || active
    // console.log("cachePageData?.[paramsActive] && cachePageData?.[paramsActive]?.['data']?.length > 0", cachePageData, paramsActive);

    // 有缓存的时候，且筛选框无数据
    if (
      (cachePageData?.[paramsActive] &&
        cachePageData?.[paramsActive]?.['data']?.length > 0 &&
        filterValue?.length === 0 &&
        searchValue === '') ||
      (searchValue === '' &&
        filterValue?.['product']?.length === 0 &&
        filterValue?.['tags']?.length === 0)
    ) {
      console.log('-------->有缓存')
      setSideData(cachePageData?.[paramsActive]?.data)
      // 从右侧使用缓存进入时，才用缓存内的大类与小类数据调接口
      const foundItem = AllTypeData.find(
        (item: any) => item?.tabName === paramsActive,
      )
      const nowItem =
        foundItem && foundItem.label
          ? foundItem
          : getCacheItem('elementMenus')?.AllTypeData.find(
            (item: any) => item?.tabName === paramsActive,
          )
      // 判断是否有更多数据需要加载更多
      if (nowItem?.label?.length > cachePageData?.[paramsActive]?.data.length) {
        currentIndex.current = cachePageData?.[paramsActive]?.data.length
        setListMore(true)
      } else {
        setListMore(false)
        return
      }
      // alert(1)
    } else {
      console.log('----->无缓存')
      //没搜索数据，没筛选数据
      if (
        (filterValue?.length === 0 && searchValue === '') ||
        (searchValue === '' &&
          filterValue?.['product']?.length === 0 &&
          filterValue?.['tags']?.length === 0)
      ) {
        fetchSonClass(tempActive)
        console.log('----->2', tempActive, changeTab)

        // alert(2)
      } else {
        console.log('----->3')
        getSearchData('', '', '', paramsActive)
        // alert(3)
      }
    }
  }

  const item_refresh = (item: any) => {
    // 添加需要loading状态的id项
    setRefreshLoading((oldData: any) => [...oldData, item.id])
    fetchData([{ label: item.label, id: item?.id }])
  }

  // 点击seeAll时调用，seeAllState：是否点击了seeAll，item：当前点击的小类，clear：清空数据状态
  const IsSeeAll = (seeAllState: any) => {
    SeeAllref.current = seeAllState
    // console.log("------IsSeeAll", seeAllState);

    setIsSeeAll(seeAllState)
  }

  useEffect(() => {
    // console.log("----->isSeeAll进行了修改", isSeeAll);
    // 当输入框存在数据时，不设置表格数据，使用旧值
    if (searchValue.length === 0) {
      // 没有点击seeAll时,且不是切换tab,且不是刚进入页面时,则使用旧的数据
      if (
        !isSeeAll &&
        isSeeAll !== '' &&
        cacheData('elementMenus')?.[active]?.data
      ) {
        // alert(5)
        // setSideData(OldsideData)
        setSideData(cacheData('elementMenus')?.[active]?.data)
      }
    } else {
      if (!isSeeAll && isSeeAll !== '') {
        // setSideData()
        // setSideData(cacheData('elementMenus')?.[active]?.data);
      }
    }
  }, [isSeeAll])

  // console.log("interface_loading.current状态", interface_loading.current);

  return (
    <div className="element_box">
      <FilterPopover
        open={FilterPopoverState}
        onClose={onClose}
        anchorEl={anchorEl}
        ConfirmClick={ConfirmClick}
        ClearnAllClick={ClearnAllClick}
      />
      <div className="element_top">
        <div className="element_title">{getTranslation(TranslationsKeys.Element)}</div>
        {/* <img src={close_icon} className="element_icon" /> */}
      </div>

      <div
        style={{
          pointerEvents: interface_loading.current ? 'none' : undefined,
        }}
        className="ElementInput_box"
      >
        <SearchInput
          SearchValue={SearchValue}
          IconClick={IconClick}
          editClick={editClick}
          getSearchData={getSearchData}
          fetchSonClass={fetchSonClass}
          CloseState={CloseState}
          filterValue={filterValue}
          clearSeeAllState={clearSeeAllState}
          refInput={refInput}
        />
      </div>

      <div
        className="TabSwitcher"
        style={{
          pointerEvents: interface_loading.current ? 'none' : undefined,
        }}
      >
        <TabSwitcher tabs={tabs} onTabChange={handleTabChange} />
      </div>
      {isError && (
        <div className="error_box">
          <div
            className="item_refresh"
            onClick={() => {
              fetchSonClass()
            }}
          >
            {getTranslation(TranslationsKeys.Refresh)}
          </div>
          <div className="no_data_box">
            <img src={empty_data_icon} className="no_data_icon" />
            <div>{getTranslation(TranslationsKeys.NO_DATA_AVAILABLE)}</div>
          </div>
        </div>
      )}
      <div style={{ height: '80%', overflow: isSeeAll === true ? '' : 'auto' }}>
        <SideTable
          data={sideData}
          CardClick={CardClick}
          isLoading={isLoading}
          hasLoading={hasLoading}
          hasMore={hasMore}
          type={'ElementMenus'}
          active={active}
          fetchDataMore={fetchDataMore}
          IsSeeAll={IsSeeAll}
          refdata={refdata}
          item_refresh={item_refresh}
          RefreshLoading={RefreshLoading}
          fetchListMore={fetchListMore}
          ListLoading={ListLoading}
          ListMore={ListMore}
          RightMoreData={RightMoreData}
          isDetailsIcon={true}
        />
      </div>
      <Loading loading={isNetLoading} />
    </div>
  )
}

export default ElementMenus
