// 依赖
import React from "react";

// 图标
import delete_icon from 'src/assets/svg/delete_icon_black.svg';

// 组件
import Dialog from '@mui/material/Dialog';
import { Button } from 'src/components/MakeUI'
import CustomCheckbox from 'src/components/CustomCheckbox';

// 样式
import * as classes from './MainUiLeftFooterBarStyle.module.scss';

import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

// 父组件参数类型
interface ObjViewerProps {
  selectedItems: any[], // 勾选条数
  alertTip?: string, // 提示语
  isHandleConfirmSuccess: boolean, // 是否处于提交状态
  openDialog: boolean, // 是否打开弹窗
  dialogDes: string, // 弹窗内容
  selectAll: boolean, // 是否全选
  isShowFooterbar?: boolean, // 是否显示底部操作
  setIsEditing: () => void, // 是否编辑状态
  handleSelectAll: () => void, // 全选
  handleConfirm: () => void, // 点击确认
  setOpenDialog: () => void, // 打开弹窗
  setCloseDialog: () => void, // 关闭弹窗
  dataList: any[] // 列表数据
  isItemDeleteId: any // 删除的id
}

const MainUiLeftFooterBar: React.FC<ObjViewerProps> = ({
  selectedItems, isHandleConfirmSuccess, alertTip = '请先勾选要删除的文件', handleSelectAll, handleConfirm, setIsEditing,
  setOpenDialog, openDialog, setCloseDialog, dialogDes, selectAll, isShowFooterbar = true, dataList, isItemDeleteId
}) => {

  const { getTranslation } = useCustomTranslation();

  const confirmSubmit = () => {
    handleConfirm();
  }

  const handleOpenDialog = () => {
    setOpenDialog();
  }

  return (
    <div>
      {(isShowFooterbar || !isItemDeleteId) && <div className={classes.footerBar}>
        <div className={classes.allCheckBox}>
          <CustomCheckbox
            className={classes.inputCheckbox}
            checked={selectAll || (dataList?.length === selectedItems.length)}
            onChange={handleSelectAll}
          />
          {`(${selectedItems.length})`} <span className={classes.selectLable}>{selectAll ? getTranslation(TranslationsKeys.ALL) : getTranslation(TranslationsKeys.SELECTED)}</span>
        </div>
        <div className={classes.footerBarRight}>
          <img
            className={classes.projectDeleteIcon}
            src={delete_icon}
            onClick={() => { selectedItems.length === 0 ? console.log('') : handleOpenDialog() }}
          />
          <button className={classes.cancelBtn} onClick={setIsEditing}>{getTranslation(TranslationsKeys.BUTTON_CANCEL)}</button>
        </div>
      </div>}
      <Dialog onClose={() => setCloseDialog} open={openDialog}>
        <div className={classes.dialogLayout}>
          <div className={classes.tipDes}>
            {dialogDes}
          </div>
          <div className={classes.btnGroup}>
            <div className={classes.btnItem}>
              <Button
                disabled={isHandleConfirmSuccess}
                className={classes.cancelBtn}
                onClick={setCloseDialog}
                size="large"
              >
                {getTranslation(TranslationsKeys.BUTTON_CANCEL)}
              </Button>
            </div>
            <div className={classes.btnItem}>
              <Button
                loading={isHandleConfirmSuccess}
                className={classes.confirmBtn}
                onClick={() => confirmSubmit()}
              >
                {getTranslation(TranslationsKeys.BUTTON_CONFIRM)}
              </Button>
            </div>
          </div>
        </div>
      </Dialog>
    </div>
  );
}

export default MainUiLeftFooterBar;