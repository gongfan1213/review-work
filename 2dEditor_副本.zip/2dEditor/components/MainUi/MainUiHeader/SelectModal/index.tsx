import React, { useState } from 'react'
import * as classes from './index.module.scss'
import minus_down from 'src/assets/svg/minus_down.svg'
import clsx from 'clsx'
import {
  CustomKey,
  WorkspaceID,
  ACTION_MAGICK,
  EDITOR_JSON_KEY,
} from 'src/templates/2dEditor/cons/2dEditorCons'
import { post } from 'src/services'
import { convertToBase64 } from 'src/common/utils'
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common'

//@ts-ignore
import IMagickWorker from 'src/templates/2dEditor/core/worker/imagick.worker'
import { AddJsonTempID } from 'src/templates/2dEditor/core/plugin/HistoryPlugin/types'
import { getImgStr, selectFiles } from 'src/templates/2dEditor/utils/utils'
import {
  useCanvasEditor,
  useProjectData
} from 'src/templates/2dEditor/hooks/context'
import Button from '@mui/material/Button'
import { Form, Input } from 'src/components/MakeUI'
import Base64Worker from 'src/templates/2dEditor/core/worker/base64.worker'
import { useFontFamily } from 'src/templates/2dEditor/components/MainUi/MainUiTopTool/hooks/useFontFamily'

import { BaseMapChangeManager } from '../../../BaseMapChange/logic/BaseMapChangeManager'
export default function SettingLanguage({
  label,
  width,
}: {
  label?: string
  width?: number
}) {
  const [isLanguage, setIsLanguage] = useState<boolean>(false)
  const canvasEditor = useCanvasEditor()
  const projectModel = useProjectData()
  const [form] = Form.useForm()

  let _imageElement: any = null
  // let worker = new Base64Worker()
  // worker.onmessage = async (e: any) => {
  //   await replaceThumbnailWithOriginal(e.data)
  //   worker.terminate()
  //   worker = null
  // }

  const replaceThumbnailWithOriginal = async (base64Original: any) => {
    // const base64Original = await convertToBase64(data?.canvas_image);

    if (base64Original) {
      // 获取画布的缩放因子
      const zoom = canvasEditor?.canvas.getZoom()
      // 考虑缩放因子计算原始尺寸
      const originalWidth = _imageElement.width! * _imageElement.scaleX! * zoom!
      const originalHeight =
        _imageElement.height! * _imageElement.scaleY! * zoom!
      //@ts-ignore
      _imageElement.set(CustomKey.key_prefix, '')
      //@ts-ignore
      _imageElement.set(CustomKey.skip_upload, false)

      _imageElement.setSrc(
        base64Original,
        () => {
          _imageElement.scaleToWidth(originalWidth)
          _imageElement.scaleToHeight(originalHeight)
          canvasEditor?.canvas.renderAll()
          canvasEditor?.startSaveHistory(true)
          // ProjectManager?.getInstance()?.atOnceSave();
        },
        { crossOrigin: 'anonymous' },
      )
    } else {
      canvasEditor?.startSaveHistory(true)
    }
  }

  //模版自动化测试方法
  const handleSubmit = () => {
    canvasEditor?.clear()
    const values = form?.getFieldsValue(['templateUrl'])
    canvasEditor?.addJSON(values?.templateUrl, true)
    form?.resetFields()
  }

  //element自动化测试方法
  const handlePatternImport = async (data: any) => {
    const response = await fetch(data?.canvas_image)
    const blob = await response.blob()
    const workspace: any = canvasEditor?.canvas
      .getObjects()
      .find((item: any) => !!~item.id.indexOf(WorkspaceID.WorkspaceCavas))
    // @ts-ignore
    const patternWidth = !!workspace
      ? workspace?.width * workspace?.scaleX
      : projectModel?.canvases[projectModel.canvasesIndex].base_map_width
    // @ts-ignore
    const patternHeight = !!workspace
      ? workspace?.height * workspace?.scaleY
      : projectModel?.canvases[projectModel.canvasesIndex].base_map_height
    // const patternLeft = !!workspace ? workspace.left : 0;
    // const patternTop = !!workspace ? workspace.top + patternWidth / 2 : 0;
    getImgStr(blob).then((base64) => {
      canvasEditor?.addPattern(base64, {
        width: patternWidth,
        height: patternHeight,
        left: 0,
        top: 0,
      })
    })
  }

  const addSvgToCanvas = async (url: any) => {
    if (!url) return
    const response = await fetch(url)
    const blob = await response.blob()
    getImgStr(blob).then((file) => {
      canvasEditor?.addSvgFile(file as string)
    })
  }

  const addImageToCanvas = async (url: any, fileExtension: string) => {
    if (!url) return
    canvasEditor?.stopSaveHistory()
    const base64: any = await convertToBase64(url)
    canvasEditor?.addImage(
      base64,
      {
        importSource: ImportSource?.Cloud,
        fileType: fileExtension,
        [CustomKey.skip_upload]: true,
      },
      async (imageElement: fabric.Image) => {
        // setNetLoading(false);
        if (imageElement) {
          // worker?.postMessage(url)
          _imageElement = imageElement
          // await replaceThumbnailWithOriginal(data, imageElement);
        }
      },
    )
  }
  const CardClick = async () => {
    // 获取文件后缀;
    canvasEditor?.clear()
    const data: any = form?.getFieldsValue(['elementUrl', 'elementType'])
    const fileExtension = data?.elementUrl?.split('.')?.pop()
    if (fileExtension === 'svg') {
      if (data?.elementType === 'Pattern') {
        handlePatternImport(data)
        form?.resetFields()
      } else {
        await addSvgToCanvas(data?.elementUrl)
        form?.resetFields()
      }
    } else {
      await addImageToCanvas(data?.elementUrl, fileExtension)
      form?.resetFields()
    }
  }

  //字体模版自动化测试
  const handleFontImport = async () => {
    canvasEditor?.clear()
    const values = form?.getFieldsValue(['templateFont'])
    await canvasEditor?.addJSON(values?.templateFont)
    form?.resetFields()
  }

  //替换字体自动化测试
  const { loadFont } = useFontFamily()
  const handleTypefaceClick = async () => {
    const fontFamily: any = form?.getFieldsValue([
      'fontFamilyName',
      'fontFamilyUrl',
    ])
    const activeObjects = canvasEditor!.canvas.getActiveObjects()
    activeObjects.forEach(async (activeObject) => {
      if (await loadFont(fontFamily.fontFamilyName)) {
        activeObject.set({
          fontFamily: fontFamily.fontFamilyName,
          [CustomKey.FontUrl]: fontFamily.fontFamilyUrl,
        })
        canvasEditor!.canvas.requestRenderAll()
        canvasEditor?.historySave()
        form?.resetFields()
      }
    })
  }

  const moduleData = [
    {
      label: 'init',
      value: 'init',
      fn: () => {
        var selectImg = canvasEditor?.canvas.getActiveObject()
        if (selectImg) {
          selectImg.set({
            left: 0,
            top: 0,
            scaleX: 1,
            scaleY: 1,
          })
          // 更新 canvas 以显示更改
          canvasEditor?.canvas.renderAll()
        }
      },
    },
    {
      label: 'posi',
      value: 'posi',
      fn: () => {
        console.log('selectImg====start ====')
        var selectImg = canvasEditor?.canvas.getActiveObject()
        if (selectImg) {
          console.log('selectImg====start ====')
          let worker = new IMagickWorker()
          ///得到图片数据dataUrl，传入worker里面
          worker.onmessage = function (e: any) {
            // 使用处理后的图像数据
            console.log('selectImg====getData ====')

            const base64 = e.data
            // 创建一个新的 Image 对象
            const img = new Image()
            img.onload = function () {
              // 图像加载完成后，将其添加到 canvas 中
              const fabricImage = new fabric.Image(img)
              canvasEditor?.canvas.add(fabricImage)
              canvasEditor?.canvas.renderAll()
            }
            // 设置图像的 src 为 base64 编码的数据
            img.src = base64
            worker.terminate()
            worker = null
          }
          ///四个角，原始坐标-》目标坐标
          // iphone15 323 645, （392，782）339，59
          //  const params = [
          //     0, 0, 0, 0,       // 左上角坐标不变（源坐标 (0, 0) -> 目标坐标 (10, 0)）
          //     1169, 0, 1169 - 104, 200,   // 右上角坐标向内倾斜（源坐标 (303, 0) -> 目标坐标 (216, 30)）
          //     0, 1654, 0, 1654,    // 左下角坐标不变（源坐标 (0, 597) -> 目标坐标 (0, 597)）
          //     1169, 1654, 1169 - 104, 1654 - 200  // 右下角坐标向内倾斜（源坐标 (303, 597) -> 目标坐标 (230, 607)）
          //   ];
          // {"rectPerspective":[0, 0, 86, 0, 1654, 0, 1506, 0, 0, 1654, 0, 1700, 1654, 1220, 1620, 1220]}
          const params = [
            0, 0, 0, 0, 110, 0, 110, 14, 0, 197, 0, 197, 110, 197, 141, 210,
          ]
          worker.postMessage({
            action: ACTION_MAGICK.ACTION_TYPE_DISTORT,
            data: {
              dataUrl: selectImg.toDataURL(), // 原始图像数据
              params: params, // 透视变换参数,
            },
          })
        }
      },
    },
    {
      label: 'posi Drinkware',
      value: 'posi Drinkware',
      fn: () => {
        let selectImg = canvasEditor?.canvas.getActiveObject()
        if (selectImg) {
          // 获取选中图像的宽度和高度
          const originalWidth = selectImg.getScaledWidth()
          const originalHeight = selectImg.getScaledHeight()
          // 瓶子左侧是cyCutLeft 0，中间是originalWidth! / 4，右侧是originalWidth! / 2
          // 杯子的场景图分为左侧视图，中间视图，右侧视图，分别截图矩形绘图区域的
          // 0到originalWidth! / 2，（左视图）
          // originalWidth! / 4 到 originalWidth! /4*3，（正视图） （注：金属杯与锥形金属杯(originalWidth! / 4 到 (originalWidth! / 4) * 2）
          // originalWidth! / 2到 originalWidth! ，（右视图）
          // 生成视图方法是setDistortCylinder
          const cyCutLeft = originalWidth! / 4
          const cyCutTop = 0
          const cyCutWidth = (originalWidth! / 4) * 2
          const cyCutHeight = originalWidth!
          // 创建新的图像对象，并设置裁剪区域
          const newImg = new fabric.Image(selectImg?.getElement(), {
            left: 0, // 通常设置为0，除非你需要在画布上移动图像
            top: 0, // 通常设置为0，除非你需要在画布上移动图像
            width: cyCutWidth,
            height: cyCutHeight,
            cropX: cyCutLeft, // 设置裁剪区域的起始X坐标
            cropY: cyCutTop, // 设置裁剪区域的起始Y坐标
          })

          let worker = new IMagickWorker()
          ///得到图片数据dataUrl，传入worker里面
          worker.onmessage = function (e: any) {
            // 使用处理后的图像数据
            const base64 = e.data
            // 创建一个新的 Image 对象
            const img = new Image()
            img.onload = function () {
              // 图像加载完成后，将其添加到 canvas 中
              const fabricImage = new fabric.Image(img)
              canvasEditor?.canvas.add(fabricImage)
              canvasEditor?.canvas.renderAll()
            }
            // 设置图像的 src 为 base64 编码的数据
            img.src = base64
            worker.terminate()
            worker = null
          }
          ///四个角，原始坐标-》目标坐标
          console.log('selectImg====start ====', newImg.width, newImg.height)
          const width = newImg.width!
          const height = newImg.height!

          const offset = 170 // 数值越大，宽度越小
          const offsetH = 550 // 数值越大，高度越小
          // 源图像的四个角点
          const srcPoints = [
            // 源图像坐标点    目标图像坐标点
            0,
            0,
            offset - 4,
            0, // 左上角
            width,
            0,
            width - offset + 4,
            0, // 右上角
            0,
            height,
            offset,
            height - offsetH, // 左下角
            width,
            height,
            width - offset,
            height - offsetH, // 右下角
          ]
          // 控制点数组，需要根据图像尺寸和所需效果进行调整
          const amplitude = 50 // 波浪的振幅
          const length = width * 2 // 波浪的波长，设置为图片宽度的两倍,数值越小，波浪越向右
          console.log('selectImg====srcPoints ====', srcPoints)

          var retData: CyRetData = {
            cyCutLeft: cyCutLeft,
            cyCutTop: cyCutTop,
            cyCutWidth: cyCutWidth,
            cyCutHeight: cyCutHeight,
            srcPoints: srcPoints,
            amplitude: amplitude,
            length: length,
          }

          console.log('selectImg====Ret ====', JSON.stringify(retData))

          const params = srcPoints
          worker.postMessage({
            action: ACTION_MAGICK.ACTION_TYPE_DISTORT_CYLINDER,
            data: {
              dataUrl: newImg.toDataURL(), // 原始图像数据
              params: params, // 透视变换参数,
              amplitude: amplitude,
              length: length,
            },
          })
        }
      },
    },
    {
      label: '导入文件',
      value: '导入文件',
      fn: () => {
        selectFiles({ accept: '.json' }).then((files) => {
          const [file] = files
          const reader = new FileReader()
          reader.readAsText(file, 'UTF-8')
          reader.onload = () => {
            const _uuid = AddJsonTempID.ID
            const allObjects = canvasEditor?.canvas
              .getObjects()
              .map((item: any) => item.toJSON(['selectable', 'evented', 'id']))

            console.log('=======allObjects===', allObjects)
            const currentObjects = allObjects.filter((item: any) =>
              item.id.includes(WorkspaceID.WorkspaceCavas),
            )
            console.log('=======currentObjects===', reader.result)

            if (typeof reader.result === 'string') {
              // 解析 JSON 字符串为对象
              const resultObject = JSON.parse(reader.result)
              const newObjects = resultObject.objects
              console.log('=======newObjects ===', newObjects)
              const result = { objects: [...currentObjects, ...newObjects] }
              canvasEditor?.insertSvgFile(result)
            }
          }
        })
      },
    },
    {
      label: 'templateUrl',
      value: 'templateUrl',
      component: (
        <div className={classes.templateUrl}>
          <Form
            form={form}
            layout="vertical"
            className={classes.templateUrlForm}
            scrollToFirstError
          >
            <Form.Item name="templateUrl" className="str_width" label={''}>
              <Input placeholder="模板地址" />
            </Form.Item>
          </Form>
          <Button
            className={classes.submit}
            variant="contained"
            onClick={handleSubmit}
          >
            Submit
          </Button>
        </div>
      ),
    },
    {
      label: 'element',
      value: 'element',
      component: (
        <div
          className={classes.templateUrl}
          style={{
            height: '100px',
            borderTop: '1px solid #ccc',
            borderBottom: '1px solid #ccc',
            marginTop: '20px',
            padding: '10px 0',
          }}
        >
          <Form
            form={form}
            layout="vertical"
            className={classes.templateUrlForm}
            scrollToFirstError
          >
            <Form.Item
              name="elementType"
              className="str_width"
              label={''}
              style={{ marginBottom: '14px' }}
            >
              <Input placeholder="element类型" />
            </Form.Item>
            <Form.Item name="elementUrl" className="str_width" label={''}>
              <Input placeholder="Element地址" />
            </Form.Item>
          </Form>
          <Button
            className={classes.submit}
            style={{ marginTop: '20px' }}
            variant="contained"
            onClick={CardClick}
          >
            Submit
          </Button>
        </div>
      ),
    },
    {
      label: 'templateFont',
      value: 'templateFont',
      component: (
        <div className={classes.templateUrl} style={{ marginTop: '18px' }}>
          <Form
            form={form}
            layout="vertical"
            className={classes.templateUrlForm}
            scrollToFirstError
          >
            <Form.Item name="templateFont" className="str_width" label={''}>
              <Input placeholder="fontTemplate" />
            </Form.Item>
          </Form>
          <Button
            className={classes.submit}
            variant="contained"
            onClick={handleFontImport}
          >
            Submit
          </Button>
        </div>
      ),
    },
    {
      label: 'fontFamily',
      value: 'fontFamily',
      component: (
        <div
          className={classes.templateUrl}
          style={{
            height: '100px',
            borderTop: '1px solid #ccc',
            borderBottom: '1px solid #ccc',
            marginTop: '20px',
            padding: '10px 0',
          }}
        >
          <Form
            form={form}
            layout="vertical"
            className={classes.templateUrlForm}
            scrollToFirstError
          >
            <Form.Item
              name="fontFamilyName"
              className="str_width"
              label={''}
              style={{ marginBottom: '14px' }}
            >
              <Input placeholder="fontName" />
            </Form.Item>
            <Form.Item name="fontFamilyUrl" className="str_width" label={''}>
              <Input placeholder="font地址" />
            </Form.Item>
          </Form>
          <Button
            className={classes.submit}
            style={{ marginTop: '20px' }}
            variant="contained"
            onClick={handleTypefaceClick}
          >
            Submit
          </Button>
        </div>
      ),
    },
    {
      label: '生成Templates json模板',
      value: '生成Templates json模板',
      fn: () => {
        // 获取当前画布的所有对象，返回的是一个数组
        // canvasEditor?.canvas.getObjects()
        const workspaceObjects = canvasEditor?.canvas
          .getObjects()
          ?.filter(
            (item: any) => !item.id?.includes(WorkspaceID.WorkspaceCavas),
          )
          .map((item: any) => item.toJSON(EDITOR_JSON_KEY)) // 使用 toJSON 方法并传入 EDITOR_JSON_KEY

        const result = { objects: workspaceObjects }
        // 创建一个 Blob 对象，包含 JSON 数据
        const blob = new Blob([JSON.stringify(result)], {
          type: 'application/json',
        })
        // 创建一个可以下载的链接
        const url = URL.createObjectURL(blob)
        // 创建一个新的 'a' 标签，并触发点击事件来开始下载
        const link = document.createElement('a')
        link.href = url
        link.download = 'stencil.json' // 设置下载的文件名
        link.click()
        // 释放创建的 URLcanvasEditorgetElement
        URL.revokeObjectURL(url)
      },
    },
    {
      label: '生成Text json模板',
      value: '生成Text json模板',
      fn: () => {
        // 获取当前画布的所有对象，返回的是一个数组
        // canvasEditor?.canvas.getObjects()
        // const workspaceObjects = canvasEditor?.canvas.getObjects()?.filter((item: any) => !item.id?.includes(WorkspaceID.WorkspaceCavas));
        // const result = { objects: workspaceObjects }
        // // 创建一个 Blob 对象，包含 JSON 数据
        // const blob = new Blob([JSON.stringify(result)], { type: 'application/json' });
        const canvasJson = JSON.stringify({
          objects: canvasEditor?.canvas
            .toJSON(EDITOR_JSON_KEY)
            .objects.filter(
              (item: any) => !~item?.id?.indexOf(WorkspaceID.WorkspaceCavas),
            ),
        })
        // 创建一个 Blob 对象，包含 JSON 数据
        const blob = new Blob([canvasJson], { type: 'application/json' })
        // 创建一个可以下载的链接
        const url = URL.createObjectURL(blob)
        // 创建一个新的 'a' 标签，并触发点击事件来开始下载
        const link = document.createElement('a')
        link.href = url
        link.download = 'font.json' // 设置下载的文件名
        link.click()
        // 释放创建的 URL
        URL.revokeObjectURL(url)
      },
    },
    {
      label: 'nojsTest',
      value: 'nojsTest',
      fn: () => {
        nojsTest()
      },
    },
    {
      label: 'getDeviceInfo',
      value: 'getDeviceInfo',
      fn: () => {
        BaseMapChangeManager.getInstance().getDeviceInfo();
        BaseMapChangeManager.getInstance().initNotifyListener((action: any, data: any) => {

        });
      },
    },
    {
      label: 'printTest',
      value: 'printTest',
      fn: () => {
        printTest()
      },
    },
    {
      label: 'LightTest',
      value: 'LightTest',
      fn: () => {
        lightTest()
      },
    },
  ]

  function lightTest() {
    // LightMapManager.getInstance().adjustColorSaturation("");
  }

  function printTest() {
    var selectImg = canvasEditor?.canvas.getActiveObject();
    BaseMapChangeManager.getInstance().selectImgToCanvas(selectImg!, projectModel!);
    canvasEditor?.canvas.discardActiveObject();
    // BaseMapChangeManager.getInstance().getCutBaseImgs("", {
    //   orginX: 0,
    //   orginY: 0,
    //   width: 0,
    //   height: 0,
    //   outlineSvgStr: ''
    // });
    // BaseMapChangeManager.getInstance().getCutImgs("", []);
    // BaseMapChangeManager.getInstance().takePhoto();
  }

  async function nojsTest() {
    try {
      console.debug(
        'print_file ====',
        projectModel?.canvases[0].print_file.download_url,
      )
      //   const resp = await post<any>('http://10.1.121.157:3000/api/lumen-server', { "data": projectModel })
      const resp = await post<any>(
        'https://aiot-api-ci.mkitreal.com/lumenserver/api/lumen-server',
        { data: projectModel },
      )
      return resp
    } catch {
      return null
    }
  }

  const handleMouseEnter = () => {
    setIsLanguage(true)
  }

  const handleMouseLeave = () => {
    setIsLanguage(false)
  }

  const handleChangeLanguage = (item: {
    label: string
    value: string
    fn?: () => void
  }) => {
    item.fn && item.fn()
  }

  return (
    <div className={classes.unitSelect}>
      {label && <span className={classes.unitName}>{label}:</span>}
      <div
        style={{ width: (width || 206) + 'px' }}
        className={classes.language}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        {/* <div className={classes.title}>
          <span className={classes.defaultName}>{'development tools'}</span>
          <img className={classes.arrow_down} src={minus_down} />
        </div> */}
        {isLanguage && (
          <div className={classes.selectProps}>
            <div className={classes.selectGroupBox}>
              <i className={classes.triangleUp}></i>
            </div>
            <ul className={classes.selectGroup}>
              {moduleData.map((item, index) => {
                return (
                  <li
                    className={clsx(classes.ulLi, {
                      [classes.ulLiKey]: !item.component,
                    })}
                    key={index}
                    onClick={() => handleChangeLanguage(item)}
                  >
                    {item.component ? item.component : item.label}
                  </li>
                )
              })}
            </ul>
          </div>
        )}
      </div>
    </div>
  )
}
