import React, { useRef, useEffect, useState } from 'react'
import * as classes from './index.module.scss'
import edit_pencil from 'src/assets/svg/edit_pencil.svg'
import { updateProject } from 'src/templates/2dEditor/service/2dEditService'
import { Form, Field } from 'react-final-form'
import Tooltip from '../Tooltip'
import { PROJECT_STANDARD_TYPE } from 'src/templates/2dEditor/cons/2dEditorCons'
import clsx from 'clsx'
import { sendCommandToPc } from 'src/common/jsbridge'

export default function ProjectName({
  dialogData,
  getEditProjectName,
}: {
  dialogData: any
  getEditProjectName: (item: any) => void
}) {
  const [gradientAngle, setGradientAngle] = useState<any>({})
  const [isEditable, setIsEditable] = useState(false)
  const inputRef = useRef<any>(null)

  useEffect(() => {
    setGradientAngle(dialogData || {})
  }, [dialogData])

  useEffect(() => {
    if (inputRef.current) {
      inputRef?.current?.focus()
    }
  }, [isEditable])

  useEffect(() => {
    function handleKeyDown(e: any) {
      if (e?.key === 'Enter') {
        inputRef?.current?.blur()
      }
    }
    window.addEventListener('keydown', (e) => {
      handleKeyDown(e)
    })
    return () => {
      window.removeEventListener('keydown', (e) => {
        handleKeyDown(e)
      })
    }
  }, [])

useEffect(() => {
  if (typeof window === 'undefined') return
  const div = inputRef?.current
  if (div) {
    // const text = div?.innerText
    // if (text !== dialogData.project_name) return
    div.focus()
    const range = document.createRange()
    range?.selectNodeContents(div)
    range?.collapse(false)
    const sel = window.getSelection()
    sel?.removeAllRanges()
    sel?.addRange(range)
  }
})

const handleSubmitAll = (values: any) => {
  const dom:any = inputRef?.current?.innerText || ''
    if (
      !dom || // 空值
      dom?.startsWith(' ') || // 以空格开头
      dom?.endsWith(' ') || // 以空格结尾
      dom?.trim().length === 0 // 全部为空格
    ) {
      setGradientAngle(gradientAngle)
      setIsEditable(false)
      return
    }
  const payload = { ...gradientAngle }
  payload.project_name = dom
  updateProject(payload).then((resp: any) => {
    if (resp?.code === 0) {
      sendCommandToPc('command_update_project_name', { project_name: dom , project_id: payload.project_id})
      setIsEditable(false)
      setGradientAngle((pre:any)=>{
         return {...pre, project_name: dom}
      })
    }else{
      setIsEditable(false)
      return
    }
  })
}

  const handleEdit = () => {
    setIsEditable(true)
    inputRef?.current?.focus()
  }

  return (
    <>
      {gradientAngle?.project_name && (
        <div
          className={clsx(classes.content_btn, {
            [classes.content_hover]: !isEditable,
          })}
        >
       {!isEditable ? (
            <div className={classes.from_box}>
              <img
                className={classes.btn_icon}
                src={edit_pencil}
                onClick={handleEdit}
              />
              <Tooltip
                fullLabel={
                  gradientAngle?.project_name
                    ? gradientAngle?.is_standard_product ===
                      PROJECT_STANDARD_TYPE.PROJECT_STANDARD
                      ? gradientAngle?.project_name
                      : `Untitled-${gradientAngle?.project_name}`
                    : ''
                }
                splitNum={26}
                setIsEditable={setIsEditable}
              />
            </div>
          ) : ( 
            <Form
              onSubmit={handleSubmitAll}
              initialValues={{
                projectName: gradientAngle?.project_name ?? '',
              }}
              render={({ handleSubmit, form }) => (
                <form onSubmit={handleSubmit}>
                  <div className={clsx(classes.from_box,classes.from_box_border)}>
                    <img
                      className={classes.btn_icon}
                      src={edit_pencil}
                      onClick={handleEdit}
                    />
                    <Field name="projectName">
                      {({ input, meta }) => {
                        return (
                          <div
                            ref={inputRef}
                            {...input}
                            contentEditable="true"
                            onBlur={handleSubmitAll}
                            onInput={(e) => {
                              const target = e.target as HTMLDivElement
                              if (target.innerText.length > 60) {
                                target.innerText = target.innerText.slice(0, 60)
                                // 将光标移动到文本末尾
                                const range = document.createRange()
                                range.selectNodeContents(target)
                                range.collapse(false)
                                const sel = window.getSelection()
                                sel?.removeAllRanges()
                                sel?.addRange(range)
                              }
                            }}
                            className={classes.project_name}
                          >
                            {input.value}
                          </div>
                          // <div>
                          //   <input
                          //     ref={inputRef}
                          //     {...input}
                          //     type="text"
                          //     autoComplete="off"
                          //     onBlur={() =>
                          //       handleSubmitAll(form.getState().values)
                          //     }
                          //     maxLength={60}
                          //     style={{
                          //       color: '#000',
                          //       border: 'none',
                          //       outline: 'none',
                          //       background: 'transparent',
                          //       fontSize: '16px',
                          //       padding: '0',
                          //       width: 'auto',
                          //       maxWidth: '300px',
                          //     }}
                          //   />
                          // </div>
                        )
                      }}
                    </Field>
                  </div>
                </form>
              )}
            ></Form>
          )}
        </div>
      )}
    </>
  )
}
