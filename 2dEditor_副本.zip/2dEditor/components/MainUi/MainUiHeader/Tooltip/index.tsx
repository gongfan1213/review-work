import React, { useState,useMemo } from 'react'
import * as classes from './index.module.scss'
import minus_down from 'src/assets/svg/minus_down.svg'



export default function SettingLanguage({
  fullLabel,
  setIsEditable,
  splitNum,
}: {
  fullLabel: string
  splitNum: number
  setIsEditable?: (flag: boolean) => void
}) {
  const [isLanguage, setIsLanguage] = useState<boolean>(false)

  const handleMouseEnter = () => {
    setIsLanguage(true)
  }

  const handleMouseLeave = () => {
    setIsLanguage(false)
  }

  const handleName = useMemo(() => {
        return fullLabel ? fullLabel.length > splitNum ? `${fullLabel.slice(0, splitNum)}···` : fullLabel : ''
  }, [fullLabel])

  return (
    <div className={classes.unitSelect}>
      <div
        className={classes.language}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        <div
          className={classes.title}
          onClick={(e) => {
            e.preventDefault()
            e.stopPropagation()
            setIsEditable && setIsEditable(true)
          }}
        >
         {handleName}
        </div>
        {isLanguage && fullLabel.length > splitNum && (
          <div className={classes.selectProps}>
            <div className={classes.selectGroupBox}>
              <i className={classes.triangleUp}></i>
            </div>
            <ul className={classes.selectGroup}>
              <li>{fullLabel}</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  )
}
