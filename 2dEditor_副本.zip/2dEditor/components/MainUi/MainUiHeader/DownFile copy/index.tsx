import React, { useState, useRef, useEffect } from 'react'
import clsx from 'clsx'
import { TextField, Dialog, Button, Rating, IconButton, SvgIcon, Switch } from '@mui/material'
import { Form, Modal } from 'src/components/MakeUI'
import { Clear as ClearIcon } from 'src/components/icon'
import * as classes from './index.module.scss'
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import { useCanvasEditor } from 'src/templates/2dEditor/hooks/context'
import { DownFileUnit, DownFileType, WorkspaceID } from 'src/templates/2dEditor/cons/2dEditorCons'
import close from 'src/assets/svg/close.svg'
import ring_vip from 'src/assets/svg/ring_vip.svg'
import add_up from 'src/assets/svg/add_up.svg'
import minus_down from 'src/assets/svg/minus_down.svg'
import { useTranslation } from '@volcengine/i18n'
import lockClose from 'src/assets/svg/lockClose.svg'
import lockOpen from 'src/assets/svg/lockOpen.svg'
import { useDispatch } from 'react-redux'
import { openToast } from 'src/state/reducers/toast'
import SelectModal from '../SelectModal'
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

export type Editor2dDownFileProps = {
  visible?: boolean
  className?: string
  onSuccess?: () => void
  onFail?: () => void
  onClose?: () => void
  dialogData?: any
}

export default function Editor2dDownFile(props: Editor2dDownFileProps) {
  const canvasEditor = useCanvasEditor();
  const { visible, className, onSuccess, onFail, onClose } = props
  const [form] = Form.useForm()
  const { resetFields } = form
  const [selectedFormat, setSelectedFormat] = useState('png')
  const [width, setWidth] = useState<any>('');
  const [height, setHeight] = useState<any>('');
  const [isFixedAspectRatio, setIsFixedAspectRatio] = useState(false);
  const [unit, setUnit] = useState(DownFileUnit.px);
  const [removeLogo, setRemoveLogo] = useState(false);
  const [sourceSize, setSourceSize] = useState<{ [key: string]: any }>({})
  const [isLock, setIsLock] = useState(true)
  const { t } = useTranslation()
  const dispatch = useDispatch()
  const projectInfo = useProjectData();
  const { getTranslation } = useCustomTranslation();

  useEffect(() => {
    if (!visible) {
      resetFields?.()
    }
  }, [visible, resetFields])

  const handleWidthChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event?.target?.value) {
      if (!/^[0-9]\d*$/.test(event?.target?.value)) {
        dispatch(
          openToast({
            message: getTranslation(TranslationsKeys.ENTER_INTEGER),
            severity: 'error',
          }),
        )
        return
      }
      setWidth(Number(event?.target?.value));
      if (isLock && Number(width) > 0) {
        setHeight(Math.floor((Number(event?.target?.value) / (Number(sourceSize?.width) / (Number(sourceSize?.height))))))
      };
    } else {
      setWidth(event?.target?.value);
    }
  }

  const handleHeightChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event?.target?.value) {
      if (!/^[0-9]\d*$/.test(event?.target?.value)) {
        dispatch(
          openToast({
            message: getTranslation(TranslationsKeys.ENTER_INTEGER),
            severity: 'error',
          }),
        )
        return
      }
      setHeight(event?.target?.value);
      if (isLock && Number(height) > 0) {
        setWidth(Math.floor((Number(event?.target?.value) * (Number(sourceSize?.width) / (Number(sourceSize?.height))))));
      };
    } else {
      setHeight(event?.target?.value);
    }
  };

  const handleWidthIncrement = () => {
    setWidth((previousWidth: any) => {
      if (isLock && Number(width) >= 0) {
        setHeight(Math.floor((Number(previousWidth) + 1) / (Number(sourceSize?.width) / (Number(sourceSize?.height)))));
      }
      return Number(previousWidth) + 1
    });

  };

  const handleWidthDecrement = () => {
    if (Number(width) > 0) {
      setWidth((previousWidth: any) => {
        if (isLock) {
          setHeight(Math.floor((Number(previousWidth) - 1) / (Number(sourceSize?.width) / (Number(sourceSize?.height)))));
        }
        return Number(previousWidth) - 1
      });
    } else {
      setWidth('');
    }
  };

  const handleHeightIncrement = () => {
    setHeight((previousHeight: any) => {
      if (isLock && Number(height) >= 0) {
        setWidth(Math.floor((Number(previousHeight) + 1) * (Number(sourceSize?.width) / (Number(sourceSize?.height)))))
      }
      return Number(previousHeight) + 1
    });

  };

  const handleHeightDecrement = () => {
    if (Number(height) > 0) {
      setHeight((previousHeight: any) => {
        if (isLock) {
          setWidth(Math.floor((Number(previousHeight) - 1) * (Number(sourceSize?.width) / (Number(sourceSize?.height)))));
        }
        return Number(previousHeight) - 1
      });
    } else {
      setHeight('');
    }
  };

  const handleToggleAspectRatio = () => {
    setIsFixedAspectRatio((prevIsFixedAspectRatio) => !prevIsFixedAspectRatio);
  };

  const handleUnitChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setUnit(event.target.value as unknown as DownFileUnit);
  };

  const handleRemoveLogoChange = () => {
    setRemoveLogo(!removeLogo);
  };

  useEffect(() => {
    setSelectedFormat('png')
    if (!canvasEditor) return
    const pictureData: any = canvasEditor?.canvas?.getObjects()
    const obj: any = pictureData.find((item: any) => item.id?.includes(WorkspaceID.WorkspaceCavas))
    setSourceSize(obj)
    setWidth(obj?.width || 0)
    setHeight(obj?.height || 0)
  }, [visible])

  const InitializationWidthHeight = () => {
    setIsLock(!isLock)
    if (!isLock) {
      if (!canvasEditor) return
      const pictureData: any = canvasEditor?.canvas?.getObjects()
      const obj: any = pictureData.find((item: any) => item.id?.includes(WorkspaceID.WorkspaceCavas))
      setWidth(obj?.width || 0)
      setHeight(obj?.height || 0)
    }
  }

  const startDown = () => {
    if (!canvasEditor) return
    
    if (!width && !height) {
      dispatch(
        openToast({
          message: getTranslation(TranslationsKeys.ENTER_SIZE),
          severity: 'error',
        }),
      )
      return
    }

    if (!width) {
      dispatch(
        openToast({
          message: getTranslation(TranslationsKeys.ENTER_WIDTH),
          severity: 'error',
        }),
      )
      return
    }

    if (!height) {
      dispatch(
        openToast({
          message: getTranslation(TranslationsKeys.ENTER_HEIGHT),
          severity: 'error',
        }),
      )
      return
    }

    canvasEditor?.downFile(
      projectInfo,
      selectedFormat,
      width,
      height,
      removeLogo,
      unit,
      props?.dialogData?.project_name || 'file_name',
    )
    // 下载svg
    // let svgString = canvasEditor?.canvas.toSVG({
    //   width,
    //   height,
    //   viewBox: {
    //     x: 0,
    //     y: 0,
    //     width,
    //     height,
    //   },
    // })
    // if (svgString) {
    //   const blob = new Blob([svgString], {
    //     type: 'image/svg+xml;charset=utf-8',
    //   })
    //   const url = URL.createObjectURL(blob)
    //   const a = document.createElement('a')
    //   a.href = url
    //   a.download = `${props?.dialogData?.project_name}.svg` || 'filename.svg'
    //   a.click()
    //   URL.revokeObjectURL(url)
    // } else {
    //   console.error('Failed to generate SVG string')
    // }

    // 下载png/jpg
    // const dataUrl = canvasEditor?.canvas?.toDataURL({
    //   format: selectedFormat,
    //   width,
    //   height,
    // })
    // if (dataUrl) {
    //   const a: any = document.createElement('a')
    //   a.href = dataUrl
    //   a.download = props?.dialogData?.project_name || 'file_name'
    //   a.click()
    //   onClose && onClose()
    // } else {
    //   console.error(`Failed to generate ${selectedFormat} string`)
    // }

    // 下载pdf
    //   const dataUrl = canvasEditor?.canvas?.toDataURL({
    //     format: 'jpeg',
    //     width,
    //     height,
    //   })
    //  let pdf:any = new jsPDF();
    //  pdf.addImage(dataUrl, 'jpeg', 0, 0)
    //  pdf.save(`${props?.dialogData?.project_name}.pdf` || 'filename.pdf')
  };

  return (
    <div className={clsx(classes.root, className)}>
      <Dialog open={!!visible} className={classes.dialog}
        onClick={(e) => {
          e.stopPropagation()
          e.preventDefault()
        }}>
        <div
          className={classes.body}
          onClick={(e) => {
            e.preventDefault()
            e.stopPropagation()
          }}
        >
          <div className={classes.close}>
            <img src={close} onClick={onClose} />
          </div>
          <div className={classes.layoutItem}>
            <div className={`${BaseStyles.txt20} ${classes.titleItem}`}>
              {t('str_download_as', 'Download AS')}:
            </div>
            <div
              className={classes.contentBlock}
              style={{ marginRight: '24px' }}
            >
              <div className={clsx(BaseStyles.txt18, classes.top_title)}>
                {t('str_for_share', 'for Share')}
              </div>
              <div className={classes.wrapBotton}>
                <Button
                  className={
                    selectedFormat === DownFileType.DownFileTypePNG
                      ? classes.btnSelected
                      : classes.btnNormal
                  }
                  onClick={() =>
                    setSelectedFormat(DownFileType.DownFileTypePNG)
                  }
                >
                  PNG
                </Button>
                <Button
                  className={
                    selectedFormat === DownFileType.DownFileTypeJPG
                      ? classes.btnSelected
                      : classes.btnNormal
                  }
                  onClick={() =>
                    setSelectedFormat(DownFileType.DownFileTypeJPG)
                  }
                >
                  JPG
                </Button>
              </div>
            </div>
            <div className={classes.contentBlock}>
              <div className={clsx(BaseStyles.txt18, classes.top_title)}>
                {t('str_for_print', 'for Print')}
              </div>
              <div className={classes.wrapBotton}>
                <Button
                  className={`${selectedFormat === DownFileType.DownFileTypePDF
                    ? classes.btnSelected
                    : classes.btnNormal
                    }`}
                  onClick={() =>
                    setSelectedFormat(DownFileType.DownFileTypePDF)
                  }
                >
                  PDF
                </Button>
                <Button
                  className={
                    selectedFormat === DownFileType.DownFileTypeSVG
                      ? classes.btnSelected
                      : classes.btnNormal
                  }
                  onClick={() =>
                    setSelectedFormat(DownFileType.DownFileTypeSVG)
                  }
                >
                  <img src={ring_vip} className={classes.vip_icon} />
                  SVG
                </Button>
              </div>
            </div>
          </div>

          <div className={classes.layoutItem}>
            <div className={`${BaseStyles.txt20} ${classes.titleItem}`}>
              {t('str_download_size', 'Download size')}:
            </div>

            <div className={classes.imageSizeSetting}>
              <div className={classes.widthHeight}>
                <div
                  className={classes.inputGroup}
                  style={{ marginBottom: '14px' }}
                >
                  <label htmlFor="width">{t('str_width', 'Width')}:</label>
                  <input
                    type="text"
                    id="width"
                    value={width}
                    autoComplete="off"
                    className={classes.widthInput}
                    onChange={handleWidthChange}
                  />
                  <button
                    onClick={handleWidthIncrement}
                    className={classes.add_up}
                  >
                    <img src={add_up} />
                  </button>
                  <button
                    onClick={handleWidthDecrement}
                    className={classes.minus_down}
                  >
                    <img src={minus_down} />
                  </button>
                </div>
                <div className={classes.inputGroup}>
                  <label htmlFor="height">{t('str_height', 'Height')}:</label>
                  <input
                    type="text"
                    id="height"
                    value={height}
                    autoComplete="off"
                    onChange={handleHeightChange}
                  />
                  <button
                    onClick={handleHeightIncrement}
                    className={classes.add_up}
                  >
                    <img src={add_up} />
                  </button>
                  <button
                    onClick={handleHeightDecrement}
                    className={classes.minus_down}
                  >
                    <img src={minus_down} />
                  </button>
                </div>
              </div>
              <div className={classes.lockIcon} onClick={InitializationWidthHeight}>
                <img src={isLock ? lockClose : lockOpen} />
              </div>
            </div>
          </div>

          <div className={classes.layoutItem}>
            <div
              className={clsx(BaseStyles.txt20)}
              style={{ color: '#000', display: 'flex' }}
            >
              <img
                src={ring_vip}
                className={classes.vip_icon}
                style={{ margin: '4px 4px 0 0' }}
              />
              {t('str_ankermake_logo', 'Remove eufyMake logo')}:
            </div>

            <div onClick={handleRemoveLogoChange}>
              <Switch
                checked={removeLogo}
              />
            </div>
          </div>

          <Button className={classes.btnSelectedBottom} onClick={startDown}>
            {t('str_download', 'Download')}
          </Button>
        </div>
      </Dialog>
    </div>
  )

}
