import axios from 'axios'
import { useDispatch } from 'react-redux'
import { openToast } from 'src/state/reducers/toast'
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

const getHost = () => {
    if (typeof window === 'undefined') return
    const hostname:string = window?.location?.hostname || '';
    const hostMap:{ [key: string]: string } = {
      'localhost': 'https://cloud-cms-ci.mkitreal.com/',
      'playground-ci.mkitreal.com':'https://cloud-cms-ci.mkitreal.com/',
      'playground-qa.mkitreal.com': 'https://cloud-cms-qa.mkitreal.com/',
      'makeitreal.ankermake.com': 'https://cloud-cms.mkitreal.com/',
    };

    let baseHost = hostMap.localhost;
    if(hostname){
         for (let host in hostMap) {
      if (hostname.includes(host)) {
        baseHost = hostMap[host];
      }
    }
    }
   return baseHost;
}

const api = axios.create({
  baseURL: getHost(),
  timeout: 6000,
  headers: {
   'Content-Type':'application/json'
  },
});

const getCms = (url:string, params?:{[key:string]: any}, headers?:{[key:string]: any}) => {
  const { getTranslation } = useCustomTranslation();
  headers && Object.assign(api.defaults.headers, headers);
  return new Promise((resolve, reject) => {
    api.get(url, params ? { params } : {})
      .then(response => {
        return resolve(response)
      })
      .catch(error => {
       useDispatch()(
          openToast({
            message:  error?.message || getTranslation(TranslationsKeys.REQUEST_ERROR),
            severity: 'error',
          }),
         )
        return 
      });
  });
};

const postCms = async (url:string, params?:{[key:string]: any}, headers?:{[key:string]: any}) => {
  const { getTranslation } = useCustomTranslation();
  headers && Object.assign(api.defaults.headers, headers);
  return new Promise((resolve, reject) => {
    api.post(url, params ? { ...params } : {})
      .then(response => {
        return resolve(response)
      })
      .catch(error => {
         useDispatch()(
          openToast({
            message:  error?.message || getTranslation(TranslationsKeys.REQUEST_ERROR),
            severity: 'error',
          }),
         )
        return
      });
  });
};

export{
  getCms,
  postCms
}