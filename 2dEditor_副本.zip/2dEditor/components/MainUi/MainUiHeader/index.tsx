import React, { useEffect, useState, useMemo, useRef } from 'react';
import Feedback from 'src/components/Feedback';
import { FeedbackTypeEnum } from 'src/services';
import * as classes from './index.module.scss';
import clsx from 'clsx';
import hotkeys from 'hotkeys-js';
import Editor2dDownFile from './DownFile';
import ProjectName from './ProjectName';
import { useCanvasEditor, useEvent, useProjectData } from 'src/templates/2dEditor/hooks/context';
import { useTranslation } from '@volcengine/i18n';
import ProjectManager from 'src/templates/2dEditor/utils/ProjectManager';
import { formatDate } from 'src/templates/LoginVms/common/utils';
import { EventNameCons, PROJECT_STANDARD_TYPE, ProjectSaveState } from 'src/templates/2dEditor/cons/2dEditorCons';
import { get } from 'src/services';
import PublishDialog from 'src/templates/2dEditor/components/PublishDialog';
// import ImportJSONButton from 'src/templates/2dEditor/components/ImportJSONButton/ImportJSONButton';
import { ImageStatus } from 'src/templates/2dEditor/core/eventbus/types/image';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { getUserInfo } from 'src/common/storage';
import { HistoryEvent } from 'src/templates/2dEditor/core/eventbus/types/history';
import go_ahead from 'src/assets/svg/go_ahead.svg';
import go_back from 'src/assets/svg/go_back.svg';
// import gripper from 'src/assets/svg/gripper.svg'
import feedback from 'src/assets/svg/feedback.svg';
import download from 'src/assets/svg/download.svg';
import ic_cloud_offline from 'src/assets/svg/ic_cloud_offline.svg';
import ic_cloud_save from 'src/assets/svg/ic_cloud_save.svg';
import loading_icon from 'src/assets/svg/loading.svg';
import SelectModal from './SelectModal';
import arrow_right from 'src/assets/svg/arrow_right.svg';
import back from 'src/assets/svg/back.svg';
import ban_cloud from 'src/assets/svg/ban_cloud.svg';
import union from 'src/assets/svg/logo.svg';
import { isPc } from 'src/common/jsbridge';

import {
  CustomKey,
  WorkspaceID,
  // ACTION_MAGICK,
} from 'src/templates/2dEditor/cons/2dEditorCons';
import { getCms, postCms } from './request';
import { editorToastShow, EditorToastType } from '../../Toast';
import { useShowUiContainerState } from 'src/templates/2dEditor/hooks/context';
import { From2dEditorType } from 'src/templates/2dEditor/utils/event/types';
// import { post } from 'src/services'
// import { AddJsonTempID } from 'src/templates/2dEditor/core/plugin/HistoryPlugin/types'
// import { selectFiles } from 'src/templates/2dEditor/utils/utils'
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
const MainUiHeader: React.FC<{
  setSelectDialogVisible?: (visible: boolean) => void;
  dialogData?: any;
  setIsClose?: (isClose: boolean) => void;
  setIsOff?: (isOff: boolean) => void;
  PrintClick: () => void;
  isExport?: number;
  setEditUrl?: (url: boolean) => void;
}> = ({ setSelectDialogVisible, dialogData, setIsClose, setIsOff, PrintClick, isExport, setEditUrl }) => {
  const canvasEditor = useCanvasEditor();
  const [feedbackVisible, setFeedbackVisible] = useState<boolean>(false);
  const [downFileVisible, setDownFileVisible] = useState<boolean>(false);
  const [projectData, setProjectData] = useState<any>();
  const [saveState, setSaveState] = useState<string>();
  const event = useEvent();
  const [fatherClassData, setFatherClassData] = useState<any>([]);
  const [sonClassData, setSonClassData] = useState<any>([]);
  const [exportLoading, setExportLoading] = useState<boolean>(false);
  const [isPcShowLogo, setIsPcShowLogo] = useState(true);
  const [userEmail, setUserEmail] = useState<string[]>([]);
  const { t } = useTranslation();
  const projectModel = useProjectData();
  const { showUiContainer, setShowUiContainer } = useShowUiContainerState();
  const { getTranslation } = useCustomTranslation();
  useEffect(() => {
    event?.on(EventNameCons.EventProjectSaveState, updateSaveState);
    // 遇见冲突别改为event 就是eventBus没错.
    eventBus?.on(ImageStatus.Cropping, handleHistoryDisabled);
    eventBus?.on(ImageStatus.RemovingBackground, handleHistoryDisabled);
    eventBus?.on(ImageStatus.Upscaling, handleHistoryDisabled);
    eventBus?.on(ImageStatus.Editing, handleHistoryDisabled);
    eventBus?.on(HistoryEvent.Save, handleHistoryAction);
    eventBus?.on(HistoryEvent.Undo, handleHistoryAction);
    eventBus?.on(HistoryEvent.Redo, handleHistoryAction);
    return () => {
      event?.off(EventNameCons.EventProjectSaveState, updateSaveState);
      // 遇见冲突别改为event 就是eventBus没错
      eventBus?.off(ImageStatus.Cropping, handleHistoryDisabled);
      eventBus?.off(ImageStatus.RemovingBackground, handleHistoryDisabled);
      eventBus?.off(ImageStatus.Upscaling, handleHistoryDisabled);
      eventBus?.off(ImageStatus.Editing, handleHistoryDisabled);
      eventBus?.off(HistoryEvent.Save, handleHistoryAction);
      eventBus?.off(HistoryEvent.Undo, handleHistoryAction);
      eventBus?.off(HistoryEvent.Redo, handleHistoryAction);
    };
  }, [canvasEditor]);

  const getEditProjectName = (item: any) => {
    setProjectData((pre: any) => {
      const newPre = { ...pre };
      newPre.project_name = item.project_name;
      return newPre;
    });
  };

  const handleItemName = () => {
    setEditUrl?.(true);
    ProjectManager?.getInstance()?.atOnceSave();
    setSelectDialogVisible && setSelectDialogVisible(true);
    setIsClose && setIsClose(true);
    setIsOff && setIsOff(true);
  };

  // #region 抓手工具;
  const [dragFlag, setDragFlag] = useState<boolean>(false);
  // #endregion ;
  // #region 历史记录;
  enum HistoryStepType {
    Redo,
    Undo,
  }
  const handleHistoryStep = (type: HistoryStepType) => {
    type === HistoryStepType.Redo && redo();
    type === HistoryStepType.Undo && undo();
  };
  const [historyDisabled, setHistoryDisabled] = useState<boolean>(false);
  const historyDisabledRef = useRef<boolean>(false);
  // @ts-ignore;
  const handleHistoryDisabled = (e) => {
    setHistoryDisabled(e.value);
    historyDisabledRef.current = e.value;
  };
  // 保存历史动作;
  const [historyLength, setHistoryLength] = useState<number>(0);
  const [historyCurrentStep, setHistoryCurrentStep] = useState<number>(0);
  // @ts-ignore;
  const handleHistoryAction = (e) => {
    // console.log('handleHistoryAction; e', e)
    if (!e) return;
    const currentStep = e.currentIndex;
    const historyLength = e.data.length;
    setHistoryLength(historyLength);
    setHistoryCurrentStep(currentStep);
  };
  const redo = () => {
    !historyDisabledRef.current && canvasEditor?.redo();
  };
  const undo = () => {
    !historyDisabledRef.current && canvasEditor?.undo();
  };
  // #endregion ;
  // ;
  const updateSaveState = (state: string) => {
    if (!navigator.onLine) {
      state = ProjectSaveState.SaveStateOffline;
      if (saveState != ProjectSaveState.SaveStateOffline) {
        editorToastShow({
          tips: getTranslation(TranslationsKeys.str_editor_offline_lab),
          type: EditorToastType.error,
        });
      }
    }
    setSaveState(state);
  };

  const getSaveStateTxt = () => {
    switch (saveState) {
      case ProjectSaveState.SaveStateSaving:
        return getTranslation(TranslationsKeys.STR_COMMON_SAVING);
      case ProjectSaveState.SaveStateSaved:
        return formatDate(Date.now(), 'HH:mm') + ' ' + getTranslation(TranslationsKeys.STR_COMMON_SAVED);
      case ProjectSaveState.SaveStateOffline:
        return getTranslation(TranslationsKeys.STR_COMMON_OFFLINE);
      default:
        return '';
    }
  };

  const getSaveStateIcon = () => {
    switch (saveState) {
      case ProjectSaveState.SaveStateOffline:
        return ic_cloud_offline;
      default:
        return ic_cloud_save;
    }
  };

  const fetchFatherClass = async () => {
    if (typeof window === 'undefined') return;
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-category-types',
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'], // 按weight降序排列
    });
    const data = json.data?.data;
    if (Array.isArray(data) && data.length) {
      const newdata = data.map((item: any) => {
        return item.attributes;
      });
      setFatherClassData(newdata);
    }
  };

  const fetchSonCategory = async (value?: number) => {
    if (typeof window === 'undefined') return;
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-category-sub-types',
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'], // 按weight降序排列
    });
    const data = json.data?.data;
    if (Array.isArray(data) && data.length) {
      const newdata = data.map((item: any) => {
        return item.attributes;
      });
      setSonClassData(newdata);
    }
  };

  useEffect(() => {
    fetchFatherClass();
    fetchSonCategory();
    develoToolAuthen();
  }, []);

  useEffect(() => {
    setProjectData(dialogData?.project_info);
  }, [dialogData]);

  const getFatherClass = useMemo(() => {
    if (dialogData && fatherClassData?.length && sonClassData?.length) {
      let categoryTitle = fatherClassData.find((item: any) => {
        if (item?.categoryKey === dialogData?.project_info?.category) {
          return item;
        }
      });
      let subCategoryTitle = sonClassData.find((item: any) => {
        if (item?.categorySubKey === dialogData?.project_info?.sub_category) {
          return item;
        }
      });
      if (categoryTitle?.categoryName && subCategoryTitle?.categorySubName) {
        return categoryTitle.categoryName + ' > ' + subCategoryTitle.categorySubName;
      } else {
        return '';
      }
    }
  }, [dialogData, fatherClassData, sonClassData]);

  // #region handle public click;
  const [isShowPublishDialog, setIsShowPublishDialog] = useState<boolean>(false);
  const [publishPreloading, setPublishPreloading] = useState<boolean>(false);
  const [publishImg, setPublishImg] = useState<boolean>(false);
  const handlePublishClick = () => {
    canvasEditor?.preview1(projectModel).then((data: any) => {
      canvasEditor?.canvas.discardActiveObject();
      setPublishImg(data.dataUrl);
      setIsShowPublishDialog(true);
      // setShowUiContainer(false)
    });
  };

  const develoToolAuthen = async (value?: number) => {
    if (typeof window === 'undefined') return;
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      // cms接口地址
      content_type: 'make-2d-development-tools',
      pagination: {
        page: 1,
        pageSize: 10000,
      },
    });
    const data = json.data?.data;
    const email: string[] = data?.map((item: any) => {
      return item.attributes.email;
    });
    setUserEmail(email);
  };

  const userInfo = getUserInfo();
  const fetchFolder = async (value?: number) => {
    if (typeof window === 'undefined') return;
    const payload = await getCms('/admin/users/', {
      pageSize: 10,
      page: 1,
    });
  };

  const handleExportClick = () => {
    fetchFolder();
    //生成JSON文件
    const canvasJson = JSON.stringify({
      objects: canvasEditor?.canvas
        .toJSON(['id', CustomKey.FontUrl])
        .objects.filter((item: any) => !~item?.id?.indexOf(WorkspaceID.WorkspaceCavas)),
    });
    // // 创建一个 Blob 对象，包含 JSON 数据
    // const blob = new Blob([canvasJson], { type: 'application/json' })
    // // 创建一个可以下载的链接
    // const url = URL.createObjectURL(blob)
    // // 创建一个新的 'a' 标签，并触发点击事件来开始下载
    // const link = document.createElement('a')
    // link.href = url
    // link.download = 'font.json' // 设置下载的文件名
    // link.click()
    // // 释放创建的 URL
    // URL.revokeObjectURL(url)
  };

  // 优化了条件判断逻辑，减少了不必要的判断和变量创建
  const handleJump = () => {
    if (typeof window !== 'undefined') {
      if (!navigator.onLine) return;
      if (isPc()) {
        console.log(window.location.host, 'domain');
        location.href = `https://${window.location.host}/apps/2dStudio/`;
      } else {
        window.open('/', '_blank');
      }
    }
  };

  const backMouseEnter = () => {
    if (isPc()) {
      setIsPcShowLogo(false);
    }
  };
  const backMouseLeave = () => {
    if (isPc()) {
      setIsPcShowLogo(true);
    }
  };

  return (
    <div className={classes.root}>
      <div className={classes.header}>
        <div className={classes.header_left}>
          {
            !isPc() ? <i className={classes.icon} onClick={handleJump} onMouseEnter={backMouseEnter} onMouseLeave={backMouseLeave}>
              <img src={union} alt="" />
            </i> : null
          }

          <div className={classes.header_conter}>
            <ProjectName dialogData={projectData} getEditProjectName={getEditProjectName} />

            <div className={classes.line}></div>

            <div className={clsx(classes.content_btn)}>
              <img
                style={{
                  opacity: historyDisabled || historyLength === 0 || historyCurrentStep === 0 ? 0.4 : 1,
                  cursor:
                    historyDisabled || historyLength === 0 || historyCurrentStep === 0 ? 'not-allowed' : 'pointer',
                  marginRight: '16px',
                }}
                src={go_ahead}
                alt="Go Ahead"
                onClick={() =>
                  !historyDisabled &&
                  historyLength > 0 &&
                  historyCurrentStep !== 0 &&
                  handleHistoryStep(HistoryStepType.Undo)
                }
              />
              <img
                style={{
                  opacity: historyDisabled || historyLength === 0 || historyCurrentStep === historyLength - 1 ? 0.4 : 1,
                  cursor:
                    historyDisabled || historyLength === 0 || historyCurrentStep === historyLength - 1
                      ? 'not-allowed'
                      : 'pointer',
                }}
                src={go_back}
                alt="go_back"
                onClick={() =>
                  !historyDisabled &&
                  historyLength > 0 &&
                  historyCurrentStep !== historyLength - 1 &&
                  handleHistoryStep(HistoryStepType.Redo)
                }
              />
            </div>
          </div>
        </div>
        <div className={classes.content_btn_name}>
          {getSaveStateTxt() ? (
            <img alt="" className={classes.btn_cloud_save} src={getSaveStateIcon()} />
          ) : (
            <img alt="" className={classes.btn_cloud_save} src={ban_cloud} />
          )}
          <span className={classes.btn_time}>{getSaveStateTxt()}</span>
        </div>
        <div className={classes.header_right}>
          {window.location.hostname !== 'cloud-cms.mkitreal.com' &&
            userInfo?.email &&
            userEmail.indexOf(userInfo?.email) !== -1 && (
              <SelectModal />
              // <ImportJSONButton />
            )}
          <div className={classes.right_icon_div}>
            {/* <div className={classes.feedback}>
                <img
                  alt=""
                  src={feedback}
                  onClick={() => setFeedbackVisible(true)}
                />
              </div> */}
            <div className={classes.feedback}>
              <img src={download} onClick={() => setDownFileVisible(true)} />
            </div>
          </div>
          <div className={classes.right_btn_div}>
            {/* {isExport && isExport === 3 ? (
              <button
                className={classes.publish}
                style={{ marginRight: '20px' }}
                onClick={() => handleExportClick()}
              >
                {exportLoading ? (
                  <img className={classes.loading_img} src={loading_icon} />
                ) : (
                  <span className={classes.footerButtonText}>
                    {t('str_Export', 'Export')}
                  </span>
                )}
              </button>
            ) : (
              ''
            )} */}
            <button
              className={classes.publish}
              style={{ marginRight: '20px' }}
              onClick={() => handlePublishClick()}
            // disabled={!showUiContainer}
            >
              {publishPreloading ? (
                <img className={classes.loading_img} src={loading_icon} alt="" />
              ) : (
                <span className={classes.footerButtonText}>{getTranslation(TranslationsKeys.STR_PUBLISH)}</span>
              )}
            </button>
            {/* isPc toDo */}
            {!isPc() && (
              <button
                className={classes.print}
                onClick={() => {
                  PrintClick();
                }}
              // disabled={!showUiContainer}
              >
                <span className={classes.footerButtonText}>{getTranslation(TranslationsKeys.STR_COMMON_PRINT)}</span>
              </button>
            )}
          </div>
        </div>
      </div>
      <Feedback
        visible={feedbackVisible}
        onClose={() => setFeedbackVisible(false)}
        onSuccess={() => setFeedbackVisible(false)}
        className="feedback"
        type={FeedbackTypeEnum.MemeMaker}
        title={t(
          'str_feedback',
          'Please rate your MEME Maker experience and share feedback for improvement, thank you !',
        )}
      />
      <Editor2dDownFile
        visible={downFileVisible}
        onClose={() => setDownFileVisible(false)}
        onSuccess={() => setDownFileVisible(false)}
        dialogData={dialogData}
        className="feedback"
      />

      {/* public window; */}
      {isShowPublishDialog && (
        <PublishDialog
          isOpen={isShowPublishDialog}
          publishImgDef={publishImg}
          onPropsClose={() => {
            setIsShowPublishDialog(false);
          }}
          publishStatus={'add'}
        />
      )}
    </div>
  );
};

export default MainUiHeader;
