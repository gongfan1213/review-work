import React, { useState, FC, useEffect } from 'react'
import  * as classes from './indexSelect.module.scss'
import ic_down from 'src/assets/svg/ic_down.svg'
import clsx from 'clsx'
import camera_error from 'src/assets/editor/camera_error.png'
import { Blank } from 'src/components/icon'
import { useTranslation } from '@volcengine/i18n'
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
interface ValueItem {
  device_name: string
  sn: string
  state: number
  deviceImg: string
}
interface DropdownProps {
  options: ValueItem[]
  defaultSelectValue: string
  isAdd?:boolean
  callback: (item: ValueItem) => void
}

const SelectDown: FC<DropdownProps> = ({
  options,
  defaultSelectValue,
  isAdd,
  callback,
}) => {
  const [isOpen, setIsOpen] = useState(true)
  const [selectedValue, setSelectedValue] = useState<ValueItem | undefined>()
  const { getTranslation } = useCustomTranslation();

  useEffect(() => {
    // 设置默认选中的值
    const defaultValue: ValueItem = options.filter(
      (item) => item?.device_name === defaultSelectValue,
    )?.[0]
    setSelectedValue(defaultValue)
  }, [])

  const handleSelect = (item: ValueItem) => {
    setSelectedValue(item)
    setIsOpen(false)
    callback(item)
  }

 const stateObj: { state: number; name: string; bg: string }[] = [
   { state: 0, name: 'Online', bg: '#33bf5a' },
   { state: 1, name: 'Offline', bg: '#adadad' },
   { state: 2, name: 'Printing', bg: '#ffc90e' },
   { state: 3, name: 'Busy', bg: '#ed1c24' },
 ]

const lineState = (state:number)=>{
  console.log(0===0);
  
  console.log(
    'state',
    stateObj.filter(
      (item: { state: number; name: string; bg: string }) =>
        item.state === state,
    ),
  )
  
    return stateObj.find((item: {state:number,name:string,bg:string})=>item.state===state)
}

  return (
    <div className={classes.selectedContainer} onBlur={() => setIsOpen(false)}>
      {Array.isArray(options) && options?.length ? (
        <div>
          <div
            className={classes.selectedOption}
            onClick={() => setIsOpen(!isOpen)}
          >
            <div className={classes.selectedCreate}>
              <img
                src={selectedValue?.deviceImg}
                className={classes.CardRules}
                onError={(e: any) => {
                  e.target.src = camera_error
                }}
              />
              <div className={classes.option}>
                <p className={classes.deviceName}>
                  {selectedValue?.device_name || ''}
                </p>
                <p className={classes.stateCss}>
                  <i
                    className={classes.stateIcon}
                    style={{
                      backgroundColor:
                        selectedValue?.state !== undefined
                          ? lineState(selectedValue?.state)?.bg
                          : '',
                    }}
                  ></i>
                  <span className={classes.stateName}>
                    {selectedValue?.state !== undefined
                      ? lineState(selectedValue?.state)?.name
                      : ''}
                  </span>
                </p>
              </div>
            </div>
            <img className={classes.selectedIcon} src={ic_down} />
          </div>
          {isOpen && (
            <div className={classes.ptionsItem}>
              {options.map((item, index) => (
                <div
                  className={clsx(classes.optionItemCss, {
                    [classes.selectedItemoption]:
                      item.state === selectedValue?.state,
                  })}
                >
                  <img
                    src={item?.deviceImg}
                    className={classes.CardRules}
                    onError={(e: any) => {
                      e.target.src = camera_error
                    }}
                  />
                  <div
                    className={classes.option}
                    onClick={() => handleSelect(item)}
                    key={index}
                  >
                    <p className={classes.deviceName}>
                      {item?.device_name || ''}
                    </p>
                    <p className={classes.stateCss}>
                      <i
                        className={classes.stateIcon}
                        style={{
                          backgroundColor:
                            item?.state !== undefined
                              ? lineState(item?.state)?.bg
                              : '',
                        }}
                      ></i>
                      <span className={classes.stateName}>
                        {item?.state !== undefined
                          ? lineState(item?.state)?.name
                          : ''}
                      </span>
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div className={classes.empty}>
          <div>
            <Blank />
            <p>{getTranslation(TranslationsKeys.NO_DATA)}</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default SelectDown