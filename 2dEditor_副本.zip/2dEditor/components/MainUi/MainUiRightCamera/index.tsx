import React, { useEffect, useState, useCallback } from 'react';
import { useProjectData, useCanvasEditor, useEvent } from 'src/templates/2dEditor/hooks/context';
import * as classs from './indexStyle.module.scss';
import Dialog from '@material-ui/core/Dialog'
import DeviceSelect from './components/DeviceSelect'
import camera from 'src/assets/editor/img_camera.png'
interface ObjViewerProps {
  closeClick?: () => void
}

const MainUiRightComponent: React.FC<ObjViewerProps> = ({ closeClick }) => {
  const [dialogOpen, setDialogOpen] = useState<boolean>(false)
  const [options, setOptions] = useState<any>(
    [
      { device_name: 'xxx', sn: 'sdsasa', state: 0, deviceImg: camera },
      { device_name: 'yyy', sn: 'dsssss', state: 1, deviceImg: camera },
      { device_name: 'zzz', sn: 'dssds', state: 2, deviceImg: 'base64' },
      { device_name: 'zzz', sn: 'dssds', state: 3, deviceImg: 'base64' },
    ],
    //state字典：0:空闲 1:离线 2:打印中 3:忙碌中
  )

  const [defaultSelectValue, setDefaultSelectValue] = useState<any>('xxx')

  const [item, itemObj] = useState<any>({})
  // 关闭放大弹窗
  const handleClose = () => {
    setDialogOpen(false)
  }

  // 打开放大弹窗
  const handleDialogOpen = () => {
    setDialogOpen(true);
  }





  return (
    <div className={classs.mainUiRightComponent}>
      {/* <img src={close_icon} className={classs.closeIcon} onClick={closeClick} /> */}
      <div>
        <DeviceSelect
          options={options}
          defaultSelectValue={defaultSelectValue}
          callback={itemObj}
        />
      </div>

      {/* 
      {
        projectModel
        &&
        <Dialog
          open={dialogOpen}
          onClose={handleClose}
          PaperProps={{ style: { maxWidth: 'none', width: '884px', height: '592px', borderRadius: '16px' } }}
        >
          <PrintPreviewDialog
            projectModel={projectModel}
            scenesDef={scenes}
            mergedImagesDef={mergedImages}
            materials={materials}
            texturePathState={texturePathState}
            callback={handleClose}
          />
        </Dialog>
      } */}
    </div>
  )
}

export default MainUiRightComponent;