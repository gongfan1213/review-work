// 依赖
import React, { useEffect, useState } from "react";
// 组件
import Dropdown from 'src/templates/2dEditor/common/widget/Dropdown/Dropdown';
// 外部变量
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import { PrintLayerModel, PrintModel, PrintQuality } from '../PrintLayer/model/PrintLayerModel';
import useDataCache from '../../../../utils/DataCache';
// 样式
import * as classes from './SelectFormListStyle.module.scss';
// 下拉选项
const modeOptions = [
  { str: '白彩', value: PrintModel.printModel1 },
  { str: '白彩光', value: PrintModel.printModel2 },
  { str: '彩', value: PrintModel.printModel3 },
  { str: '彩光', value: PrintModel.printModel4 },
  { str: '彩白', value: PrintModel.printModel5 },
  { str: '彩白彩', value: PrintModel.printModel6 },
];
const qualityOptions = [
  { str: 'Fast', value: PrintQuality.printQuality1 },
  { str: 'Normal', value: PrintQuality.printQuality2 },
  { str: 'Delicacy', value: PrintQuality.printQuality3 },
];

// 父组件参数类型
interface ObjViewerProps {
  printLayerModelDef: PrintLayerModel;
  handleQualitySelection: (item: { str: string; value: number; }) => void;
  handleModeSelection: (item: { str: string; value: number; }) => void;
}

const SelectFormList: React.FC<ObjViewerProps> = ({ printLayerModelDef, handleQualitySelection, handleModeSelection }) => {

  const { getTranslation } = useCustomTranslation();

  const [printLayerModel, setPrintLayerModel] = useState<PrintLayerModel>({
    printModel: PrintModel.printModel1,
    imgQuality: PrintQuality.printQuality2,
    printLayerData: [],
  });

  useEffect(() => {
    setPrintLayerModel(printLayerModelDef);
  }, [printLayerModelDef]);

  return (
    <div style={{ height: '260px' }}>
      <div className={classes.prepareTitle}>
        {getTranslation(TranslationsKeys.STR_COMMON_PRINT_SETTING)}
      </div>
      <Dropdown
        values={qualityOptions}
        typeStr={getTranslation(TranslationsKeys.STR_COMMON_QUALITY)}
        defaultSelectValue={printLayerModel.imgQuality}
        callback={handleQualitySelection}
      />
      <div style={{ marginTop: '12px' }} />
      {/* <Dropdown
        values={modeOptions}
        typeStr={t("str_common_ink_mode", "Ink Mode")}
        defaultSelectValue={printLayerModel.printModel}
        callback={handleModeSelection}
      /> */}
    </div>
  );
}

export default SelectFormList;