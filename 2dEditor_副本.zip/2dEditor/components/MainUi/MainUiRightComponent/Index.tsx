// 依赖
import React, { useEffect, useState, useCallback } from 'react';
// hooks
import { useProjectData, useCanvasEditor, useEvent } from 'src/templates/2dEditor/hooks/context';
// 组件
import Prepare from './Prepare/Prepare';
import Snapshot from './Snapshot/index';
import BaseMaterial from './BaseMaterial/BaseMaterial';
import MainUiRightBottom from './MainUiRightBottom/MainUiRightBottom';
import Dialog from '@material-ui/core/Dialog';
import PrintPreviewDialog from './PrintPreview/PrintPreviewDialog';

// 外部参数
import { EventNameCons, PROJECT_STANDARD_TYPE } from 'src/templates/2dEditor/cons/2dEditorCons';
import { CategoryMaterialsModel, CategoryScenesModel } from '../../SelectDialog/model/CategoryModel';
import useDataCache from '../../../utils/DataCache';

import { isPc } from 'src/common/jsbridge';
//png
import ic_3dpre_def from 'src/assets/img/ic_3dpre_def.png';
// 样式
import * as classs from './IndexStyle.module.scss';
import FastClick from 'src/common/utils/FastClick';
import close_icon from 'src/images/2dEditor/close_icon.png';
import { debounce } from 'lodash';
import AutoMeasure from './AutoMeasure/AutoMeasure';

// 参数类型
interface ObjViewerProps {
  closeClick: () => void;
}

const MainUiRightComponent: React.FC<ObjViewerProps> = ({ closeClick }) => {
  // 常量
  const [materials, setMaterials] = useState<CategoryMaterialsModel[]>([]);
  const [scenes, setScenes] = useState<CategoryScenesModel[]>([]);
  const [mergedImages, setMergedImages] = useState<string[]>([]);
  const [texturePathState, setTexturePathState] = useState<string>('');
  const [scenesSelect, setScenesSelect] = useState(0);
  const [snapshotData, setSnapshotData] = useState({ rectIndex: -1, isCompleted: true });
  const [deviceData, setDeviceData] = useState({ sn: '', deviceState: 1 });

  const [dialogOpen, setDialogOpen] = useState(false);

  const projectModel = useProjectData();
  const canvasEditor = useCanvasEditor();
  const event = useEvent();
  const [isLoadingProject, setIsLoadingProject] = useState(false);
  const { getCacheItem } = useDataCache();

  // 3d base metarial list
  const materialList: CategoryMaterialsModel[] = [
    { productColorID: 1, productColorName: '' },
    { productColorID: 2, productColorName: '' },
    { productColorID: 3, productColorName: '' },
  ];

  // 当前渲染是否是3d场景
  const is3dScenes = () => {
    return projectModel?.canvases[projectModel.canvasesIndex].model_link?.trim() !== '';
  };

  // 关闭放大弹窗
  const handleClose = () => {
    setDialogOpen(false);
  };

  // 打开放大弹窗
  const handleDialogOpen = () => {
    setDialogOpen(true);
  };

  // 监听鼠标松开事件，并在事件发生时更新贴图
  function handleMouseUp() {
    updateTexture();
  }

  const handleObjectRemove = (e: any) => {
    updateTexture();
  };

  const updateTexture = debounce((scenesTemp?: CategoryScenesModel[]) => {
    if (!canvasEditor) return;
    canvasEditor.preview1(projectModel).then((data: any) => {
      setTexturePathState(data.dataUrl);
      mergeAllImages(data.dataUrl, scenesTemp);
    });
  }, 300);

  const mergeAllImages = useCallback(
    (dataUrl: string, scenesTemp?: CategoryScenesModel[]) => {
      var scenesRet;
      if (scenesTemp) {
        scenesRet = is3dScenes() ? scenesTemp.slice(1) : scenesTemp;
      } else {
        scenesRet = is3dScenes() ? scenes.slice(1) : scenes;
      }

      if (!scenesRet) return;

      var cut_data: any = null;
      if (
        projectModel?.canvases[projectModel.canvasesIndex].extra &&
        JSON.parse(projectModel.canvases[projectModel.canvasesIndex].extra!).cutData
      ) {
        cut_data = JSON.parse(JSON.parse(projectModel.canvases[projectModel.canvasesIndex].extra!).cutData);
      }
      Promise.all(
        scenesRet.map((image) => canvasEditor?.mergeSceneImages(image, dataUrl, cut_data ? cut_data : undefined)),
      )
        .then((mergedUrls) => {
          const blobUrls = mergedUrls.map((base64) => {
            const byteString = atob(base64.split(',')[1]);
            const mimeString = base64.split(',')[0].split(':')[1].split(';')[0];
            const ab = new ArrayBuffer(byteString.length);
            const ia = new Uint8Array(ab);
            for (let i = 0; i < byteString.length; i++) {
              ia[i] = byteString.charCodeAt(i);
            }
            const blob = new Blob([ab], { type: mimeString });
            const blobUrl = URL.createObjectURL(blob);
            return blobUrl;
          });
          if (projectModel?.canvases[projectModel.canvasesIndex].model_link?.trim()) {
            blobUrls.unshift(ic_3dpre_def);
          }

          setMergedImages(blobUrls);
        })
        .catch((error) => {
          // 处理错误情况
          console.error('Error merging images:', error);
        });
    },
    [scenes, projectModel, canvasEditor],
  );

  useEffect(() => {
    setScenesSelect(getCacheItem('mainUiRight')?.scenesSelect || 0);
  }, [getCacheItem('mainUiRight')?.scenesSelect]);

  // 请求materialList
  useEffect(() => {
    if (projectModel) {
      const scenes: CategoryScenesModel[] = JSON.parse(projectModel.canvases[projectModel.canvasesIndex].scenes);
      scenes.forEach((scene) => {
        scene.scenesImgSelect = 0;
      });
      if (is3dScenes()) {
        scenes.unshift({
          scenesImg: [ic_3dpre_def],
          width: 0,
          height: 0,
          positionX: 0,
          positionY: 0,
          curvature: 0,
          scenesImgSelect: 0,
        });
        setMaterials(materialList);
      } else if (projectModel.canvases[projectModel.canvasesIndex].materials) {
        const materials: CategoryMaterialsModel[] = JSON.parse(
          projectModel.canvases[projectModel.canvasesIndex].materials!,
        );
        setMaterials(materials);
      }
      setMergedImages([]);
      setScenes(scenes);
      updateTexture(scenes);
    }
  }, [projectModel]);

  useEffect(() => {
    if (!canvasEditor) return;
    // 监听画布上的鼠标松开事件
    addEventListeners();
    event?.on(EventNameCons.EventProjectChangeState, setChangeProjectState);
    if (isLoadingProject) {
      setIsLoadingProject(false);
      handleMouseUp();
    }
    // 清理事件监听器
    return () => {
      removeEventListeners();
      event?.off(EventNameCons.EventProjectChangeState, setChangeProjectState);
    };
  }, [canvasEditor, scenes]);

  const setChangeProjectState = (state: boolean) => {
    if (state) {
      setIsLoadingProject(true);
      removeEventListeners();
    } else {
      addEventListeners();
    }
  };

  function addEventListeners() {
    if (!canvasEditor) return;
    // 监听画布上的鼠标松开事件
    canvasEditor.canvas.on('mouse:up', handleMouseUp);
    canvasEditor.canvas.on('object:added', handleMouseUp);
    canvasEditor.canvas.on('object:removed', handleObjectRemove);
  }

  function removeEventListeners() {
    if (!canvasEditor) return;
    // 清理事件监听器
    canvasEditor.canvas.off('mouse:up', handleMouseUp);
    canvasEditor.canvas.off('object:added', handleMouseUp);
    canvasEditor.canvas.off('object:removed', handleObjectRemove);
  }

  const is_standard_product = () => {
    return (
      projectModel?.canvases[projectModel.canvasesIndex].is_standard_product === PROJECT_STANDARD_TYPE.PROJECT_STANDARD
    );
  };

  return (
    <div className={classs.mainUiRightComponent}>
      {/* isPc toDo */}

      {!isPc() && <img src={close_icon} className={classs.closeIcon} onClick={closeClick} />}

      {/* {
        is_standard_product() && !isPc() ? <Prepare
          dialogOpen={dialogOpen}
          scenes={scenes}
          mergedImages={mergedImages}
          scenesSelect={scenesSelect}
          handleDialogOpen={handleDialogOpen}
          setScenesSelect={setScenesSelect}
          closeClick={closeClick}
          display={true}
        /> : null
      } */}

      {<Snapshot setSnapshotData={setSnapshotData} setDeviceData={setDeviceData} />}

      {is_standard_product() && materials.length > 0 && (
        <BaseMaterial
          materials={materials}
          mergedImages={mergedImages}
          scenes={scenes}
          texturePathState={texturePathState}
          setScenes={setScenes}
          setMergedImages={setMergedImages}
        />
      )}
      <MainUiRightBottom snapshotData={snapshotData} deviceData={deviceData} />
      {projectModel && (
        <Dialog
          open={dialogOpen}
          onClose={handleClose}
          PaperProps={{ style: { maxWidth: 'none', width: '884px', height: '592px', borderRadius: '16px' } }}
        >
          <PrintPreviewDialog
            projectModel={projectModel}
            scenesDef={scenes}
            mergedImagesDef={mergedImages}
            materials={materials}
            texturePathState={texturePathState}
            callback={handleClose}
          />
        </Dialog>
      )}
    </div>
  );
};

export default MainUiRightComponent;
