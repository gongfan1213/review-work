// 依赖
import React, { Dispatch, SetStateAction } from 'react'
// hooks
import { useProjectData, useCanvasEditor, useEvent } from 'src/templates/2dEditor/hooks/context';
// 外部参数
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';
import { CategoryMaterialsModel, CategoryScenesModel } from '../../../SelectDialog/model/CategoryModel';
//样式
import * as classes from './BaseMaterialStyle.module.scss'

// 父组件参数
interface ObjViewerProps {
  materials: CategoryMaterialsModel[],
  mergedImages: string[],
  texturePathState: string,
  scenes: CategoryScenesModel[],
  setScenes: Dispatch<SetStateAction<CategoryScenesModel[]>>
  setMergedImages: Dispatch<SetStateAction<string[]>>
}

const BaseMaterial: React.FC<ObjViewerProps> = ({ materials, mergedImages, scenes, texturePathState, setScenes, setMergedImages }) => {

  const projectModel = useProjectData();
  const canvasEditor = useCanvasEditor();
  const event = useEvent();

  // 当前渲染是否是3d场景
  const is3dScenes = () => {
    return projectModel?.canvases[projectModel.canvasesIndex].model_link?.trim();
  }

  return (
    <div className={classes.baseMComponent}>
      <div className={classes.baseMListTitle}>Base Material</div>
      <div className={classes.baseMListcomponent}>
        {materials.map((material, materialIndex) => (
          <div
            key={materialIndex}
            className={classes.itemMaterialImg}
            style={{ backgroundColor: `${material.productColorName}` }}
            onClick={() => {
              if (is3dScenes()) {
                event?.emitEvent(EventNameCons.EventMaterialSet, material.productColorID)
              } else {
                scenes.map((scene, index) => {
                  scene.scenesImgSelect = materialIndex;
                })
                if (mergedImages && texturePathState) {
                  scenes.map((scene, index) => {
                    console.log('scene;', scene);
                    console.log('texturePathState;', texturePathState);

                    canvasEditor?.mergeSceneImages(scene, texturePathState,).then((base64: string) => {
                      const byteString = atob(base64.split(',')[1]);
                      const mimeString = base64.split(',')[0].split(':')[1].split(';')[0];
                      const ab = new ArrayBuffer(byteString.length);
                      const ia = new Uint8Array(ab);
                      for (let i = 0; i < byteString.length; i++) {
                        ia[i] = byteString.charCodeAt(i);
                      }
                      const blob = new Blob([ab], { type: mimeString });
                      const blobUrl = URL.createObjectURL(blob);
                      setMergedImages((prevMergedImages) => {
                        const updatedMergedImages = [...prevMergedImages];
                        updatedMergedImages[index] = blobUrl;
                        return updatedMergedImages;
                      });
                    })
                  })
                }
                setScenes(scenes);
              }
            }} />
        ))}
      </div>
    </div>
  );
}

export default BaseMaterial;