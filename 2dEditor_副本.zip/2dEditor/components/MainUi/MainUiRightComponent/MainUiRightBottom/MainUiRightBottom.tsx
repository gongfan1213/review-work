import React, { useEffect, useRef, useState } from 'react';
import * as classes from './MainUiRightBottomStyle.module.scss';
import { useTranslation } from '@volcengine/i18n';
import { useCanvasEditor, useEvent, useFabric, useProjectData } from 'src/templates/2dEditor/hooks/context';
import {
  PrintLayerData,
  PrintLayerModel,
  PrintLayerType,
  PrintModel,
  PrintQuality,
} from '../PrintLayer/model/PrintLayerModel';
import Tar from 'tar-js';
import { updateProjectCavas } from 'src/templates/2dEditor/service/2dEditService';
import {
  CanvasesResInfo,
  ProjectCavasItemUpdateRequestModel,
  ProjectCavasUpdateRequestModel,
  ProjectModel,
  ProjectUpdateRequestModel,
} from '../../../SelectDialog/model/ProjectModel';
import { upload } from 'src/hooks/useUpload';
import { isPc, schemeUrlPC } from 'src/common/jsbridge';
import { getUserInfo } from 'src/common/storage';
import {
  CustomPcAction,
  EventNameCons,
  PROJECT_STANDARD_TYPE,
  ReliefType,
} from 'src/templates/2dEditor/cons/2dEditorCons';
import { PrintToPcModel } from '../PrintLayer/model/PrintToPcModel';
import Dropdown from 'src/templates/2dEditor/common/widget/Dropdown/Dropdown';
import SelectFormList from '../SelectFormList/SelectFormList';
import Loading from 'src/components/Loading';
import useDataCache from '../../../../utils/DataCache';
import Editor from 'src/templates/2dEditor/core';
import ProjectManager from 'src/templates/2dEditor/utils/ProjectManager';
import { blobToBase64, compressorImage1, convertToBase64, dataURLtoFile, getImgCompress } from 'src/common/utils';
import { EditorToastType, editorToastShow } from '../../../Toast';
import { generateTar, getCanvasThumbnail } from 'src/templates/2dEditor/common/cavasUtil';
import { sendCommandToPcWithResponse, sendCommandToPc } from 'src/common/jsbridge/util';
import { Dialog } from '@mui/material';
import { Button } from 'src/components/MakeUI';
import { TextureEffect2dManager } from '../../../TextureEdit/logic/TextureEffect2dManager';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import { toast } from 'src/templates/2dEditor/components/Toast';

const MainUiRightBottom: React.FC<{
  snapshotData: { rectIndex: number; isCompleted: boolean };
  deviceData: { sn: string; deviceState: number };
}> = ({ snapshotData, deviceData }) => {
  const { setCacheItem, getCacheItem } = useDataCache();
  const canvasEditor = useCanvasEditor();
  const projectModel = useProjectData();
  const [printLayerModel, setPrintLayerModel] = useState<PrintLayerModel>({
    printModel: PrintModel.printModel2,
    imgQuality: PrintQuality.printQuality2,
    printLayerData: [],
  });
  const printLayerManager = useRef<any | null>(null);
  const fabric = useFabric();
  const [isNetLoading, setNetLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const event = useEvent();
  const cachedata = getCacheItem('mainUiRight');
  const [layerPrint, setLayerPrint] = useState<boolean>(false);
  const { getTranslation } = useCustomTranslation();

  useEffect(() => {
    if (cachedata) {
      setPrintLayerModel((prev) => {
        return {
          ...prev,
          printModel: cachedata.printModel || printLayerModel.printModel,
          imgQuality: cachedata.imgQuality || printLayerModel.imgQuality,
        };
      });
    }
  }, [cachedata]);

  useEffect(() => {
    if (!canvasEditor || !fabric) return;
    Promise.all([import('../PrintLayer/manager/PrintLayerManager')]).then(([PrintLayerManagerModel]) => {
      var printLayerModelNet: PrintLayerModel = JSON.parse(
        projectModel!.canvases[projectModel!.canvasesIndex].print_param!,
      );
      const { PrintLayerManager } = PrintLayerManagerModel;
      printLayerManager.current = new PrintLayerManager();
      printLayerManager.current.initLayerList(printLayerModel, canvasEditor.canvas);
      if (!printLayerModelNet.imgQuality) {
        printLayerModelNet.imgQuality = PrintQuality.printQuality2;
      }
      if (!printLayerModelNet.printModel) {
        printLayerModelNet.printModel = PrintModel.printModel2;
      }
      console.log('printLayerModelDef==setPrintLayerModel==', printLayerModelNet);
      setPrintLayerModel(printLayerModelNet);
      canvasEditor.canvas.on('object:added', handleMouseUp);
      canvasEditor.canvas.on('object:removed', handleMouseUp);
    });

    handleMouseUp();
    return () => {
      canvasEditor.canvas.off('object:added', handleMouseUp);
      canvasEditor.canvas.off('object:removed', handleMouseUp);
    };
  }, [canvasEditor, fabric, projectModel]);

  const handleMouseUp = () => {
    let hasLayerPrint = canvasEditor?.hasLayerPrint(canvasEditor.canvas);
    if (!hasLayerPrint) {
      const canvases = projectModel!.canvases;
      for (let i = 0; i < canvases.length; i++) {
        if (i !== projectModel!.canvasesIndex) {
          const extraData = canvases[i].extra;
          if (extraData && JSON.parse(extraData).hasLayerPrint) {
            hasLayerPrint = true;
            break;
          }
        }
      }
    }
    setLayerPrint(hasLayerPrint);
  };

  const doPrint = () => {
    setNetLoading(true);
    const promises: Promise<void>[] = [];
    var reliefType = TextureEffect2dManager.getInstance().checkGrayCanvas(canvasEditor!.canvas, projectModel);
    printLayerModel.subPrintType = reliefType;
    if (reliefType === ReliefType.print_relief_type_def) {
      printLayerModel.printModel = PrintModel.printModel2;
    } else {
      printLayerModel.printModel = PrintModel.printModel8;
    }
    console.log('=====printLayerModel.printModel====', printLayerModel.printModel, reliefType);
    projectModel?.canvases.forEach((canvas, index) => {
      console.log('printClick =download_url==', canvas.print_file.download_url, new Date().toISOString());
      if (index == projectModel!.canvasesIndex) {
        console.log('printClick =effect_file download_url==', canvas.effect_file.download_url);
        promises.push(
          generateTar(
            projectModel,
            canvas,
            canvasEditor!.canvas,
            printLayerModel,
            canvas.print_file.upload_url,
            deviceData.sn,
            canvasEditor,
          ),
        );
        promises.push(getCanvasThumbnail(canvasEditor!.canvas));
        promises.push(canvasEditor?.preview1(projectModel));
      } else if (canvas.extra && JSON.parse(canvas.extra).hasLayerPrint) {
        ///未选中的画布，需要先下载json完整文件，并绘制到临时canvas里，然后生成tar包
        var printLayerModelNet: PrintLayerModel = JSON.parse(canvas.print_param!);
        const promise = ProjectManager.getInstance()
          .getProjectJson(projectModel, index)
          .then((json: string | undefined) => {
            if (!json) return;
            const tempCanvas = new fabric.Canvas(null, {
              width: canvas.base_map_width,
              height: canvas.base_map_height,
            });
            console.log('printClick =开始渲染==', new Date().toISOString());
            return canvasEditor?.insertSvgFileTemp(json, tempCanvas).then(() => {
              console.log('printClick =渲染完成==', new Date().toISOString());
              return generateTar(
                projectModel,
                canvas,
                tempCanvas,
                printLayerModelNet,
                canvas.print_file.upload_url,
                deviceData.sn,
                canvasEditor,
              );
            });
          });
        promises.push(promise);
      }
    });

    return Promise.all(promises)
      .then((res) => {
        const tarData: any = res[0];
        const thumbnail = res[1].dataUrl;
        const effectImage = res[2].dataUrl;
        const projectModel = res[0].projectModel;

        var canvas = projectModel.canvases[projectModel?.canvasesIndex];
        canvas.thumb_file.thumbnail = thumbnail;
        canvas.effect_file.effectImage = effectImage;
        setNetLoading(false);

        if (isPc()) {
          var canvases = [...projectModel?.canvases];
          canvases[0].print_param = JSON.stringify({
            ...JSON.parse(canvases[0].print_param),
            textureData: tarData.textureData,
          });

          sendCommandToPcWithResponse(
            CustomPcAction.PrintNeedLocalData,
            (data: any) => {
              let model: PrintToPcModel = {
                project_id: projectModel?.project_info.project_id,
                project_info: JSON.stringify(projectModel?.project_info),
                canvases: JSON.stringify(canvases),
                sn: deviceData.sn,
                rectIndex: snapshotData.rectIndex,
              };
              if (data === 1) {
                model.file_tar = tarData?.base64Tar;
                model.file_md5 = tarData?.md5Tar;
              }
              console.log('========CustomPcAction.PrintAction=====model=====', model);
              //埋点 发起打印成功
              StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.canvas_print, 1);
              sendCommandToPc(CustomPcAction.PrintAction, model);
            },
            { sn: deviceData.sn },
          );
        } else {
          StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.canvas_print, 1);
          var url = `project_id=${projectModel?.project_info.project_id}&source=${'2dPrint'}&handle_id=${getUserInfo()!.user_id}`;
          schemeUrlPC(url);
        }
      })
      .catch((error) => {
        //埋点 发起打印失败
        StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.canvas_print, 0);
        setNetLoading(false);
        editorToastShow({
          tips: getTranslation(TranslationsKeys.ERROR_PROCESSING_PRINT_LAYERS),
          type: EditorToastType.error,
        });
      });
  };

  const printClick = () => {
    if (canvasEditor?.getLoadingElements().length !== 0) {
      toast.current?.show();
      toast.current?.type('warning');
      toast.current?.tips(getTranslation(TranslationsKeys.VIEW3D_LOAD));
      return;
    }
    if (!canvasEditor || !fabric || !printLayerManager || !printLayerManager.current) return;
    //如果拍照还没结束，询问是否需要中断拍照
    if (!snapshotData.isCompleted) {
      setShowConfirm(true);
    } else {
      doPrint();
    }
  };

  /*
   * 生成当前tar包
   */
  // function generateTar(canvasInfo: CanvasesResInfo, canvas: fabric.Canvas, printLayerData: PrintLayerModel, uploadUrl: string, effectUploadUrl: string): Promise<void> {

  //   printLayerManager.current.initLayoutId(canvas);
  //   printLayerManager.current.initLayerList(printLayerData, canvas);

  //   const promises: Promise<PrintLayerData>[] = [];
  //   printLayerData.printLayerData.forEach((layerData) => {
  //     if (layerData.layerNum > 0) {
  //       let promise: Promise<PrintLayerData>;
  //       switch (layerData.printType) {
  //         case PrintLayerType.printLayerType1:
  //           promise = printLayerManager.current!.getPrintPicWhiteInk(projectModel?.project_info.is_standard_product, layerData, printLayerData, canvas);
  //           break;
  //         case PrintLayerType.printLayerType2:
  //           promise = printLayerManager.current!.getPrintPicColorInk(projectModel?.project_info.is_standard_product, layerData, printLayerData, canvas);
  //           break;
  //         case PrintLayerType.printLayerType3:
  //           promise = printLayerManager.current!.getPrintPicVarnishInk(projectModel?.project_info.is_standard_product, layerData, printLayerData, canvas);
  //           break;
  //         default:
  //           promise = Promise.reject(new Error('Unknown print type'));
  //       }
  //       promises.push(promise);
  //     }
  //   });
  //   return Promise.all(promises).then((printLayerDatas) => {
  //     console.log('printClick =生图完成==', new Date().toISOString())
  //     return createAndDownloadTar(canvasInfo, printLayerDatas, printLayerData, uploadUrl, effectUploadUrl);
  //   });
  // }

  // function base64ToUint8Array(base64: string) {
  //   const binaryString = window.atob(base64);
  //   const len = binaryString.length;
  //   const bytes = new Uint8Array(len);
  //   for (let i = 0; i < len; i++) {
  //     bytes[i] = binaryString.charCodeAt(i);
  //   }
  //   return bytes;
  // }

  // 创建tar包并下载
  // async function createAndDownloadTar(canvasInfo: CanvasesResInfo, printLayerDatas: PrintLayerData[], printLayerData: PrintLayerModel, uploadUrl: string, effectUploadUrl: string): Promise<any> {
  //   const tarball = new Tar(); // 创建一个新的 tar 实例

  //   printLayerDatas.forEach((data, index) => {
  //     data.printTypeFileStr = data.printTypeFileStr + index;
  //     let prefix = data.printTypeFileStr;
  //     printLayerData.printLayerData.find((item) => item.printType === data.printType)!.printTypeFileStr = prefix;
  //     for (let index = 0; index < data.layerNum; index++) {
  //       const filename = `${prefix}${index + 1}.png`;
  //       const fileData = base64ToUint8Array(data.dataUrl!.split(',')[1]); // 假设 data.dataUrl 是一个 Base64 编码的 Data URL
  //       tarball.append(filename, fileData);
  //     }
  //   });
  //   for (const data of printLayerDatas) {
  //     //上传效果图
  //     if (data.printType === PrintLayerType.printLayerType2 && data.dataUrl) {
  //       const filename = 'mockUp.png'; // 你可以根据需要设置文件名
  //       const file = dataURLtoFile(data.dataUrl, filename);
  //       if (file) {
  //         // 压缩
  //         compressorImage1(file, 0, 0, 1, 200).then((blob) => {
  //           var fileRet: File = new File([blob], file.name, { type: blob.type, lastModified: Date.now() });
  //           if (effectUploadUrl) {
  //             /// 上传缩略图
  //             upload(effectUploadUrl, fileRet).then((uploadSuccess) => {
  //               // 上传成功的处理
  //             }).catch((error) => {
  //               console.error('Upload thumbnail error:', error);
  //             });
  //           }
  //         }).catch((error) => {
  //           console.error('Error compressing image:', error);
  //         });
  //       } else {
  //         console.error('Failed to convert data URL to file');
  //       }
  //       break;
  //     }
  //   }
  //   //非标品数据再次上传
  //   if (projectModel!.project_info.is_standard_product !== PROJECT_STANDARD_TYPE.PROJECT_STANDARD) {
  //     updatePrintParams(printLayerData);
  //   }

  //   let retJson: PrintLayerModel = JSON.parse(JSON.stringify(printLayerData));
  //   retJson.printLayerData.forEach((data, index) => {
  //     data.printLayerObjIds = [];
  //   })
  //   const configData = new TextEncoder().encode(JSON.stringify(retJson));
  //   // 将 config.json 文件及其内容添加到 tarball 中
  //   tarball.append('config.json', configData);

  //   // tar包添加缩略图
  //   // const thumbnailData = await canvasEditor?.getThumbnail();
  //   // const decodedUrl = decodeURIComponent(canvasInfo.thumb_file.download_url);
  //   // const base64 = await convertToBase64(decodedUrl);
  //   // if (base64) {
  //   //   const filename = 'thumbnail.png'; // 你可以根据需要设置文件名
  //   //   const file = dataURLtoFile(base64, filename);
  //   //   if (!file) {
  //   //     throw new Error('Failed to convert data URL to file');
  //   //   }
  //   //   // 等待压缩缩略图
  //   //   const blob = await compressorImage1(file, 200, 200, 1);
  //   //   var blobBase64 = await blobToBase64(blob);
  //   //   tarball.append(file.name, base64ToUint8Array(blobBase64!.split(',')[1]));
  //   // }

  //   // 将 tar 包转换为 Blob
  //   const blobTar = new Blob([tarball.out], { type: 'application/x-tar' });
  //   const fileTar = new File([blobTar], "printLayers.tar", { type: 'application/x-tar' });

  //   // 等待上传tar包
  //   const uploadResult = await upload(uploadUrl, fileTar);
  //   console.log('printClick =上传完成==', new Date().toISOString())
  //   return uploadResult;

  // }

  // 选择打印模型
  const handleModeSelection = (item: { str: string; value: number }) => {
    setCacheItem('mainUiRight', { ...getCacheItem('mainUiRight'), printModel: item.value });
    if (!printLayerManager || !printLayerManager.current) return;
    var newPrintParam = {
      ...printLayerModel,
      printModel: item.value,
    };
    setPrintLayerModel(newPrintParam);
    updatePrintParams(newPrintParam);
  };

  // 选择打印质量
  const handleQualitySelection = (item: { str: string; value: number }) => {
    setCacheItem('mainUiRight', { ...getCacheItem('mainUiRight'), imgQuality: item.value });
    console.log('zhiliang', getCacheItem('mainUiRight'));
    if (!printLayerManager || !printLayerManager.current) return;
    var newPrintParam = {
      ...printLayerModel,
      imgQuality: item.value,
    };
    setPrintLayerModel(newPrintParam);
    updatePrintParams(newPrintParam);
  };

  const updatePrintParams = (printLayerModel: PrintLayerModel) => {
    var itemRequest: ProjectCavasItemUpdateRequestModel = {
      canvas_id: projectModel!.canvases[projectModel!.canvasesIndex].canvas_id,
      print_param: JSON.stringify(printLayerModel),
    };

    var request: ProjectCavasUpdateRequestModel = {
      project_id: projectModel!.project_info.project_id,
      canvases: [itemRequest],
    };
    updateProjectCavas(request);
    projectModel!.canvases[projectModel!.canvasesIndex].print_param = JSON.stringify(printLayerModel);
    event?.emitEvent(EventNameCons.EventUpdateDetailProjectDataOnly, projectModel);
  };

  return (
    <>
      <SelectFormList
        printLayerModelDef={printLayerModel}
        handleQualitySelection={handleQualitySelection}
        handleModeSelection={handleModeSelection}
      />
      <button
        className={classes.submitBottom}
        onClick={printClick}
        disabled={!layerPrint || (isPc() && !deviceData.sn)}
      >
        {getTranslation(TranslationsKeys.STR_EDITOR_PRINT_TASK)}
      </button>
      <Loading loading={isNetLoading} />
      <Dialog className={classes.erroState} open={showConfirm}>
        {/* @ts-ignore */}
        <div>{getTranslation(TranslationsKeys.SNAPSHOT_ISCONTINUE)}</div>
        {/* @ts-ignore */}
        <Button
          className={classes.confirmButton}
          onClick={() => {
            setShowConfirm(false);
          }}
        >
          NO
        </Button>
        <Button
          className={classes.confirmButton}
          onClick={() => {
            sendCommandToPc(CustomPcAction.TakePhotoAction, {
              sn: deviceData.sn,
              state: 1,
            });
            doPrint();
            setShowConfirm(false);
          }}
        >
          YES
        </Button>
      </Dialog>
    </>
  );
};

export default MainUiRightBottom;
