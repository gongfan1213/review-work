// 依赖
import React, { Dispatch, SetStateAction, useState } from 'react'
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
// 组件
import ObjViewer from '../../../3dModel/ObjViewer';
// hooks
import { useProjectData } from 'src/templates/2dEditor/hooks/context';
// 外部参数
import { CategoryScenesModel } from '../../../SelectDialog/model/CategoryModel';
import useDataCache from '../../../../utils/DataCache';
// 样式
import * as classes from './PrepareStyle.module.scss';
// png
import icon_arrows_out from 'src/assets/svg/icon_arrows_out.svg';
import close_icon from 'src/images/2dEditor/close_icon.png';
import { PROJECT_STANDARD_TYPE } from 'src/templates/2dEditor/cons/2dEditorCons';

// 父组件参数
interface ObjViewerProps {
  scenes: CategoryScenesModel[],
  mergedImages: string[],
  scenesSelect: number,
  handleDialogOpen?: () => void,
  setScenesSelect: Dispatch<SetStateAction<number>>,
  height?: number,
  display?: boolean,
  closeClick?: () => void,
  showCloseIcon?: boolean,
  showArrowsIcon?: boolean;
  dialogOpen?: boolean;
}

const Prepare: React.FC<ObjViewerProps> = ({ scenes, mergedImages, scenesSelect, handleDialogOpen, setScenesSelect, height = 276, display = true, closeClick, showCloseIcon = true, showArrowsIcon = true, dialogOpen }) => {

  const projectModel = useProjectData();
  const { setCacheItem, getCacheItem } = useDataCache();
  const scenesImgList = () => {

    return (
      <div className={classes.prepareList}>
        {scenes.map((image, index) => (
          <img
            crossOrigin="anonymous"
            key={index}
            className={classes.itemSceneImg}
            src={mergedImages[index] || image.scenesImg[image.scenesImgSelect]} // 使用合成后的图片 URL 或原始 URL
            onClick={(e) => {
              setScenesSelect(index);
              setCacheItem('mainUiRight', { ...getCacheItem('mainUiRight'), scenesSelect: index })
            }}
          />
        ))}
      </div>
    );
  };
  // 当前渲染是否是3d场景
  const is3dScenes = () => {
    return projectModel?.canvases[projectModel.canvasesIndex].model_link?.trim();
  }

  const is_standard_product = () => {
    return projectModel?.canvases[projectModel.canvasesIndex].is_standard_product === PROJECT_STANDARD_TYPE.PROJECT_STANDARD
  }

  const { getTranslation } = useCustomTranslation();

  return (
    <div className={classes.prepareComponent}>
      {display && <div className={classes.prepareTitle}>{getTranslation(TranslationsKeys.STR_COMMON_PREPARE)}</div>}
      <div className={classes.layoutPreview} style={{ height }}>

        {
          dialogOpen == undefined ? ((projectModel?.canvases[projectModel.canvasesIndex].model_link?.trim() && scenesSelect == 0) && <ObjViewer modelPath={projectModel.canvases[projectModel.canvasesIndex].model_link} texturePath={""} />)
            : ((projectModel?.canvases[projectModel.canvasesIndex].model_link?.trim() && scenesSelect == 0 && !dialogOpen) && <ObjViewer modelPath={projectModel.canvases[projectModel.canvasesIndex].model_link} texturePath={""} />)
        }
        {
          (is3dScenes() && scenes.length > 0 && scenesSelect > 0) && <img
            crossOrigin="anonymous"
            className={classes.itemSceneImgPre}
            src={mergedImages[scenesSelect] || (scenes[scenesSelect] && scenes[scenesSelect].scenesImg && scenes[scenesSelect].scenesImg[scenes[scenesSelect].scenesImgSelect]) || ""}
          />
        }
        {
          (!is3dScenes() && scenes.length > 0) && <img
            crossOrigin="anonymous"
            className={classes.itemSceneImgPre}
            src={mergedImages[scenesSelect] || (scenes[scenesSelect] && scenes[scenesSelect].scenesImg && scenes[scenesSelect].scenesImg[scenes[scenesSelect].scenesImgSelect]) || ""}
          />
        }
        {showArrowsIcon && scenes.length > 0 && <img src={icon_arrows_out} className={classes.arrowsOutIcon} onClick={handleDialogOpen} />}
      </div>
      {
        display && projectModel && scenes.length > 0 && scenesImgList()
      }
    </div>
  );
}

export default Prepare;