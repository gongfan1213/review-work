// 依赖
import React, { useEffect, useRef, useState } from 'react';
import { useTranslation } from '@volcengine/i18n';
// 组件
import Prepare from '../Prepare/Prepare';
import BaseMaterial from '../BaseMaterial/BaseMaterial';
import SelectFormList from '../SelectFormList/SelectFormList';

// 外部变量
import { PrintLayerModel, PrintModel, PrintQuality } from '../PrintLayer/model/PrintLayerModel'
import { ProjectModel } from '../../../SelectDialog/model/ProjectModel';
import { useCanvasEditor, useEvent, useFabric } from 'src/templates/2dEditor/hooks/context';
import { CategoryMaterialsModel, CategoryScenesModel } from '../../../SelectDialog/model/CategoryModel';
import useDataCache from '../../../../utils/DataCache';
import close_icon from 'src/images/2dEditor/close_icon.png';

// 样式
import * as classes from './PrintPreviewDialogStyle.module.scss';

// import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
// import ObjViewer from '../../../3dModel/ObjViewer';
// import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';

type PrintLayerDialogProps = {
  projectModel: ProjectModel;
  scenesDef: CategoryScenesModel[];
  mergedImagesDef: string[];
  texturePathState: string;
  materials: CategoryMaterialsModel[];
  callback: () => void;

};

const PrintLayerDialog: React.FC<PrintLayerDialogProps> = ({ projectModel, scenesDef, mergedImagesDef, materials, texturePathState, callback }) => {
  const canvasEditor = useCanvasEditor();
  const { setCacheItem, getCacheItem } = useDataCache();
  const cachedata = getCacheItem('mainUiRight');
  const { t } = useTranslation()
  const [scenesSelect, setScenesSelect] = useState(0);
  const event = useEvent();
  const [scenes, setScenes] = useState<CategoryScenesModel[]>(scenesDef);
  const [mergedImages, setMergedImages] = useState<string[]>(mergedImagesDef);
  const [printLayerModel, setPrintLayerModel] = useState<PrintLayerModel>({
    printModel: PrintModel.printModel1,
    imgQuality: PrintQuality.printQuality2,
    printLayerData: [],
  });



  useEffect(() => {
    if (!canvasEditor) return;
  }, []);

  useEffect(() => {
    if (cachedata) {
      setPrintLayerModel((prev) => {
        return {
          ...prev,
          printModel: cachedata.printModel || printLayerModel.printModel,
          imgQuality: cachedata.imgQuality || printLayerModel.imgQuality
        }
      })
      if (cachedata.scenesSelect) {
        setScenesSelect(cachedata.scenesSelect);
      }
    }
  }, [cachedata])

  // const is3dScenes = () => {
  //   return projectModel?.model_path;
  // }

  const scenesImgList = () => {
    return (
      <div className={classes.imageListContainer}>
        {scenes.map((image, index) => (
          <img
            key={index}
            className={classes.itemSceneImg}
            src={mergedImages[index] || image.scenesImg[image.scenesImgSelect]} // 使用合成后的图片 URL 或原始 URL
            onClick={(e) => {
              setCacheItem('mainUiRight', { ...getCacheItem('mainUiRight'), scenesSelect: index })
              setScenesSelect(index);
            }}
          />
        ))}
      </div>
    );
  };

  const handleQualitySelection = (item: { str: string; value: number }) => {
    setCacheItem('mainUiRight', {
      ...getCacheItem('mainUiRight'),
      imgQuality: item.value,
    })
  };

  const handleModeSelection = (item: { str: string; value: number }) => {
    setCacheItem('mainUiRight', {
      ...getCacheItem('mainUiRight'),
      printModel: item.value,
    });
  };

  return (
    <div className={classes.printPreviewlayout}>
      <img className={classes.closeIcon} onClick={() => { callback() }} src={close_icon} />
      <div className={classes.previewLayout}>
        <Prepare
          mergedImages={mergedImages}
          scenesSelect={scenesSelect}
          showArrowsIcon={false}
          showCloseIcon={false}
          display={false}
          setScenesSelect={setScenesSelect}
          scenes={scenes}
          height={560}
        />
      </div>
      <div className={classes.previewInfo}>
        <div className={classes.scenesList}>
          {projectModel && scenes.length > 0 && scenesImgList()}
        </div>
        {
          materials.length > 0 && <BaseMaterial
            materials={materials}
            mergedImages={mergedImages}
            scenes={scenes}
            texturePathState={texturePathState}
            setScenes={setScenes}
            setMergedImages={setMergedImages}
          />
        }
        <div>
          <SelectFormList
            printLayerModelDef={printLayerModel}
            handleQualitySelection={handleQualitySelection}
            handleModeSelection={handleModeSelection}
          />
        </div>
      </div>
    </div>
  );
};

export default PrintLayerDialog;
