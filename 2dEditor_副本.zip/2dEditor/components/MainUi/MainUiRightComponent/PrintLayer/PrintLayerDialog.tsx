// start_ai_generated 
import React, { useEffect, useRef, useState } from 'react';
import { PrintLayerModel } from './model/PrintLayerModel';
import * as classes from './PrintLayerDialogStyle.module.scss';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import ic_close from 'src/templates/Relief/images/close.svg';
import { useCanvasEditor, useFabric } from 'src/templates/2dEditor/hooks/context';
import { PrintLayerManager } from './manager/PrintLayerManager';
import PrintLayerList from './PrintLayerList';
import JSZip from 'jszip';

type PrintLayerDialogProps = {
  model: PrintLayerModel;
  callback: (updatedModel?: PrintLayerModel | null) => void;
};

const PrintLayerDialog: React.FC<PrintLayerDialogProps> = ({ model, callback }) => {
  const canvasEditor = useCanvasEditor();
  const [printLayerModel, setPrintLayerModel] = useState<PrintLayerModel>(model);
  const { getTranslation } = useCustomTranslation();
  const fabric = useFabric()
  const printLayerManager = useRef<PrintLayerManager | null>(null);

  const [dataJson, setDataJson] = useState<any>({});

  useEffect(() => {
    if (!canvasEditor || !fabric) return;
    if (!printLayerManager.current) {
      printLayerManager.current = new PrintLayerManager()
    }
    printLayerManager.current.initLayoutId(canvasEditor.canvas);
    const dataJson = printLayerManager.current.getLayerJson(canvasEditor);
    setDataJson(dataJson);
    console.log("printClick====" + JSON.stringify(dataJson));
    setPrintLayerModel(printLayerManager.current.initLayerList(model, canvasEditor.canvas));

  }, []);

  const renderObjects = (objects: any[]) => {
    if (!objects) return null;
    return objects.map((obj, index) => {
      if (obj.type === 'group') {
        const isAllPaths = obj.objects.every((o: any) => o.type === 'path');
        if (isAllPaths) {
          return <li key={index}>Group of paths</li>;
        } else {
          return (
            <li key={index}>
              Group with mixed objects
              <ul>{renderObjects(obj.objects)}</ul>
            </li>
          );
        }
      } else {
        return <li key={index}>{obj.type}</li>;
      }
    });
  };

  // t('str_print_layer_lab5', 'Select White Ink Area')
  // t('str_print_layer_lab6', 'To ensure the quality of the final product, the white parts in the design need to be printed with white ink.')
  // t('str_layer_image', 'Image Layer')
  // t('str_layer_text', 'Text Layer')
  // t('str_layer_vector', 'Vector Layer')

  const handleSave = () => {
    // 当用户点击保存时，调用callback回调函数
    callback(printLayerModel);
  };

  return (
    <div className={classes.layout}>
      <div className={classes.titleLayout}>
        <div className={BaseStyles.txt14}>{getTranslation(TranslationsKeys.STR_PRINT_LAYER_TITLE)}</div>
        <img className={classes.closeIcon} onClick={() => { callback(null) }} src={ic_close} />
      </div>
      <div className={classes.bottomLayout}>
        <div className={classes.bottomLeftLayout}>
          <div className={BaseStyles.txt12}>{getTranslation(TranslationsKeys.STR_PRINT_LAYER_LAB1)}</div>

          <PrintLayerList data={printLayerModel.printLayerData} />
        </div>
        <div className={classes.bottomRightLayout}>
          <ul className={classes.objectList}>
            {renderObjects(dataJson.objects)}
          </ul>
        </div>
      </div>

      <button onClick={handleSave}>{getTranslation(TranslationsKeys.BUTTON_SAVE)}</button>
    </div>
  );
};

export default PrintLayerDialog;
// end_ai_generated 