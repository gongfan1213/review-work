// start_ai_generated 
import React from 'react';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import './PrintLayerList.module.scss';
import { PrintLayerData } from './model/PrintLayerModel';

interface PrintLayerListProps {
  data: PrintLayerData[];
}

const PrintLayerList: React.FC<PrintLayerListProps> = ({ data }) => {
  const { getTranslation } = useCustomTranslation();

  const getPrintTypeLabel = (printType: number) => {
    switch (printType) {
      case 0:
        return getTranslation(TranslationsKeys.STR_PRINT_LAYER_LAB2);
      case 1:
        return getTranslation(TranslationsKeys.STR_PRINT_LAYER_LAB3);
      case 2:
        return getTranslation(TranslationsKeys.STR_PRINT_LAYER_LAB4);
      default:
        return '';
    }
  };

  return (
    <ul className="printLayerList">
      {data.map((layerData, index) => (
        <li key={index} className="printLayerItem">
          <span className="printLayerType">{getPrintTypeLabel(layerData.printType)}</span>
          <span className="layerNum">{layerData.layerNum}</span>
          {/* <span className="printLayerObjIds">{layerData.printLayerObjIds.join(', ')}</span> */}
        </li>
      ))}
    </ul>
  );
};

export default PrintLayerList;
// end_ai_generated 