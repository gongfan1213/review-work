import { RotaryParams } from "src/templates/2dEditor/components/SelectDialog/model/ProjectModel"

export enum PrintModel {
  ///打印模式，全不打，全打，自定义（0，1，2）
  printModel1 = 0, ////白彩
  printModel2 = 1, //白彩光
  printModel3 = 2, //彩
  printModel4 = 3, //彩光
  printModel5 = 4, //彩白
  printModel6 = 5, //彩白彩
  printModel7 = 110, //灯光画
  printModel8 = 120, //纹理&浮雕

}

export enum PrintQuality {
  printQuality1 = 100,     // 100dpi
  printQuality2 = 200,     // 200dpi
  printQuality3 = 300,     // 300dpi
}

export enum PrintLayerType {
  ///白，彩，光（0，1，2）
  printLayerType1 = 0,
  printLayerType2 = 1,
  printLayerType3 = 2,
}

export enum PrintLayerFileStr {
  ///白，彩，光（0，1，2）
  printLayerTypeStr1 = 'PicWhiteInk',
  printLayerTypeStr2 = 'PicColorInk',
  printLayerTypeStr3 = 'PicVarnishInk',
  printLayerTypeStr4 = 'PicVarnishGrayCmyk',
  printLayerTypeStr5 = 'PicVarnishGrayGloss',

}


export type PrintLayerModel = {
  printModel: number ///打印模式，全不打，全打，自定义（0，1，2）
  printLayerData: PrintLayerData[]  ///打印涂层数据
  format_size_w?: number  ///打印底图宽,单位mm
  format_size_h?: number  ///打印底图高,单位mm
  format_size_w_non?: number  ///非标打印格式宽,单位mm
  format_size_h_non?: number  ///非标打印格式高,单位mm
  imgQuality?: number // 打印质量 -- 快速,标准,精细 （0，1，2）
  thumbnail_x?: number  ///缩略图x
  thumbnail_y?: number  ///缩略图y
  cavas_map?: string  ///画布图片
  rotary_params?: RotaryParams
  subPrintType?: number  ///浮雕类型
}

export type PrintLayerData = {
  printType: number  /// 白，彩，光（0，1，2）
  printTypeFileStr: string  ///打印类型文件名
  layerNum: number  ///打印层数
  printLayerObjIds: string[]  ///选中涂层id
  dataUrl?: string
  grayCmykUrl?: string
  grayGlosskUrl?: string
  grayCmykFileStr?: string  //纹理cmyk
  grayGlossFileStr?: string  //纹理gloss
  thickness?: number  ///厚度
}

