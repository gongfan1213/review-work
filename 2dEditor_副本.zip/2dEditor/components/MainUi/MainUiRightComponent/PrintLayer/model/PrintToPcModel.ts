

export type PrintToPcModel = {
  project_id: string;
  project_info: string;
  // source: string;
  // user_id: string;
  file_tar?: string;
  sn: string;
  canvases: any;
  // thumbnail: string;
  rectIndex: number;
  file_md5?: string;
}


