import { fabric } from 'fabric';
import { v4 as uuid } from 'uuid';
import { PrintLayerData, PrintLayerFileStr, PrintLayerModel, PrintLayerType, PrintModel, PrintQuality } from "../model/PrintLayerModel";
import { ACTION_MAGICK, CanvasSubCategory, EDITOR_JSON_KEY, PROJECT_STANDARD_TYPE, WorkspaceID } from 'src/templates/2dEditor/cons/2dEditorCons';
import StringUtil from 'src/common/utils/stringUtil';
import { ProjectModel } from '../../../../../components/SelectDialog/model/ProjectModel';
// @ts-ignore
// import IMagickWorker from 'src/templates/2dEditor/core/worker/imagick.worker';
import { TextureEffect2dManager } from 'src/templates/2dEditor/components/TextureEdit/logic/TextureEffect2dManager';
import Editor from 'src/templates/2dEditor/core';
import { Texture3dGrayPrint } from 'src/templates/2dEditor/components/TextureEdit/model/TextureModel';
import { filterTextureElements } from 'src/templates/2dEditor/common/cavasUtil';
import { Texture } from '@mui/icons-material';

export class PrintLayerManager {

  constructor() {
  }


  initLayoutId(canvas: any) {
    if (!canvas) return;
    // 遍历所有对象并添加layerId属性
    canvas.getObjects().forEach((obj: any) => {
      this.addLayerId(obj);
    });
    canvas.renderAll();
  }

  private addLayerId(obj: any) {
    // 如果对象是组，为组内每个对象也添加layerId属性
    if (obj.type === 'group') {
      const isAllPaths = obj.getObjects().every((o: any) => o.type === 'path');
      if (isAllPaths) {
        if (!(obj as any).layerId) {
          var uuidValue = uuid();
          (obj as any).set('layerId', uuidValue);
        }
      } else {
        (obj as any).getObjects().forEach((groupObj: any) => {
          this.addLayerId(groupObj)
        });
      }
    } else {
      // 为对象添加layerId属性
      if (!(obj as any).layerId) {
        var uuidValue = uuid();
        (obj as any).set('layerId', uuidValue);
      }
    }
  }

  getLayerJson(canvas: any): string {
    const dataJson = canvas.toJSON(EDITOR_JSON_KEY);
    dataJson.objects = dataJson.objects.filter((obj: any, index: number) => {
      return obj.id && !obj.id.includes(WorkspaceID.WorkspaceCavas);
    });
    return dataJson;
  }

  initLayerList(model: PrintLayerModel, canvas: any): PrintLayerModel {
    switch (model.printModel) {
      case PrintModel.printModel1:
        //白彩
        const layerIds1 = this.extractLayerIds((this.getLayerJson(canvas) as any).objects);
        model.printLayerData = [
          { printType: PrintLayerType.printLayerType1, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr1, layerNum: 1, printLayerObjIds: layerIds1 },
          { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: layerIds1 },
        ];
        break;
      case PrintModel.printModel2:
        //白彩光
        const layerIds2 = this.extractLayerIds((this.getLayerJson(canvas) as any).objects);
        model.printLayerData = [
          { printType: PrintLayerType.printLayerType1, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr1, layerNum: 1, printLayerObjIds: layerIds2 },
          { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: layerIds2 },
          { printType: PrintLayerType.printLayerType3, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr3, layerNum: 1, printLayerObjIds: layerIds2 },
        ];
        break;
      case PrintModel.printModel3:
        //彩
        const layerIds3 = this.extractLayerIds((this.getLayerJson(canvas) as any).objects);
        model.printLayerData = [
          { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: layerIds3 },
        ];
        break;
      case PrintModel.printModel4:
        //彩光
        const layerIds4 = this.extractLayerIds((this.getLayerJson(canvas) as any).objects);
        model.printLayerData = [
          { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: layerIds4 },
          { printType: PrintLayerType.printLayerType3, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr3, layerNum: 1, printLayerObjIds: layerIds4 },
        ];
        break;
      case PrintModel.printModel5:
        //彩白
        const layerIds5 = this.extractLayerIds((this.getLayerJson(canvas) as any).objects);
        model.printLayerData = [
          { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: layerIds5 },
          { printType: PrintLayerType.printLayerType1, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr1, layerNum: 1, printLayerObjIds: layerIds5 },
        ];
        break;
      case PrintModel.printModel6:
        //彩白彩
        const layerIds6 = this.extractLayerIds((this.getLayerJson(canvas) as any).objects);
        model.printLayerData = [
          { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: layerIds6 },
          { printType: PrintLayerType.printLayerType1, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr1, layerNum: 1, printLayerObjIds: layerIds6 },
          { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: layerIds6 },
        ];
        break;
      case PrintModel.printModel8:
        const layerIds7 = this.extractLayerIds((this.getLayerJson(canvas) as any).objects);
        model.printLayerData = [
          { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: layerIds7 },
          { printType: PrintLayerType.printLayerType1, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr1, layerNum: 1, printLayerObjIds: layerIds7 },
          { printType: PrintLayerType.printLayerType3, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr3, layerNum: 1, printLayerObjIds: layerIds7 },
        ];
        break;
    }
    return model;
  }

  // 递归函数以过滤不包含在printLayerObjIds中的对象
  filterObjects(objects: any[], printLayerData: PrintLayerData): any[] {
    return objects.reduce((acc: any[], obj: any, index: number) => {
      if (obj.id.includes(WorkspaceID.WorkspaceCavas)) { // || (obj.type === 'rect' && index === 1)
        acc.push(obj);
      } else if (!obj.layerId || printLayerData.printLayerObjIds.includes(obj.layerId)) {
        // 如果对象没有layerId或者layerId在printLayerObjIds中，则保留
        acc.push(obj);
      } else if (obj.type === 'group' && obj.getObjects()) {
        // 对group类型的对象递归过滤
        obj.objects = this.filterObjects(obj.getObjects(), printLayerData);
        acc.push(obj);
      }
      return acc;
    }, []);
  };

  getPrintPicWhiteInk(projectModel: ProjectModel, is_standard_product: number, printLayerData: PrintLayerData, printLayerModel: PrintLayerModel, canvasSource: any): Promise<PrintLayerData> {
    if (!canvasSource) return Promise.reject('Canvas editor not available.');
    const canvas: fabric.Canvas = canvasSource;
    if (!canvas) return Promise.reject('Canvas not available.');

    var dataObjects = canvas.getObjects();
    // 过滤掉不在printLayerObjIds中的对象
    dataObjects = this.filterObjects(dataObjects, printLayerData);
    return this.getPrintImgRet(projectModel, printLayerData, canvas, dataObjects, true, printLayerModel).then((dataUrl: string) => {
      // 创建一个新的PrintLayerData对象，包含dataUrl
      const updatedPrintLayerData: PrintLayerData = {
        ...printLayerData, // 复制原有的PrintLayerData属性
        dataUrl: dataUrl   // 设置新的dataUrl
      };
      return updatedPrintLayerData; // 返回更新后的PrintLayerData对象
    });
  }

  getPrintImgRet(projectModel: ProjectModel, printLayerData: PrintLayerData, canvas: fabric.Canvas, dataObjects: any[], isSingleChannel: boolean, printLayerModel: PrintLayerModel): Promise<string> {
    let textureEffect2dManager: TextureEffect2dManager = TextureEffect2dManager.getInstance();
    return new Promise((resolve, reject) => {
      const workspace = canvas.getObjects().find((item) => (item as any).id === (WorkspaceID.WorkspaceCavas));
      var bgWidth = workspace?.width;

      var retSize = StringUtil.scaleToWidth(printLayerModel.format_size_w!, printLayerModel.format_size_h!, printLayerModel.imgQuality!);
      var scale = retSize.width / bgWidth!;
      var scaledWidth = retSize.width;
      var scaledHeight = retSize.height;
      // Sticker间距2px
      var distanceSticker = 2;
      var scaleSticker = (retSize.width + distanceSticker) / bgWidth!;
      var sub_category = projectModel.canvases[projectModel.canvasesIndex].sub_category
      var isStickerPrint = sub_category === CanvasSubCategory.CANVAS_CATEGORY_ACCESSORY_STICKER_S || sub_category === CanvasSubCategory.CANVAS_CATEGORY_ACCESSORY_STICKER_M;

      if (!printLayerModel.format_size_w_non) {
        const width = projectModel.canvases[projectModel.canvasesIndex].base_map_width;
        const height = projectModel.canvases[projectModel.canvasesIndex].base_map_height;
        var retSizeMM = StringUtil.pixelsToMM(width, height, PrintQuality.printQuality1);
        printLayerModel.format_size_w_non = retSizeMM.widthMM;
        printLayerModel.format_size_h_non = retSizeMM.heightMM;
      }

      const baseLayer = workspace;

      const tempCanvas = new fabric.StaticCanvas(null, {
        width: scaledWidth,
        height: scaledHeight
      });
      // 创建一个 promise 数组来跟踪所有克隆操作
      async function cloneObjectsSequentially() {
        for (const obj of dataObjects) {
          if (!(obj as any).id?.includes(WorkspaceID.WorkspaceCavas)) {
            const objProps = obj.toJSON(EDITOR_JSON_KEY);
            await new Promise((resolveClone) => {
              obj.clone((clonedObj: fabric.Object) => {
                if ((objProps as any).clipPath) {
                  delete (objProps as any).clipPath;
                }
                var scaleRet = isStickerPrint && printLayerData.printType == PrintLayerType.printLayerType3 ? scaleSticker : scale;
                clonedObj.set({
                  ...objProps,
                  left: clonedObj.left! * scaleRet,
                  top: clonedObj.top! * scaleRet,
                  scaleX: clonedObj.scaleX! * scaleRet,
                  scaleY: clonedObj.scaleY! * scaleRet
                });
                tempCanvas.add(clonedObj);
                resolveClone(clonedObj); // 克隆完成后解决 promise
              });
            });
          }
        }
      }
      // 等待所有克隆操作完成
      cloneObjectsSequentially().then(() => {
        filterTextureElements(canvas, tempCanvas);
        const finalCanvas = new fabric.StaticCanvas(null, {
          width: scaledWidth,
          height: scaledHeight
        });

        baseLayer?.clone((clonedBaseLayer: fabric.Object) => {
          clonedBaseLayer.set({
            left: 0,
            top: 0,
            scaleX: scale,
            scaleY: scale
          });
          finalCanvas.add(clonedBaseLayer);
          finalCanvas.renderAll();

          const tempDataURL = tempCanvas.toDataURL({ format: 'png' });

          // 使用 fromURL 方法创建一个 fabric.Image 对象
          fabric.Image.fromURL(tempDataURL, (img) => {
            // 设置图片的宽高
            img.set({
              left: 0,
              top: 0,
              scaleX: 1,
              scaleY: 1,
              globalCompositeOperation: 'source-in'
            });
            finalCanvas.add(img);
            finalCanvas.renderAll();
            setTimeout(async () => {
              const dataURL = finalCanvas.toDataURL({
                format: 'png',
              });
              if (isSingleChannel) {
                const ret = await textureEffect2dManager.base64ToGrayscale(dataURL);
                resolve(ret.grayscaleImage);
                // let worker = new IMagickWorker();
                // worker.onmessage = function (e: { data: any; }) {
                //   try {
                //     const base64 = e.data;
                //     resolve(base64);
                //   } catch (error) {
                //     reject("image magick error");
                //   }
                //   worker.terminate();
                //   worker = null;
                // };
                // worker.postMessage({
                //   action: ACTION_MAGICK.ACTION_TYPE_FORMAT,
                //   data: {
                //     dataUrl: dataURL,
                //     params: {}
                //   }
                // });
              } else {
                //   console.log('====getPrintImgRet====,', dataURL)
                resolve(dataURL);
              }
            }, 0);
          });
        });
      });
    });
  }

  async getPrintPicColorInk(projectModel: ProjectModel, is_standard_product: number, printLayerData: PrintLayerData, printLayerModel: PrintLayerModel, canvasSource: any, editor?: Editor): Promise<PrintLayerData> {
    if (!canvasSource) return Promise.reject('Canvas editor not available.');
    const canvas: fabric.Canvas = canvasSource;
    if (!canvas) return Promise.reject('Canvas not available.');

    var dataObjects = canvas.getObjects();
    // 过滤掉不在printLayerObjIds中的对象
    dataObjects = this.filterObjects(dataObjects, printLayerData);
    if (printLayerModel.printModel == PrintModel.printModel8 && editor) {
      var texture3dGrayPrint: Texture3dGrayPrint = await TextureEffect2dManager.getInstance().getCanvasGrayImgOfPrint(editor, projectModel);
      printLayerData.grayCmykUrl = texture3dGrayPrint.mergeGrayImg;
      printLayerData.grayGlosskUrl = texture3dGrayPrint.glossGrayImg;
      printLayerData.thickness = texture3dGrayPrint.thickness;
      if (printLayerData.grayCmykUrl) {
        printLayerData.grayCmykFileStr = PrintLayerFileStr.printLayerTypeStr4;
      }
      if (printLayerData.grayGlosskUrl) {
        printLayerData.grayGlossFileStr = PrintLayerFileStr.printLayerTypeStr5;
      }
    }
    return this.getPrintImgRet(projectModel, printLayerData, canvas, dataObjects, false, printLayerModel).then((dataUrl: string) => {
      const updatedPrintLayerData: PrintLayerData = {
        ...printLayerData,
        dataUrl: dataUrl
      };
      return updatedPrintLayerData; // 返回更新后的PrintLayerData对象
    });
  }

  getPrintPicVarnishInk(projectModel: ProjectModel, is_standard_product: number, printLayerData: PrintLayerData, printLayerModel: PrintLayerModel, canvasSource: any): Promise<PrintLayerData> {
    return this.getPrintPicWhiteInk(projectModel, is_standard_product, printLayerData, printLayerModel, canvasSource);
  }

  private extractLayerIds(objects: any[]): string[] {
    let layerIds: string[] = [];
    objects.forEach((obj) => {
      if (obj.layerId) {
        layerIds.push(obj.layerId);
      }
      if (obj.type === 'group' && obj.objects) {
        layerIds = layerIds.concat(this.extractLayerIds(obj.objects));
      }
    });
    return layerIds;
  }

}