// 依赖
import React, { useState, useEffect } from 'react';
// 外部变量
import { PrintModel } from '../PrintLayer/model/PrintLayerModel'
// 样式
import * as classes from './PrintSetting.module.scss';
import Form, { Field } from 'rc-field-form';

// 父组件参数
interface ObjViewerProps {
  defaultModeSelectValue: number,
  callback: (formName: string, value: any) => void;
}


const PrintSetting: React.FC<ObjViewerProps> = ({ defaultModeSelectValue = 0, callback }) => {

  // 表单默认值
  const [modeSelectValue, setModeSelectValue] = useState(0);

  // quality下拉选项
  const qualityOptions = [
    { str: 'model 1', value: PrintModel.printModel1 },
    { str: 'model 2', value: PrintModel.printModel2 },
  ];

  // mode下拉选项
  const modeOptions = [
    { str: 'model 1', value: PrintModel.printModel1 },
    { str: 'model 2', value: PrintModel.printModel2 },
  ];

  // 表单选值
  const onChangeFiled = (formName: string, value: string) => {
    console.log(formName, value)
    callback(formName, value)
  }

  // 初始化赋值
  useEffect(() => {
    setModeSelectValue(defaultModeSelectValue);
  }, [defaultModeSelectValue])

  return <div className={classes.printSettingComponent}>
    <div className={classes.componentTitle}>Print Setting</div>
    <form>
      <div className={classes.fieldItem}>
        <label className={classes.fieldLabel}>Quality</label>
        <select name="Quality" defaultValue={modeSelectValue} onChange={(event) => onChangeFiled('imgQuality', event.target.value)}>
          {qualityOptions.map((item) => <option value={item.value}>{item.str}</option>)}
        </select>
      </div>
      <div className={classes.fieldItem}>
        <label className={classes.fieldLabel}>Mode</label>
        <select name="Mode" onChange={(event) => onChangeFiled('printModel', event.target.value)}>
          {modeOptions.map((item) => <option value={item.value}>{item.str}</option>)}
        </select>
      </div>
    </form>
  </div>
}

export default PrintSetting;