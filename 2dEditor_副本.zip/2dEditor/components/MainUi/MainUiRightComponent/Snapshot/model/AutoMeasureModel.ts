export type AutoMeasureModel = {
    sn: string
    result: string
    progress: number
    rimCircumference: number // 杯口圆周长 mm
    baseCircumference: number // 杯底圆周长 mm
    cupHeight: number         // 杯子高度 mm
    handleWidth: number       // 杯柄宽度 mm
    isWithHandle: boolean     // 是否有柄
    horizontalProhibited: number // 水平禁止线
    verticalRecommandedBlanklen: number // 垂直推荐空白长度

}