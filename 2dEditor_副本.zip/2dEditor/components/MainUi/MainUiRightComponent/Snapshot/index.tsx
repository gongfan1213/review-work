// 依赖
import React, { useEffect, useState, useRef } from 'react';
import { sendCommandToPc, receivePCMessageOnWeb } from 'src/common/jsbridge/util';
import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';
import { Switch } from '@mui/material';
import { Button } from 'src/components/MakeUI';
import { useDispatch } from 'react-redux';
import { imgStr } from './test';
import { mastImgStr } from './test1';
import { Modal } from 'src/components/MakeUI';
import {
  CanvasCategory,
  CanvasParams,
  CanvasSubCategory,
  EventNameCons,
  WorkspaceID,
} from 'src/templates/2dEditor/cons/2dEditorCons';
import { Device } from './type';
import { openToast } from 'src/state/reducers/toast';
import { BaseMapChangeManager } from '../../../BaseMapChange/logic/BaseMapChangeManager';
import { CustomPcAction } from 'src/templates/2dEditor/cons/2dEditorCons';
import ErroStateDialog from './erroStateDialog';

// hooks
import { useProjectData, useCanvasEditor, useEvent } from 'src/templates/2dEditor/hooks/context';

//图片
import camera from 'src/assets/editor/img_camera.png';
import ic_down from 'src/assets/svg/ic_down.svg';
import appbar_close_icon from 'src/assets/img/appbar_close_icon.png';
import canvas_icon from 'src/assets/img/canvas.png';
import snapshot_icon from 'src/assets/img/snapshot.png';
import ic_auto_measure from 'src/assets/svg/ic_auto_measure.svg';

// 样式
import * as classs from './index.module.scss';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss';

import { isPc } from 'src/common/jsbridge';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { CanvasesResInfo, RotaryParams } from '../../../SelectDialog/model/ProjectModel';
import { px2mm } from 'src/templates/2dEditor/core/plugin/ImagePlugin/utils/image';
import StringUtil from 'src/common/utils/stringUtil';
import { SelectImgToPngData } from '../../../BaseMapChange/model/OutLineData';
import { AutoMeasureModel } from './model/AutoMeasureModel';
import CustomCheckbox from 'src/components/CustomCheckbox';
import Dropdown from 'src/templates/2dEditor/common/widget/Dropdown/Dropdown';
import ProjectManager from 'src/templates/2dEditor/utils/ProjectManager';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';

const device = [
  { device_name: 'aaa', sn: '11', state: 0, deviceImg: camera },
  { device_name: 'bbb', sn: '22', state: 1, deviceImg: camera },
  { device_name: 'ccc', sn: '33', state: 2, deviceImg: 'base64' },
  { device_name: 'ddd', sn: '44', state: 8, deviceImg: 'base64' },
];

const device1 = [
  { device_name: 'aaa', sn: '11', state: 0, deviceImg: camera },
  { device_name: 'bbb', sn: '22', state: 1, deviceImg: camera },
  { device_name: 'ccc', sn: '33', state: 0, deviceImg: 'base64' },
  { device_name: 'ddd', sn: '44', state: 8, deviceImg: 'base64' },
];

let outLineData = [1876, 1281, 1335, 711];

let outLineData1 = [2815, 1919, 374, 121];

const imgBoxSize = { width: 280, height: 220 };

const Snapshot: React.FC<{
  setSnapshotData: (snapshotData: { rectIndex: number; isCompleted: boolean }) => void;
  setDeviceData: (deviceData: { sn: string; deviceState: number }) => void;
}> = ({ setSnapshotData, setDeviceData }) => {
  const dispatch = useDispatch();
  const [base64str, setBase64str] = useState<string>('');
  const [deviceInfo, setDeviceInfo] = useState<any>([]);
  const [photoInfo, setPhotoInfo] = useState<any>();
  const [selectedDevice, setSelectedDevice] = useState<any>({ sn: '', device_name: '', state: -1 });
  const [rectIndex, setRectIndex] = useState<number>(-1);
  const [imgSize, setImgSize] = useState<any>({ width: 0, height: 0, scale: 1 });
  const [showDropdown, setShowDropdown] = useState<boolean>(false);
  const [showBg, setShowBg] = useState<boolean>(true);
  const [isShowBgButton, setIsShowBgButton] = useState<boolean>(false);
  const [showLoading, setShowLoading] = useState<boolean>(false);
  const [showErroState, setShowErroState] = useState<boolean>(false);
  const [outLineswitch, setOutLineswitch] = useState<boolean>(false);
  const [erroDescribe, setErroDescribe] = useState<string>('');

  const canvasEditor = useCanvasEditor();
  const projectInfo = useProjectData();
  const outLineCanvas = useRef(null);
  const outlinePaths = useRef([]);
  const baseMapChangeManager = BaseMapChangeManager.getInstance();
  const [canvasWidth, setCanvasWidth] = useState(0);
  const [canvasHeight, setCanvasHeight] = useState(0);
  const [canvasBottomD, setCanvasBottomD] = useState(0);
  const [canvasUpperD, setCanvasUpperD] = useState(0);
  const [autoMeasureModel, setAutoMeasureModel] = useState<AutoMeasureModel | null>();

  const { getTranslation } = useCustomTranslation();
  const [hasHandle, setHasHandle] = useState(false);
  const [isDisableCyEditor, setDisableCyEditor] = useState(false);
  const categoryOptions = [
    { str: getTranslation(TranslationsKeys.string_canvas_flat), value: CanvasCategory.CANVAS_CATEGORY_PHONECASE },
    {
      str: getTranslation(TranslationsKeys.string_canvas_cylindrical),
      value: CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL,
    },
  ];

  const deviceStateCode = {
    '0': getTranslation(TranslationsKeys.SNAPSHOT_STATE_IDLE),
    '1': getTranslation(TranslationsKeys.SNAPSHOT_STATE_OffLINE),
    '2': getTranslation(TranslationsKeys.SNAPSHOT_STATE_PRINTING),
    '3': getTranslation(TranslationsKeys.SNAPSHOT_STATE_BUSY),
    '4': getTranslation(TranslationsKeys.SNAPSHOT_STATE_BUSY),
    '5': getTranslation(TranslationsKeys.SNAPSHOT_STATE_BUSY),
    '6': getTranslation(TranslationsKeys.SNAPSHOT_STATE_BUSY),
    '7': getTranslation(TranslationsKeys.SNAPSHOT_STATE_BUSY),
    '8': getTranslation(TranslationsKeys.SNAPSHOT_STATE_ONLINE),
    '-1': getTranslation(TranslationsKeys.SNAPSHOT_STATE_ERROR),
  };

  const snapshotStateCode = {
    '-1': getTranslation(TranslationsKeys.SNAPSHOT_STATE_DEVICE_ERROR),
    '-2': getTranslation(TranslationsKeys.SNAPSHOT_STATE_DEVICE_ERROR),
    '-3': getTranslation(TranslationsKeys.SNAPSHOT_STATE_MEASURE_FAILED),
    '-4': getTranslation(TranslationsKeys.SNAPSHOT_STATE_DEVICE_ERROR),
    '-5': getTranslation(TranslationsKeys.SNAPSHOT_STATE_NO_CALIBRATED),
    '-6': getTranslation(TranslationsKeys.SNAPSHOT_STATE_S_FAILED),
    '-7': getTranslation(TranslationsKeys.SNAPSHOT_STATE_S_FAILED),
  };

  const snapshotErrorCode = {
    1: getTranslation(TranslationsKeys.SNAPSHOT_STATE_FAILED),
    6: getTranslation(TranslationsKeys.SNAPSHOT_STATE_BUSY),
    7: getTranslation(TranslationsKeys.SNAPSHOT_STATE_NOBOARD),
  };

  const autoMeaSureErrorCode = {
    '-1': getTranslation(TranslationsKeys.SNAPSHOT_STATE_FAILED),
    '1': getTranslation(TranslationsKeys.SNAPSHOT_STATE_BUSY),
  };

  useEffect(() => {
    //发送获取设备指令
    sendCommandToPc(CustomPcAction.GetDeviceInfoAction);
    receivePCMessageOnWeb(async (action: string, data: any) => {
      switch (action) {
        case CustomPcAction.GetDeviceInfoAction:
          //接收设备信息
          handleGetDeviceInfo(data);
          break;
        case CustomPcAction.SyncDeviceInfoAction:
          //同步设备状态
          handleSyncDeviceInfo(data);
          break;
        case CustomPcAction.TakePhotoProgressAction:
          //接收拍照状态
          handleTakePhotoProgress(data);
          break;
        case CustomPcAction.TakePhotoAction:
          //接收拍照指令结果，需要处理异常状态（失败/忙碌）
          hanleTakePhoto(data);
          break;
        case CustomPcAction.Command_Auto_Measure:
          //接收拍照指令结果，需要处理异常状态（失败/忙碌）
          hanleAutoMeasure(data);
          break;
        default:
      }
    });

    const currentObjects = canvasEditor?.canvas
      .getObjects()
      .filter((item: any) => item.id.includes(WorkspaceID.WorkspaceBGCavas));
    if (currentObjects && currentObjects[0]) {
      setShowBg(currentObjects[0].visible);
    }
    eventBus.on(EventNameCons.EventCanvasSizeDisable, unDisableCyEditor);
    return () => {
      eventBus.off(EventNameCons.EventCanvasSizeDisable, unDisableCyEditor);
    };
  }, []);

  useEffect(() => {
    if (projectInfo) {
      var canvas = projectInfo.canvases[projectInfo.canvasesIndex];
      if (canvas.category == CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL) {
        var rotary_params: RotaryParams = JSON.parse(canvas.print_param!).rotary_params;

        console.log('======rotary_params====', rotary_params);
        // if (!rotary_params) {
        //   rotary_params = getRotaryParams(canvas.base_map_width, canvas.base_map_height);
        // }
        console.log('======projectSelectSize====', projectInfo, rotary_params);
        setCanvasHeight(rotary_params.cupHeight!);
        setCanvasUpperD(rotary_params.upperD!);
        setCanvasBottomD(rotary_params.bottomD!);
        setHasHandle(rotary_params.hasHandle ? rotary_params.hasHandle : false);
      } else {
        setCanvasWidth(JSON.parse(canvas.print_param).format_size_w);
        setCanvasHeight(JSON.parse(canvas.print_param).format_size_h);
      }
      setAutoMeasureModel(null);
    }
  }, [projectInfo]);

  function hanleAutoMeasure(data: any) {
    if (data.result == -1) {
      dispatch(
        openToast({
          message: autoMeaSureErrorCode[data.result.toString() as keyof typeof autoMeaSureErrorCode],
          severity: 'warning',
        }),
      );
      return;
    }
    var ret: AutoMeasureModel = {
      ...data,
    };
    setAutoMeasureModel(ret);
    // if (ret.progress == 100) {
    //   //更新测量数据？
    //   setCanvasHeight(ret.cupHeight);
    //   setCanvasUpperD(ret.rimCircumference / Math.PI);
    //   setCanvasBottomD(ret.baseCircumference / Math.PI);
    // }
  }

  const unDisableCyEditor = () => {
    setDisableCyEditor(false);
  };

  function hanleTakePhoto(data: any) {
    //todo,目前忙碌是按停止失败来处理
    if (data.ret !== 0) {
      if (data.action === 0) {
        //埋点, 拍照失败
        StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.canvas_snapshot, 0);
      }
      dispatch(
        openToast({
          message: snapshotErrorCode[data.ret],
          severity: 'warning',
        }),
      );
    } else if (data.action === 0) {
      setPhotoInfo(null);
      setBase64str('');
      setSnapshotData({
        rectIndex,
        isCompleted: false,
      });
    } else if (data.action === 1) {
      //埋点,取消拍照
      StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.canvas_snapshot_cannel);
      setShowLoading(false);
      setSnapshotData({
        rectIndex,
        isCompleted: true,
      });
    }
  }

  function handleTakePhotoProgress(data: any) {
    if (!data) {
      return;
    }
    setShowLoading(false);
    setSnapshotData({
      rectIndex,
      isCompleted: true,
    });
    if (data.value === 0) {
      //埋点，拍照成功
      StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.canvas_snapshot, 1);
      setPhotoInfo(data);
      // if(data.contour && data.contour[0]){
      //   setRectIndex(0)
      // }
      //设置图片宽高
      setImageSize(data.plate_image, () => {
        setBase64str(data.plate_image);
      });
    } else if (data.value == 1) {
      setPhotoInfo(data);
      setShowLoading(true);
      setSnapshotData({
        rectIndex,
        isCompleted: false,
      });
    } else {
      setShowErroState(true);
      setErroDescribe(snapshotStateCode[data.value + ''] || '');
    }
  }

  function handleSyncDeviceInfo(data: any) {
    if (data && data.device && data.device.length > 0) {
      setDeviceInfo(data.device);
      updateDevice(data.device, data.select);
    } else {
      setDeviceInfo([]);
      setSelectedDevice({ sn: '', device_name: '', state: -1 });
      setDeviceData({
        sn: '',
        deviceState: -1,
      });
    }
  }

  function handleGetDeviceInfo(data: any) {
    if (data && data.device && data.device.length > 0) {
      setDeviceInfo(data.device);
      updateDevice(data.device, data.select);
    } else {
      setDeviceInfo([]);
      setSelectedDevice({ sn: '', device_name: '', state: -1 });
      setDeviceData({
        sn: '',
        deviceState: -1,
      });
    }
  }

  function updateDevice(device: Device[], select?: string) {
    const sn = select || selectedDevice.sn || device[0].sn;
    device.forEach((dev: Device) => {
      if (dev.sn === sn) {
        setSelectedDevice({ sn: dev.sn, device_name: dev.device_name, state: dev.state });
        setDeviceData({
          sn: dev.sn,
          deviceState: dev.state,
        });
      }
    });
  }

  function clearCanvas() {
    setRectIndex(-1);
    const canvas = outLineCanvas.current;
    if (!canvas) {
      return;
    }
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, imgSize.width, imgSize.height);
  }

  async function drwaOutLine(outLineData: any, activeIndex: number) {
    //根据矩阵和研磨图，获取到轮廓列表
    //绘制轮廓
    const canvas = outLineCanvas.current;

    if (!canvas) {
      return;
    }
    canvas.width = imgSize.width;
    canvas.height = imgSize.height;

    outlinePaths.current.forEach((outlinePath, i) => {
      const orginX = outLineData[i].aabb[0];
      const orginY = outLineData[i].aabb[1];
      const ctx = canvas.getContext('2d');
      if (activeIndex === i) {
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 30;
      } else {
        ctx.strokeStyle = '#ffffff';
        ctx.setLineDash([5, 10]);
        ctx.lineWidth = 20;
      }

      outlinePath.forEach((path) => {
        ctx.beginPath();
        for (let i = 0; i < path.length; i++) {
          let item = path[i];
          if (i === 0) {
            ctx?.moveTo(item[0] + orginX, item[1] + orginY);
          } else {
            ctx?.lineTo(item[0] + orginX, item[1] + orginY);
          }
        }
        ctx.closePath();
        ctx.stroke();
      });
    });
  }

  function handleClick(e) {
    const canvas = outLineCanvas.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const matrixs = photoInfo.contour;

    matrixs.forEach((item: any, i) => {
      const matrix = item.aabb;
      if (
        x >= matrix[0] * imgSize.scale &&
        x <= (matrix[0] + matrix[2]) * imgSize.scale &&
        y >= matrix[1] * imgSize.scale &&
        y <= (matrix[1] + matrix[3]) * imgSize.scale
      ) {
        setRectIndex(i);
        drwaOutLine(photoInfo.contour, i);
        return;
      }
    });
  }

  function setImageSize(base64str: string, callback?: Function) {
    let img = new Image();
    img.src = base64str;
    img.onload = function () {
      let scale;
      if (img.width / img.height > imgBoxSize.width / imgBoxSize.height) {
        scale = imgBoxSize.width / img.width;
      } else {
        scale = imgBoxSize.height / img.height;
      }
      setImgSize({ width: img.width, height: img.height, scale: scale });

      callback && callback(img.width, img.height);
      img = null;
    };
  }

  async function getCutImg() {
    if (photoInfo.contour && photoInfo.contour[rectIndex]) {
      //根据当前选中轮廓的矩形、研磨图，得到裁剪后的图片
      const { newImgBase64, newBgImgBase64 } = await baseMapChangeManager.getCutBaseImg(
        photoInfo.plate_image,
        photoInfo.mask_image,
        photoInfo.contour[rectIndex],
      );
      const size = {
        width: photoInfo.contour[rectIndex].aabb[2],
        height: photoInfo.contour[rectIndex].aabb[3],
      };
      const sizeMM = {
        width: ((photoInfo.plate_print_width || 0) / imgSize.width) * photoInfo.contour[rectIndex].aabb[2],
        height: ((photoInfo.plate_print_height || 0) / imgSize.height) * photoInfo.contour[rectIndex].aabb[3],
      };
      const selectImgToPngData = { size, sizeMM, newImgBase64: newImgBase64, newBgImgBase64: newBgImgBase64 };
      baseMapChangeManager.replaceImgToCanvas(selectImgToPngData).then((params) => {
        setSnapshotData({
          rectIndex,
          isCompleted: true,
        });
        setIsShowBgButton(true);
        setShowBg(true);
      });
    } else {
      //无轮廓的情况, 增加一张白色底图
      const canvas = document.createElement('canvas');
      canvas.width = imgSize.width;
      canvas.height = imgSize.height;
      var ctx = canvas.getContext('2d');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, imgSize.width, imgSize.height);
      const base64 = canvas.toDataURL('image/png');
      const size = {
        width: imgSize.width,
        height: imgSize.height,
      };
      const sizeMM = {
        width: photoInfo.plate_print_width,
        height: photoInfo.plate_print_height,
      };
      const selectImgToPngData = { size, sizeMM, newImgBase64: base64, newBgImgBase64: base64str };
      baseMapChangeManager.replaceImgToCanvas(selectImgToPngData).then(() => {
        setSnapshotData({
          rectIndex,
          isCompleted: true,
        });
      });
    }
  }

  function getThumbnailStyle() {
    return {
      width: imgSize.width * imgSize.scale + 'px',
      height: imgSize.height * imgSize.scale + 'px',
      marginLeft: '-' + (imgSize.width * imgSize.scale) / 2 + 'px',
      marginTop: '-' + (imgSize.height * imgSize.scale) / 2 + 'px',
    };
  }

  function stateColorStyle(data: Device) {
    let style;
    if (!data.sn) {
      style = { background: '#a1a1a1' };
    } else if (data.state === 1) {
      style = { background: '#a1a1a1' };
    } else {
      style = { background: '#33BF5A' };
    }
    return style;
  }
  var sizeBanEdit =
    projectInfo?.canvases[projectInfo.canvasesIndex].category === CanvasCategory.CANVAS_CATEGORY_PHONECASE &&
    projectInfo?.canvases[projectInfo.canvasesIndex].sub_category !==
      CanvasSubCategory.CANVAS_CATEGORY_PHONECASE_NORMAL;
  var isCylindrical =
    projectInfo?.canvases[projectInfo.canvasesIndex].category === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL;

  return (
    <div className={classs.snapshotWrap}>
      {isPc() && (
        <div className={classs.selectedDeviceBox}>
          <img className={classs.cameraImg} src={camera} />
          <div className={classs.deviceInput}>
            <span className={classs.deviceName} style={!selectedDevice.sn ? { color: '#a1a1a1' } : {}}>
              {selectedDevice.device_name || getTranslation(TranslationsKeys.SNAPSHOT_DEVNAME)}
            </span>
            {deviceInfo.length > 0 ? (
              <img
                src={ic_down}
                onClick={(event) => {
                  setShowDropdown(!showDropdown);
                }}
              />
            ) : null}
            <div className={classs.deviceState}>
              <span className={classs.stateColor} style={stateColorStyle(selectedDevice)}></span>
              <span className={classs.stateText}>
                {selectedDevice.sn ? (selectedDevice.state === 1 ? 'Offline' : 'Online') : 'Disconnected'}
              </span>
            </div>
          </div>
          <div className={classs.dropdownBox} style={{ display: showDropdown ? 'block' : 'none' }}>
            {deviceInfo.map((item) => (
              <div
                className={classs.dropdownItemFree}
                key={item.sn}
                onClick={() => {
                  setSelectedDevice({ sn: item.sn, device_name: item.device_name, state: item.state });
                  setDeviceData({
                    sn: item.sn,
                    deviceState: item.state,
                  });
                  setShowDropdown(false);
                }}
              >
                <img className={classs.cameraImg} src={camera} />
                <div className={classs.deviceInput}>
                  <span className={classs.deviceName}>{item.device_name}</span>
                  <div className={classs.deviceState}>
                    <span className={classs.stateColor} style={stateColorStyle(item)}></span>
                    <span className={classs.stateText}>{item.state === 1 ? 'Offline' : 'Online'}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className={classs.canvasSection}>
        <div className={classs.canvasTitles}>
          <span className={`${BaseStyles.txt14} ${classs.canvasTitle}`}>
            {getTranslation(TranslationsKeys.STR_COMMON_CANVAS)}
          </span>
          <span
            className={`${BaseStyles.txt14} ${classs.canvasTitle} ${classs.canvasTitleRight}`}
            onClick={() => {
              eventBus.emit(EventNameCons.EventShowCanvasDialog);
            }}
          >
            {getTranslation(TranslationsKeys.string_common_presets)}
          </span>
        </div>

        <div className={classs.canvasCategory}>
          <Dropdown
            values={categoryOptions}
            defaultSelectValue={
              projectInfo?.project_info?.category === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL
                ? CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL
                : CanvasCategory.CANVAS_CATEGORY_PHONECASE
            }
            callback={handleCategorySelection}
          />
        </div>

        {isCylindrical ? (
          <div>
            <div className={classs.canvasInputs}>
              <div className={classs.canvasInput}>
                <label className={BaseStyles.txt12}>{getTranslation(TranslationsKeys.STR_HEIGHT)}</label>
                <input
                  className={BaseStyles.txt12_light}
                  value={canvasHeight}
                  readOnly={sizeBanEdit}
                  onChange={(e) => setCanvasHeight(getEditChangeTxt(e.target.value))}
                  onBlur={() => changeSize(canvasUpperD, canvasBottomD, canvasHeight)}
                  step={1}
                  pattern="^[1-9]\d*$"
                  disabled={isDisableCyEditor}
                />
                <label className={BaseStyles.txt12_light}>mm</label>
              </div>
              <div className={classs.canvasInput}>
                <label className={BaseStyles.txt12}>{getTranslation(TranslationsKeys.string_canvas_bottomD)}</label>
                <input
                  className={BaseStyles.txt12_light}
                  value={canvasBottomD}
                  readOnly={sizeBanEdit}
                  onChange={(e) => setCanvasBottomD(getEditChangeTxt(e.target.value))}
                  onBlur={() => changeSize(canvasUpperD, canvasBottomD, canvasHeight)}
                  step={1}
                  pattern="^[1-9]\d*$"
                  disabled={isDisableCyEditor}
                />
                <label className={BaseStyles.txt12_light}>mm</label>
              </div>
            </div>
            <div className={classs.canvasInputs}>
              <div className={classs.canvasInput}>
                <label className={BaseStyles.txt12}>{getTranslation(TranslationsKeys.string_canvas_upperD)}</label>
                <input
                  className={BaseStyles.txt12_light}
                  value={canvasUpperD}
                  readOnly={sizeBanEdit}
                  onChange={(e) => setCanvasUpperD(getEditChangeTxt(e.target.value))}
                  onBlur={() => changeSize(canvasUpperD, canvasBottomD, canvasHeight)}
                  step={1}
                  pattern="^[1-9]\d*$"
                  disabled={isDisableCyEditor}
                />
                <label className={BaseStyles.txt12_light}>mm</label>
              </div>
              <div className={classs.canvasInputSpace}></div>
            </div>
            <div className={classs.itemSelectLayout}>
              <CustomCheckbox
                checked={hasHandle}
                onChange={(event: any) => {
                  setHasHandle(event.target.checked);
                  changeSize(canvasUpperD, canvasBottomD, canvasHeight, event.target.checked);
                }}
              />
              <label className={BaseStyles.txt12}>
                {getTranslation(TranslationsKeys.string_canvas_auto_measure_lab3)}
              </label>
            </div>
          </div>
        ) : (
          <div className={classs.canvasInputs}>
            <div className={classs.canvasInput}>
              <label className={BaseStyles.txt12}>{getTranslation(TranslationsKeys.STR_WIDTH)}</label>
              <input
                className={BaseStyles.txt12_light}
                value={canvasWidth}
                readOnly={sizeBanEdit}
                onChange={(e) => setCanvasWidth(getEditChangeTxt(e.target.value))}
                onBlur={() => changeSize(canvasWidth, canvasHeight)}
                step={1}
                pattern="^[1-9]\d*$"
              />
              <label className={BaseStyles.txt12_light}>mm</label>
            </div>
            <div className={classs.canvasInput}>
              <label className={BaseStyles.txt12}>{getTranslation(TranslationsKeys.STR_HEIGHT)}</label>
              <input
                className={BaseStyles.txt12_light}
                value={canvasHeight}
                readOnly={sizeBanEdit}
                onChange={(e) => setCanvasHeight(getEditChangeTxt(e.target.value))}
                onBlur={() => changeSize(canvasWidth, canvasHeight)}
                step={1}
                pattern="^[1-9]\d*$"
              />
              <label className={BaseStyles.txt12_light}>mm</label>
            </div>
          </div>
        )}
      </div>
      {isPc() && isCylindrical && (
        <Button
          className={classs.snapshotButton}
          disabled={!selectedDevice.sn}
          onClick={async () => {
            // 发送拍照指令
            if (selectedDevice.state !== 0 && selectedDevice.state !== 8) {
              dispatch(
                openToast({
                  message: deviceStateCode[selectedDevice.state + ''],
                  severity: 'warning',
                }),
              );
              return;
            }
            var canvas = projectInfo!.canvases[projectInfo!.canvasesIndex];
            var projectSelectSize: RotaryParams = JSON.parse(canvas.print_param!).rotary_params;
            sendCommandToPc(CustomPcAction.Command_Auto_Measure, {
              sn: selectedDevice.sn,
              value: 0,
              isWithHandle: hasHandle ? 1 : 0,
              CupType: projectSelectSize.baseMapWidth == projectSelectSize.baseMapHeight ? 0 : 1,
            });
          }}
        >
          <img src={ic_auto_measure} className={classs.snapshotIcon} />
          {getTranslation(TranslationsKeys.string_canvas_auto_measure)}
        </Button>
      )}

      {isPc() && !isCylindrical && (
        <Button
          className={classs.snapshotButton}
          disabled={!selectedDevice.sn}
          onClick={async () => {
            // 发送拍照指令
            if (selectedDevice.state !== 0 && selectedDevice.state !== 8) {
              dispatch(
                openToast({
                  message: getTranslation(TranslationsKeys.DEVICE_STATE_MESSAGE, { state: deviceStateCode[selectedDevice.state + ''] }),
                  severity: 'warning',
                }),
              );
              return;
            }
            sendCommandToPc(CustomPcAction.TakePhotoAction, {
              sn: selectedDevice.sn,
              state: 0,
            });
          }}
        >
          <img src={snapshot_icon} className={classs.snapshotIcon} />
          Snapshot
        </Button>
      )}

      {autoMeasureModel && autoMeasureModel.progress < 100 && (
        <div className={classs.loadingBox}>
          <div className={classs.loadingTip}>
            <span className={classs.tipTitle}>{getTranslation(TranslationsKeys.string_canvas_auto_measure_lab2)}</span>
            <span className={classs.tipBody}>{getTranslation(TranslationsKeys.string_canvas_auto_measure_lab1)}</span>
          </div>
          <Box className={classs.progressBox} sx={{ width: '80%' }}>
            <LinearProgress variant="determinate" value={autoMeasureModel.progress} />
            <img
              src={appbar_close_icon}
              className={classs.closeTabIcon}
              onClick={() => {
                sendCommandToPc(CustomPcAction.Command_Auto_Measure, {
                  sn: selectedDevice.sn,
                  value: 1,
                });
              }}
            />
          </Box>
        </div>
      )}

      {autoMeasureModel && autoMeasureModel.progress == 100 && (
        <div className={classs.resultCard}>
          <div className={`${BaseStyles.txt14} ${classs.resultCardTitle}`}>
            {getTranslation(TranslationsKeys.string_common_result)}
          </div>
          <div className={`${classs.resultCardItem}`}>
            <label className={BaseStyles.txt12}>{getTranslation(TranslationsKeys.string_canvas_upperD)}</label>
            <label className={BaseStyles.txt12_light}>
              {(autoMeasureModel?.rimCircumference || 0) / Math.PI + ' mm'}
            </label>
          </div>
          <div className={classs.resultCardItem}>
            <label className={BaseStyles.txt12}>{getTranslation(TranslationsKeys.string_canvas_bottomD)}</label>
            <label className={BaseStyles.txt12_light}>
              {(autoMeasureModel?.baseCircumference || 0) / Math.PI + ' mm'}
            </label>
          </div>
          <div className={classs.resultCardItem}>
            <label className={BaseStyles.txt12}>{getTranslation(TranslationsKeys.STR_HEIGHT)}</label>
            <label className={BaseStyles.txt12_light}>{autoMeasureModel?.cupHeight + ' mm'}</label>
          </div>
          <Button
            className={classs.replaceButton}
            onClick={async () => {
              if (autoMeasureModel) {
                setCanvasHeight(autoMeasureModel.cupHeight);
                setCanvasUpperD(autoMeasureModel.rimCircumference / Math.PI);
                setCanvasBottomD(autoMeasureModel.baseCircumference / Math.PI);
                changeSize(
                  autoMeasureModel.rimCircumference / Math.PI,
                  autoMeasureModel.baseCircumference / Math.PI,
                  autoMeasureModel.cupHeight,
                );
                setDisableCyEditor(true);
              }
            }}
          >
            {getTranslation(TranslationsKeys.string_canvas_replace)}
          </Button>
        </div>
      )}

      {/* <Button
        className={classs.snapshotButton}
        onClick={async () => {
          setDeviceInfo(device);
          updateDevice(device);
        }}
      >
        设备信息触发
      </Button>
      <Button
        className={classs.snapshotButton}
        onClick={async () => {
          setDeviceInfo(device1);
          updateDevice(device1, '33');
          // setShowErroState(true)
          // setErroDescribe(snapshotStateCode['-1'] || '')
        }}
      >
        设备信息触发1
      </Button>
      <Button
        className={classs.snapshotButton}
        onClick={async () => {
          setPhotoInfo({
            plate_image: imgStr,
            mask_image: mastImgStr,
            contour: [{ aabb: outLineData }, { aabb: outLineData1 }],
            value: 1,
            step: 1,
            plate_print_width: 130,
            plate_print_height: 70,
          });
          setShowLoading(true);
          setSnapshotData({
            rectIndex,
            isCompleted: false,
          });
          // setRectIndex(0)
          //设置图片宽高
          setImageSize(imgStr, () => {
            setBase64str(imgStr);
          });
        }}
      >
        拍照触发
      </Button> */}

      {photoInfo && base64str ? (
        <div>
          {/* <img src={appbar_close_icon} className={classs.closeTabIcon} onClick={() =>{

            }} /> */}
          <div className={classs.imgBox} style={{ width: imgBoxSize.width + 'px', height: imgBoxSize.height + 'px' }}>
            <img className={classs.baseImg} src={base64str} style={getThumbnailStyle()} />
            <canvas
              ref={outLineCanvas}
              onClick={handleClick}
              className={classs.canvas}
              id="outLineCanvas"
              style={getThumbnailStyle()}
            ></canvas>
          </div>
          <div className={classs.outLineswitchBox}>
            <span className={classs.label}>{getTranslation(TranslationsKeys.SNAPSHOT_CONTOUR)}</span>
            <Switch
              // defaultChecked={false}
              checked={outLineswitch}
              onChange={async (e) => {
                if (photoInfo.contour && photoInfo.contour.length > 0) {
                  if (e.target.checked) {
                    //绘制轮廓
                    outlinePaths.current = await baseMapChangeManager.getCutImgs(
                      photoInfo.mask_image,
                      photoInfo.contour,
                    );
                    setRectIndex(0);
                    drwaOutLine(photoInfo.contour, 0);
                  } else {
                    clearCanvas();
                  }
                  setOutLineswitch(e.target.checked);
                } else {
                  dispatch(
                    openToast({
                      message: getTranslation(TranslationsKeys.SNAPSHOT_NO_CONTOURDATA),
                      severity: 'warning',
                    }),
                  );
                }
              }}
            />
          </div>
          <Button
            className={classs.replaceButton}
            onClick={async () => {
              //替换底图，后续需要通过点选轮廓，获取具体的outLineData值
              //  await getCutImg(photoInfo ? photoInfo.mask_image : '', outLineData);
              await getCutImg();
            }}
          >
            {getTranslation(TranslationsKeys.string_canvas_replace)}
          </Button>
          {isShowBgButton && (
            <Button
              className={classs.showBgButton}
              onClick={() => {
                const currentObjects = canvasEditor?.canvas
                  .getObjects()
                  .filter((item: any) => item.id.includes(WorkspaceID.WorkspaceBGCavas));
                if (currentObjects && currentObjects[0]) {
                  currentObjects[0].set({
                    visible: !showBg,
                  });
                  canvasEditor?.canvas.renderAll();
                  setShowBg(!showBg);
                }
              }}
            >
              {showBg ? getTranslation(TranslationsKeys.SNAPSHOT_HIDE) : getTranslation(TranslationsKeys.SNAPSHOT_SHOW)}
            </Button>
          )}
        </div>
      ) : null}

      {showLoading && photoInfo ? (
        <div className={classs.loadingBox}>
          <div className={classs.loadingTip}>
            <span className={classs.tipTitle}>
              {photoInfo.step === 0
                ? getTranslation(TranslationsKeys.SNAPSHOT_H_MEASUREMENT)
                : getTranslation(TranslationsKeys.SNAPSHOT_PHOTOS)}
            </span>
            <span className={classs.tipBody}>
              {photoInfo.step === 0
                ? getTranslation(TranslationsKeys.SNAPSHOT_H_MEASUREMENT_TIPS)
                : getTranslation(TranslationsKeys.SNAPSHOT_PHOTOS_TIPS)}
            </span>
          </div>
          <Box className={classs.progressBox} sx={{ width: '80%' }}>
            <LinearProgress variant="determinate" value={photoInfo.process} />
            <img
              src={appbar_close_icon}
              className={classs.closeTabIcon}
              onClick={() => {
                // 发送停止拍照指令
                Modal.confirm({
                  content: getTranslation(TranslationsKeys.SNAPSHOT_ISSTOP),
                  okText: '',
                  cancelText: '',
                  closable: true,
                  closeIconColor: '#000',
                  onOk: async (callBack: () => void) => {
                    sendCommandToPc(CustomPcAction.TakePhotoAction, {
                      sn: selectedDevice.sn,
                      state: 1,
                    });
                    callBack();
                  },
                  onCancel: async (callBack: () => void) => {
                    callBack();
                  },
                });
              }}
            />
          </Box>
        </div>
      ) : (
        ''
      )}
      <ErroStateDialog
        visible={showErroState}
        errorData={{ title: selectedDevice.device_name, describe: erroDescribe }}
        onClose={() => {
          setShowErroState(false);
          setErroDescribe('');
        }}
      />
    </div>
  );

  function handleCategorySelection(item: { str: string; value: number }) {
    BaseMapChangeManager.getInstance().replaceCategory(
      item.value,
      item.value === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL
        ? CanvasSubCategory.CANVAS_CATEGORY_CYLINDRICAL_MUG
        : CanvasSubCategory.CANVAS_CATEGORY_PHONECASE_NORMAL,
    );
  }

  function getEditChangeTxt(value: string): number {
    // Remove leading zeros and ensure the value is at least 1
    const newValue = value.replace(/^0+/, '') || '1';
    console.log('=====newValue=====', newValue);
    return Number(newValue) <= 0 ? 1 : Number(newValue);
  }

  function changeSize(width: number, height: number, cupHeight?: number, hasHandleChange?: boolean) {
    console.log('=====changeSize=====', width, height);
    if (projectInfo) {
      let canvas: CanvasesResInfo = projectInfo.canvases[projectInfo.canvasesIndex];
      let print_param = JSON.parse(canvas.print_param);

      let hasChange = false;
      console.log('======hasHandleRet==start==', hasHandleChange, projectInfo);
      if (isCylindrical) {
        var projectSelectSize: RotaryParams = print_param.rotary_params;
        hasChange =
          projectSelectSize.upperD != width ||
          projectSelectSize.bottomD != height ||
          projectSelectSize.cupHeight != cupHeight ||
          (hasHandleChange != undefined && projectSelectSize.hasHandle != hasHandleChange);

        let hasHandleRet = hasHandleChange != undefined ? hasHandleChange : hasHandle;
        console.log('======hasHandleRet====', hasHandleRet);
        let circle: number = width >= height ? width : height;

        var upperD = width;
        var bottomD = height;
        projectSelectSize.hasHandle = hasHandleRet;
        projectSelectSize.upperD = upperD;
        projectSelectSize.bottomD = bottomD;
        projectSelectSize.cupHeight = cupHeight;

        print_param.rotary_params = projectSelectSize;

        width =
          Math.floor(Math.PI * circle) -
          (hasHandleRet && projectSelectSize.horizontalProhibited ? projectSelectSize.horizontalProhibited : 0);
        height = Number(cupHeight);
      } else {
        hasChange = print_param.format_size_w != width || print_param.format_size_h != height;
      }

      if (hasChange) {
        // 修改对象数据
        print_param.format_size_w = width;
        print_param.format_size_h = height;
        print_param.format_size_w_non = width;
        print_param.format_size_h_non = height;
        var retSize = StringUtil.scaleToWidth(width, height, 100);
        canvas.base_map_width = retSize.width;
        canvas.base_map_height = retSize.height;
        canvas.print_param = JSON.stringify(print_param);

        let data: SelectImgToPngData = {
          size: {
            width: canvas.base_map_width,
            height: canvas.base_map_height,
          },
          sizeMM: {
            width: print_param.format_size_w,
            height: print_param.format_size_h,
          },
          atOnceSave: true,
          newProjectModel: { ...projectInfo },
        };
        eventBus.emit(EventNameCons.EventCanvasChangeImg, data);
      }
    }
  }
};

export default Snapshot;
