export interface Device {
    device_name: string;
    sn: string;
    state: number;
    deviceImg?: string
  }