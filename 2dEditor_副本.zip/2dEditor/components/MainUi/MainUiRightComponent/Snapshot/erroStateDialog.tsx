// 依赖
import React, { useEffect, useState, useRef } from 'react';
import { Dialog } from '@mui/material';
import { Button } from 'src/components/MakeUI';
import error_icon from 'src/assets/img/error.png';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import useCustomTranslation from 'src/hooks/useCustomTranslation';

// 样式
import * as classs from './dialog.module.scss';

export default function ErroStateDialog({ visible, errorData, onClose }: any) {
  const { getTranslation } = useCustomTranslation();
  return (
    <Dialog className={classs.erroState} open={visible} onClose={onClose}>
      {/* @ts-ignore */}
      <div className={classs.headerBox}>
        <div className={classs.title}>{errorData?.title}</div>
        <span></span>
      </div>
      {/* @ts-ignore */}
      <div>
        <img src={error_icon} className={classs.erroIcon} />
        <div className={classs.errorTitle}>{getTranslation(TranslationsKeys.SNAPSHOT_STATE_SN_FAILED)}</div>
        <div className={classs.errorContent}>{errorData?.describe}</div>
      </div>
      <Button className={classs.confirmButton} onClick={onClose}>
        OK
      </Button>
    </Dialog>
  );
}
