import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useState } from 'react'
import { useCanvasEditor, useFabric, useEvent } from 'src/templates/2dEditor/hooks/context';
import * as classes from './index.module.scss';
import Typeface from "./Typeface";
import Transform from "./Transform";
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';
import eventBus from 'src/templates/2dEditor/core/eventbus';

function MainUiLeftTextTool(props: any) {
  /**
   * selectNum: font family / transform;
   */
  const { selectNum } = props;
  const canvasEditor = useCanvasEditor();
  const { t } = useTranslation();
  const event = useEvent();
  const activeObject = canvasEditor?.canvas.getActiveObject();
  useEffect(() => {
    // !activeObject && closeLeftbar();
    // return () => { closeLeftbar() }
    eventBus?.on(EventNameCons.EventCanvasTextDeSelect,closeLeftbar );
    return () => { 
      eventBus?.off(EventNameCons.EventCanvasTextDeSelect,closeLeftbar);
    }
  }, [activeObject])

  // close;
  const closeLeftbar = () => {
    event?.emitEvent(EventNameCons.OpenTextTool, false);
  }
  return (
    <div className={classes.bar_container}>
      {selectNum === 0 && <Typeface closeLeftbar={closeLeftbar} />}
      {selectNum === 1 && <Transform closeLeftbar={closeLeftbar} />}
    </div>
  )
}

export default MainUiLeftTextTool