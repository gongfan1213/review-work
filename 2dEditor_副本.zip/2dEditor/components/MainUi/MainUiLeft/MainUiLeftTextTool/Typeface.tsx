import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useState, useRef } from 'react'
import { useCanvasEditor, useFabric } from 'src/templates/2dEditor/hooks/context';
import * as classes from './typeface.module.scss';
import { useFontFamily } from 'src/templates/2dEditor/components/MainUi/MainUiTopTool/hooks/useFontFamily';
import { get } from 'src/services'
import debounce from 'lodash/debounce'
import Loading from 'src/components/Loading';
import search from 'src/assets/svg/search.svg';
import close from 'src/assets/svg/close.svg';
import sliders from 'src/assets/svg/sliders.svg';
import { useEvent } from 'src/templates/2dEditor/hooks/context';
import { CustomKey } from 'src/templates/2dEditor/cons/2dEditorCons';
import DOMPurify from 'dompurify';

export default function Typeface(props: any) {
  const { closeLeftbar } = props;
  const canvasEditor = useCanvasEditor();
  const { t } = useTranslation();
  const event = useEvent();
  const typefaceUlRef = useRef(null);
  const typefaceDivRef = useRef(null);
  const { loadFont } = useFontFamily();
  interface FontFamily {
    type: string;
    font_name: string;
    url: string;
  }
  enum TypefaceTypes {
    All = "",
    Serif = "Serif",
    SansSerif = "Sans Serif",
    Script = "Script",
    Other = "Other",
  }
  const [fontFamilies, setFontFamilies] = useState<FontFamily[]>([]);
  useEffect(() => {
    getFonts();
    getCountryLanguageOptions()
    // ;
    !!typefaceUlRef.current && typefaceUlRef.current.addEventListener('scroll', handleTypefaceUlScroll);
    // ;
    return () => {
      !!typefaceUlRef.current && typefaceUlRef.current.removeEventListener('scroll', handleTypefaceUlScroll);
    }
  }, []);
  // watch typeface ul scroll;
  const handleTypefaceUlScroll = (e: any) => {
    // console.log(e)
    const typefaceUlRefHeight = typefaceUlRef.current.offsetHeight
    const typefaceDivRefHeight = typefaceDivRef.current.offsetHeight
    const scrollTop = e.target.scrollTop
    // touch bottom;
    if (typefaceUlRefHeight + scrollTop >= typefaceDivRefHeight) {
      getFontsPage.current++
      if (!!filtersRef.current && filtersRef.current.length > 0) {
        getFonts(filtersRef.current, countryFiltersRef.current)
      } else {
        getFonts(undefined, countryFiltersRef.current)
      }
    }
  }
  // cache for font family;
  const initialCache = {
    [TypefaceTypes.All]: [],
    [TypefaceTypes.Serif]: [],
    [TypefaceTypes.SansSerif]: [],
    [TypefaceTypes.Script]: [],
    [TypefaceTypes.Other]: [],
  };
  const fontFamiliesCache = useRef(initialCache);
  const searchFontName = useRef();
  const handleSearchInput = (e: any) => {
    searchFontName.current = e;
    if (!e) {
      fontFamiliesCache.current = initialCache
    };
    if (!!filters && filters.length > 0) {
      getFonts(filters);
    } else {
      getFonts();
    }
  };
  const getCountryLanguageOptions = async () => {
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-text-languages',
    });
    if (!json || !json.data || !json.data.data) return;
    const data = json.data.data;
    const temCountryLanguageOptions: { id: string, label: string }[] = [];
    data.forEach((item: any) => {
      temCountryLanguageOptions.push({
        id: item.attributes.language,
        label: item.attributes.language,
      })
    });
    countryLanguageOptions.current = temCountryLanguageOptions;
  }
  // 获取cms 字体;
  const [loading, setLoading] = useState(false);
  const getFontsPage = useRef(1);
  const countryLanguageOptions = useRef<any>([]);
  const [filters, setFilters] = useState<TypefaceTypes[]>([TypefaceTypes.All]);
  const filtersRef = useRef(filters);
  const [countryFilters, setCountryFilters] = useState<string[]>([]);
  const countryFiltersRef = useRef(countryFilters);
  // watch font type;
  useEffect(() => {
    if (!!filters && filters.length > 0) {
      getFonts(filters, countryFilters);
    } else {
      getFonts(undefined, countryFilters);
    }
  }, [filters]);
  useEffect(() => {
    countryFiltersRef.current = countryFilters;
    filtersRef.current = filters;
  }, [filters]);

  const pageSize = 20;
  const getFonts = debounce(async (type?: string[], countries?: string[]) => {
    // @ts-ignore; // CACHE;
    if (!!type && type.length === 1 && !searchFontName.current && (!countries || countries.length === 0)) {
      const currentType = type[0];
      // @ts-ignore;
      if (!!fontFamiliesCache.current[currentType] && fontFamiliesCache.current[currentType].length >= getFontsPage.current * pageSize) {
        // @ts-ignore;
        getFontsPage.current = Math.ceil(fontFamiliesCache.current[currentType].length / pageSize);
        // @ts-ignore;
        setFontFamilies(fontFamiliesCache.current[currentType]);
        return;
      }
    };
    // ;
    const searchType = !!type && type.length > 0 && type[0] !== TypefaceTypes.All
      ? { $eq: type } : {};
    const searchCountry = !!countries && countries.length > 0
      ? { $in: countries } : {};
    setLoading(true);
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      // cms接口地址;
      content_type: 'make-2d-element-shapes',
      populate: [
        'font_file',
      ],
      // 筛选（搜索）条件
      filters: {
        type: {
          ...searchType
        },
        language: {
          language: {
            ...searchCountry
          }
        },
        font_name: {
          $contains: searchFontName.current
        }
      },
      pagination: {
        page: getFontsPage.current || 1,
        pageSize: pageSize,
      },
    });
    setLoading(false);
    if (!json || !json.data || !json.data.data) return;
    const data = json.data.data;
    // console.log('search data;', data);
    const temFontFamilies: FontFamily[] = [];
    data.forEach((item: any) => {
      temFontFamilies.push({
        type: item.attributes.type,
        font_name: item.attributes.font_name,
        // url: item.attributes.font_file.data[0].attributes.url,
        url: item.attributes.font_file.data.attributes.url,
      })
    });

    if (searchFontName.current) {
      setFontFamilies(temFontFamilies);
    }
    // ;
    else {
      getFontsPage.current === 1 ?
        setFontFamilies(() => {
          // handle cache;
          if (!!type) {
            type.forEach((item: string) => {
              fontFamiliesCache.current[item] = temFontFamilies;
            })
          }
          // all;
          else {
            fontFamiliesCache.current[TypefaceTypes.All] = temFontFamilies;
          }
          return temFontFamilies;
        }) :
        setFontFamilies((prev) => {
          // handle cache;
          if (!!type) {
            type.forEach((item: string) => {
              fontFamiliesCache.current[item] = prev.concat(temFontFamilies);
            })
          }
          // all;
          else {
            fontFamiliesCache.current[TypefaceTypes.All] = prev.concat(temFontFamilies);
          }
          return prev.concat(temFontFamilies);
        });
    }


  });
  // set css fontface;
  const setCssFontface = () => {
    fontFamilies.forEach((item) => {
      const style = document.createElement('style');
      style.innerHTML = `
        @font-face {
          font-family: '${item.font_name}';
          src: url('${item.url}');
        }
      `;
      document.head.appendChild(style);
    });
  }
  useEffect(() => {
    setCssFontface();
  }, [fontFamilies]);
  const defaultFontFamily = 'Times New Roman';
  const typefaceTypeOptions = [
    { id: TypefaceTypes.All, label: 'All' },
    { id: TypefaceTypes.Serif, label: 'Serif' },
    { id: TypefaceTypes.SansSerif, label: 'Sans Serif' },
    { id: TypefaceTypes.Script, label: 'Script' },
    { id: TypefaceTypes.Other, label: 'Other' },
  ];
  // type face type click;
  const handleTypefaceTypeClick = (id: TypefaceTypes) => {
    typefaceUlRef.current.scrollTop = 0;
    getFontsPage.current = 1;
    setFilters([id])
  }
  // typeface click and change font family;
  const handleTypefaceClick = async (fontFamily: any) => {
    console.log('+++++fontFamily++++++', fontFamily);
    // 使用getActiveObjects获取多个选中对象;
    const activeObjects = canvasEditor!.canvas.getActiveObjects();
    // console.log('--------activeObjects', activeObjects);
    activeObjects.forEach(async (activeObject) => {
      if (fontFamily?.font_name === defaultFontFamily) {
        // console.log("if成功内部");
        activeObject.set("fontFamily", fontFamily.font_name);
        canvasEditor!.canvas.requestRenderAll();
        canvasEditor?.historySave();
      } else {
        // console.log("else成功内部");
        if (await loadFont(fontFamily.font_name)) {
          activeObject.set({
            fontFamily: fontFamily.font_name,
            [CustomKey.FontUrl]: fontFamily.url,
          });
          canvasEditor!.canvas.requestRenderAll();
          canvasEditor?.historySave();
        }
      }
    });
  };
  // #region filter popover;
  // typeface filter trigger;
  const [isShowFilter, setIsShowFilter] = useState(false);
  const handleSearchInputSliderClick = () => {
    setIsShowFilter(!isShowFilter);
  }
  const filterItemClick = (id: string) => {
    typefaceUlRef.current.scrollTop = 0;
    getFontsPage.current = 1;
    const tmpCountryFilters = [...countryFilters];
    // is already checked;
    if (tmpCountryFilters.includes(id)) {
      const index = tmpCountryFilters.indexOf(id);
      tmpCountryFilters.splice(index, 1);
    }
    // push;
    else {
      tmpCountryFilters.push(id);
    }
    setCountryFilters(tmpCountryFilters);

  }
  // button click;
  const filterClearAll = () => {
    // 只清空弹窗内的选中状态
    setCountryFilters([]);
  };
  const filterConfirm = () => {
    setIsShowFilter(false);
    // 点击时重新获取字体;
    getFonts(filters, countryFilters);
  };
  // #endregion ;
  // ;
  return (
    <div className={classes.typeface_container} onClick={() => {
      setIsShowFilter(false);
    }}>
      <div className={classes.title_div}>
        <span>Typeface</span>
        {/* <img className={classes.close_icon} src={close} onClick={() => closeLeftbar()} /> */}
      </div>
      <div className={classes.input_div}>
        {/* 搜索框模块 */}
        <img className={classes.search_img} src={search} />
        <input type="text" placeholder='Search' onInput={(e) => { handleSearchInput(DOMPurify.sanitize(e.target.value)) }} />
        <img className={classes.sliders_img} src={sliders} onClick={(e) => {
          e.stopPropagation();
          e.preventDefault();
          handleSearchInputSliderClick()
        }} />

        {/* 筛选弹框 */}
        <div
          className={classes.filter_popover_div}
          style={{
            height: isShowFilter ? '122px' : 0,
          }}
        >
          <ul>
            {
              countryLanguageOptions.current.map(item => (
                <li key={item.id} className={countryFilters.includes(item.id) ? classes.filter_li_active : ''} onClick={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  filterItemClick(item.id)
                }}>
                  <span>{item.label}</span>
                </li>
              ))
            }
          </ul>
          <div className={classes.filter_button_div}>
            <button onClick={(e) => {
              e.stopPropagation();
              e.preventDefault();
              filterClearAll();
            }}>
              Clear All
            </button>
            <button onClick={(e) => {
              e.stopPropagation();
              e.preventDefault();
              filterConfirm();
            }}>
              Confirm
            </button>
          </div>
        </div>
      </div>

      {/* 筛选模块 */}
      <ul className={classes.typeface_type_ul}>
        {
          typefaceTypeOptions.map((item) => {
            return (
              <li
                key={item.id}
                onClick={() => { handleTypefaceTypeClick(item.id) }}
                style={{ color: filters.includes(item.id) ? '#60ce75' : '#9b9b9b' }}
              >
                {item.label}
                {
                  filters.includes(item.id) &&
                  <span className={classes.active_bottomline}></span>
                }
              </li>
            )
          })
        }
      </ul>

      {/* 底部表格 */}
      <div className={classes.master_div}>
        <Loading className={classes.loading} loading={loading} isAbsolute />
        <p className={classes.lt_corner_title}>Recently Used</p>
        <ul ref={typefaceUlRef} className={classes.typeface_ul}>
          <div ref={typefaceDivRef}>
            {
              fontFamilies.map((item, index) => {
                return (
                  <li className={classes.typeface_li} key={index} onClick={() => { handleTypefaceClick(item) }}>
                    <span style={{ fontFamily: item.font_name }}> {item.font_name}
                    </span>
                  </li>
                )
              })
            }
          </div>
        </ul>
      </div>
    </div>
  )
}