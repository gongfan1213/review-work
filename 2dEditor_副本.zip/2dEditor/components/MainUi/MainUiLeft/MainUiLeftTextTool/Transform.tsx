import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useState, useRef } from 'react'
import { useCanvasEditor, useEvent, useFabric } from 'src/templates/2dEditor/hooks/context';
import * as classes from './transform.module.scss';
import close from 'src/assets/svg/close.svg';
import { TransformType } from 'src/templates/2dEditor/core/plugin/ArcTextPlugin/types';
import { TextStatus } from 'src/templates/2dEditor/core/eventbus/types/text';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';

export default function Transform(props: any) {
  const { closeLeftbar } = props;
  const { t } = useTranslation();
  const canvasEditor = useCanvasEditor();
  const activeObject = canvasEditor?.canvas.getActiveObject();
  const [renderFlag, setRenderFlag] = useState(false);
  useEffect(() => {

    // if (!activeObject) {
    //   closeLeftbar();
    //   return;
    // };
    eventBus?.on(TextStatus.UnderTransform, handleTextStatus);
    return () => {
      eventBus?.off(TextStatus.UnderTransform, handleTextStatus);
    }
  }, [activeObject]);

  const handleTextStatus = (flag: boolean) => {
    console.log('_transformType====handleTextStatus==11111', flag)
    if (!flag) {
      eventBus.emit(EventNameCons.ChangeEditorSaveState, true);
    }
  }

  const transformTypes = [
    {
      id: TransformType.Custom,
      name: 'CUSTOM'
    },
    {
      id: TransformType.Circle,
      name: 'CIRCLE'
    },
    {
      id: TransformType.Angle,
      name: 'ANGLE'
    },
    {
      id: TransformType.Bezier2,
      name: 'BEZIER'
    },
    // {
    //   id: TransformType.Polygon,
    //   name: 'Polygon'
    // },
    // {
    //   id: TransformType.Distort,
    //   name: 'DISTORT'
    // }
  ];
  // ;
  const handleTransformClick = (id: TransformType) => {
    if (!activeObject) return;
    eventBus.emit(EventNameCons.ChangeEditorSaveState, false);
    activeObject.set({
      // @ts-ignore;
      "_transformType": id === activeObject._transformType ? null : id
    });
    setRenderFlag(!renderFlag);
  }

  // ;
  return (
    <div className={classes.transform_container}>
      <div className={classes.title_div}>
        <span>Transformation</span>
      </div>
      <div className={classes.master_div}>
        <ul className={classes.master_ul}>
          {
            transformTypes.map((item, index) => {
              return (
                <li key={index} className={`${classes.li_item} ${(!!activeObject && activeObject._transformType === item.id) && classes.active_li_item}`} onClick={() => handleTransformClick(item.id)}>
                  <span>{item.name}</span>
                </li>
              )
            })
          }
        </ul>
      </div>
    </div>
  )
}
