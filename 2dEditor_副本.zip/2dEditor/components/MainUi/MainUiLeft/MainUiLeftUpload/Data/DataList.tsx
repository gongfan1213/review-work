
// 依赖
import React, { Dispatch, SetStateAction, useState, useEffect, useCallback, useRef } from "react";
// 组件
import { Masonry } from 'react-masonry-component2';
import Popover from '@material-ui/core/Popover';
import CommonImage from 'src/components/CommonImage';
import CustomCheckbox from 'src/components/CustomCheckbox';

// 数据类型
import { MaterialEditData } from '../../../../SelectDialog/model/ProjectModel';
// 样式
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import * as classes from './DataListStyle.module.scss'
// 图标
import more_icon from 'src/images/2dEditor/more.png';
import prohibit from 'src/assets/svg/prohibit.svg'


// 参数类型
interface PropsObj {
  dataList: MaterialEditData[], // 数据
  isEditing: boolean, // 是否编辑状态
  selectAll: boolean, // 是否全选
  selectedItems: any[], // 勾选数据
  clickItem: (arg0: any) => void, // 点击当前对象
  deleteProject: (id: number) => void, // 点击删除
  setIsEditing: () => void, // 设置是否编辑状态
  itemOperator: (id: any) => void, // 设置当前操作对象信息
  setIsShowFooterbar: Dispatch<SetStateAction<boolean>>,
  allRight_state: boolean, // 左侧布局是否放大
  setIsItemDeleteId: Dispatch<SetStateAction<number>>,
  setOpenDialog: Dispatch<SetStateAction<boolean>>
  isApps: boolean, // 从app界面跳过来
  handleSelectItem: (arg0: any) => void, // 勾选复选框
}

// 自定义popover弹窗样式
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    paper: {
      width: '80px',
      backgroundColor: '#fff',
      fontSize: 12
    },
    operatorItem: {
      height: '34px',
      lineHeight: "34px",
      paddingLeft: '8px',
      cursor: 'pointer'
    }
  }),
);

const DataList: React.FC<PropsObj> = ({ 
  dataList, isEditing, selectAll, selectedItems, clickItem, setIsItemDeleteId, setIsEditing, itemOperator, 
  setIsShowFooterbar, allRight_state, setOpenDialog,isApps, handleSelectItem
}) => {
  // popover样式
  const classess = useStyles();

  // popover相关定义 -- start
  const [anchorEl, setAnchorEl] = useState(null);
  const [openedPopoverId, setOpenedPopoverId] = useState(null);

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;
  const [hoverStates, setHoverStates] = useState<{ [key: number]: boolean }>({});

  // 维护每个项的打开状态
  const [openState, setOpenState] = useState({});

   // 处理鼠标进入
   const handleMouseEnter = (id: number) => {
    setHoverStates({});
    setHoverStates(prev => ({ ...prev, [id]: true }));
  };

  // 处理鼠标离开
  const handleMouseLeave = (id: number) => {
    setHoverStates(prev => ({ ...prev, [id]: false }));
  };

  const handleClick = (event, id) => {
    setAnchorEl(event.currentTarget);
    setOpenedPopoverId(id);
  };
  const handleClose = () => {
    setAnchorEl(null);
    setOpenedPopoverId(null);
  };
  // popover相关定义 -- end

  // 删除操作
  const itemOperatorDelete = (event: React.MouseEvent<HTMLDivElement, MouseEvent>, id: number) => {
    console.log('=========',id)
    event.stopPropagation();
    setOpenDialog(true);
    setIsItemDeleteId(id)
    handleClose();
  }

  // 选择操作
  const itemOperatorSelect = (event: React.MouseEvent<HTMLDivElement, MouseEvent>, id: number) => {
    event.stopPropagation();
    setIsShowFooterbar(true);
    itemOperator(id)
    setIsEditing();
    handleClose();
  }

  // 切换特定项的打开状态
  const togglePopover = (index: any,) => {
    setOpenState((prevState) => {
      const newState = {};
      console.log('prevState',prevState,index)
      if (JSON.stringify(prevState) !== '{}') {
        for (const key in prevState) {
          if (index == key) {
            newState[key] = !prevState[index]
          } else {
            newState[index] = true;
          }
        }
      } else {
        newState[index] = true;
      }
      return newState;
    })
  };

  const handlePopoverDelete = (event: React.MouseEvent<HTMLDivElement, MouseEvent>,index: number,material_id: any) => {
    event.stopPropagation();
    togglePopover(index);
    itemOperatorDelete(event, material_id)
  }

  const handlePopoverSelect = (event: React.MouseEvent<HTMLDivElement, MouseEvent>,index: number,material_id: any) => {
    togglePopover(index);
    itemOperatorSelect(event, material_id)
  }

  const handleScreenClick = () => {
    setOpenState({});
  }

  useEffect(() => {
    document.addEventListener('click', handleScreenClick);
    return () => {
      document.removeEventListener('click', handleScreenClick);
    }
  },[])

  const clickImgItem = useCallback((item:any)=> {
    if(isApps && item.download_url.includes('svg')) {
      return;
    } else {
      clickItem(item)
    }
  },[])

  return (
    allRight_state
      ?
      <div className={classes.flexDataList}>
        {dataList.map((item,index) => {
          if (!item) return null;
          // const decodedUrl = decodeURIComponent(item.download_url);
           let decodedUrl =
             item.download_url &&
             item.download_url.indexOf('oss-cn-shenzhen') !== -1
               ? item.download_url
               : item.download_url
               ? decodeURIComponent(item.download_url)
               : ''
          const isMaterialHovered = hoverStates[item.material_id];
          const isChecked = selectAll || selectedItems.includes(item.material_id);
 
          return (
            <div
              key={item.material_id}
              className={classes.item}
              onMouseEnter={() => handleMouseEnter(item.material_id)}
              onMouseLeave={() => handleMouseLeave(item.material_id)}
            >
              <CommonImage 
                 src={decodedUrl}
                 style={{ aspectRatio: 1, width: 114, height: 114 }}
                 onClick={() => clickImgItem(item)}
              />
              {(isEditing || isMaterialHovered) && (
                 <CustomCheckbox 
                  className={classes.itemSelectBox}
                  checked={isChecked}
                  onChange={(event) => {
                    handleSelectItem(item.material_id);
                  }}
                />
              )}
              <div className={classes.popoverBox}>
                {openState[item.material_id] && (
                  <div className={classes.popoverOperatoer}>
                    <div onClick={(event) => { event.stopPropagation(); handlePopoverDelete(event, index, item.material_id) }}>Delete</div>
                    <div onClick={(event) => { event.stopPropagation(); handlePopoverSelect(event, index, item.material_id) }}>Select</div>
                  </div>
                )}
                <img
                  className={classes.moreIcon}
                  src={more_icon}
                  onClick={(event) => {
                    event.stopPropagation();
                    togglePopover(item.material_id);
                  }}
                  style={{ display: isMaterialHovered ? 'block' : 'none' }}
                />
              </div>
            </div>
          );
        })}
      </div>
      :
      <Masonry
        className={classes.listContainer}
        columnsCountBreakPoints={{ 0: 3 }}
        style={{ gap: 0 }}
      >
        {dataList.map((v) => {
          if (!v) return null;
          // 解码下载URL
          let decodedUrl =v?.download_url.indexOf('oss-cn-shenzhen') !==-1 ? v.download_url : decodeURIComponent(v.download_url)
          const isSvg = v.download_url.includes('svg');
          const isChecked = selectAll || selectedItems.includes(v.material_id);
          const showHoverIcon = isApps && isSvg;
          const showCheckbox = isEditing || hoverStates[v.material_id];
          const showMoreIcon = hoverStates[v.material_id];

          return (
            <div
              key={v.material_id}
              id={decodedUrl}
              className={classes.item}
              onMouseEnter={() => handleMouseEnter(v.material_id)}
              onMouseLeave={() => handleMouseLeave(v.material_id)}
              draggable={true}
              onDragEnd={() => clickItem(v)}
              onDragStart={() => {
                setHoverStates((prev) => ({ ...prev, [v.material_id]: false }))
              }}
            >
              <CommonImage
                src={decodedUrl}
                style={{ 
                  aspectRatio: 1, 
                  borderRadius: 8, 
                  width: '100%', 
                  height: '100%', 
                  objectFit: 'cover' 
                }}
                onClick={() => clickImgItem(v)}
              />

              {showHoverIcon && (
                <img className={classes.hoverIcon} src={prohibit} />
              )}
              {showHoverIcon && <div className={classes.disableBox} />}
              {showCheckbox && (
                <CustomCheckbox
                  className={classes.itemSelectBox}
                  checked={isChecked}
                  onChange={(event) => {
                    handleSelectItem(v.material_id)
                  }}
                />
              )}
              <div key={v.material_id} className={classes.moreOperator}>
                <img
                  src={more_icon}
                  aria-describedby={id}
                  onClick={(e) => {
                    e.stopPropagation()
                    handleClick(e, v.material_id)
                  }}
                  style={{ display: showMoreIcon ? 'block' : 'none' }}
                />
                <Popover
                  id={id}
                  open={openedPopoverId === v.material_id}
                  anchorEl={anchorEl}
                  onClose={handleClose}
                  classes={{ paper: classess.paper }}
                  anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                >
                  <div className={classes.operatorPopper}>
                    <div
                      className={classess.operatorItem}
                      onClick={(event) =>
                        itemOperatorDelete(event, v.material_id)
                      }
                    >
                      Delete
                    </div>
                    <div
                      className={classess.operatorItem}
                      onClick={(event) =>
                        itemOperatorSelect(event, v.material_id)
                      }
                    >
                      Select
                    </div>
                  </div>
                </Popover>
              </div>
            </div>
          )
        })}
      </Masonry>
  );
}

export default DataList;