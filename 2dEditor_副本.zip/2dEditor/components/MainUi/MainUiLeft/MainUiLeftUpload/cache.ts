import React from "react";
import { CanvasEventEmitter } from "src/templates/2dEditor/utils/event/notifier";
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';
import { ProjectModel } from 'src/templates/2dEditor/components/SelectDialog/model/ProjectModel';

class DataCache extends React.Component{
  private static instance: DataCache | null = null;
  private data: Record<string, any>;
  private event: CanvasEventEmitter | null = null;

  private constructor() {
    super({});
    this.data = {};
  }

  public static getInstance(): DataCache {
    if (!DataCache.instance) {
      DataCache.instance = new DataCache();
    }
    return DataCache.instance;
  }

  public updateMaterialtEmitter(event: CanvasEventEmitter) {
    this.event = event;
    this.event?.on(EventNameCons.EventUpdateMaterial, this.updateMaterial);
  }

  public updateProjectCreateEmitter(event: CanvasEventEmitter) {
    this.event = event;
    this.event?.on(EventNameCons.EventUpdateDetailCreate, this.updateProjectCreate);
  }

  public removeUpdateMaterialtEmitter() {
    this.event?.off(EventNameCons.EventUpdateMaterial, this.updateMaterial);
  }

  public removeUpdateProjectCreateEmitter() {
    this.event?.off(EventNameCons.EventUpdateDetailCreate, this.updateProjectCreate);
  }

  // 上传图片更新upload界面数据
  private  updateMaterial (params:any) {
    const origindata = DataCache.getInstance().cachePageData?.('upload')|| [];
    console.log('origindata',origindata)
    const cachePageSize = DataCache.getInstance().cachePageSize('upload') || 1;
    const cacheHasMore = DataCache.getInstance().cacheHasMore('upload') || false;
    DataCache.getInstance().setCacheItem('upload', {'pageData': [params, ...origindata], 'pageSize': cachePageSize, 'hasMore': cacheHasMore})
  }

  // 创建项目 在列表上手动创建是新的数据，要push到列表上
  public updateProjectCreate (data: ProjectModel) {
    const cacheData = DataCache.getInstance().cachePageData?.('project') || [];
    const cachePageSize = DataCache.getInstance().cachePageSize('project') || 1;
    const cacheHasMore = DataCache.getInstance().cacheHasMore('project') || false;
    DataCache.getInstance().setCacheItem('project', { 'pageData': [data?.project_info, ...cacheData], "pageSize": cachePageSize, 'hasMore': cacheHasMore })
  }

  public setCacheItem(key: string, value: any): void {
    this.data[key] = value;
  }

  public getCacheItem(key: string): any {
    return this.data[key];
  }

  public removeItem(key: string): void {
    delete this.data[key];
  }

  public cachePageData(key: string): any {
    return this.data?.[key]?.['pageData'];
  }

  public cachePageSize(key: string): any {
    return this.data[key]?.['pageSize'];
  }

  public cacheHasMore(key: string): any {
    return this.data[key]?.['hasMore'];
  }

  public clear(): void {
    this.data = {};
  }
}

export default DataCache;
