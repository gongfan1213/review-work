import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useRef, useState, useCallback } from 'react'
import { useCanvasEditor, useEvent } from 'src/templates/2dEditor/hooks/context';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import { deleteUserMateria, getUserMaterialList } from 'src/templates/2dEditor/service/2dEditService';
import { MaterialEditData } from '../../../SelectDialog/model/ProjectModel';
import * as classes from './MainUiLeftUpload.module.scss'
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';
import { CusPageRequestModel, isNetSuccess } from 'src/templates/2dEditor/common/netUtil';
import { openToast } from 'src/state/reducers/toast';
import Loading from 'src/components/Loading';
import { getImgStr, selectFiles } from 'src/templates/2dEditor/utils/utils';
import { GetUpTokenFileTypeEnum } from 'src/services';
import { ImportSource } from 'src/templates/2dEditor/core/plugin/ImagePlugin/types/common';
import { convertToBase64 } from 'src/common/utils';
import MainUiLeftFooterBar from '../../../MainUiLeftFooterBar/MainUiLeftFooterBar';
import DataList from './Data/DataList';
import return_icon from '/src/images/2dEditor/Apps_icon/appbar_back_icon.png'
import useDataCache from '../../../../utils/DataCache';
import { uploadImageForCavas } from 'src/templates/2dEditor/common/cavasUtil';
import empty_upload_icon from 'src/images/empty_upload.png';
import upload from '/src/assets/svg/upload.svg';
import { EditorToastType, editorToastHidden, editorToastShow } from '../../../Toast';
import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';
import DataCache from './cache';
import { checkFileSize } from 'src/templates/2dEditor/utils/checkFileSize';
import { useDispatch } from 'react-redux';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

function MainUiLeftUpload(props: any) {

  const { setCacheItem, getCacheItem, } = useDataCache();

  const { isApps, handleStep4Data, Petindex, prevStep, allRight_state, isPetPoratrait, handlePetPoraData } = props

  const canvasEditor = useCanvasEditor()
  const { t } = useTranslation()
  const [isLoading, setLoading] = useState(false)
  const [hasMore, setHasMore] = useState(false)
  const pageIndex = useRef(1);
  const [dataList, setDataList] = useState<MaterialEditData[]>([])
  const PAGE_SIZE = 20
  const event = useEvent();
  const { getTranslation } = useCustomTranslation();

  const [isEditing, setEditing] = useState(false);
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [isNetLoading, setNetLoading] = useState(false)
  const [openDialog, setOpenDialog] = useState(false);
  const [isShowFooterbar, setIsShowFooterbar] = useState(false);
  const [isItemDeleteId, setIsItemDeleteId] = useState<any>(null);
  const dispatch = useDispatch()
  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault(); // 阻止默认行为
  }, []);

  useEffect(() => {
    if (DataCache.getInstance()?.cachePageData('upload')?.length > 0) {
      setDataList(DataCache.getInstance().cachePageData('upload'));
      setHasMore(DataCache.getInstance().cacheHasMore('upload'));
      pageIndex.current = DataCache.getInstance().cachePageSize('upload');
    } else {
      getListData();
    }
    // console.log('----useEffect-----', getCacheItem('upload'))

  }, [canvasEditor]);

  useEffect(() => {
    event?.on(EventNameCons.EventUpdateMaterial, updateDataAdd);
    if (event) {
      DataCache.getInstance().updateProjectCreateEmitter(event);
    }
    return () => {
      event?.off(EventNameCons.EventUpdateMaterial, updateDataAdd);
      DataCache.getInstance().removeUpdateProjectCreateEmitter();
    }
  }, [])

  useEffect(() => {
    setSelectAll(selectedItems.length > 0 && selectedItems.length == dataList.length);
  }, [selectedItems]);


  const updateDataAdd = (data: MaterialEditData) => {
    setDataList(prevDataList => {
      const newDataList = [data, ...prevDataList];
      return newDataList;
    });
    const hasMore = DataCache.getInstance().getCacheItem('upload')?.['hasMore'];
    const pageIndex = DataCache.getInstance().getCacheItem('upload')?.['pageSize'];
    const originData = DataCache.getInstance().cachePageData?.('upload')?.length > 0 ? DataCache.getInstance().cachePageData?.('upload') : dataList;
    DataCache.getInstance().setCacheItem('upload', { 'pageData': [data, ...originData], "pageSize": pageIndex, 'hasMore': hasMore });
  }

  const getListData = () => {
    var request: CusPageRequestModel = {
      pagination: {
        page_size: PAGE_SIZE,
        page: pageIndex.current,
      }
    }
    setLoading(true);
    getUserMaterialList(request).then((res) => {
      setLoading(false)
      if (res?.data?.material_list?.length == 0 && res?.data?.total == 0) {
        setDataList([]);
        setHasMore(false);
        setCacheItem('upload', { 'pageData': [], "pageSize": 1, 'hasMore': false })
      } else {
        const reqDataList = res?.data?.material_list || [];
        pageIndex.current++;
        const data = [...dataList, ...reqDataList];
        setDataList(prevProjects => [...prevProjects, ...reqDataList]);
        setHasMore(reqDataList.length >= PAGE_SIZE)
        DataCache.getInstance().setCacheItem('upload', { 'pageData': data, 'pageSize': pageIndex.current, 'hasMore': reqDataList.length >= PAGE_SIZE });

        // 如果是全选的话 要把继续加载的数据也加入到选中项
        if (selectAll || (selectedItems.length > 0 && (selectedItems.length == reqDataList.length))) {
          const allIds = data.map((project) => project.material_id);
          setSelectedItems(allIds);
        }
      }
    }).finally(() => {
      setLoading(false)
    })
  }

  const clickItem = async (data: MaterialEditData) => {
    // if (isEditing) {
    //   handleSelectItem(data.material_id);
    //   return;
    // }
    // 判断是否从apps模块点击进入
    if (isApps) {
      handleStep4Data({ ...Petindex.item, [Petindex.index]: { ...data } })
    } else if (isPetPoratrait) {
      handlePetPoraData(data);
    } else {
      /// 导入到画布
      // const decodedUrl = decodeURIComponent(data.download_url);
      let decodedUrl =
        data.download_url &&
          data.download_url.indexOf('oss-cn-shenzhen') !== -1
          ? data.download_url
          : data.download_url
            ? decodeURIComponent(data.download_url)
            : ''
      const fileExtension = data.file_name.split('.').pop(); // 获取文件后缀
      if (fileExtension === 'svg') {
        // SVG 文件的处理逻辑
        const response = await fetch(decodedUrl);
        const blob = await response.blob();
        getImgStr(blob).then((file) => {
          canvasEditor?.addSvgFile(file as string);
        });
      } else {
        setNetLoading(true);
        const base64 = await convertToBase64(decodedUrl);
        canvasEditor?.addImage(base64,
          {
            importSource: ImportSource.Cloud,
            fileType: fileExtension,
            key_prefix: data.file_name
          });
        setNetLoading(false);
      }
    }

  }

  const handleSelectItem = (id: number) => {
    const newSelectedItems = new Set(selectedItems);
    if (newSelectedItems.has(id)) {
      newSelectedItems.delete(id);
      setSelectAll(false);
    } else {
      newSelectedItems.add(id);
    }
    setSelectedItems(Array.from(newSelectedItems));
    if (Array.from(newSelectedItems).length > 0) {
      setEditing(true)
    } else {
      setEditing(false);
    }
  };

  const itemOperator = (id: number) => {
    const newSelectedItems = new Set(selectedItems);
    if (!newSelectedItems.has(id)) {
      newSelectedItems.add(id);
    }
    setSelectedItems(Array.from(newSelectedItems));
  }

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedItems([]);
    } else {
      const allIds = dataList.map((data) => data.material_id);
      setSelectedItems(allIds);
    }
    setSelectAll(!selectAll);
  };

  const deleteProject = (id: any) => {
    itemOperator(id);
    setOpenDialog(true);
  }

  const handleDeleteSelected = () => {
    setNetLoading(true);
    const ids = isItemDeleteId ? [isItemDeleteId] : selectedItems;
    if (ids.length > 100) {
      dispatch(openToast({
        message: getTranslation(TranslationsKeys.DELETE_UP_TO_100_IMAGES),
        severity: 'warning',
      }))
      setNetLoading(false);
      return;
    }
    deleteUserMateria({ material_ids: ids }).then((resp) => {
      setNetLoading(false)
      if (isNetSuccess(resp)) {
        // 过滤掉已删除的项目
        const newProjectList = dataList.filter(
          (data) => !ids.includes(data.material_id)
        );
        // 更新projectList状态
        setDataList(newProjectList);
        const hasMore = DataCache.getInstance().cacheHasMore('upload');
        const cachePageIndex = newProjectList.length > 0 ? DataCache.getInstance().cachePageSize('upload') : 1;
        DataCache.getInstance().setCacheItem('upload', { 'pageData': newProjectList, "pageSize": cachePageIndex, 'hasMore': hasMore });
        // 清空选中项
        setSelectedItems([]);
        // 删除所有后，重新加载下一页数据
        if (newProjectList.length == 0 && hasMore) {
          pageIndex.current = 1
          getListData();
        }
        // 关闭弹窗
        setOpenDialog(false);
        setEditing(false);
        setSelectAll(false);
        setIsItemDeleteId(null);
        setIsShowFooterbar(false);
      } else {
        dispatch(
          openToast({
            message: resp?.msg || getTranslation(TranslationsKeys.SOMETHING_WENT_WRONG_AGAIN),
            severity: 'error',
          })
        );
      }
    });
  };

  const updateFile = () => {
    // '.jpeg,.jpg,.png,.svg,.webp';
    const supportImageTypes = '.jpeg,.png,.jpg,.webp,.svg,.psd,.ai,.pdf';
    selectFiles({ accept: supportImageTypes, multiple: true }).then((fileList) => {
      Array.from(fileList as FileList).forEach((item) => {
        if (!checkFileSize(item)) return;
        console.log('====item', item)
        const fileExtension = item.name.split('.').pop()?.toLowerCase(); // 获取文件后缀并转换为小写
        // 缺陷：文件过长且有特殊字符 -- 后端的留言：前端调用get_upload_token接口时，文件名参数不应该使用实际文件名
        const newName = 'uploadImage.' + fileExtension; // 新的文件名
        const newFile = new File([item], newName, { type: item.type });

        uploadImageForCavas({
          updateStart: () => editorToastShow({
            tips: getTranslation(TranslationsKeys.Loading),
            type: EditorToastType.loading,
          }),
          updateEnd: (ret: boolean, error: number, message?: string) => {
            if (ret) {
              editorToastHidden()
            } else {
              editorToastShow({
                tips: getTranslation(TranslationsKeys.SOMETHING_WENT_WRONG_AGAIN),
                type: EditorToastType.error,
              })
            }
          },
          fileExtension: fileExtension as string,
          fileItem: newFile,
          event: event,
          canvasEditor: canvasEditor,
          uploadFileType: GetUpTokenFileTypeEnum.Edit2dLocal,
          isApps: isApps,
        });
      });
    });
  };

  const handleDialogClose = () => {
    setIsItemDeleteId(null);
    setOpenDialog(false);
    setIsShowFooterbar(false);
  }

  const handleDialogOpen = () => {
    setOpenDialog(true);
  }

  const setIsNotEditing = () => {
    setEditing(false);
    setSelectedItems([]);
    setIsShowFooterbar(false);
  }

  const setIsEditing = () => {
    setEditing(true);
    setSelectAll(false);
    setIsShowFooterbar(true);
  }

  const handleDrop = useCallback((action: React.DragEvent<HTMLDivElement>) => {
    action.stopPropagation(); // 阻止冒泡
    action.preventDefault(); // 阻止默认行为
    const files = action.dataTransfer.files;
    if (files.length > 0) {
      Array.from(files as FileList).forEach((item) => {
        if (!checkFileSize(item)) return;
        const fileExtension = item.name.split('.').pop()?.toLowerCase(); // 获取文件后缀并转换为小写
        const newName = 'uploadImage.' + fileExtension; // 新的文件名
        const newFile = new File([item], newName, { type: item.type });
        uploadImageForCavas({
          updateStart: () => editorToastShow({
            tips: getTranslation(TranslationsKeys.Loading),
            type: EditorToastType.loading,
          }),
          updateEnd: (ret: boolean, error: number, message?: string) => {
            if (ret) {
              editorToastHidden()
            } else {
              editorToastShow({
                tips: getTranslation(TranslationsKeys.SOMETHING_WENT_WRONG_AGAIN),
                type: EditorToastType.error,
              })
            }
          },
          fileExtension: fileExtension as string,
          fileItem: newFile,
          event: event,
          canvasEditor: canvasEditor,
          uploadFileType: GetUpTokenFileTypeEnum.Edit2dLocal,
        });
      });
    } else {
      setNetLoading(false);
    }
  }, [canvasEditor]);

  const selectedLength = selectedItems.length;
  return (
    <div className={classes.layout}>
      <div className={classes.layoutTitle}>
        <div style={{ display: 'flex', 'alignItems': 'center' }}>
          {isApps && <img src={return_icon} style={{ 'marginRight': '8px', 'width': '24px', 'height': '24px' }} onClick={() => { prevStep('', '') }} />}
          <div className={`${BaseStyles.txt24} ${classes.uploadTitle}`}>
            <span>{getTranslation(TranslationsKeys.UPLOAD)}</span>
          </div>
        </div>
      </div>

      <button className={`${BaseStyles.cusButtonWrap} ${classes.updateButton}`} onClick={updateFile}>
        <img src={upload} />
        {getTranslation(TranslationsKeys.STR_COMMON_UPLOAD_IMAGE)}
      </button>

      <div
        className={classes.listWrap}
        style={{ paddingRight: allRight_state?.state ? 20 : 0 }}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        <ScrollMoreView2d
          onLoadMore={getListData}
          hasMore={hasMore}
          isLoading={isLoading}
        >
          {!isLoading && dataList.length === 0 && <div className={classes.emptyTip}>
            <img src={empty_upload_icon} />
            <div>{getTranslation(TranslationsKeys.NO_PHOTO_TIP)}</div>

          </div>}
          {dataList.length > 0 && <DataList
            dataList={dataList}
            isEditing={isEditing}
            selectAll={selectAll}
            selectedItems={selectedItems}
            clickItem={clickItem}
            deleteProject={deleteProject}
            setIsEditing={setIsEditing}
            itemOperator={itemOperator}
            setIsShowFooterbar={setIsShowFooterbar}
            allRight_state={allRight_state?.state || false}
            setIsItemDeleteId={setIsItemDeleteId}
            setOpenDialog={setOpenDialog}
            isApps={isApps}
            handleSelectItem={handleSelectItem}
          />}
        </ScrollMoreView2d>
      </div>
      {
        ((isEditing) || isItemDeleteId) && <MainUiLeftFooterBar
          selectedItems={selectedItems}
          dataList={dataList}
          selectAll={selectAll}
          handleSelectAll={handleSelectAll}
          handleConfirm={handleDeleteSelected}
          isHandleConfirmSuccess={isNetLoading}
          setIsEditing={setIsNotEditing}
          openDialog={openDialog}
          setCloseDialog={handleDialogClose}
          setOpenDialog={handleDialogOpen}
          isShowFooterbar={isShowFooterbar}
          isItemDeleteId={isItemDeleteId}
          dialogDes={
            t('string_delete_upload_tip', `Are You Sure Want To Delete ${selectedLength > 1 ? "These" : "This"} ${selectedLength > 0 ? selectedLength : 1} ${selectedLength > 1 ? "Uploads" : "Upload"}?`)
          }
        />
      }
      <Loading loading={isNetLoading} />
    </div>
  )
}

export default MainUiLeftUpload

