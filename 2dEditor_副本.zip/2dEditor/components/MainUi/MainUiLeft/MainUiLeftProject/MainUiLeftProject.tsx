import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useMemo, useRef, useState, } from 'react'
import { useCanvasEditor, useEvent, useProjectData } from 'src/templates/2dEditor/hooks/context';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import { deleteProjectList, getProjectList } from 'src/templates/2dEditor/service/2dEditService';
import { ProjectModel, ProjectResInfo } from '../../../SelectDialog/model/ProjectModel';
import { Masonry } from 'react-masonry-component2';
import * as classes from './MainUiLeftProject.module.scss'
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';
import ProjectManager from 'src/templates/2dEditor/utils/ProjectManager';
import { CusPageRequestModel, isNetSuccess } from 'src/templates/2dEditor/common/netUtil';
import { openToast } from 'src/state/reducers/toast';
import Loading from 'src/components/Loading';
import MainUiLeftFooterBar from '../../../MainUiLeftFooterBar/MainUiLeftFooterBar';
import more_icon from 'src/images/2dEditor/more.png';
import Popover from '@material-ui/core/Popover';
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import useDataCache from '../../../../utils/DataCache';
import { blobToBase64 } from 'src/common/utils';
import empty_project_icon from "src/images/empty_progress.png";
import { EditorToastType, editorToastShow } from '../../../Toast';
import DataCache from '../MainUiLeftUpload/cache';
import ScrollMoreView2d from 'src/templates/2dEditor/components/ScrollMoreView2d/ScrollMoreView2d';
import { useDispatch } from 'react-redux';
import { From2dEditorType } from 'src/templates/2dEditor/utils/event/types'
import CommonImage from 'src/components/CommonImage';
import CustomCheckbox from 'src/components/CustomCheckbox';
import useCustomTranslation from "src/hooks/useCustomTranslation";
import { TranslationsKeys } from "src/templates/2dEditor/utils/TranslationsKeys";

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    paper: {
      width: '80px',
      backgroundColor: '#fff',
      fontSize: 12
    },
    operatorItem: {
      height: '34px',
      lineHeight: "34px",
      paddingLeft: '8px',
      cursor: 'pointer'
    }
  }),
);


function MainUiLeftProject(props: any) {

  const { setCacheItem, getCacheItem } = useDataCache();
  const { allRight_state } = props;
  const { getTranslation } = useCustomTranslation();

  const canvasEditor = useCanvasEditor()
  const { t } = useTranslation()
  const [isLoading, setLoading] = useState(false)
  const [hasMore, setHasMore] = useState(false)
  const pageIndex = useRef(1);
  const [projectList, setProjectList] = useState<ProjectResInfo[]>([])
  const PAGE_SIZE = 20
  const event = useEvent();
  const dispatch = useDispatch()

  const [isEditing, setIsEditing] = useState(false);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [isNetLoading, setNetLoading] = useState(false)
  const [openDialog, setOpenDialog] = useState(false);
  const [isShowFooterbar, setIsShowFooterbar] = useState(false);

  const [anchorEl, setAnchorEl] = useState<any>(null);
  const [openedPopoverId, setOpenedPopoverId] = useState<string | null>(null);
  const [isItemDeleteId, setIsItemDeleteId] = useState<string | null>(null);
  const currentEditId = useRef<any>(null);
  const projectModelCur = useProjectData();

  // 维护每个项的打开状态
  const [openState, setOpenState] = useState({});

  const classess = useStyles();

  const handleClick = (event: any, id: string): void => {
    setAnchorEl(event.currentTarget);
    setOpenedPopoverId(id);
  };

  const handleClose = () => {
    setAnchorEl(null);
    setOpenedPopoverId(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;
  const [hoverStates, setHoverStates] = useState<{ [key: string]: boolean }>({});

  const handleScreenClick = (event) => {
    setOpenState({});
  }

  // 处理鼠标进入
  const handleMouseEnter = (id: string) => {
    setHoverStates({});
    setHoverStates(prev => ({ ...prev, [id]: true }));
  };

  // 处理鼠标离开
  const handleMouseLeave = (id: string) => {
    setHoverStates(prev => ({ ...prev, [id]: false }));
  };

  useEffect(() => {
    setOpenState({});
  }, [allRight_state])

  useEffect(() => {
    if (DataCache.getInstance()?.cachePageData('project')?.length > 0) {
      setProjectList(DataCache.getInstance().cachePageData('project'));
      setHasMore(DataCache.getInstance().cacheHasMore('project'));
      pageIndex.current = DataCache.getInstance().cachePageSize('project');
    } else {
      getProjectListData();
    }
  }, [canvasEditor])

  useEffect(() => {
    event?.on(EventNameCons.EventUpdateProjectThumbnail, updateThumbnail);
    event?.on(EventNameCons.EventUpdateDetailCreate, updateProjectCreate);
    DataCache.getInstance().updateMaterialtEmitter(event);
    document.addEventListener('click', handleScreenClick);

    return () => {
      event?.off(EventNameCons.EventUpdateProjectThumbnail, updateThumbnail);
      event?.off(EventNameCons.EventUpdateDetailCreate, updateProjectCreate);
      DataCache.getInstance().removeUpdateMaterialtEmitter();
      document.removeEventListener('click', handleScreenClick);
    }
  }, [])


  useEffect(() => {
    // 从其他界面回来，需要根据id匹配显示选中样式
    // const editProjectId = getCacheItem('editProjectId');
    // currentEditId.current = editProjectId;
    currentEditId.current = projectModelCur?.project_info.project_id;
  }, [projectModelCur])

  useEffect(() => {
    setSelectAll(selectedItems.length > 0 && projectList.length > 1 && selectedItems.length >= projectList.length - 1);
  }, [selectedItems]);

  // 处理缩略图 用ID匹配列表，然后blob替换img的src
  const updateThumbnail = (blob: Blob, project_id: string) => {
    const originData = DataCache.getInstance().cachePageData?.('project')?.length > 0 ? DataCache.getInstance().cachePageData?.('project') : projectList;

    const dataList = [...originData];
    for (let i = 0; i < dataList.length; i++) {
      var projectData = dataList[i];
      const dataProjectId = projectData.project_id || projectData.project_info.project_id;
      if (dataProjectId === project_id) {
        blobToBase64(blob).then(file => {
          projectData.img_blob = file;
          setProjectList(dataList);
          DataCache.getInstance().setCacheItem('project', { 'pageData': dataList, "pageSize": DataCache.getInstance().cachePageSize('project'), 'hasMore': DataCache.getInstance().cacheHasMore('project') })

        })
        return;
      }
    }
  }

  // 创建项目 在列表上手动创建是新的数据，要push到列表上
  const updateProjectCreate = (data: ProjectModel) => {
    const originData = DataCache.getInstance().cachePageData?.('project')?.length > 0 ? DataCache.getInstance().cachePageData?.('project') : projectList;
    const dataList = [data?.project_info, ...originData];
    setCacheItem('editProjectId', data.project_info.project_id);
    setProjectList(dataList);
    const hasMore = DataCache.getInstance().getCacheItem('project')?.['hasMore'];
    const pageIndex = DataCache.getInstance().getCacheItem('project')?.['pageSize'];
    DataCache.getInstance().setCacheItem('project', { 'pageData': dataList, "pageSize": pageIndex, 'hasMore': hasMore });
  }

  const getProjectListData = () => {
    var request: CusPageRequestModel = {
      // 1:2D编辑器 2:灯光画
      project_type: 1,
      pagination: {
        page_size: PAGE_SIZE,
        page: pageIndex.current,
      }
    }
    setLoading(true);
    getProjectList(request).then((res) => {
      setLoading(false)
      if (res?.data?.project_list.length == 0 && res?.data?.total == 0) {
        setProjectList([]);
        setHasMore(false);
        DataCache.getInstance().setCacheItem('project', { 'pageData': [], "pageSize": 1, 'hasMore': false })
      } else {
        const editProjectId = getCacheItem('editProjectId');
        const dataList = res?.data?.project_list || [];
        if (!editProjectId) {
          currentEditId.current = projectModelCur?.project_info.project_id;
        }
        pageIndex.current++;
        const cacheData = DataCache.getInstance().getCacheItem('project');
        const cacheList = cacheData?.['pageData'];
        let data = [];
        if (cacheList) {
          data = [...cacheList, ...dataList];
        } else {
          data = dataList;
        }
        setProjectList(data);
        setHasMore(dataList.length >= PAGE_SIZE)
        DataCache.getInstance().setCacheItem('project', { 'pageData': data, "pageSize": pageIndex.current, 'hasMore': dataList.length >= PAGE_SIZE });

        // 如果是全选的话 要把继续加载的数据也加入到选中项
        if (selectAll || (selectedItems.length > 0 && (selectedItems.length == projectList.length))) {
          const allIds = data.map((project) => project.project_id);
          setSelectedItems(allIds);
        }
      }
      console.log('---------', DataCache.getInstance().getCacheItem('project'))
    })
  }

  const clickChangeProject = (project_id: string) => {
    const params = {
      project_id: project_id,
      type: From2dEditorType.Replace,
    }
    const queryString = new URLSearchParams(params).toString()
    history.pushState({}, '', `/apps/2dEditor/?${queryString}`)
    if (project_id == currentEditId.current) return;
    // if (isEditing) {
    //   handleSelectItem(project_id);
    //   return;
    // }

    setNetLoading(true);
    ProjectManager.getInstance().changeProject(project_id, (ret: boolean) => {
      setNetLoading(false);
      if (!ret) {
        editorToastShow({ tips: getTranslation(TranslationsKeys.str_common_project_load_fail), type: EditorToastType.error });
        pageIndex.current = 1;
        setProjectList([]);
        setHasMore(false)
        DataCache.getInstance().setCacheItem('project', { 'pageData': [], "pageSize": pageIndex.current, 'hasMore': false });
        getProjectListData();
      } else {
        setCacheItem('editProjectId', project_id);
        currentEditId.current = project_id;
      }
    });
  }

  const handleSelectItem = (id: string) => {
    const newSelectedItems = new Set(selectedItems);
    if (newSelectedItems.has(id)) {
      newSelectedItems.delete(id);
    } else {
      newSelectedItems.add(id);
    }
    setSelectedItems(Array.from(newSelectedItems));
    if (Array.from(newSelectedItems).length > 0) {
      setIsEditing(true);
    } else {
      setIsEditing(false);
    }

  };

  const itemOperator = (id: string) => {
    const newSelectedItems = new Set(selectedItems);
    if (!newSelectedItems.has(id) && currentEditId.current != id) {
      newSelectedItems.add(id);
    }
    setSelectedItems(Array.from(newSelectedItems));
  }

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedItems([]);
    } else {
      const allIds = projectList
        .filter((project) => project.project_id !== currentEditId.current)
        .map((project) => project.project_id);
      setSelectedItems(allIds);
    }
    setSelectAll(!selectAll);
  };

  const handleDeleteSelected = () => {
    const ids = isItemDeleteId ? [isItemDeleteId] : selectedItems;
    if (ids.includes(currentEditId.current)) {
      dispatch(
        openToast({
          message: getTranslation(TranslationsKeys.CANNOT_DELETE_PROJECT),
          severity: 'error',
        })
      )
      return;
    }
    setNetLoading(true);
    deleteProjectList({ project_ids: ids }).then((resp) => {
      setNetLoading(false);
      // setIsItemDelete(false);
      if (isNetSuccess(resp)) {
        // 过滤掉已删除的项目
        const newProjectList = projectList.filter(
          (project) => !ids.includes(project.project_id)
        );
        // 更新projectList状态
        setProjectList(newProjectList);
        const hasMore = DataCache.getInstance().getCacheItem('project')?.['hasMore'];
        const cachePageIndex = newProjectList.length > 0 ? DataCache.getInstance().getCacheItem('project')?.['pageSize'] : 1;
        DataCache.getInstance().setCacheItem('project', { 'pageData': newProjectList, "pageSize": cachePageIndex, 'hasMore': hasMore })

        // 清空选中项
        setSelectedItems([]);
        // 删除所有后，重新加载下一页数据
        if (newProjectList.length == 0 && hasMore) {
          pageIndex.current = 1
          getProjectListData();
        }
        // 关闭弹窗
        setOpenDialog(false);
        setIsEditing(false);
        setSelectAll(false);
        setIsItemDeleteId(null);
        setIsShowFooterbar(false);
      } else {
        openToast({
          message: getTranslation(TranslationsKeys.DELETE_FAST),
          severity: 'error',
        });
      }
    });
  };

  const handleDialogClose = () => {
    setOpenDialog(false);
    // setIsItemDelete(false);
    setIsItemDeleteId(null);
    setIsShowFooterbar(false);
  }

  const handleDialogOpen = () => {
    setOpenDialog(true);
  }

  const handleSetEditing = () => {
    setIsEditing(false);
    setSelectedItems([]);
    setSelectAll(false);
    setIsShowFooterbar(false);
  }

  const itemOperatorDelete = (event: React.MouseEvent<HTMLDivElement, MouseEvent>, id: string) => {
    event.stopPropagation();
    handleClose();
    setOpenDialog(true);
    setIsItemDeleteId(id)
  }

  const itemOperatorSelect = (event: React.MouseEvent<HTMLDivElement, MouseEvent>, id: string) => {
    event.stopPropagation();
    itemOperator(id);
    setIsEditing(true);
    setIsShowFooterbar(true);
    handleClose()
  }

  // 切换特定项的打开状态
  const togglePopover = (index: any,) => {
    setOpenState((prevState) => {
      const newState = {};
      console.log('prevState', prevState, index)
      if (JSON.stringify(prevState) !== '{}') {
        for (const key in prevState) {
          if (index == key) {
            newState[key] = !prevState[index]
          } else {
            newState[index] = true;
          }
        }
      } else {
        newState[index] = true;
      }
      return newState;
    })
  };

  const handlePopoverDelete = (event: React.MouseEvent<HTMLDivElement, MouseEvent>, index: number, project_id: string) => {
    event.stopPropagation();
    togglePopover(index);
    itemOperatorDelete(event, project_id)
  }

  const handlePopoverSelect = (event: React.MouseEvent<HTMLDivElement, MouseEvent>, index: number, project_id: string) => {
    togglePopover(index);
    itemOperatorSelect(event, project_id)
  }

  return (
    <div className={classes.layout}>
      <div className={classes.layoutTitle}>
        <div className={`${BaseStyles.txt24}`}>{t('str_common_projects', 'Projects')}</div>
      </div>
      <div className={classes.listWrap} style={{ paddingRight: allRight_state?.state ? 20 : 0 }}>
        <ScrollMoreView2d
          onLoadMore={getProjectListData}
          hasMore={hasMore}
          isLoading={isLoading}
        >
          {!isLoading && projectList.length === 0 && <div className={classes.emptyTip}>
            <img src={empty_project_icon} />
            <div>{getTranslation(TranslationsKeys.NO_PROJECT_TIP)}</div>
          </div>}
          {
            allRight_state?.state
              ?
              <div className={classes.flexDataList}>
                {projectList.map((project, index) => {
                  if (!project) return null;
                  const { project_id, thumb_file, img_blob, project_name } = project;
                  // 优化：避免在每次迭代中重复解码URL
                  // const decodedUrl = thumb_file.download_url ? decodeURIComponent(thumb_file.download_url) : '';
                  let decodedUrl =
                    thumb_file.download_url && thumb_file.download_url.indexOf('oss-cn-shenzhen') !== -1
                      ? thumb_file.download_url
                      : thumb_file.download_url ? decodeURIComponent(
                        thumb_file.download_url,
                      ) : ''
                  const imagerUrl = img_blob || decodedUrl;
                  // const isSelected = project_id === currentEditId.current;
                  const isPopoverOpen = openState[index];
                  const isHovering = hoverStates[project_id];
                  const isCurrentEditing = project_id === currentEditId.current;
                  // 优化：避免不必要的样式对象创建
                  const borderStyle = selectedItems.includes(project_id) ? { border: '1px solid #33BF5A' } : isCurrentEditing ? { border: '1px solid #33BF5A' } : '1px solid #fff';

                  return (
                    <div
                      key={project_id}
                      className={classes.itemLayout}
                      style={borderStyle}
                      onMouseEnter={() => handleMouseEnter(project_id)}
                      onMouseLeave={() => handleMouseLeave(project_id)}
                    >
                      <div className={classes.item}>
                        <CommonImage src={imagerUrl} />
                        <div
                          className={classes.clickDiv}
                          onClick={(event) => {
                            event.stopPropagation();
                            clickChangeProject(project_id);
                          }}
                        />
                        {(isEditing || isHovering) && (
                          <CustomCheckbox
                            className={classes.itemSelectBox}
                            checked={selectedItems.includes(project_id)}
                            onChange={(event) => {
                              handleSelectItem(project_id);
                            }}
                          />
                        )}
                      </div>

                      <div className={classes.itemDesLayout}>
                        <span className={classes.itemDes}>{project_name}</span>
                        <div className={classes.popoverBox}>
                          {isPopoverOpen && (
                            <div className={classes.popoverOperatoer}>
                              <div onClick={(event) => { event.stopPropagation(); handlePopoverDelete(event, index, project_id) }}>{getTranslation(TranslationsKeys.BUTTON_DELETE)}</div>
                              <div onClick={(event) => { event.stopPropagation(); handlePopoverSelect(event, index, project_id) }}>{getTranslation(TranslationsKeys.BUTTON_SELECT)}</div>
                            </div>
                          )}
                          <img
                            src={more_icon}
                            onClick={(event) => { event.stopPropagation(); togglePopover(index) }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              :
              <Masonry
                className={classes.listContainer}
                columnsCountBreakPoints={{ 0: 2 }}
                style={{ gap: 0 }}
              >
                {projectList.map((project, index) => {
                  if (!project) return null;
                  const { project_id, thumb_file, img_blob, project_name } = project;
                  // const decodedUrl = decodeURIComponent(thumb_file?.download_url || '');
                  let decodedUrl =
                    thumb_file.download_url &&
                      thumb_file.download_url.indexOf('oss-cn-shenzhen') !== -1
                      ? thumb_file.download_url
                      : thumb_file.download_url
                        ? decodeURIComponent(thumb_file.download_url)
                        : ''
                  const isCurrentEditing = project_id === currentEditId.current;
                  const isSelected = selectedItems.includes(project_id);
                  const isHovered = hoverStates[project_id];

                  return (
                    <div
                      key={project_id}
                      className={classes.itemLayout}
                      style={{ border: isSelected ? '1px solid #33BF5A' : isCurrentEditing ? '1px solid #33BF5A' : '1px solid #fff' }}
                      onMouseEnter={() => handleMouseEnter(project_id)}
                      onMouseLeave={() => handleMouseLeave(project_id)}
                    >
                      <div className={classes.item}>
                        <CommonImage src={img_blob || decodedUrl} />
                        <div
                          className={classes.clickDiv}
                          onClick={() => clickChangeProject(project_id)}
                        />
                        {
                          (isEditing || isHovered) && (
                            <CustomCheckbox
                              className={classes.itemSelectBox}
                              checked={isSelected}
                              disabled={isCurrentEditing}
                              onChange={(event) => {
                                handleSelectItem(project_id);
                              }}
                            />
                          )
                        }
                      </div>

                      <div className={classes.itemDesLayout}>
                        <span className={classes.itemDes}>{project_name}</span>
                        <div>
                          <img
                            src={more_icon}
                            aria-describedby={id}
                            onClick={(event) => {
                              event.stopPropagation();
                              handleClick(event, project_id);
                            }}
                          />
                          <Popover
                            id={id}
                            open={openedPopoverId === project_id}
                            anchorEl={anchorEl}
                            onClose={handleClose}
                            classes={{ paper: classess.paper }}
                            transformOrigin={{
                              vertical: 'top',
                              horizontal: 'right',
                            }}
                          >
                            <div className={classes.operatorPopper}>
                              {project_id !== currentEditId.current && (
                                <div
                                  className={classess.operatorItem}
                                  onClick={(event) => {
                                    event.stopPropagation();
                                    itemOperatorDelete(event, project_id);
                                  }}
                                >
                                  {getTranslation(TranslationsKeys.BUTTON_DELETE)}
                                </div>
                              )}
                              <div
                                className={classess.operatorItem}
                                onClick={(event) => {
                                  event.stopPropagation();
                                  itemOperatorSelect(event, project_id);
                                }}
                              >
                                {getTranslation(TranslationsKeys.BUTTON_SELECT)}
                              </div>
                            </div>
                          </Popover>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </Masonry>
          }

        </ScrollMoreView2d>
      </div>
      {
        (((isEditing)) || isItemDeleteId) && <MainUiLeftFooterBar
          selectedItems={selectedItems}
          dataList={projectList}
          selectAll={selectAll}
          handleSelectAll={handleSelectAll}
          handleConfirm={handleDeleteSelected}
          isHandleConfirmSuccess={isNetLoading}
          setIsEditing={handleSetEditing}
          openDialog={openDialog}
          setCloseDialog={handleDialogClose}
          setOpenDialog={handleDialogOpen}
          isShowFooterbar={isShowFooterbar}
          isItemDeleteId={isItemDeleteId}
          dialogDes={t('delete_project_tip', `Are you sure want to delete ${selectedItems.length > 1 ? "these" : "this"} ${isItemDeleteId ? 1 : selectedItems.length} ${selectedItems.length > 1 ? 'projects' : 'project'}?`)}
        />
      }
      <Loading loading={isNetLoading} />
    </div>
  )
}

export default MainUiLeftProject;



