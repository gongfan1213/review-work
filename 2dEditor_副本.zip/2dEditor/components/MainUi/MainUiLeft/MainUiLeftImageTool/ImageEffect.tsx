import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useState } from 'react'
import { useCanvasEditor, useFabric } from 'src/templates/2dEditor/hooks/context';
import * as classes from './imageEffect.module.scss';
import { useSelect } from 'src/templates/2dEditor/hooks/select'
import filter_icon from 'src/images/FilterImg/filter_icon.png';
import { FILTER_IDENTIFIERS } from 'src/templates/2dEditor/components/FrontApps/const'

export default function ImageEffect() {
  const canvasEditor = useCanvasEditor()
  const { t } = useTranslation()
  const activeObject: any = canvasEditor?.canvas.getActiveObject();
  const select = useSelect()
  const selectMode = select?.selectMode;
  // 新增状态来存储当前选中元素的滤镜信息
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [filtersMapData, setFiltersMapData] = useState<any>({})

  // console.log("activeObject====filters=======>", activeObject);

  const ConvoluteData = {
    // 浮雕滤镜
    'Emboss': [-2, -1, 0, -1, 1, 1, 0, 1, 2],
    // 模糊滤镜
    // 'HorizontalBlur': [1 / 9, 1 / 9, 1 / 9, 1 / 9, 1 / 9, 1 / 9, 1 / 9, 1 / 9, 1 / 9],
    // 凹入滤镜
    'Inset': [1, 1, 1, 1, -8, 1, 1, 1, 1],
    // 突出滤镜
    'Outset': [-1, -1, -1, -1, 9, -1, -1, -1, -1],
    // 边缘强化滤镜
    'EdgeEnhance': [0, 1, 0, 1, -4, 1, 0, 1, 0],
    //边缘检测（水平方向）
    'LevelEdge': [-1, 0, 1, -2, 0, 2, -1, 0, 1],
    //  边缘检测（垂直方向）
    'VerticalEdge': [-1, -2, -1, 0, 0, 0, 1, 2, 1],
    // 增强对比度
    'EnhanceContrast': [0, -1, 0, -1, 5, -1, 0, -1, 0],
    // 浮雕效果（另一种）
    'NewEmboss': [2, 0, 0, 0, -1, 0, 0, 0, -1],
    // 高通滤波器（寻找细节）
    'HighPassFilter': [-1, -1, -1, -1, 8, -1, -1, -1, -1]
  };

  // 应用官方无参数自带滤镜
  const applyFilter = (filterName: any) => {
    if (!activeObject) return;
    // 确保每个对象都有一个filtersMap属性
    if (!activeObject.filtersMap) {
      activeObject.filtersMap = {};
    }

    // 检查 fabric.Image 和 fabric.Image.filters 是否已定义
    // @ts-ignore
    if (fabric && fabric.Image && fabric.Image.filters) {
      // 因为此处会跑两次，所以需要判断是否已经应用了滤镜，用了就删掉保留最后一次
      if (activeObject.filtersMap[filterName]) {
        // 检查 filterName 是否存在于 fabric.Image.filters 中
        // @ts-ignore
        if (!(filterName in fabric.Image.filters)) {
          console.log(`Filter ${filterName} does not exist.`);
          return;
        }
        // 动态访问 fabric.Image.filters 中的滤镜类
        // @ts-ignore
        const filterClass = fabric.Image.filters[filterName];
        // 如果已经应用了，则先移除旧的滤镜
        activeObject.filters = activeObject.filters.filter(
          (f: any) => !(f instanceof filterClass)
        );
      }
    } else {
      console.log('fabric.Image 或 fabric.Image.filters 未定义');
    }

    let filter;
    switch (filterName) {
      case 'BlackWhite':
        // @ts-ignore
        filter = new fabric.Image.filters.BlackWhite();
        break;
      case 'Sepia':
        // @ts-ignore
        filter = new fabric.Image.filters.Sepia();
        break;
      case 'Grayscale':
        // @ts-ignore
        filter = new fabric.Image.filters.Grayscale();
        break;
      case 'Invert':
        // @ts-ignore
        filter = new fabric.Image.filters.Invert();
        break;
      case 'Brownie':
        // @ts-ignore
        filter = new fabric.Image.filters.Brownie();
        break;
      case 'Vintage':
        // @ts-ignore
        filter = new fabric.Image.filters.Vintage();
        break;
      case 'Kodachrome':
        // @ts-ignore
        filter = new fabric.Image.filters.Kodachrome();
        break;
      case 'Technicolor':
        // @ts-ignore
        filter = new fabric.Image.filters.Technicolor();
        break;
      case 'Polaroid':
        // @ts-ignore
        filter = new fabric.Image.filters.Polaroid();
        break;
      default:
        return;
    }

    activeObject.filters.push(filter);
    activeObject.filtersMap[filterName] = filter;
    activeObject.applyFilters();
    canvasEditor?.canvas.renderAll();
  };

  // 设置浮雕滤镜,固定参数
  const Convolute = (data: any, filterClass: any) => {
    if (!activeObject) return
    canvasEditor?.setConvolute(activeObject, data, filterClass);
  }

  const applyOldPhoto = () => {
    if (activeObject) {
      canvasEditor?.setOldPhoto(activeObject);
    }
  }

  const applyHighlight = () => {
    if (activeObject) {
      canvasEditor?.setHighlight(activeObject);
    }
  }

  const filterEffects = [
    // 自定义滤镜
    { label: '浮雕滤镜', action: () => Convolute(ConvoluteData['Emboss'], FILTER_IDENTIFIERS.EMBOSS), text: 'Emboss', icon: filter_icon },
    // { label: '模糊滤镜', action: () => Convolute(ConvoluteData['HorizontalBlur'], FILTER_IDENTIFIERS.HORIZONTAL_BLUR), text: 'HorizontalBlur', icon: filter_icon },
    { label: '老照片滤镜', action: applyOldPhoto, text: 'oldPhoto', icon: filter_icon },
    { label: '高光滤镜', action: applyHighlight, text: 'Highlight', icon: filter_icon },
    { label: '凹入滤镜', action: () => Convolute(ConvoluteData['Inset'], FILTER_IDENTIFIERS.INSET), text: 'Inset', icon: filter_icon },
    { label: '突出滤镜', action: () => Convolute(ConvoluteData['Outset'], FILTER_IDENTIFIERS.OUTSET), text: 'Outset', icon: filter_icon },
    { label: '边缘强化', action: () => Convolute(ConvoluteData['EdgeEnhance'], FILTER_IDENTIFIERS.EDGE_ENHANCE), text: 'EdgeEnhance', icon: filter_icon },
    { label: '边缘检测(水平方向)', action: () => Convolute(ConvoluteData['LevelEdge'], FILTER_IDENTIFIERS.LEVEL_EDGE), text: 'LevelEdge', icon: filter_icon },
    { label: '边缘检测(垂直方向)', action: () => Convolute(ConvoluteData['VerticalEdge'], FILTER_IDENTIFIERS.VERTICAL_EDGE), text: 'VerticalEdge', icon: filter_icon },
    { label: '增强对比度', action: () => Convolute(ConvoluteData['EnhanceContrast'], FILTER_IDENTIFIERS.ENHANCE_CONTRAST), text: 'EnhanceContrast', icon: filter_icon },
    { label: '浮雕效果(另一种)', action: () => Convolute(ConvoluteData['NewEmboss'], FILTER_IDENTIFIERS.NEW_EMBOSS), text: 'NewEmboss', icon: filter_icon },
    { label: '高通滤波器(寻找细节)', action: () => Convolute(ConvoluteData['HighPassFilter'], FILTER_IDENTIFIERS.HIGH_PASS_FILTER), text: 'HighPassFilter', icon: filter_icon },
    // 官方滤镜
    { label: '黑白滤镜', action: () => applyFilter('BlackWhite'), text: 'BlackWhite', icon: filter_icon },
    { label: '棕褐色滤镜', action: () => applyFilter('Sepia'), text: 'Sepia', icon: filter_icon },
    { label: '灰度滤镜', action: () => applyFilter('Grayscale'), text: 'Grayscale', icon: filter_icon },
    { label: '反色滤镜', action: () => applyFilter('Invert'), text: 'Invert', icon: filter_icon },
    { label: '巧克力滤镜', action: () => applyFilter('Brownie'), text: 'Brownie', icon: filter_icon },
    { label: '复古滤镜', action: () => applyFilter('Vintage'), text: 'Vintage', icon: filter_icon },
    { label: '胶片滤镜', action: () => applyFilter('Kodachrome'), text: 'Kodachrome', icon: filter_icon },
    { label: '鲜艳滤镜', action: () => applyFilter('Technicolor'), text: 'Technicolor', icon: filter_icon },
    { label: '高光滤镜', action: () => applyFilter('Polaroid'), text: 'Polaroid', icon: filter_icon },
  ];

  const inputClick = (e: any, effectName: any, effectClick: any) => {
    // console.log("effectName-=-=-=", effectName,);
    // 选中时
    if (e.target.checked) {
      effectClick();
      setSelectedFilters(prev => [...prev, effectName]);
    } else {
      setSelectedFilters(prev => prev.filter(name => name !== effectName));
      canvasEditor?.removeSpecificFilters(activeObject, [effectName], filtersMapData)
    }
  }

  // 更换不同的对象时，更新input选中框的状态
  useEffect(() => {
    // console.log("activeObject", activeObject);
    if (activeObject && activeObject.filtersMap) {
      const filtersMap = activeObject.filtersMap;
      // console.log("-----切换画布上的对象，", filtersMap);

      setFiltersMapData(filtersMap)
      // 将filtersMap的键提取出来，设置为selectedFilters
      const filterKeys = Object.keys(filtersMap);
      setSelectedFilters(filterKeys);
    } else {
      setSelectedFilters([]);
    }
  }, [selectMode, activeObject?.id]);

  return (
    <div className={classes.effect_container}>
      {
        filterEffects.map((item, index) => {
          const isChecked = selectedFilters.includes(item.text);
          // 为每个图片元素添加一个 onClick 事件处理器
          const handleImageClick = () => {
            // 找到与图片对应的 input 元素
            const inputElement = document.getElementById(`input-${item.text}`);
            // 如果找到了 input 元素，则模拟点击它
            if (inputElement) {
              inputElement.click();
            }
          };
          return (
            <div key={index} className={classes.effect_box}>
              <img src={item?.icon} className={classes.effect_img} onClick={handleImageClick} />
              <div className={classes.btn} onClick={item.action}>
                <input id={`input-${item.text}`} type='checkbox' checked={isChecked} onChange={(e) => inputClick(e, item.text, item.action)} />
                <div onClick={(e)=>{e.stopPropagation(),handleImageClick()}}>
                  {item.label}
                </div>
              </div>
            </div>
          )
        })
      }
    </div>
  )
}
