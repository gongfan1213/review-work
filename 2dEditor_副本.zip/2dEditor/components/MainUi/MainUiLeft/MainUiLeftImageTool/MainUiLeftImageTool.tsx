import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useState } from 'react'
import { useCanvasEditor, useEvent } from 'src/templates/2dEditor/hooks/context';
import TabSwitcher from 'src/templates/2dEditor/common/widget/TabSwitcher/TabSwitcher';
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';

import ImageAdjustment from './ImageAdjustment copy';
import ImageEffect from './ImageEffect';

import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import * as classes from './index.module.scss';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import close from "src/assets/svg/close.svg";


export enum ImageEditTabValue {
  ImageEditTab1 = 0,
  ImageEditTab2 = 1,
  ImageEditTab3 = 2,
  ImageEditTab4 = 3,
  ImageEditTabRemove = 10,
}

interface IMainUiLeftImageAdjustmentProps {
  selectNum: number;
}

export default function MainUiLeftImageTool(pros: IMainUiLeftImageAdjustmentProps) {
  const canvasEditor = useCanvasEditor()
  const { getTranslation } = useCustomTranslation();
  const event = useEvent();
  const [active, setActive] = useState<number>(pros.selectNum);
  // console.log(" ========activeTab");

  const tabs = [
    { tabName: getTranslation(TranslationsKeys.STR_COMMON_ADJUSTMENT), tabValue: ImageEditTabValue.ImageEditTab1 },
    { tabName: getTranslation(TranslationsKeys.STR_COMMON_EFFECT), tabValue: ImageEditTabValue.ImageEditTab2 },
    // { tabName: t("str_common_overlay", "Overlay"), tabValue: ImageEditTabValue.ImageEditTab3 },
    // { tabName: t("str_common_filter", "Filter"), tabValue: ImageEditTabValue.ImageEditTab4 },
  ];

  const handleTabChange = (tab: any) => {
    setActive(tab.tabValue);
  };

  function showTabView(active: number) {
    // ajustment;
    if (active === ImageEditTabValue.ImageEditTab1) {
      return <ImageAdjustment />
    }
    // effect;
    else if (active === ImageEditTabValue.ImageEditTab2) {
      return <ImageEffect />
    }
    // overlay;
    else if (active === ImageEditTabValue.ImageEditTab3) {
      return <></>
    }
    // filter;
    else if (active === ImageEditTabValue.ImageEditTab4) {
      return <></>
    }
  }

  const closeLeftbar = () => {
    event?.emitEvent(EventNameCons.OpenImageTool, false);
  }

  useEffect(() => {
    // console.log("pros.selectNum", pros.selectNum);
    setActive(pros.selectNum);
  }, [pros.selectNum])

  return (
    <div className={classes.image_leftbar_container}>
      <div className={`${BaseStyles.txt24} ${classes.title_div}`}>
        <p>{getTranslation(TranslationsKeys.STR_COMMON_EDIT)}</p>
        {/* <img src={close} onClick={() => { closeLeftbar() }} /> */}
      </div>
      <TabSwitcher tabs={tabs} onTabChange={handleTabChange} nowTab={active} />
      {showTabView(active)}
    </div>
  )
}
