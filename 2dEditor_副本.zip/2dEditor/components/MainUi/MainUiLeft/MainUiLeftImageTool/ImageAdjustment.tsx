import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useState, useRef } from 'react'
import { useCanvasEditor, useFabric } from 'src/templates/2dEditor/hooks/context';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import CusSeekBar from 'src/templates/2dEditor/common/widget/SeekBar/CusSeekBar';
import * as classes from './imageAdjustment.module.scss';
import { uiType, paramsFilters, combinationFilters } from './config/filter';

export default function ImageAdjustment() {
  const canvasEditor = useCanvasEditor();
  const fabric = useFabric() as any;
  const { t } = useTranslation();
  const activeObject = canvasEditor?.canvas.getActiveObject();

  useEffect(() => {
  }, [activeObject])
  // 重置;
  const handleRestoreClick = () => { };

  const [brightness, setBrightness] = useState<number>(0);
  const [contrast, setContrast] = useState<number>(0);
  const [saturation, setSaturation] = useState<number>(0);
  const [vibrance, setVibrance] = useState<number>(0);
  const [noise, setNoise] = useState<number>(0);
  const [pixelate, setPixelate] = useState<number>(0);
  const [blur, setBlur] = useState<number>(0);
  const [grayscale, setGrayscale] = useState<number>(0);
  const [removeColor, setRemoveColor] = useState<number>(0);
  const [gamma, setGamma] = useState<number>(0);

  const state = useRef({
    uiType,
    // noParamsFilters,
    paramsFilters: [...paramsFilters],
    combinationFilters: [...combinationFilters],
    type: '',
  })

  enum AjustmentType {
    Brightness = "Brightness", // 亮度
    Contrast = "Contrast", // 对比
    Saturation = "Saturation", // 饱和
    Vibrance = "Vibrance", // 鲜艳
    Noise = "Noise", // 噪音
    Pixelate = "Pixelate", // 像素
    Blur = "Blue", // 模糊
    Grayscale = "Grayscale", // 灰度
    RemoveColor = "RemoveColor", // 去色
    Gamma = "Gamma", // 调整
  }

  // #region 处理图片 has problem;
  // const handler = (type: AjustmentType, value: number) => {
  //   if (!activeObject) return;
  //   // Brightness 亮度;
  //   if (type === AjustmentType.Brightness) {
  //     const useValue = value / 100;
  //     console.log("useValue", useValue);
  //     console.log("value", value);
  //     setBrightness(value);
  //     const brightnessFilter = new fabric.Image.filters.Brightness({
  //       brightness: useValue,
  //     });
  //     activeObject.filters = activeObject.filters.filter(
  //       (obj) => obj.type !== type
  //     );
  //     activeObject.filters.push(brightnessFilter as filters.BaseFilter);
  //   }
  //   // Contrast 对比;
  //   else if (type === AjustmentType.Contrast) {
  //     setContrast(value);
  //     const contrastFilter = new fabric.filters.Contrast({ contrast: value });
  //     activeObject.filters = activeObject.filters.filter(
  //       (obj) => obj.type !== type
  //     );
  //     activeObject.filters.push(contrastFilter as filters.BaseFilter);
  //   }
  //   // Saturation 饱和;
  //   else if (type === AjustmentType.Saturation) {
  //     setSaturation(value);
  //     const saturationFilter = new fabric.filters.Saturation({
  //       saturation: value,
  //     });
  //     activeObject.filters = activeObject.filters.filter(
  //       (obj) => obj.type !== type
  //     );
  //     activeObject.filters.push(saturationFilter as filters.BaseFilter);
  //   }
  //   // Vibrance 鲜艳;
  //   else if (type === AjustmentType.Vibrance) {
  //     setVibrance(value);
  //     const vibranceFilter = new fabric.filters.Vibrance({ vibrance: value });
  //     activeObject.filters = activeObject.filters.filter(
  //       (obj) => obj.type !== type
  //     );
  //     activeObject.filters.push(vibranceFilter as filters.BaseFilter);
  //   }
  //   // Hue 色调;
  //   else if (type === AjustmentType.Hue) {
  //     setHue(value);
  //     const hueFilter = new fabric.filters.HueRotation({ rotation: value });
  //     activeObject.filters = activeObject.filters.filter(
  //       (obj) => obj.type !== type
  //     );
  //     activeObject.filters.push(hueFilter as filters.BaseFilter);
  //   }
  //   // Noise 噪音;
  //   else if (type === AjustmentType.Noise) {
  //     setNoise(value);
  //     const noiseFilter = new fabric.filters.Noise({ noise: value });
  //     activeObject.filters = activeObject.filters.filter(
  //       (obj) => obj.type !== type
  //     );
  //     activeObject.filters.push(noiseFilter as filters.BaseFilter);
  //   }
  //   // Pixelate 像素;
  //   else if (type === AjustmentType.Pixelate) {
  //     setPixelate(value);
  //     const pixelateFilter = new fabric.filters.Pixelate({ blocksize: value });
  //     activeObject.filters = activeObject.filters.filter(
  //       (obj) => obj.type !== type
  //     );
  //     activeObject.filters.push(pixelateFilter as filters.BaseFilter);
  //   }
  //   // Blur 模糊;
  //   else if (type === AjustmentType.Blur) {
  //     setBlur(value);
  //     const blurFilter = new fabric.filters.Blur({ blur: value });
  //     activeObject.filters = activeObject.filters.filter(
  //       (obj) => obj.type !== type
  //     );
  //     activeObject.filters.push(blurFilter as filters.BaseFilter);
  //   }
  //   activeObject.applyFilters();
  //   canvasEditor?.canvas.requestRenderAll();
  // };
  // #endregion ;
  const handler = (type: AjustmentType) => {
    console.log(type);
    const activeObject = canvasEditor?.canvas.getActiveObject();
    const filtersAll = [...state.current.paramsFilters, ...state.current.combinationFilters];
    const moduleInfo = filtersAll.find((item) => item.type === type);
    console.log("moduleInfo;", moduleInfo);
    if (moduleInfo.status) {
      // 组合参数滤镜修改
      if (moduleInfo.handler) {
        _changeAttrByHandler(moduleInfo);
      } else {
        // 有参数滤镜修改
        moduleInfo.params.forEach((paramsItem) => {
          _changeAttr(type, paramsItem.key, paramsItem.value);
        });
      }
    } else {
      _removeFilter(activeObject, type);
    }
  }
  // #region filter utils;
  // 设置滤镜值
  function _changeAttr(type, key, value) {
    const activeObject = canvasEditor?.canvas.getActiveObject();
    const itemFilter = _getFilter(activeObject, type);
    if (itemFilter) {
      itemFilter[key] = value;
    } else {
      const imgFilter = _createFilter(activeObject, type);
      imgFilter[key] = value;
    }
    //@ts-ignore;
    activeObject.applyFilters();
    canvasEditor?.canvas.renderAll();
  }

  function _changeAttrByHandler(moduleInfo) {
    const activeObject = canvasEditor?.canvas.getActiveObject();
    // 删除
    _removeFilter(activeObject, moduleInfo.type);
    // 创建
    const params = moduleInfo.params.map((item) => item.value);
    _createFilter(activeObject, moduleInfo.type, moduleInfo.handler(...params));
  }

  /**
 * Create filter instance
 * @param {fabric.Image} sourceImg - Source image to apply filter
 * @param {string} type - Filter type
 * @param {Object} [options] - Options of filter
 * @returns {Object} Fabric object of filter
 * @private
 */
  function _createFilter(sourceImg, type, options = null) {
    let filterObj;
    // capitalize first letter for matching with fabric image filter name
    const fabricType = _getFabricFilterType(type);
    const ImageFilter = fabric.Image.filters[fabricType];
    if (ImageFilter) {
      filterObj = new ImageFilter(options);
      filterObj.options = options;
      sourceImg.filters.push(filterObj);
    }
    sourceImg.applyFilters();
    canvasEditor?.canvas.renderAll();
    return filterObj;
  }
  /**
   * Get applied filter instance
   * @param {fabric.Image} sourceImg - Source image to apply filter
   * @param {string} type - Filter type
   * @returns {Object} Fabric object of filter
   * @private
   */
  function _getFilter(sourceImg, type) {
    let imgFilter = null;

    if (sourceImg) {
      const fabricType = _getFabricFilterType(type);
      const { length } = sourceImg.filters;
      let item, i;

      for (i = 0; i < length; i += 1) {
        item = sourceImg.filters[i];
        if (item.type === fabricType) {
          imgFilter = item;
          break;
        }
      }
    }

    return imgFilter;
  }
  /**
   * Remove applied filter instance
   * @param {fabric.Image} sourceImg - Source image to apply filter
   * @param {string} type - Filter type
   * @private
   */
  function _removeFilter(sourceImg, type) {
    const fabricType = _getFabricFilterType(type);
    sourceImg.filters = sourceImg.filters.filter((value) => value.type !== fabricType);
    sourceImg.applyFilters();
    canvasEditor?.canvas.renderAll();
  }
  /**
   * Change filter class name to fabric's, especially capitalizing first letter
   * @param {string} type - Filter type
   * @example
   * 'grayscale' -> 'Grayscale'
   * @returns {string} Fabric filter class name
   */
  function _getFabricFilterType(type) {
    return type.charAt(0).toUpperCase() + type.slice(1);
  }
  // #endregion ;

  return (
    <div className={classes.ajustment_container}>
      <div className={classes.ajustment_div}>
        {/* brightness 亮度; */}
        <div className={classes.typeWrap}>
          <div className={`${BaseStyles.txt14} ${classes.typeText}`}>{t('str_common_brightness', 'Brightness')}</div>
          <div style={{ width: "240px" }}>
            <CusSeekBar min={-100} max={100} defaultValue={brightness} onChange={(e) => { handler(AjustmentType.Brightness) }} />
          </div>
        </div>
        {/* contrast 对比; */}
        <div className={classes.typeWrap}>
          <div className={`${BaseStyles.txt14} ${classes.typeText}`}>{t('str_common_contrast', 'Contrast')}</div>
          <div style={{ width: "240px" }}>
            <CusSeekBar min={-100} max={100} defaultValue={brightness} onChange={() => { }} />
          </div>
        </div>

        {/* 
        {getTypeUi(t('str_common_brightness', 'Brightness'), brightness, setImageBrightness)}
        {getTypeUi(t('str_common_saturation', 'Saturation'), saturation, setImageSaturation)}
        {getTypeUi(t('str_common_contrast', 'Contrast'), contrast, setImageContrast)}
        {getTypeUi(t('str_common_gamma', 'Gamma'), gamma, setImageGamma)}
        <div className={classes.placeholder_line_div}>
          <span></span>
        </div>
        {getTypeUi(t('str_common_clarify', 'Clarify'), clarify, setImageClarify)}
        {getTypeUi(t('str_common_exposure', 'Exposure'), brightness, setImageBrightness)}
        {getTypeUi(t('str_common_shadows', 'Shadows'), brightness, setImageSetShadows)}
        {getTypeUi(t('str_common_highlight', 'Highlight'), brightness, setImageBrightness)}
        {getTypeUi(t('str_common_blacks', 'Blacks'), brightness, setImageBrightness)}
        {getTypeUi(t('str_common_whites', 'Whites'), brightness, setImageBrightness)}
        {getTypeUi(t('str_common_temperature', 'Temperature'), brightness, setImageBrightness)}
        {getTypeUi(t('str_common_sharpness', 'Sharpness'), brightness, setImageBrightness)} 
        */}
      </div>
      <div className={classes.button_div}>
        <button className={classes.restore_button} onClick={() => { handleRestoreClick() }}>Restore</button>
      </div>
    </div>
  )
}
