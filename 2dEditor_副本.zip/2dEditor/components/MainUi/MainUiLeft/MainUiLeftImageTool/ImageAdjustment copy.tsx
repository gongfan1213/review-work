import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useState } from 'react'
import { useCanvasEditor, useFabric, useEvent } from 'src/templates/2dEditor/hooks/context';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import CusSeekBar from 'src/templates/2dEditor/common/widget/SeekBar/CusSeekBar';
import * as classes from './imageAdjustment.module.scss';
import { useSelect } from 'src/templates/2dEditor/hooks/select'
import {
  CustomKey,
  EventNameCons,
  FabricObjectType,
} from 'src/templates/2dEditor/cons/2dEditorCons'

export default function ImageAdjustment() {
  const canvasEditor = useCanvasEditor()
  const { t } = useTranslation()
  const [brightness, setBrightness] = useState<number>(0);//亮度
  const [saturation, setSaturation] = useState<number>(0);//饱和度
  const [contrast, setContrast] = useState<number>(0); //对比度
  const [gamma, setGamma] = useState<number>(0); //伽马
  const [clarify, setClarify] = useState<number>(0); //清晰度
  const [shadows, setShadows] = useState<number>(0); //阴影
  const [blur, setBlur] = useState<number>(0); //模糊
  const [hueRotation, setHueRotation] = useState<number>(0); //色调旋转
  const [Pixelate, setPixelate] = useState<number>(0); //像素化
  const select = useSelect()
  const selectMode = select?.selectMode;
  const event = useEvent()

  // brightness 亮度
  // contrast 对比
  // saturation 饱和
  // vivid 鲜艳
  // hue 色调
  // noise 噪音
  // pixel 像素
  // blur 模糊

  // 当前选中的画布元素（单个对象）
  const activeObject: any = canvasEditor?.canvas.getActiveObject();
  console.log("canvasEditor有啥方法-----", activeObject?.src, activeObject);

  // 监听selectMode可以实时更新
  //canvasEditor?.getBrightness(activeObject)中获取activeObject的Brightness值，然后设置到setBrightness中
  useEffect(() => {
    // console.log("------jinru 进入useeffect", activeObject);
    //  不为图片类型，或者没有选中对象，不显示调整工具，需要关闭调整工具
    if (activeObject?.type !== 'image' || !activeObject) {
      //   event?.emitEvent(
      //     EventNameCons.OpenImageTool,
      //     false,
      //     // ImageEditTabValue.ImageEditTab1,
      //   )
      // console.log("-----------shezhi 为0");
      setBrightness(0)
      setSaturation(0)
      setContrast(0)
      setGamma(0)
      setClarify(0)
      setShadows(0)
      setBlur(0)
      setHueRotation(0)
      setPixelate(0)
      return;
    };
    console.log(canvasEditor?.getBrightness(activeObject) * 100,'canvasEditor?.getBrightness(activeObject) * 100');
    
    setBrightness(Math.round(canvasEditor?.getBrightness(activeObject) * 100))
    setSaturation(Math.round(canvasEditor?.getSaturation(activeObject) * 100))
    setContrast(Math.round(canvasEditor?.getContrast(activeObject) * 100))
    setGamma(Math.round(canvasEditor?.getGamma(activeObject) * 100))
    setClarify(Math.round(canvasEditor?.getClarify(activeObject) * 100))
    setShadows(Math.round(canvasEditor?.getShadows(activeObject) * 100))
    setBlur(Math.round(canvasEditor?.getBlur(activeObject) * 100))
    setHueRotation(Math.round(canvasEditor?.getHueRotation(activeObject) * 100))
    setPixelate(Math.round(canvasEditor?.getPixelate(activeObject)))
  }, [activeObject?.id, selectMode])

  const setImageBrightness = (value: number) => {
    setBrightness(value)
    canvasEditor?.setBrightness(activeObject, value / 100)
  }

  const setImageSaturation = (value: number) => {
    setSaturation(value)
    canvasEditor?.setSaturation(activeObject, value / 100)
  }

  const setImageContrast = (value: number) => {
    setContrast(value)
    canvasEditor?.setContrast(activeObject, value / 100)
  }

  const setImageGamma = (value: number) => {
    setGamma(value)
    canvasEditor?.setGamma(activeObject, value / 100)
  }

  const setImageClarify = (value: number) => {
    setClarify(value)
    canvasEditor?.setClarify(activeObject, value / 100)
  }

  const setImageSetShadows = (value: number) => {
    setShadows(value)
    const fabricValue = value / 100;
    canvasEditor?.setShadows(activeObject, fabricValue)
  }

  const setImageSetBlur = (value: number) => {
    setBlur(value)
    canvasEditor?.setBlur(activeObject, value / 100)
  }

  const setImageHueRotation = (value: number) => {
    setHueRotation(value)
    canvasEditor?.setHueRotation(activeObject, value / 100)
  }

  const setImagePixelate = (value: number) => {
    setPixelate(value)
    canvasEditor?.setPixelate(activeObject, value / 100)
  }

  const getTypeUi = (typeStr: string, valueDef: number, onChange: (value: number) => void) => {
    // console.log("valueDef", valueDef);
    return (
      <div className={classes.typeWrap}>
        <div className={`${BaseStyles.txt14} ${classes.typeText}`}>{typeStr}</div>
        <div style={{ width: "240px" }}>
          <CusSeekBar min={-100} max={100} defaultValue={valueDef} onChange={onChange} />
        </div>
      </div>
    )
  }

  // restore;
  const handleRestoreClick = () => {

  };

  return (
    <div className={classes.ajustment_container}>
      <div className={classes.ajustment_div}>
        {getTypeUi(t('str_common_brightness', 'Brightness'), brightness, setImageBrightness)}
        {getTypeUi(t('str_common_contrast', 'Contrast'), contrast, setImageContrast)}
        {getTypeUi(t('str_common_saturation', 'Saturation'), saturation, setImageSaturation)}
        {getTypeUi(t('str_common_gamma', 'Gamma'), gamma, setImageGamma)}
        {/* <div className={classes.placeholder_line_div}>
          <span></span>
        </div> */}
        {getTypeUi(t('str_common_clarify', 'Clarify'), clarify, setImageClarify)}
        {/* {getTypeUi(t('str_common_exposure', 'Exposure'), brightness, setImageBrightness)} */}
        {getTypeUi(t('str_common_shadows', 'Shadows'), shadows, setImageSetShadows)}
        {getTypeUi(t('str_common_blur', 'Blur'), blur, setImageSetBlur)}
        {getTypeUi(t('str_common_HueRotation', 'HueRotation'), hueRotation, setImageHueRotation)}
        {getTypeUi(t('str_common_Pixelate', 'Pixelate'), Pixelate, setImagePixelate)}
        {/* {getTypeUi(t('str_common_highlight', 'Highlight'), brightness, setImageBrightness)} */}
        {/* {getTypeUi(t('str_common_blacks', 'Blacks'), brightness, setImageBrightness)} */}
        {/* {getTypeUi(t('str_common_whites', 'Whites'), brightness, setImageBrightness)} */}
        {/* {getTypeUi(t('str_common_temperature', 'Temperature'), brightness, setImageBrightness)} */}
        {/* {getTypeUi(t('str_common_sharpness', 'Sharpness'), brightness, setImageBrightness)} */}
      </div>
      <div className={classes.button_div}>
        <button className={classes.restore_button} onClick={() => { handleRestoreClick() }}>Restore</button>
      </div>
    </div>
  )
}
