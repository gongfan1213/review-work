// start_ai_generated 
// 依赖
import React, { useEffect, useRef, useState } from 'react';

// 组件
import { Tabs, TabPanel } from 'react-tabs';
import Menu from '../../Menu';
import FrontApps from '../../FrontApps';
import ImportTmpl from '../../ImportTmpl';
import ElementMenus from '../../ElementMenus';
import TextMenus from '../../TextMenus';
import MainUiLeftTextTool from './MainUiLeftTextTool';
import MainUiLeftProject from './MainUiLeftProject/MainUiLeftProject';
import MainUiLeftUpload from './MainUiLeftUpload/MainUiLeftUpload';
import MainUiLeftImageTool, { ImageEditTabValue } from './MainUiLeftImageTool/MainUiLeftImageTool';
import TextureLib from '../../TextureEdit/TextureLib';
import Craft from 'src/templates/2dEditor/components/Craft/index';
import { get } from 'src/services';

// 外部引用 
import { EventNameCons, LeftTabValue } from 'src/templates/2dEditor/cons/2dEditorCons';
import { useEvent } from 'src/templates/2dEditor/hooks/context';

// 样式
import * as classes from './index.module.scss';
import { truncate } from 'fs/promises';

// icon
import appbar_close_icon from 'src/assets/img/appbar_close_icon.png';

const MainUiLeft = (props: any) => {

  const { activeValue, allRight_state, location, allRight_click, showLeftTabPanel, setShowLeftTabPanel } = props
  const [active, setActive] = useState<number>(0);
  const [imggeToolSelectNum, setImggeToolSelectNum] = useState<number>(0);
  // 需要展示的相应侧边栏的内容，1：Typeface，2：Transform
  const [textToolSelectNum, setTextToolSelectNum] = useState<number>(0);
  const event = useEvent();
  const mLastTab = useRef<number>(0);
  const showCLoseIcon = useRef<boolean>(true);
  const [showIcon, setShowIcon] = useState<boolean>(true);
  const [craftList, setCraftList] = React.useState(['Texture Lib', 'Relief Maker']);
  const pageTitle = ['textureLib', 'reliefMaker'];
  const [defaultCraft, setDefaultCraft] = useState<string>({} as any);
  const AiTitle = typeof window !== 'undefined'
    ? window.sessionStorage.getItem('AiTitle') || ''
    : '';

  const getCraftList = async () => {
    const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
      content_type: 'make-2d-all-tools',
      populate: [
        'image',
        'toolClass.class_name',
        'frontType.frontName',
      ],
      filters: { toolClass: { class_name: { $eq: 'fractalDimension' } } },
      pagination: {
        page: 1,
        pageSize: 10000,
      },
      sort: ['weight:DESC'], // 按weight降序排列
    });
    console.log('----AiTitle', AiTitle)
    let tempTab = [] as any;
    if (json?.data?.data?.length > 0) {
      let tempTitleArr = [] as any;
      json.data.data.map((item: any, index: number) => {
        console.log('---index', index, pageTitle[index])
        const { title, description, image } = item.attributes;
        tempTitleArr.push(title);
        const obj = { img: image.data?.attributes?.url, title, description, pageTag: pageTitle[index] };
        tempTab.push(obj);
        if (AiTitle == title) {
          setDefaultCraft(obj);
        }
      });
      // setCraftList(tempArr);
      setCraftList(tempTitleArr);
    }
  }

  useEffect(() => {
    getCraftList();
  }, [])

  useEffect(() => {
    event?.on(EventNameCons.OpenImageTool, showImageAdjustment)
    event?.on(EventNameCons.OpenTextTool, showTextAdjustment)
    event?.on(EventNameCons.EventHiddenCloseIcon, hiddenCloseIcon)
    return () => {
      eventOff();
    }
  })

  const eventOff = () => {
    event?.off(EventNameCons.OpenImageTool, showImageAdjustment)
    event?.off(EventNameCons.OpenTextTool, showTextAdjustment)
    event?.off(EventNameCons.EventHiddenCloseIcon, hiddenCloseIcon)
  }

  const hiddenCloseIcon = (value: boolean) => {
    // alert(1)
    console.log('==============', value)
    // showCLoseIcon.current = value;
    // console.log('-------------',showCLoseIcon.current)
    setShowIcon(value)
  }

  const ShowLeftTabHandle = () => {
    setShowLeftTabPanel(false);
    if (allRight_state?.state) {
      allRight_click(false)
    }
  }

  function showImageAdjustment(flag: boolean, selectNum: number) {
    if (flag) {
      if (selectNum === ImageEditTabValue.ImageEditTabRemove) {
        setActive(mLastTab.current)
        return;
      }
      setImggeToolSelectNum(selectNum);
      onChangeMenu(LeftTabValue.LeftTabValueImageAdjustment)
    } else {
      onChangeMenu(LeftTabValue.LeftTabUpload);
    }
  }

  // show leftbar text menu;
  function showTextAdjustment(flag: boolean, selectNum: number) {
    console.log("show text ajustment; flag, selectNum;", flag, selectNum);
    if (flag) {
      // 只有当flag为true时，才会展示textTool的内容，所以放在内部设置
      setTextToolSelectNum(selectNum);
      onChangeMenu(LeftTabValue.LeftTabValueTextAdjustment);
    } else {
      console.log('active value;', activeValue);
      console.log('active;', active);
      // 失焦时触发的方法
      // onChangeMenu(LeftTabValue.LeftTabValueText);
    }
  }

  function onChangeMenu(active: number) {
    props.setIsExport && props.setIsExport(active)
    // 在useEffect里面监听这3个事件每次刷新都执行，所以在切换菜单的时候要先取消监听，不然就会重复执行监听事件，导致切换菜单内容显示不正确 
    eventOff();
    console.log('==========active', active)
    setShowLeftTabPanel(true);
    allRight_click(false)
    setActive(active)
    activeValue(active)
    if (active === LeftTabValue.LeftTabApps
      || active === LeftTabValue.LeftTabValueModel
      || active === LeftTabValue.LeftTabValueElements
      || active === LeftTabValue.LeftTabValueText
      || active === LeftTabValue.LeftTabProject
      || active === LeftTabValue.LeftTabUpload
      || active === LeftTabValue.LeftCraft
    ) {
      mLastTab.current = active;
    }
    event?.emit(EventNameCons.EventHideZoomSelect);
    event?.emit(EventNameCons.EventHideLayerTreeList);
  }

  function handleShowTab(activeMune: string) {
    console.log('--activeMune', activeMune)
    // 如果当前是在aiTool菜单界面并且进入第二层级展示内容的时候，由于右上角有tips的出现，所以再次点击menu的时候不需要展示icon
    if (activeMune === 'aiTools' && !showIcon) return;
    if (['textureLib', 'reliefMaker'].includes(activeMune)) {
      setShowIcon(false);
      return;
    }
    setShowIcon(true);
    if (!showLeftTabPanel) {
      setShowLeftTabPanel(true);
    }
  }

  return (

    <div className={classes.layout} style={{ width: (showLeftTabPanel && !allRight_state?.state) ? 469 : 'auto' }}>
      <div className={classes.tabLeft} >
        <Menu craftList={craftList} onChangeMenu={onChangeMenu} handleShowTab={handleShowTab} showLeftTabPanel={showLeftTabPanel} fatherActive={active}></Menu>
      </div>

      {showLeftTabPanel && showIcon &&
        <img src={appbar_close_icon} className={classes.closeTabIcon} onClick={() => ShowLeftTabHandle()} />
      }
      <Tabs style={{ display: showLeftTabPanel ? '' : 'none' }} selectedIndex={active} className={classes.tabs} onSelect={(index) => setActive(index)}>
        <TabPanel>
          <FrontApps location={location} />
        </TabPanel>
        <TabPanel>
          <Craft allRight_state={allRight_state} handleShowTab={handleShowTab} defaultCraft={defaultCraft} craftList={craftList} AiTitle={AiTitle} />
          {/* <TextureLib allRight_state={allRight_state} /> */}
        </TabPanel>
        <TabPanel>
          <ImportTmpl />
        </TabPanel>
        <TabPanel>
          <ElementMenus />
        </TabPanel>
        <TabPanel>
          <TextMenus />
        </TabPanel>
        <TabPanel>
          <MainUiLeftUpload allRight_state={allRight_state} />
        </TabPanel>
        <TabPanel>
          <MainUiLeftProject allRight_state={allRight_state} />
        </TabPanel>
        <TabPanel>
          <MainUiLeftImageTool selectNum={imggeToolSelectNum} />
        </TabPanel>
        <TabPanel>
          <MainUiLeftTextTool selectNum={textToolSelectNum} />
        </TabPanel>
      </Tabs>
    </div>
  );
};

export default MainUiLeft;
// end_ai_generated 