import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useState, useRef } from 'react';
import * as classes from './MainUiTopToolFont.module.scss'
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
// import ic_opacity from 'src/assets/svg/ic_opacity.svg';
import ic_opacity from 'src/assets/svg/opacity.svg'
import ic_border_weight from 'src/assets/svg/border_weight.svg';
import ic_font_size from 'src/assets/svg/font_size.svg';
import ic_line_height from 'src/assets/svg/line_height.svg';
import ic_line_gap from 'src/assets/svg/line_gap.svg';
import ic_font_weight from 'src/assets/svg/font_weight.svg';
import ic_font_italic from 'src/assets/svg/font_italic.svg';
import ic_font_left from 'src/assets/svg/font_left.svg';
import ic_font_center from 'src/assets/svg/font_center.svg';
import ic_font_right from 'src/assets/svg/font_right.svg';
import ic_font_justify from 'src/assets/svg/font_justify.svg';
import down_triangle from 'src/assets/svg/down_triangle.svg';
import underline from 'src/assets/svg/underline.svg';
import throughline from 'src/assets/svg/throughline.svg';
import up_black_triangle from 'src/assets/svg/up_black_triangle.svg';
import down_black_triangle from 'src/assets/svg/down_black_triangle.svg';
// ;
import { useEvent, useCanvasEditor, useFabric } from 'src/templates/2dEditor/hooks/context';
import { EventNameCons, FabricObjectType } from 'src/templates/2dEditor/cons/2dEditorCons';
import { Popover, Slider, Input } from "@mui/material";
import ColorPicker from 'src/components/ColorPicker';

// 选择多个数据时的组件
const MainUiTopToolMultiSelection: React.FC = () => {
  const { t } = useTranslation()
  const event = useEvent();
  const canvasEditor = useCanvasEditor();
  const fabric = useFabric();
  const activeObject: fabric.Textbox | fabric.Text = canvasEditor!.canvas.getActiveObject();
  const activeObjects: fabric.Object[] = canvasEditor!.canvas.getActiveObjects();
  // 多选对象都是文字;
  const isAllText = activeObjects.every(object => object.type === FabricObjectType.Text || object.type === FabricObjectType.TextBox);
  // 多选对象都是位图;
  const isAllImage = activeObjects.every(object => object.type === FabricObjectType.Image);
  enum PopoverFlag {
    Opacity,
    BorderWeight,
    // ...;
    Effect,
    Transform
  }
  const [ancholEl, setAncholEl] = useState<HTMLElement | null>(null);
  const [showPopoverFlag, setShowPopoverFlag] = useState<PopoverFlag | "">();
  const handleAncholElClick = (event: HTMLElement, flag: PopoverFlag) => {
    // 获取多选时透明度的数据
    let opacityData: any[] = []
    canvasEditor?.canvas?.getActiveObjects()?.forEach((res: any) => {
      opacityData.push(res?.opacity);
    });
    const minOpacity = Math.min(...opacityData);
    // 设置最小值
    setObjectOpacity(minOpacity * 100);
    setAncholEl(event.currentTarget);
    setShowPopoverFlag(flag);
  }
  const closePopover = () => {
    setAncholEl(null);
    setShowPopoverFlag("");
  }
  // #region font family;
  const [selectFontFamily, setSelectFontFamily] = useState<string>();
  const initFontFamily = async () => {
    if (!isAllText) return;
    const fontFamiles = activeObjects.map(textObject => textObject.fontFamily);
    console.log('fontFamiles;', fontFamiles);
    // if font family all same;
    if ([...new Set(fontFamiles)].length === 1) {
      setSelectFontFamily(fontFamiles[0]);
    }
    // ;
    else {
      setSelectFontFamily('Multiple Fonts Selected');
    }
  };
  // #endregion ;
  // #region color picker;
  const [previewColors, setPreviewColors] = useState<string[]>([]);
  const initPreviewColors = () => {
    if (isAllImage) return;
    const previewColors: string[] = [];
    activeObjects.forEach(object => {
      if (!!object.fill) {
        if (typeof object.fill === "string") {
          previewColors.push(object.fill);
        } else if (!!object.fill.type && !!object.fill.colorStops) {
          const gradientColor = `linear-gradient(${90}deg, ${object.fill.colorStops[0].color}, ${object.fill.colorStops[1].color})`;
          previewColors.push(gradientColor);
        };
      };
    });
    setPreviewColors([...new Set(previewColors)]);
  };
  // 将渐变色css string转成fabric的渐变对象;
  const gradientColor2FabricGradient = (cssGradient: string) => {
    const angle = Number(cssGradient.substring(cssGradient.indexOf("(") + 1, cssGradient.indexOf("deg")));
    const color1 = cssGradient.substring(cssGradient.indexOf("rgba"), cssGradient.indexOf(")") + 1);
    const color2 = cssGradient.substring(cssGradient.lastIndexOf("rgba"), cssGradient.lastIndexOf(")"));
    const angleInRad = fabric!.util.degreesToRadians(angle);
    // 计算渐变的起始和结束坐标
    const sin = Math.sin(angleInRad);
    const cos = Math.cos(angleInRad);
    const halfWidth = activeObject.width * activeObject.scaleX / 2;
    const halfHeight = activeObject.height * activeObject.scaleY / 2;
    const x1 = halfWidth - halfWidth * cos + halfHeight * sin;
    const y1 = halfHeight - halfWidth * sin - halfHeight * cos;
    const x2 = halfWidth + halfWidth * cos - halfHeight * sin;
    const y2 = halfHeight + halfWidth * sin + halfHeight * cos;
    // 创建一个渐变对象
    return new fabric!.Gradient({
      type: 'linear',
      coords: {
        x1,
        y1,
        x2,
        y2
      },
      colorStops: [
        { offset: 0, color: color1 },
        { offset: 1, color: color2 }
      ]
    });
  };
  const handleColorPicker = (prepareColor: string, color: string) => {
    if (!activeObjects || activeObjects.length === 0 || isAllImage) return;
    activeObjects.forEach((object: fabric.Object) => {
      if (object.fill === prepareColor) {
        setColor(object, color);
        canvasEditor?.canvas.fire('object:modified');
      }
    });
  }
  // 设置纯色/渐变色;
  const setColor = (object: fabric.Object | fabric.Group, color: string) => {
    if (object.type === FabricObjectType.Group) {
      (object as fabric.Group).forEachObject((item: fabric.Object | fabric.Group) => {
        setColor(item, color);
      });
    } else {
      // 纯色;
      if (!~color.indexOf("gradient")) {
        object.set({
          fill: color,
          stroke: color,
        });
      }
      // 渐变色;
      else if (!!~color.indexOf("gradient")) {
        const fabricGradient = gradientColor2FabricGradient(color);
        object.set({
          fill: fabricGradient,
          stroke: "transparent",
        });
      }
      canvasEditor!.canvas.requestRenderAll();
    }
  };
  // 更新预览色;
  const updatePreviewColors = (prepareColor: string, color: string) => {
    setPreviewColors([...(previewColors.filter(item => item !== prepareColor)), color]);
  }
  // #endregion ;
  // #region opacity;
  const [objectOpacity, setObjectOpacity] = useState<number>(100);
  const handleFontOpacityChange = (e: number) => {
    activeObjects.forEach((object: fabric.Object) => {
      object.set("opacity", e / 100);
      canvasEditor!.canvas.requestRenderAll();
      setObjectOpacity(e);
      canvasEditor!.canvas.fire('object:modified');
    });
  }
  // #endregion ;
  // #region font weight;
  const [borderWeight, setBorderWeight] = useState<number>();
  const handleBorderWeightChange = (e: number) => {
    activeObjects.forEach((object: fabric.Object) => {
      if (!object.stroke || object.stroke === "transparent") {
        object.set("stroke", object.fill as string || '#000000');
      }
      if (e === 0) {
        object.set("stroke", "transparent");
      }
      object.set("strokeWidth", e);
      canvasEditor!.canvas.requestRenderAll();
      setBorderWeight(e);
    });
  };
  const handleFontStrokeColorPicker = (prepareColor: string, color: string) => {
    activeObjects.forEach((object: fabric.Object) => {
      object.set("stroke", color);
      canvasEditor!.canvas.requestRenderAll();
    });
  }
  // #endregion ;
  // #region font size;
  const [fontSize, setFontSize] = useState<number>();
  const maxFontSize = 1000;
  const minFontSize = 1;
  const handleFontSizeChange = (e: any) => {
    setFontSize(e.target.value);
    if (e.target.value > maxFontSize || e.target.value < minFontSize) return;
    activeObjects.forEach((object: fabric.Object) => {
      object.set({
        fontSize: e.target.value,
        width: object.width,
      });
    });
    canvasEditor!.canvas.requestRenderAll();
  }
  const handleFontSizeBlur = (e: any) => {
    if (Number(e.target.value) > maxFontSize) {
      setFontSize(maxFontSize);
      activeObjects.forEach((object: fabric.Object) => {
        activeObject.set({
          fontSize: maxFontSize,
          width: object.width,
        });
      })
      canvasEditor!.canvas.requestRenderAll();
    };
    if (Number(e.target.value) < minFontSize) {
      setFontSize(minFontSize);
      activeObjects.forEach((object: fabric.Object) => {
        object.set({
          fontSize: minFontSize,
          width: activeObject.width,
        });
      })
      canvasEditor!.canvas.requestRenderAll();
    }
  }
  // #endregion ;
  // #region line height;
  const [fontLineHeight, setFontLineHeight] = useState<number>();
  const maxLineHeight = 100;
  const minLineheight = 0.1;
  const handleFontLineHeightChange = (e: any) => {
    setFontLineHeight(e.target.value);
    if (e.target.value > maxLineHeight || e.target.value < minLineheight) return;
    activeObjects.forEach((object: fabric.Object) => {
      object.set("lineHeight", e.target.value);
    });
    canvasEditor!.canvas.requestRenderAll();
  }
  const handleFontLineHeightBlur = (e: any) => {
    if (Number(e.target.value) > maxLineHeight) {
      setFontLineHeight(maxLineHeight);
      activeObjects.forEach((object: fabric.Object) => {
        object.set("lineHeight", maxLineHeight);
      })
      canvasEditor!.canvas.requestRenderAll();
    };
    if (Number(e.target.value) < minLineheight) {
      setFontLineHeight(minLineheight);
      activeObjects.forEach((object: fabric.Object) => {
        object.set("lineHeight", minLineheight);
      });
      canvasEditor!.canvas.requestRenderAll();
    }
  }
  // #endregion ;
  // #region font gap;
  const [fontGap, setFontGap] = useState<number>();
  const maxFontGap = 1000;
  const minFontGap = -300;
  const handleFontGapChange = (e: any) => {
    let value = Number(e.target.value);
    setFontGap(value);
    if (e.target.value > maxFontGap || e.target.value < minFontGap) return;
    activeObjects.forEach((object: fabric.Object) => {
      object.set("charSpacing", value);
    });
    canvasEditor!.canvas.requestRenderAll();
  }
  const handleFontGapBlur = (e: any) => {
    if (Number(e.target.value) > maxFontGap) {
      setFontGap(maxFontGap);
      activeObjects.forEach((object: fabric.Object) => {
        object.set("charSpacing", maxFontGap);
      })
      canvasEditor!.canvas.requestRenderAll();
    };
    if (Number(e.target.value) < minFontGap) {
      setFontGap(minFontGap);
      activeObjects.forEach((object: fabric.Object) => {
        object.set("charSpacing", minFontGap);
      });
      canvasEditor!.canvas.requestRenderAll();
    }
  }
  // #endregion ;
  // #region font align;
  enum FontAlignType {
    Left,
    Center,
    Right,
    Jusitify
  }
  const fontAlignTypes = [
    {
      id: FontAlignType.Left,
      label: "Left",
      icon: ic_font_left, // tmp
    },
    {
      id: FontAlignType.Center,
      label: "Center",
      icon: ic_font_center, // tmp
    },
    {
      id: FontAlignType.Right,
      label: "Right",
      icon: ic_font_right, // tmp
    },
    {
      id: FontAlignType.Jusitify,
      label: "Jusitify",
      icon: ic_font_justify, // tmp
    },
  ];
  const handleFontAlign = (type: FontAlignType) => {
    switch (type) {
      case FontAlignType.Left:
        activeObject.set("textAlign", "left");
        break;
      case FontAlignType.Center:
        activeObject.set("textAlign", "center");
        break;
      case FontAlignType.Right:
        activeObject.set("textAlign", "right");
        break;
      case FontAlignType.Jusitify:
        activeObject.set("textAlign", "justify"); // 暂时不支持;
        break;
    }
    canvasEditor!.canvas.requestRenderAll();
  }
  // #endregion ;
  const initStroke = () => {
    if (!activeObject) return;
    if (!activeObject.stroke) activeObject.set("stroke", 'transparent');
  }
  const initText = () => {
    initFontFamily(); // 初始化字体;
    initPreviewColors(); // 初始化颜色,为了处理渐变色;
    // initTextStrokeColor(); // 初始化文本描边颜色;
    initStroke();
    // for text transform and enter edit state;
    const fontTransformObj = {
      path: activeObject.path,
      pathAlign: activeObject.pathAlign,
      pathSide: activeObject.pathSide,
      pathStartOffset: activeObject.pathStartOffset,
    };
    activeObject.on("editing:entered", () => {
      activeObject.set({
        path: null,
        pathAlign: null,
        pathSide: null,
        pathStartOffset: null,
      });
    });
    activeObject.on("editing:exited", () => {
      activeObject.set({
        path: fontTransformObj.path,
        pathAlign: fontTransformObj.pathAlign,
        pathSide: fontTransformObj.pathSide,
        pathStartOffset: fontTransformObj.pathStartOffset,
      });
    });
  }

  // const getFontSize = ()=>{

  // }
  // console.log("-------activeObjects-", activeObjects);


  useEffect(() => {
    // 获取文本最小值
    if (!activeObject) return;
    let fontSizeData: any[] = []
    canvasEditor?.canvas?.getActiveObjects()?.forEach((res: any) => {
      fontSizeData.push(res?.fontSize);
    });
    const minOpacity = Math.min(...fontSizeData);

    initText();
    setObjectOpacity((activeObject.opacity || 1) * 100);
    setBorderWeight(activeObject.strokeWidth || 0);
    setFontSize(activeObject.fontSize || minOpacity || 16);
    setFontLineHeight(activeObject.lineHeight || 1);
    setFontGap(activeObject.charSpacing || 0);
    return () => { };
  }, [activeObject, activeObjects]);
  // 调出左侧工具栏;
  const showleftbar = (select: number) => {
    event?.emitEvent(EventNameCons.OpenTextTool, true, select);
  };
  //;
  return (
    <div className={classes.buttonContainer}>
      {
        (isAllText && !!selectFontFamily)
        &&
        <div className={`${classes.graySelect} ${classes.mr_10px}`} onClick={() => { showleftbar(0) }}>
          <span>
            <p>{selectFontFamily}</p>
          </span>
        </div>
      }
      <div className={classes.mr_10px}>
        <ColorPicker
          previewColors={previewColors}
          previewColorBoxSize={20}
          onChange={(prepareColor, color) => handleColorPicker(prepareColor, color)}
          updatePreviewColors={(prepareColor, color) => updatePreviewColors(prepareColor, color)}
        />
      </div>
      {/* opacity; */}
      <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_opacity} onClick={(event) => {
        handleAncholElClick(event, PopoverFlag.Opacity)
      }} />
      <Popover
        className={classes.fontOpacityPop}
        open={showPopoverFlag === PopoverFlag.Opacity}
        anchorEl={ancholEl || null}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        onClose={closePopover}
      >
        <Slider
          // @ts-ignore;
          size="small"
          defaultValue={objectOpacity}
          value={objectOpacity}
          aria-label="Small"
          min={0}
          max={100}
          onChange={(e, value) => handleFontOpacityChange(value)}
        />
        <p className={classes.opacityP}>{objectOpacity.toFixed(0)}%</p>
      </Popover>
      {/* border weight; */}
      {isAllText && <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_border_weight} onClick={(event) => {
        handleAncholElClick(event, PopoverFlag.BorderWeight)
      }} />}
      <Popover
        className={classes.fontWeightPop}
        open={showPopoverFlag === PopoverFlag.BorderWeight}
        anchorEl={ancholEl || null}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        onClose={closePopover}
      >
        <div className={classes.borderWeightTopDiv}>
          <p>{t("str_font_border_weight", "Border Weight")}</p>
          <ColorPicker previewColors={[activeObject?.stroke as string]} previewColorBoxSize={20} showColorTypeSelect={false} onChange={(prepareColor, color) => handleFontStrokeColorPicker(prepareColor, color)} />
        </div>
        <div className={classes.borderWeightBottomDiv}>
          <Slider
            size="small"
            defaultValue={borderWeight}
            value={borderWeight}
            aria-label="Small"
            min={0}
            max={100}
            onChange={(e, value) => handleBorderWeightChange(value)}
          />
          <p className={classes.fontWeightP}>{borderWeight}</p>
        </div>
      </Popover>
      <div className={`${classes.lineVertical} ${classes.mr_10px}`}></div>
      {/* font size; */}
      {
        isAllText &&
        <>
          <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_font_size} />
          <input
            className={`${classes.input} ${classes.mr_10px}`}
            type='number'
            value={Number(fontSize)?.toFixed(0)}
            onChange={(e) => handleFontSizeChange(e)}
            onBlur={(e) => handleFontSizeBlur(e)}
          />
        </>
      }
      {/* </div> */}
      {/* line heigth; */}
      {
        isAllText &&
        <>
          <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_line_height} />
          <input
            type='number'
            className={`${classes.input} ${classes.mr_10px}`}
            value={fontLineHeight}
            onChange={(e) => handleFontLineHeightChange(e)}
            onBlur={(e) => handleFontLineHeightBlur(e)}
          />
        </>
      }
      {/* font gap; */}
      {
        isAllText &&
        <>
          <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_line_gap} />
          <input
            className={`${classes.input} ${classes.mr_10px}`}
            type='number'
            value={Number(fontGap)?.toFixed(0)}
            onChange={(e) => handleFontGapChange(e)}
            onBlur={(e) => handleFontGapBlur(e)}
          />
        </>
      }
      {
        isAllText &&
        <div className={`${classes.lineVertical} ${classes.mr_10px}`}></div>
      }
      {/* font weight; */}
      {
        isAllText &&
        <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_font_weight} onClick={!!activeObjects && (() => {
          activeObjects.forEach((object: fabric.Object) => {
            object.set("fontWeight", object.fontWeight === "bold" ? "normal" : "bold");
          })
          canvasEditor!.canvas.requestRenderAll();
        })} />
      }
      {/* font italic; */}
      {
        isAllText &&
        <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_font_italic} onClick={!!activeObjects && (() => {
          activeObjects.forEach((object: fabric.Object) => {
            object.set("fontStyle", object.fontStyle === "italic" ? "normal" : "italic");
          });
          canvasEditor!.canvas.requestRenderAll();
        })} />
      }
      {/* text underline; */}
      {
        isAllText &&
        <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={underline} onClick={!!activeObjects && (() => {
          activeObjects.forEach((object: fabric.Object) => {
            object.set("underline", !object.underline);
          })
          canvasEditor!.canvas.requestRenderAll();
        })} />
      }
      {/* text throughline; */}
      {
        isAllText &&
        <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={throughline} onClick={!!activeObjects && (() => {
          activeObjects.forEach((object: fabric.Object) => {
            object.set("linethrough", !object.linethrough);
          })
          canvasEditor!.canvas.requestRenderAll();
        })} />
      }
      {/* font align; */}
      {
        isAllText &&
        fontAlignTypes.map((item) => (
          <img className={`${classes.icon_24px} ${classes.mr_10px}`} key={item.id} src={item.icon} onClick={!!activeObject && (() => {
            handleFontAlign(item.id)
          })} />
        ))
      }
    </div>
  );
};

export default MainUiTopToolMultiSelection;
