import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import React, { useEffect, useState, useRef, FocusEvent } from 'react';
import * as classes from './MainUiTopToolFont.module.scss'
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import ic_opacity from 'src/assets/svg/ic_opacity.svg';
import ic_border_weight from 'src/assets/svg/border_weight.svg';
import ic_font_size from 'src/assets/svg/font_size.svg';
import ic_line_height from 'src/assets/svg/line_height.svg';
import ic_line_gap from 'src/assets/svg/line_gap.svg';
import ic_font_weight from 'src/assets/svg/font_weight.svg';
import ic_font_italic from 'src/assets/svg/font_italic.svg';
import ic_font_left from 'src/assets/svg/font_left.svg';
import ic_font_center from 'src/assets/svg/font_center.svg';
import ic_font_right from 'src/assets/svg/font_right.svg';
import ic_font_justify from 'src/assets/svg/font_justify.svg';
import down_triangle from 'src/assets/svg/down_triangle.svg';
import underline from 'src/assets/svg/underline.svg';
import throughline from 'src/assets/svg/throughline.svg';
import black_triangle from 'src/assets/svg/black_triangle.svg';
import up_black_triangle from 'src/assets/svg/up_black_triangle.svg';
import down_black_triangle from 'src/assets/svg/down_black_triangle.svg';
// ;
import { useEvent, useCanvasEditor, useFabric } from 'src/templates/2dEditor/hooks/context';
import { EventNameCons, FabricObjectType } from 'src/templates/2dEditor/cons/2dEditorCons';
import { Popover, Slider, Input } from "@mui/material";
import ColorPicker from 'src/components/ColorPicker';

// 选择单个数据时的组件
const MainUiTopToolFont: React.FC = () => {
  const { getTranslation } = useCustomTranslation();
  const event = useEvent();
  const canvasEditor = useCanvasEditor();
  const fabric = useFabric();
  const activeObject: fabric.Textbox | fabric.Text = canvasEditor!.canvas.getActiveObject();
  const activeObjects = canvasEditor!.canvas.getActiveObjects();

  // const select = useSelect();
  // const selectMode = select?.selectMode;
  enum PopoverFlag {
    Opacity,
    BorderWeight,
    // ...;
    Effect,
    Transform
  }
  const [ancholEl, setAncholEl] = useState<HTMLElement | null>(null);
  const [showPopoverFlag, setShowPopoverFlag] = useState<PopoverFlag | "">();
  const valueElcChanged = useRef<boolean>(false);
  const handleAncholElClick = (event: HTMLElement, flag: PopoverFlag) => {
    setAncholEl(event.currentTarget);
    setShowPopoverFlag(flag);
  }
  const closePopover = () => {
    setAncholEl(null);
    setShowPopoverFlag("");
    valueChangeSave();
  }
  const valueChangeSave = () => {
    if (valueElcChanged.current) {
      canvasEditor?.historySave();
    }
    valueElcChanged.current = false;
  }
  // #region font family;
  const [selectFontFamily, setSelectFontFamily] = useState<string>();
  const initFontFamily = async () => {
    if (!activeObject || (activeObject.type !== FabricObjectType.Text && activeObject.type !== FabricObjectType.TextBox && activeObject.type !== FabricObjectType.TextI)) return;
    setSelectFontFamily(activeObject.fontFamily);
  };
  // #endregion ;
  // #region color picker;
  const [previewColors, setPreviewColors] = useState<string[]>([]);
  const initPreviewColors = () => {
    if (!activeObject) return;
    const fill = activeObject.fill as string | fabric.Gradient;
    const previewColors = [];
    if (fill) {
      if (typeof fill === "string") {
        previewColors.push(fill);
      } else if (!!fill.type && !!fill.colorStops) {
        const gradientColor = `linear-gradient(${90}deg, ${fill.colorStops[0].color}, ${fill.colorStops[1].color})`;
        previewColors.push(gradientColor);
      };
    }
    setPreviewColors(previewColors);
  };
  // 将渐变色css string转成fabric的渐变对象;
  const gradientColor2FabricGradient = (cssGradient: string) => {
    const angle = Number(cssGradient.substring(cssGradient.indexOf("(") + 1, cssGradient.indexOf("deg")));
    const color1 = cssGradient.substring(cssGradient.indexOf("rgba"), cssGradient.indexOf(")") + 1);
    const color2 = cssGradient.substring(cssGradient.lastIndexOf("rgba"), cssGradient.lastIndexOf(")"));
    const angleInRad = fabric!.util.degreesToRadians(angle);
    // 计算渐变的起始和结束坐标
    const sin = Math.sin(angleInRad);
    const cos = Math.cos(angleInRad);
    const halfWidth = activeObject.width * activeObject.scaleX / 2;
    const halfHeight = activeObject.height * activeObject.scaleY / 2;
    const x1 = halfWidth - halfWidth * cos + halfHeight * sin;
    const y1 = halfHeight - halfWidth * sin - halfHeight * cos;
    const x2 = halfWidth + halfWidth * cos - halfHeight * sin;
    const y2 = halfHeight + halfWidth * sin + halfHeight * cos;
    // 创建一个渐变对象
    return new fabric!.Gradient({
      type: 'linear',
      coords: {
        x1,
        y1,
        x2,
        y2
      },
      colorStops: [
        { offset: 0, color: color1 },
        { offset: 1, color: color2 }
      ]
    });
  };
  const handleColorPicker = (prepareColor: string, color: string) => {
    if (!activeObject) return;
    setColor(activeObject, color);
    canvasEditor?.canvas.fire('object:modified');
  }
  // 设置纯色/渐变色;
  const setColor = (object: fabric.Object | fabric.Group, color: string) => {
    if (object.type === FabricObjectType.Group) {
      (activeObject as fabric.Group).forEachObject((item: fabric.Object | fabric.Group) => {
        setColor(item, color);
      });
    } else {
      // 纯色;
      if (!~color.indexOf("gradient")) {
        object.set({
          fill: color,
          stroke: color,
        });
      }
      // 渐变色;
      else if (!!~color.indexOf("gradient")) {
        const fabricGradient = gradientColor2FabricGradient(color);
        object.set({
          fill: fabricGradient,
          stroke: "transparent",
        });
      }
      canvasEditor!.canvas.requestRenderAll();
    }
  };
  // 更新预览色;
  const updatePreviewColors = (prepareColor: string, color: string) => {
    setPreviewColors([...(previewColors.filter(item => item !== prepareColor)), color]);
  }
  // #endregion ;
  // #region image opacity;
  const [fontOpacity, setFontOpacity] = useState<number>(100);
  const handleFontOpacityChange = (e: number) => {
    activeObject.set("opacity", e / 100);
    canvasEditor!.canvas.requestRenderAll();
    setFontOpacity(e);
    valueElcChanged.current = true;
    canvasEditor?.canvas.fire('object:modified')
  }
  // #endregion ;
  // #region font weight;
  const [borderWeight, setBorderWeight] = useState<number>();
  const handleBorderWeightChange = (e: number) => {
    if (!activeObject.stroke || activeObject.stroke === "transparent") {
      activeObject.set("stroke", activeObject.fill as string || '#000000');
    }
    if (e === 0) {
      activeObject.set("stroke", "transparent");
    }
    activeObject.set("strokeWidth", e);
    canvasEditor!.canvas.requestRenderAll();
    setBorderWeight(e);
    valueElcChanged.current = true;
  };
  const handleFontStrokeColorPicker = (prepareColor: string, color: string) => {
    activeObject.set("stroke", color);
    canvasEditor!.canvas.requestRenderAll();
  }

  const initTextStrokeColor = () => {
    if (!activeObject) return;
    if (!activeObject.stroke || activeObject.stroke === 'transparent') return;
    activeObject.set("stroke", activeObject.fill as string || '#000000');
  }
  // #endregion ;
  // #region font size;
  const [fontSize, setFontSize] = useState<number>();
  const maxFontSize = 1000;
  const minFontSize = 1;
  const handleFontSizeChange = (e: any) => {
    setFontSize(e.target.value);
    if (e.target.value > maxFontSize || e.target.value < minFontSize) return;
    activeObject.set({
      fontSize: e.target.value,
      width: activeObject.width,
    });
    canvasEditor!.canvas.requestRenderAll();
    valueElcChanged.current = true;
  }
  const handleFontSizeBlur = (e: any) => {
    console.log('handleFontSizeBlur; e', e);
    if (Number(e.target.value) > maxFontSize) {
      setFontSize(maxFontSize);
      activeObject.set({
        fontSize: maxFontSize,
        width: activeObject.width,
      });
      canvasEditor!.canvas.requestRenderAll();
    };
    if (Number(e.target.value) < minFontSize) {
      setFontSize(minFontSize);
      activeObject.set({
        fontSize: minFontSize,
        width: activeObject.width,
      });
      canvasEditor!.canvas.requestRenderAll();
    }
    valueChangeSave();
  }
  // #endregion ;
  // #region line height;
  const [fontLineHeight, setFontLineHeight] = useState<number>();
  const maxLineHeight = 100;
  const minLineheight = 0.1;
  const handleFontLineHeightChange = (e: any) => {
    setFontLineHeight(e.target.value);
    if (e.target.value > maxLineHeight || e.target.value < minLineheight) return;
    activeObject.set("lineHeight", e.target.value);
    canvasEditor!.canvas.requestRenderAll();
    valueElcChanged.current = true;
  }
  const handleFontLineHeightBlur = (e: FocusEvent<HTMLInputElement>) => {
    console.log('handleFontLineHeightBlur; e', e);
    if (Number(e.target.value) > maxLineHeight) {
      setFontLineHeight(maxLineHeight);
      activeObject.set("lineHeight", maxLineHeight);
      canvasEditor!.canvas.requestRenderAll();
    };
    if (Number(e.target.value) < minLineheight) {
      setFontLineHeight(minLineheight);
      activeObject.set("lineHeight", minLineheight);
      canvasEditor!.canvas.requestRenderAll();
    }
    valueChangeSave();
  }
  // #endregion ;
  // #region font gap;
  const [fontGap, setFontGap] = useState<number>();
  const maxFontGap = 1000;
  const minFontGap = -300;
  const handleFontGapChange = (e: any) => {
    let value = Number(e.target.value);
    setFontGap(value);
    if (e.target.value > maxFontGap || e.target.value < minFontGap) return;
    // if (value < 0) value = 0; // put in blur;
    activeObject.set("charSpacing", value);
    canvasEditor!.canvas.requestRenderAll();
    valueElcChanged.current = true;
  }
  const handleFontGapBlur = (e: any) => {
    console.log('handleFontGapBlur end; e', e);
    if (Number(e.target.value) > maxFontGap) {
      setFontGap(maxFontGap);
      activeObject.set("charSpacing", maxFontGap);
      canvasEditor!.canvas.requestRenderAll();
    };
    if (Number(e.target.value) < minFontGap) {
      setFontGap(minFontGap);
      activeObject.set("charSpacing", minFontGap);
      canvasEditor!.canvas.requestRenderAll();
    }
    valueChangeSave();
  }
  // #endregion ;
  // #region font align;
  enum FontAlignType {
    Left,
    Center,
    Right,
    Jusitify
  }
  const fontAlignTypes = [
    {
      id: FontAlignType.Left,
      label: "Left",
      icon: ic_font_left, // tmp
    },
    {
      id: FontAlignType.Center,
      label: "Center",
      icon: ic_font_center, // tmp
    },
    {
      id: FontAlignType.Right,
      label: "Right",
      icon: ic_font_right, // tmp
    },
    //目前框架不支持，暂时隐藏
    // {
    //   id: FontAlignType.Jusitify,
    //   label: "Jusitify",
    //   icon: ic_font_justify, // tmp
    // },
  ];
  const handleFontAlign = (type: FontAlignType) => {
    var textAlignCurrent = (activeObject as any).get("textAlign");
    var textAlignNext: string
    switch (type) {
      case FontAlignType.Left:
        textAlignNext = "left";
        break;
      case FontAlignType.Center:
        textAlignNext = "center";
        break;
      case FontAlignType.Right:
        textAlignNext = "right";
        break;
      case FontAlignType.Jusitify:
        textAlignNext = "justify"; //// 暂时不支持;
        break;
      default:
        textAlignNext = "left";
        break;
    }
    if (textAlignCurrent === textAlignNext) return;
    activeObject.set({ "textAlign": textAlignNext });
    // activeObject.set('charSpacing', 0)
    canvasEditor!.canvas.requestRenderAll();
    canvasEditor?.historySave();
  }
  // #endregion ;
  // #region font effect;
  const handleFontEffect = () => { };
  // #endregion ;
  const initStroke = () => {
    if (!activeObject) return;
    if (!activeObject.stroke) activeObject.set("stroke", 'transparent');
  }
  const initText = () => {
    initFontFamily(); // 初始化字体;
    initPreviewColors(); // 初始化颜色,为了处理渐变色;
    // initTextStrokeColor(); // 初始化文本描边颜色;
    initStroke();
    // for text transform and enter edit state;
    const fontTransformObj = {
      path: activeObject.path,
      pathAlign: activeObject.pathAlign,
      pathSide: activeObject.pathSide,
      pathStartOffset: activeObject.pathStartOffset,
    };
    activeObject.on("editing:entered", () => {
      activeObject.set({
        path: null,
        pathAlign: null,
        pathSide: null,
        pathStartOffset: null,
      });
    });
    activeObject.on("editing:exited", () => {
      activeObject.set({
        path: fontTransformObj.path,
        pathAlign: fontTransformObj.pathAlign,
        pathSide: fontTransformObj.pathSide,
        pathStartOffset: fontTransformObj.pathStartOffset,
      });
    });
  }
  useEffect(() => {
    if (!activeObject) return;
    initText();
    setFontOpacity((activeObject.opacity || 1) * 100);
    setBorderWeight(activeObject.strokeWidth || 0);
    setFontSize(activeObject.fontSize || 16);
    setFontLineHeight(activeObject.lineHeight || 1);
    setFontGap(activeObject.charSpacing || 0);
    return () => {
      valueChangeSave();
    };
  }, [activeObject]);
  // 调出左侧工具栏;
  const showleftbar = (select: number) => {
    event?.emitEvent(EventNameCons.OpenTextTool, true, select);
  };
  // handle input up and down click;
  enum UpdownInputType {
    FontSize,
    FontLineheight,
    FontGap,
  };
  const handleInputUpClick = (type: UpdownInputType) => {
    switch (type) {
      case UpdownInputType.FontSize:
        handleFontSizeChange({ target: { value: Number(fontSize) + 1 } });
        handleFontSizeChange({ target: { value: Number(fontSize) + 1 } });
        break;
      case UpdownInputType.FontLineheight:
        handleFontLineHeightChange({ target: { value: Number(fontLineHeight) + 1 } });
        handleFontLineHeightBlur({ target: { value: Number(fontLineHeight) + 1 } });
        break;
      case UpdownInputType.FontGap:
        handleFontGapChange({ target: { value: Number(fontGap) + 1 } });
        handleFontGapBlur({ target: { value: Number(fontGap) + 1 } });
        break;
    }
  };
  const handleInputDownClick = (type: UpdownInputType) => {
    switch (type) {
      case UpdownInputType.FontSize:
        handleFontSizeChange({ target: { value: fontSize - 1 } });
        handleFontSizeChange({ target: { value: fontSize - 1 } });
        break;
      case UpdownInputType.FontLineheight:
        handleFontLineHeightChange({ target: { value: Number(fontLineHeight) - 1 } });
        handleFontLineHeightBlur({ target: { value: Number(fontLineHeight) - 1 } });
        break;
      case UpdownInputType.FontGap:
        handleFontGapChange({ target: { value: Number(fontGap) - 1 } });
        handleFontGapBlur({ target: { value: Number(fontGap) - 1 } });
        break;
    }
  }

  //;
  return (
    <div className={classes.buttonContainer}>
      {
        !!selectFontFamily &&
        <div className={`${classes.graySelect} ${classes.mr_10px}`} onClick={() => { showleftbar(0) }}>
          <span>
            <p>{selectFontFamily}</p>
            {/* <img src={down_triangle} /> */}
          </span>
        </div>
      }
      <div className={classes.mr_10px}>
        <ColorPicker
          previewColors={previewColors}
          previewColorBoxSize={20}
          onChange={(prepareColor, color) => handleColorPicker(prepareColor, color)}
          updatePreviewColors={(prepareColor, color) => updatePreviewColors(prepareColor, color)}
          end={() => {
            canvasEditor?.historySave();
          }}
        />
      </div>
      {/* font opacity; */}
      <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_opacity} onClick={(event) => {
        handleAncholElClick(event, PopoverFlag.Opacity)
      }} />
      <Popover
        className={classes.fontOpacityPop}
        open={showPopoverFlag === PopoverFlag.Opacity}
        anchorEl={ancholEl || null}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        onClose={closePopover}
      >
        <Slider
          // @ts-ignore;
          size="small"
          defaultValue={fontOpacity}
          value={fontOpacity}
          aria-label="Small"
          min={0}
          max={100}
          onChange={(e, value) => handleFontOpacityChange(value)}
        />
        <p className={classes.opacityP}>{fontOpacity.toFixed(0)}%</p>
      </Popover>
      {/* border weight; */}
      <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_border_weight} onClick={(event) => {
        handleAncholElClick(event, PopoverFlag.BorderWeight)
      }} />
      <Popover
        className={classes.fontWeightPop}
        open={showPopoverFlag === PopoverFlag.BorderWeight}
        anchorEl={ancholEl || null}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        onClose={closePopover}
      >
        <div className={classes.borderWeightTopDiv}>
          <p>{getTranslation(TranslationsKeys.STR_FONT_BORDER_WEIGHT)}</p>
          <ColorPicker previewColors={[activeObject?.stroke as string]} previewColorBoxSize={20} showColorTypeSelect={false} onChange={(prepareColor, color) => handleFontStrokeColorPicker(prepareColor, color)} />
        </div>
        <div className={classes.borderWeightBottomDiv}>
          <Slider
            // @ts-ignore;
            size="small"
            defaultValue={borderWeight}
            value={borderWeight}
            aria-label="Small"
            min={0}
            max={100}
            onChange={(e, value) => handleBorderWeightChange(value)}
          />
          <p className={classes.fontWeightP}>{borderWeight}</p>
        </div>
      </Popover>
      <div className={`${classes.lineVertical} ${classes.mr_10px}`}></div>
      {/* font size; */}
      <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_font_size} />
      <div className={classes.input_div}>
        <input
          className={`${classes.input} ${classes.mr_10px}`}
          type='number'
          value={Number(fontSize)?.toFixed(0)}
          onChange={(e) => handleFontSizeChange(e)}
          onBlur={(e) => handleFontSizeBlur(e)}
        />
        <div className={classes.input_div_uddiv}>
          <span onClick={() => { handleInputUpClick(UpdownInputType.FontSize) }}>
            <img src={black_triangle} />
          </span>
          <span style={{ transform: 'rotate(180deg)' }} onClick={() => { handleInputDownClick(UpdownInputType.FontSize) }}>
            <img src={black_triangle} />
          </span>
        </div>
      </div>
      {/* line heigth; */}
      <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_line_height} />
      <div className={classes.input_div}>
        <input
          type='number'
          className={`${classes.input} ${classes.mr_10px}`}
          value={fontLineHeight}
          onChange={(e) => handleFontLineHeightChange(e)}
          onBlur={(e) => handleFontLineHeightBlur(e)}
        />
        <div className={classes.input_div_uddiv}>
          <span onClick={() => { handleInputUpClick(UpdownInputType.FontLineheight) }}>
            <img src={black_triangle} />
          </span>
          <span style={{ transform: 'rotate(180deg)' }} onClick={() => { handleInputDownClick(UpdownInputType.FontLineheight) }}>
            <img src={black_triangle} />
          </span>
        </div>
      </div>
      {/* font gap; */}
      <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_line_gap} />
      <div className={classes.input_div}>
        <input
          className={`${classes.input} ${classes.mr_10px}`}
          type='number'
          value={Number(fontGap)?.toFixed(0)}
          onChange={(e) => handleFontGapChange(e)}
          onBlur={(e) => handleFontGapBlur(e)}
        />
        <div className={classes.input_div_uddiv}>
          <span onClick={() => { handleInputUpClick(UpdownInputType.FontGap) }}>
            <img src={black_triangle} />
          </span>
          <span style={{ transform: 'rotate(180deg)' }} onClick={() => { handleInputDownClick(UpdownInputType.FontGap) }}>
            <img src={black_triangle} />
          </span>
        </div>
      </div>
      <div className={`${classes.lineVertical} ${classes.mr_10px}`}></div>
      {/* font weight; */}
      <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_font_weight} onClick={!!activeObject && (() => {
        activeObject?.set("fontWeight", activeObject.fontWeight === "bold" ? "normal" : "bold");
        activeObject?.fire('modified');
        canvasEditor!.canvas.fire('object:modified');
        canvasEditor!.canvas.requestRenderAll();
        canvasEditor?.historySave();
      })} />
      {/* font italic; */}
      <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={ic_font_italic} onClick={!!activeObject && (() => {
        activeObject?.set("fontStyle", activeObject.fontStyle === "italic" ? "normal" : "italic");
        activeObject?.fire('modified');
        canvasEditor!.canvas.fire('object:modified');
        canvasEditor!.canvas.requestRenderAll();
        canvasEditor?.historySave();
      })} />
      {/* text underline; */}
      <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={underline} onClick={!!activeObject && (() => {
        activeObject?.set("underline", !activeObject.underline);
        activeObject?.fire('modified');
        canvasEditor!.canvas.fire('object:modified');
        canvasEditor!.canvas.requestRenderAll();
        canvasEditor?.historySave();
      })} />
      {/* text throughline; */}
      <img className={`${classes.icon_24px} ${classes.mr_10px}`} src={throughline} onClick={!!activeObject && (() => {
        activeObject?.set("linethrough", !activeObject.linethrough);
        activeObject?.fire('modified');
        canvasEditor!.canvas.fire('object:modified');
        canvasEditor!.canvas.requestRenderAll();
        canvasEditor?.historySave();
      })} />
      {/* font align; */}
      {
        fontAlignTypes.map((item) => (
          <img className={`${classes.icon_24px} ${classes.mr_10px}`} key={item.id} src={item.icon} onClick={!!activeObject && (() => {
            handleFontAlign(item.id)
          })} />
        ))
      }
      {/* <div className={`${BaseStyles.lineVertical} ${classes.lineVertical}`}></div> */}
      {/* font effect; 优先级p2 */}
      {/* <button className={`${BaseStyles.cusButtonWrap} ${classes.topGrayButton}`} onClick={() => { showleftbar() }}>{t("str_common_effect", "Effect")}</button> */}
      {/* font transform; */}
      {/* <button className={`${BaseStyles.cusButtonWrap} ${classes.topGrayButton}`} onClick={(event) => {
        handleFontTransform(TransformType.Circle)
      }}>
        {t("str_common_transform", "Transform")}
      </button> */}
      {/* font transform; */}
      <button className={`${BaseStyles.cusButtonWrap} ${classes.topGrayButton}`} onClick={(event) => {
        showleftbar(1)
      }}>
        {getTranslation(TranslationsKeys.STR_COMMON_TRANSFORM)}
      </button>
    </div>
  );
};

export default MainUiTopToolFont;