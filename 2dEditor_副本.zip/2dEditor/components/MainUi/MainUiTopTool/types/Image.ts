export enum ImageLoadingType {
  RemoveBackground = 'RemoveBackground',
  Upscaler = 'Upscaler',
}