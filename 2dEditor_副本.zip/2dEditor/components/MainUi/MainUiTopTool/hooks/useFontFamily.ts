import FontFaceObserver from 'fontfaceobserver';

export function useFontFamily() {
  const loadFont = (fontName: string) => {
    if (!fontName) return false;
    return new Promise((resolve: any) => {
      const font = new FontFaceObserver(fontName);
      font
        .load(null, 15000)
        .then(() => {
          resolve(true);
          console.log("font loaded successfully;");
        })
        .catch((error: Error) => {
          resolve(false);
          console.log("font not loaded;", error);
        })
        .finally(() => {
          resolve(true);
        });
    });
  };

  return {
    loadFont,
  };
}
