import { useTranslation } from '@volcengine/i18n';
import React, { useEffect, useState, useRef } from 'react';
import * as classes from './MainUiTopToolImage.module.scss';
import ic_crop from 'src/assets/svg/ic_crop.svg';
import ai_remover from 'src/assets/svg/ai_remover.svg';
import upscaler from 'src/assets/svg/upscaler.svg';
import opacity from 'src/assets/svg/opacity.svg';
import ai_matting from 'src/assets/svg/ai_matting.svg';
import Frame from 'src/assets/svg/Frame.svg';
import Emboss from 'src/assets/svg/Emboss.svg';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss';
import { useEvent, useCanvasEditor, useFabric, useProjectData } from 'src/templates/2dEditor/hooks/context';
import { CustomKey, EventNameCons, FabricObjectType, CanvasCategory } from 'src/templates/2dEditor/cons/2dEditorCons';
import { ImageEditTabValue } from '../MainUiLeft/MainUiLeftImageTool/MainUiLeftImageTool';
import { Popover, Slider, Tooltip } from '@mui/material';
import ColorPicker from 'src/components/ColorPicker';
import { ImageClipPathType, ImageClipPaths } from 'src/templates/2dEditor/core/plugin/ImagePlugin/configs/images';
import { EditorToastType, editorToastShow, toast } from 'src/templates/2dEditor/components/Toast';
import { editorAIFeedbackShow, editorAIFeedbackHidden } from 'src/templates/2dEditor/components/AIFeedback';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { ImageStatus } from 'src/templates/2dEditor/core/eventbus/types/image';
import { HotkeyStatus } from 'src/templates/2dEditor/core/eventbus/types/hotkey';
import useDataCache from 'src/templates/2dEditor/utils/DataCache';
import ProjectManager from 'src/templates/2dEditor/utils/ProjectManager';
//埋点
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
const MainUiTopToolImage = () => {
  const { t } = useTranslation();
  const event = useEvent();
  const canvasEditor = useCanvasEditor();
  const fabric = useFabric();
  const projectModel = useProjectData();
  const { getTranslation } = useCustomTranslation();
  const { setCacheItem, getCacheItem } = useDataCache();
  let activeObject = canvasEditor?.canvas.getActiveObject() as fabric.Object;
  const [activeObjectType, setActiveObjectType] = useState<FabricObjectType | null>(
    activeObject?.type as FabricObjectType,
  );
  const toolAdjustment = (props: any) => {
    event?.emitEvent(
      EventNameCons.OpenImageTool,
      true,
      props === 0
        ? ImageEditTabValue.ImageEditTab1
        : props === 1
        ? ImageEditTabValue.ImageEditTab2
        : props === 2
        ? ImageEditTabValue.ImageEditTab3
        : ImageEditTabValue.ImageEditTab4,
    );
  };
  enum PopoverFlag {
    Opacity,
    Crop,
    RMBG,
    Upscaler,
    Filter,
    Color,
    ColorScheme,
    Texturize,
    Emboss,
    // ...;
  }
  const [ancholEl, setAncholEl] = useState<HTMLElement | null>(null);
  const [showPopoverFlag, setShowPopoverFlag] = useState<PopoverFlag | ''>();
  const handleAncholElClick = (event: HTMLElement, flag: PopoverFlag) => {
    console.log('image顶部栏 popover 点击显示; event/flag', event, flag);
    setAncholEl(event.currentTarget);
    setShowPopoverFlag(flag);
    if (flag === PopoverFlag.Opacity) {
      eventBus.emit(HotkeyStatus.UDLR, false);
      eventBus.emit(EventNameCons.ChangeEditorSaveState, false);
    }
  };
  const closePopover = () => {
    setAncholEl(null);
    setShowPopoverFlag((prevalue) => {
      prevalue === PopoverFlag.Opacity &&
        eventBus.emit(HotkeyStatus.UDLR, true) &&
        eventBus.emit(EventNameCons.ChangeEditorSaveState, true);
      return '';
    });
  };
  // #region image crop;
  const imageCropOptionsLi = ImageClipPaths.map((item) => (
    <li onClick={() => handleImageCropClick(item.id)} key={item.id}>
      <img src={item.icon} />
      <span>{item.name}</span>
    </li>
  ));
  // #region backups image cropping code2;
  const handleImageCropClick = (id: ImageClipPathType) => {
    if (!!activeObject && activeObject?.type === FabricObjectType.Image) {
      activeObject.set({
        _cropKey: id,
        _isCropping: true,
      });
    }
  };
  // #endregion ;
  // #region image opacity;
  const [imageOpacity, setImageOpacity] = useState<number>(100);
  const handleImageOpacityChange = (e: number) => {
    activeObject?.set('opacity', e / 100);
    canvasEditor!.canvas.requestRenderAll();
    setImageOpacity(e);
    canvasEditor?.canvas.fire('object:modified');
  };
  // #endregion ;
  // #region image remove bg;
  enum RMBGButtonId {
    RB,
    RF,
    ME, // magic eraser
  }
  const rmbgButtonOptions = [
    {
      id: RMBGButtonId.RB,
      label: 'Remove Background',
    },
  ];
  // ;
  const handleRMBGClick = (id: RMBGButtonId) => {
    switch (id) {
      case RMBGButtonId.RB:
        handleRemoveBackground();
        break;
      case RMBGButtonId.RF:
        break;
      case RMBGButtonId.ME:
        break;
    }
    closePopover();
  };
  // ai 去除图片背景;
  const handleRemoveBackground = async () => {
    const allImageObject = canvasEditor!.canvas.getObjects().filter((item) => item.type === FabricObjectType.Image);
    const hasRBLoading = allImageObject.some((item) => item.rbLoading);

    if (hasRBLoading) {
      toast.current?.show();
      toast.current?.type('warning');
      toast.current?.tips(getTranslation(TranslationsKeys.OPERATION_IN_PROGRESS));
      return;
    }
    if (!activeObject || activeObject?.type !== FabricObjectType.Image) return;
    if (!(canvasEditor!.canvas.getActiveObject() as any).key_prefix) {
      editorToastShow({
        tips: getTranslation(TranslationsKeys.OPERATION_IN_UPDATE),
        type: EditorToastType.warning,
      });
      return;
    }
    // const image_key_prefix = activeObject.key_prefix;
    // if (!image_key_prefix) return;
    // 以下src_image需要传的是image的file_name(配合左侧实时上传生成的数据);
    activeObject.set({
      _projectId: projectModel?.project_info.project_id,
      _canvas_id: projectModel?.canvases[projectModel.canvasesIndex].canvas_id,
      _rbLoading: true, // need put in behind;
    });
  };
  // #endregion ;
  // #region image upscaler;
  enum UpscalerType {
    HD = 2,
    UltraHD = 4,
  }
  const upscalerOptions = [
    {
      id: UpscalerType.HD,
      label: 'HD',
    },
    {
      id: UpscalerType.UltraHD,
      label: 'Ultra HD',
    },
  ];
  enum TexturizeType {
    CMYK = 1,
    Gloss = 2,
  }
  const texturizeOptions = [
    {
      id: TexturizeType.CMYK,
      label: 'CMYK',
    },
    {
      id: TexturizeType.Gloss,
      label: 'Gloss',
    },
  ];
  enum EmbossType {
    CMYK = 1,
    Gloss = 2,
  }
  const embossOptions = [
    {
      id: EmbossType.CMYK,
      label: 'CMYK',
    },
    {
      id: EmbossType.Gloss,
      label: 'Gloss',
    },
  ];
  const handleUpscalerClick = (id: UpscalerType) => {
    const allImageObject = canvasEditor!.canvas.getObjects().filter((item) => item.type === FabricObjectType.Image);
    const hasUpscaleLoading = allImageObject.some((item) => item.upscalerLoading);
    if (hasUpscaleLoading) {
      toast.current?.show();
      toast.current?.type('warning');
      toast.current?.tips(getTranslation(TranslationsKeys.SCALER_IN_PROGRESS));
      return;
    }
    if (!(canvasEditor!.canvas.getActiveObject() as any).key_prefix) {
      editorToastShow({
        tips: getTranslation(TranslationsKeys.OPERATION_IN_UPDATE),
        type: EditorToastType.warning,
      });
      return;
    }
    id === UpscalerType.HD && doScaler(UpscalerType.HD);
    id === UpscalerType.UltraHD && doScaler(UpscalerType.UltraHD);
    closePopover();
  };
  const handleTextureClick = (id: number, type: string) => {
    const activeObject = canvasEditor!.canvas.getActiveObject() as any;
    if (activeObject?._isTextureGroup) {
      const nextData = getCacheItem('craft')?.data?.filter((item) => item.title === 'Texture Lib')[0];
      nextData.tabIndexMenu = id === 1 ? 'Color Texture' : 'Gloss Texture';
      eventBus.emit('jumpToCraft', nextData);
      // eventBus.emit('triggerNextClick', nextData)
    } else {
      let imgSrc;
      if (activeObject?.src || activeObject?.getSrc) {
        imgSrc = activeObject?.src || activeObject?.getSrc();
      }
      const data = {
        title: type?.includes('Text') ? 'Texture Lib' : 'Relief Maker',
        pageTag: 'createTextureLib',
        tabMenuData: type?.includes('Text') ? ['Color Texture', 'Gloss Texture'] : ['Color Relief'],
        textureStyle: type?.includes('Text')
          ? id === 1
            ? 'Color Texture'
            : 'Gloss Texture'
          : id === 1
          ? 'Color Relief'
          : 'Color Relief',
        imgObj: {
          src: imgSrc || activeObject?._objects[0]?.src,
          ext: activeObject?.fileType || activeObject?._objects[0]?.fileType,
        },
      };
      eventBus.emit('jumpToCraft', data);
      console.log(data, 'data-----');
      // eventBus.emit('triggerNextClick', data)
    }
    closePopover();
  };
  // create scaler image;
  const HD_area = 2560 * 1440; // 3686400; // 2k;
  const ultraHD_area = 3860 * 2160; // 8337600; // 4k;
  const doScaler = async (type: UpscalerType) => {
    if (!activeObject) return;
    const currentResolution = activeObject.width * activeObject.height;
    if (type === UpscalerType.HD && Math.round(currentResolution / HD_area) >= 1) {
      toast.current?.show();
      toast.current?.type('warning');
      toast.current?.tips(getTranslation(TranslationsKeys.IMAGE_UPSCALING));
      return;
    }
    if (type === UpscalerType.UltraHD && Math.round(currentResolution / ultraHD_area) >= 1) {
      toast.current?.show();
      toast.current?.type('warning');
      toast.current?.tips(getTranslation(TranslationsKeys.IMAGE_UPSCALING));
      return;
    }
    // ;
    activeObject.set({
      _projectId: projectModel?.project_info.project_id,
      _canvas_id: projectModel?.canvases[projectModel.canvasesIndex].canvas_id,
      // ;
      _upscalerLoading: true, // need put in behind;
      _upscalerResolution: type,
    });
  };
  // #endregion ;
  // #region color;
  const [previewColors, setPreviewColors] = useState<string[]>([]);
  const refPreviewColors = useRef<string[]>([]);
  const handleColorPicker = (prepareColor: string, color: string | any[]) => {
    if (!activeObject) return;
    setColor(activeObject, prepareColor, color);
    canvasEditor?.canvas.fire('object:modified');
  };
  // 设置纯色/渐变色;
  const setColor = (object: fabric.Object | fabric.Group, prepareColor: string, color: string) => {
    if (object.type === FabricObjectType.Group) {
      (object as fabric.Group).forEachObject((item: fabric.Object | fabric.Group) => {
        setColor(item, prepareColor, color);
      });
    } else {
      // 纯色;
      if (!~prepareColor.indexOf('gradient')) {
        if (object.fill === prepareColor) {
          if (!!~color.indexOf('gradient')) {
            object.set({
              fill: gradientColor2FabricGradient(color),
              _gradientColor: color,
            });
          } else {
            object.set({
              fill: color,
            });
          }
        }
      }
      // 渐变色;
      else if (!!~prepareColor.indexOf('gradient')) {
        if (object._gradientColor != prepareColor) {
          const fabricGradient = gradientColor2FabricGradient(color);
          object.set({
            fill: fabricGradient,
            _gradientColor: color,
          });
        }
      }
      canvasEditor!.canvas.requestRenderAll();
    }
  };
  // 将渐变色css string转成fabric的渐变对象;
  const gradientColor2FabricGradient = (cssGradient: string) => {
    const angle = Number(cssGradient.substring(cssGradient.indexOf('(') + 1, cssGradient.indexOf('deg')));
    const color1 = cssGradient.substring(cssGradient.indexOf('rgba'), cssGradient.indexOf(')') + 1);
    const color2 = cssGradient.substring(cssGradient.lastIndexOf('rgba'), cssGradient.lastIndexOf(')'));
    const angleInRad = fabric!.util.degreesToRadians(angle);
    // 计算渐变的起始和结束坐标
    const sin = Math.sin(angleInRad);
    const cos = Math.cos(angleInRad);
    const halfWidth = (activeObject.width * activeObject.scaleX) / 2;
    const halfHeight = (activeObject.height * activeObject.scaleY) / 2;
    const x1 = halfWidth - halfWidth * cos + halfHeight * sin;
    const y1 = halfHeight - halfWidth * sin - halfHeight * cos;
    const x2 = halfWidth + halfWidth * cos - halfHeight * sin;
    const y2 = halfHeight + halfWidth * sin + halfHeight * cos;
    // 创建一个渐变对象
    return new fabric!.Gradient({
      type: 'linear',
      coords: {
        x1,
        y1,
        x2,
        y2,
      },
      colorStops: [
        { offset: 0, color: color1 },
        { offset: 1, color: color2 },
      ],
    });
  };
  // 转fabric的渐变对象成渐变色css string;
  // const fabricGradient2GradientColor = (fabricGradient: fabric.Gradient): string => {
  //   var type = fabricGradient.type === 'linear' ? 'linear-gradient' : 'radial-gradient';
  //   var coords = fabricGradient.coords;
  //   var colorStops = fabricGradient!.colorStops.map(function (colorStop) {
  //     return colorStop.color + ' ' + (colorStop.offset * 100) + '%';
  //   }).join(', ');

  //   if (type === 'linear-gradient') {
  //     // 对于线性渐变，我们需要计算角度
  //     var angle = Math.atan2(coords.y2 - coords.y1, coords.x2 - coords.x1) * (180 / Math.PI);
  //     return type + '(' + angle + 'deg, ' + colorStops + ')';
  //   } else {
  //     // 对于径向渐变，我们需要更多的信息来构建CSS字符串
  //     return type + '(circle, ' + colorStops + ')';
  //   }
  // }
  // 获取active object的颜色;
  const getActiveObjectColor = (object: fabric.Object | fabric.Group) => {
    if (object?.type === FabricObjectType.Group) {
      (object as fabric.Group).getObjects().forEach((item: fabric.Object | fabric.Group) => {
        getActiveObjectColor(item);
      });
    }
    // ;
    else {
      const fill = object?.fill as string;
      if (!!fill) {
        // 纯色;
        if (typeof fill === 'string') {
          refPreviewColors.current.push(fill);
          setPreviewColors(refPreviewColors.current);
        }
        // 渐变色;
        else if (typeof fill === 'object' && !!object?._gradientColor) {
          refPreviewColors.current.push(object?._gradientColor);
          setPreviewColors(refPreviewColors.current);
        }
      }
    }
  };
  // 更新预览色;
  const updatePreviewColors = (prepareColor: string, color: string) => {
    setPreviewColors([...previewColors.filter((item) => item !== prepareColor), color]);
  };
  // #endregion ;
  const toolTipProps = {
    sx: {
      [`& .MuiTooltip-tooltip`]: {
        backgroundColor: '#252627',
        color: 'white',
        fontSize: '12px',
        borderRadius: '8px',
      },
      [`& .MuiTooltip-arrow`]: {
        color: '#252627',
        '&::before': {
          borderTopLeftRadius: '4px',
        },
      },
    },
  };
  // ;
  const getSelectType = (): FabricObjectType => {
    var typeRet = activeObject?.type;
    if (typeRet == FabricObjectType.Group && activeObject!) {
      const isAllPaths = (activeObject as any).getObjects().every((o: any) => o.type === 'path');
      return isAllPaths ? FabricObjectType.SVG : FabricObjectType.Group;
    }
    if ((activeObject as any)?.isSVG) {
      return FabricObjectType.SVG;
    }
    return typeRet as FabricObjectType;
  };

  useEffect(() => {
    refPreviewColors.current = [];
    topToolRef.current = document.getElementById('image_tool_topbar');

    setActiveObjectType(getSelectType());

    console.log(
      'image顶部栏; activeObject=======',
      activeObject,
      activeObject?.type,
      getSelectType(),
      activeObject?.src,
    );

    setImageOpacity(Number(activeObject?.opacity) * 100);
    getActiveObjectColor(activeObject);
    // ;
    eventBus.on(ImageStatus.Cropping, handleImageCropping);
    eventBus.on(ImageStatus.RemovingBackground, handleImageRemovingBG);
    eventBus.on(ImageStatus.Upscaling, handleImageUpscaling);
    return () => {
      eventBus.off(ImageStatus.Cropping, handleImageCropping);
      eventBus.off(ImageStatus.RemovingBackground, handleImageRemovingBG);
      eventBus.off(ImageStatus.Upscaling, handleImageUpscaling);
    };
  }, [activeObject]);
  // #region image cropping status;
  const [isImageCropping, setIsImageCropping] = useState<boolean>(false);
  const handleImageCropping = (e) => {
    e.value && closePopover();
    setIsImageCropping(e.value);
  };
  const [isImageCroppingTipHover, setIsImageCroppingTipHover] = useState<boolean>(false);
  const handleImageCroppingTipHover = (flag: boolean) => {
    setIsImageCroppingTipHover(flag);
  };
  // 退出裁剪模式;
  const exitCroppingMode = () => {
    if (!!activeObject && activeObject?.type === FabricObjectType.Image) {
      activeObject.set({
        _isCropping: false,
        _cropKey: undefined,
      });
      !!activeObject.onDeselectEvent && activeObject.onDeselectEvent();
    }
  };
  // #endregion ;
  // #region image removing bg status;
  const [isRemovingBG, setIsRemovingBG] = useState<boolean>(false);
  const handleImageRemovingBG = (e?: { value: boolean; target: fabric.Image }) => {
    if (!activeObject) return;
    setIsRemovingBG(!!e.value || !!activeObject['rbLoading']);
  };
  // #endregion ;
  // #region image upscaler status;
  const [isUpscaler, setIsUpscaler] = useState<boolean>(false);
  const handleImageUpscaling = (e?: { value: boolean; target: fabric.Image }) => {
    if (!activeObject) return;
    setIsUpscaler(!!e.value || !!activeObject['upscalerLoading']);
  };
  const [isTexturize, setIsTexturize] = useState<boolean>(false);
  const handleImageTexturizing = (e?: { value: boolean; target: fabric.Image }) => {
    if (!activeObject) return;
    setIsTexturize(!!e.value);
  };
  // #endregion ;
  // #region handle image top tool document;
  const topToolRef = useRef();
  const [isColorPickerHover, setIsColorPickerHover] = useState(false);
  const handleColorPickerHover = (flag: boolean) => {
    setIsColorPickerHover(flag);
    // console.log('handleColorPickerHover; flag', flag);
    if (flag) {
      topToolRef.current.addEventListener('wheel', handleColorPickerWheel);
    }
    // ;
    else {
      topToolRef.current.removeEventListener('wheel', handleColorPickerWheel);
    }
  };
  const handleColorPickerWheel = (e) => {
    // console.log('handleColorPickerWheel; e', e);
    if (Math.abs(e.deltaY) < 10) return;
    // scroll up;
    if (e.deltaY >= 0) {
      topToolRef.current.scrollLeft = topToolRef.current.scrollLeft + 10;
    }
    // scroll down;
    else {
      topToolRef.current.scrollLeft = topToolRef.current.scrollLeft - 10;
    }
  };
  // #endregion ;

  return (
    <div id="image_tool_topbar" ref={topToolRef.current} className={classes.buttonContainer}>
      <>
        {/* 优先级 p2 */}
        {/* 滤镜部分暂时屏蔽 */}
        {/* 展示隐藏 */}
        {/* {activeObject?.type === FabricObjectType.Image && <button className={`${BaseStyles.cusButtonWrap} ${classes.topGrayButton}`} onClick={() => { toolAdjustment(0) }}>{t("str_common_adjustment", "Adjustment")}</button>}
        {activeObject?.type === FabricObjectType.Image && <button className={`${BaseStyles.cusButtonWrap} ${classes.topGrayButton}`} onClick={() => { toolAdjustment(1) }}>{t("str_common_effect", "Effect")}</button>} */}
        {/* <button className={`${BaseStyles.cusButtonWrap} ${classes.topGrayButton}`} onClick={() => { toolAdjustment(2) }}>{t("str_common_overlay", "Overlay")}</button>
        <button className={`${BaseStyles.cusButtonWrap} ${classes.topGrayButton}`} onClick={() => { toolAdjustment(3) }}>{t("str_common_filter", "Filter")}</button> */}
        {/* <div className={`${BaseStyles.lineVertical} ${classes.lineVertical}`}></div> */}
        {/* image crop */}
        {activeObject?.type === FabricObjectType.Image && (
          <Tooltip title={t('str_editor_image_crop', 'Crop')} arrow PopperProps={toolTipProps}>
            <img
              src={ic_crop}
              style={
                isRemovingBG || isUpscaler || isImageCropping
                  ? {
                      opacity: 0.4,
                      cursor: 'not-allowed',
                    }
                  : {}
              }
              onClick={(event) => {
                !isRemovingBG && !isUpscaler && !isImageCropping && handleAncholElClick(event, PopoverFlag.Crop);
              }}
            />
          </Tooltip>
        )}
        <Popover
          className={classes.imageCropPop}
          open={showPopoverFlag === PopoverFlag.Crop}
          anchorEl={ancholEl || null}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          onClose={closePopover}
        >
          <ul className={classes.imageCropUl}>{imageCropOptionsLi}</ul>
        </Popover>
        {/* image opacity */}
        {activeObjectType === FabricObjectType.Image ||
        activeObjectType === FabricObjectType.SVG ||
        activeObjectType === FabricObjectType.Group ? (
          <Tooltip title={t('str_editor_image_opacity', 'Opacity')} arrow PopperProps={toolTipProps}>
            <img
              style={
                isRemovingBG || isUpscaler || isImageCropping
                  ? {
                      opacity: 0.4,
                      cursor: 'not-allowed',
                    }
                  : {}
              }
              src={opacity}
              onClick={(event) => {
                !isRemovingBG && !isUpscaler && !isImageCropping && handleAncholElClick(event, PopoverFlag.Opacity);
              }}
            />
          </Tooltip>
        ) : null}
        <Popover
          className={classes.imageOpacityPop}
          open={showPopoverFlag === PopoverFlag.Opacity}
          anchorEl={ancholEl || null}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          onClose={closePopover}
        >
          <Slider
            // @ts-ignore;
            size="small"
            defaultValue={imageOpacity}
            value={imageOpacity}
            aria-label="Small"
            min={0}
            max={100}
            onChange={(e, value) => handleImageOpacityChange(value)}
          />
          <p className={classes.imageOpacityP}>{imageOpacity.toFixed(0)}%</p>
        </Popover>
        <div className={classes.line}></div>
        {/* <div className={`${BaseStyles.lineVertical} ${classes.lineVertical}`}></div> */}
        {/* image upscaler; */}
        {activeObjectType === FabricObjectType.Image && (
          <div
            className="flex"
            onClick={(event) => {
              !isRemovingBG && !isUpscaler && !isImageCropping && handleAncholElClick(event, PopoverFlag.Upscaler);
            }}
          >
            <img
              style={
                isRemovingBG || isUpscaler || isImageCropping
                  ? {
                      opacity: 0.4,
                      cursor: 'not-allowed',
                    }
                  : {}
              }
              src={upscaler}
            />
            <div
              className={classes.iconText}
              dangerouslySetInnerHTML={{
                __html: getTranslation(TranslationsKeys.EDITOR_IMAGE_UPSCALER),
              }}
            ></div>
          </div>
        )}
        <Popover
          className={classes.imageUpscalerPop}
          open={showPopoverFlag === PopoverFlag.Upscaler}
          anchorEl={ancholEl || null}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          onClose={closePopover}
        >
          {upscalerOptions.map((item) => (
            <button
              className={classes.upscaler_button}
              onClick={() => {
                handleUpscalerClick(item.id);
              }}
              key={item.id}
            >
              {item.label}
            </button>
          ))}
        </Popover>
        {activeObjectType === FabricObjectType.Image && <div className={classes.line}></div>}
        {/* imgae remove background; */}
        {activeObjectType === FabricObjectType.Image && (
          <div
            className="flex"
            onClick={(event) => {
              !isRemovingBG && !isUpscaler && !isImageCropping && handleAncholElClick(event, PopoverFlag.RMBG);
            }}
          >
            <img
              style={
                isRemovingBG || isUpscaler || isImageCropping
                  ? {
                      opacity: 0.4,
                      cursor: 'not-allowed',
                    }
                  : {}
              }
              src={ai_remover}
            />
            <div
              className={classes.iconText}
              dangerouslySetInnerHTML={{
                __html: t('str_editor_image_Remover', 'AI Remover'),
              }}
            ></div>
          </div>
        )}
        <Popover
          className={classes.imageRMBGPop}
          open={showPopoverFlag === PopoverFlag.RMBG}
          anchorEl={ancholEl || null}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          onClose={closePopover}
        >
          {rmbgButtonOptions.map((item) => (
            <button
              className={classes.rmbgButton}
              onClick={() => {
                handleRMBGClick(item.id);
              }}
              key={item.id}
            >
              {item.label}
            </button>
          ))}
        </Popover>

        {/* image 2.5D Texturize; */}
        {activeObjectType === FabricObjectType.Image &&
        !ProjectManager.getInstance().isFilterTextureEffect(projectModel) ? (
          <>
            <div className={classes.line}></div>
            <div
              className="flex"
              onClick={(event) => {
                !isRemovingBG &&
                  !isUpscaler &&
                  !isImageCropping &&
                  !isTexturize &&
                  handleAncholElClick(event, PopoverFlag.Texturize);
                StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.reliefMaker_textureLib_create_click,0)
              }}
            >
              <img
                style={
                  isRemovingBG || isUpscaler || isImageCropping || isTexturize
                    ? {
                        opacity: 0.4,
                        cursor: 'not-allowed',
                      }
                    : {}
                }
                src={Frame}
              />
              <div
                className={classes.iconText}
                dangerouslySetInnerHTML={{
                  __html: t('string_editor_image_texturize', '2.5D Texturize'),
                }}
                onClick={() => {
                  handleTextureClick(1, 'Texturize');
                }}
              ></div>
            </div>
          </>
        ) : null}
        {/* <Popover
          className={classes.imageTexturizePop}
          open={showPopoverFlag === PopoverFlag.Texturize}
          anchorEl={ancholEl || null}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          onClose={closePopover}
        >
          {texturizeOptions.map((item) => (
            <button
              className={classes.texturize_button}
              onClick={() => {
                handleTextureClick(item.id,'Texturize')
              }}
              key={item.id}
            >
              {item.label}
            </button>
          ))}
        </Popover> */}

        {/* image 2.5D Emboss; */}
        {activeObjectType === FabricObjectType.Image &&
        !ProjectManager.getInstance().isFilterTextureEffect(projectModel) ? (
          <>
            <div className={classes.line}></div>
            <div
              className="flex"
              onClick={(event) => {
                !isRemovingBG &&
                  !isUpscaler &&
                  !isImageCropping &&
                  !isTexturize &&
                  handleAncholElClick(event, PopoverFlag.Emboss);
                handleTextureClick(embossOptions[0].id, 'Emboss');
                StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.reliefMaker_textureLib_create_click,1)
              }}
            >
              <img
                style={
                  isRemovingBG || isUpscaler || isImageCropping || isTexturize
                    ? {
                        opacity: 0.4,
                        cursor: 'not-allowed',
                      }
                    : {}
                }
                src={Emboss}
              />
              <div
                className={classes.iconText}
                dangerouslySetInnerHTML={{
                  __html: t('string_editor_image_emboss', '2.5D Emboss'),
                }}
              ></div>
            </div>
          </>
        ) : null}
        {/* color picker; */}
        {activeObjectType == FabricObjectType.SVG && (
          <div
            style={{ display: 'flex' }}
            onMouseOver={() => {
              handleColorPickerHover(true);
            }}
            onMouseOut={() => {
              handleColorPickerHover(false);
            }}
          >
            <ColorPicker
              previewColors={[...new Set(previewColors)]}
              onChange={(prepareColor, color) => handleColorPicker(prepareColor, color)}
              updatePreviewColors={(prepareColor, color) => updatePreviewColors(prepareColor, color)}
            />
          </div>
        )}
      </>
    </div>
  );
};

export default MainUiTopToolImage;
