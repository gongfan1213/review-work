import React, { useEffect, useState, useRef } from 'react';
import { EventNameCons, FabricObjectType } from 'src/templates/2dEditor/cons/2dEditorCons';
import { useCanvasEditor, useEvent } from 'src/templates/2dEditor/hooks/context';
import { useSelect } from 'src/templates/2dEditor/hooks/select';
import { SelectEvent, SelectMode } from 'src/templates/2dEditor/utils/event/types';
import MainUiTopToolImage from './MainUiTopToolImage';
import { ImageEditTabValue } from '../MainUiLeft/MainUiLeftImageTool/MainUiLeftImageTool';
import * as classes from './MainUiTopTool.module.scss';
import MainUiTopToolFont from './MainUiTopToolFont';
import { ImageLoadingType } from './types/Image';
import MainUiTopToolMultiSelection from './MainUiTopToolMultiSelection';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { TextStatus } from 'src/templates/2dEditor/core/eventbus/types/text';

export default function MainUiTopTool(props: any) {
  const { onShow } = props;
  const canvasEditor = useCanvasEditor();
  const select = useSelect();
  const selectMode = select?.selectMode;
  const [selectModeEx, setSelectModeEx] = useState<SelectMode>(SelectMode.EMPTY);
  const timeoutIdRef = useRef<NodeJS.Timeout | null>(null);
  const activeObject = canvasEditor?.canvas.getActiveObject();
  const activeObjects = canvasEditor?.canvas.getActiveObjects();
  const isImageRef = useRef<boolean>(false);
  const isFontRef = useRef<boolean>(false);
  const [, forceUpdate] = useState({});
  // const isImage = activeObject?.type === FabricObjectType.Image
  //   || activeObject?.type === FabricObjectType.Group
  //   || activeObject?.type === FabricObjectType.Path
  //   || activeObject?.type === FabricObjectType.Polygon
  //   || activeObject?.type === FabricObjectType.Polyline;

  // const isFont = activeObject?.type === FabricObjectType.TextI
  //   || activeObject?.type === FabricObjectType.TextBox
  //   || activeObject?.type === FabricObjectType.Text;

  const isTexture = () => {
    if (activeObject) {
      //@ts-ignore
      return !!(activeObject.textureType || activeObject._isTextureGroup);
    }
    return false;
  };

  useEffect(() => {
    eventBus.on(TextStatus.UnderTransform, handleTextStatus);
    // ;
    return () => {
      eventBus.off(TextStatus.UnderTransform, handleTextStatus);
    };
  }, [canvasEditor]);

  useEffect(() => {
    onShow((selectMode === SelectMode.ONE || selectMode === SelectMode.MULTI) && !isTextUnderTransform);
    onShowEx();
    return () => {
      onShow(false);
      // 清除可能存在的 timeout
      if (timeoutIdRef.current != null) {
        clearTimeout(timeoutIdRef.current);
      }
    };
  }, [selectMode, activeObject, isTexture()]);

  const forceRender = () => {
    forceUpdate({});
  };

  const onShowEx = () => {
    if (timeoutIdRef.current != null) {
      clearTimeout(timeoutIdRef.current);
    }
    timeoutIdRef.current = setTimeout(() => {
      if (selectMode != undefined) {
        isImageRef.current =
          (activeObject?.type === FabricObjectType.Image ||
            activeObject?.type === FabricObjectType.Polygon ||
            activeObject?.type === FabricObjectType.Polyline ||
            activeObject?.type === FabricObjectType.Group ||
            activeObject?.type === FabricObjectType.Path ||
            activeObject?.type === FabricObjectType.Rect ||
            (activeObject && (activeObject as any).isSVG)) &&
          !isTexture();

        isFontRef.current =
          activeObject?.type === FabricObjectType.TextI ||
          activeObject?.type === FabricObjectType.TextBox ||
          activeObject?.type === FabricObjectType.Text;
        setSelectModeEx(selectMode);
        if (isImageRef.current || isFontRef.current) {
          canvasEditor?.setRulerTopOffset(41);
        } else {
          canvasEditor?.setRulerTopOffset(0);
        }
        canvasEditor?.canvas.renderAll();
        forceRender();
        timeoutIdRef.current = null;
        if (selectMode == SelectMode.EMPTY) {
          eventBus.emit(EventNameCons.EventCanvasTextDeSelect, true);
        }
      }
    }, 100);
  };
  // @ts-ignore;
  // is text under transform status;
  const [isTextUnderTransform, setIsTextUnderTransform] = useState<boolean>(false);

  const handleTextStatus = (flag: boolean) => {
    console.log('handleTextStatus;', flag);
    setIsTextUnderTransform(flag);
  };

  return (
    <div
      className={`
    ${classes.topbar_div} 
    ${
      (selectModeEx === SelectMode.ONE || selectModeEx === SelectMode.MULTI) && !isTextUnderTransform && !isTexture()
        ? classes.show
        : classes.hide
    }`}
    >
      {selectModeEx === SelectMode.ONE ? (
        <>{isImageRef.current ? <MainUiTopToolImage /> : isFontRef.current ? <MainUiTopToolFont /> : <></>}</>
      ) : (
        selectModeEx === SelectMode.MULTI && <MainUiTopToolMultiSelection />
      )}
    </div>
  );
}
