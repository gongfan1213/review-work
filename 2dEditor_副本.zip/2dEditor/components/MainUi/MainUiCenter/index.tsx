// start_ai_generated
import React, { useCallback, useEffect, useRef, useState } from 'react';
// import './index.module.scss';
import * as classes from './index.module.scss';
import Layer from 'src/templates/2dEditor/components/Layer/index';
import Zoom from 'src/templates/2dEditor/components/Zoom/index';
import CommonControl from 'src/templates/2dEditor/components/LayerControl/common';
import { useCanvasEditor, useEvent } from 'src/templates/2dEditor/hooks/context';
import { GetUpTokenFileTypeEnum } from 'src/services';
import Loading from 'src/components/Loading';
import { uploadImageForCavas } from 'src/templates/2dEditor/common/cavasUtil';
import { EditorToastType, editorToastHidden, editorToastShow } from '../../Toast';
import { useTranslation } from '@volcengine/i18n';
import { FabricObjectType, WorkspaceID } from 'src/templates/2dEditor/cons/2dEditorCons';
import { TextureEffect2dManager } from '../../TextureEdit/logic/TextureEffect2dManager';
import { EventNameCons } from 'src/templates/2dEditor/cons/2dEditorCons';
import { group } from 'console';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

interface MainUiCenterProps {
  setShowTextureView: React.Dispatch<React.SetStateAction<boolean>>;
}

const MainUiCenter: React.FC<MainUiCenterProps> = (props: any) => {
  const { setShowTextureView } = props;
  const { getTranslation } = useCustomTranslation();
  const canvasEditor = useCanvasEditor();
  const [isNetLoading, setNetLoading] = useState(false);
  const [scale, setScale] = useState(0);
  const event = useEvent();
  const highlightedLayer = useRef(null);
  const targetLayerRef = useRef(null);

  const handleDragOver = useCallback(
    (event: React.DragEvent<HTMLDivElement>) => {
      if (TextureEffect2dManager.getInstance().isDrop()) {
        const canvas = canvasEditor?.canvas;
        const rect = canvas?.getElement().getBoundingClientRect();
        if (rect) {
          canvas?.discardActiveObject();
          const x = event.clientX - rect.left;
          const y = event.clientY - rect.top;
          // 识别图层
          const targetLayer = identifyLayer(x, y, canvas);
          if (targetLayer) {
            targetLayerRef.current = targetLayer;
            if (
              targetLayer.obj &&
              (!highlightedLayer.current || (highlightedLayer.current as any).id !== targetLayer.obj.id)
            ) {
              if (highlightedLayer) {
                console.log('=========cancelFrame===111111==');
                canvasEditor?.cancelFrame(highlightedLayer);
              }
              console.log('=========addFrame=====', targetLayer);
              canvasEditor?.addFrame(
                targetLayer.obj,
                targetLayer.offsetX,
                targetLayer.offsetY,
                targetLayer.oriWidth,
                targetLayer.oriHeight,
              );
              highlightedLayer.current = targetLayer.obj;
            } else if (targetLayer.isInWorkSpace) {
              canvasEditor?.cancelFrame(highlightedLayer);
              highlightedLayer.current = null;
              targetLayerRef.current = null;
            }
          } else {
            targetLayerRef.current = null;
            // 如果没有目标图层，取消当前高亮
            if (highlightedLayer.current) {
              console.log('=========cancelFrame=====');
              canvasEditor?.cancelFrame(highlightedLayer);
              highlightedLayer.current = null;
              targetLayerRef.current = null;
            }
          }
        }
      }
      event.preventDefault(); // 阻止默认行为
    },
    [canvasEditor],
  );

  const identifyLayer = (x: number, y: number, canvas: any) => {
    const objects = canvas.getObjects().filter((item: any) => !(item as any).id?.includes(WorkspaceID.WorkspaceCavas));
    const transform = canvas?.viewportTransform;
    //@ts-ignore
    const transformedPoint = fabric.util.transformPoint(new fabric.Point(x, y), fabric.util.invertTransform(transform));
    const canvasX = transformedPoint.x;
    const canvasY = transformedPoint.y;

    console.log('=========cancelFrame====canvasX=', canvasX, canvasY);
    const isInWorkSpace = () => {
      const workspace = canvas?.getObjects().find((item: any) => item.id?.includes(WorkspaceID.WorkspaceCavas));
      //@ts-ignore;
      const workspaceWidth = workspace?.width * workspace?.scaleX;
      //@ts-ignore;
      const workspaceHeight = workspace?.height * workspace?.scaleY;
      return canvasX >= 0 && canvasX <= workspaceWidth && canvasY >= 0 && canvasY <= workspaceHeight;
    };

    const getAbsoluteCoords = (obj: any) => {
      const matrix = obj.calcTransformMatrix();
      const options = { x: obj.left, y: obj.top };
      //@ts-ignore
      const point = new fabric.Point(options.x, options.y);
      //@ts-ignore
      const transformedPoint = fabric.util.transformPoint(point, matrix);
      return {
        x: transformedPoint.x - (obj.width * obj.scaleX) / 2,
        y: transformedPoint.y - (obj.height * obj.scaleY) / 2,
      };
    };

    const checkObject = (obj: any, offsetX: number, offsetY: number, scalX: number, scalY: number): any => {
      // if (obj.type === 'group') {
      //   const groupObjects = obj.getObjects();
      //   for (let i = groupObjects.length - 1; i >= 0; i--) {
      //     var groupObject = groupObjects[i];
      //     if (groupObject.type === FabricObjectType.Image || groupObject.type === FabricObjectType.Group || groupObject.isSVG) {
      //       // var objOriginX = offsetX == 0 ? obj.left - groupObject.left : offsetX - groupObject.left;
      //       // var ObjOriginY = offsetY == 0 ? obj.top - groupObject.top : offsetY - groupObject.top;
      //       const absoluteCoords = getAbsoluteCoords(groupObject);
      //       var objOriginX = absoluteCoords.x;
      //       var ObjOriginY = absoluteCoords.y;
      //       var objOriginScalX = scalX * obj.scaleX;
      //       var objOriginScalY = scalY * obj.scaleY;
      //       const foundObj = checkObject(groupObject, objOriginX, ObjOriginY, objOriginScalX, objOriginScalY);

      //       if (foundObj) {
      //         console.log("=========cancelFrame====checkObject=", foundObj)
      //         return foundObj;
      //       }
      //     }
      //   }
      // }

      if (obj.type === FabricObjectType.Image || obj.type === 'group' || obj.isSVG) {
        const { left, top } = TextureEffect2dManager.getInstance().getElementPosition(obj);
        const objX = offsetX > 0 ? offsetX : left;
        const objY = offsetY > 0 ? offsetY : top;
        console.log(
          '=========cancelFrame====canvasX image=',
          canvasX,
          canvasY,
          objX,
          objY,
          obj.width * obj.scaleX,
          obj.height * obj.scaleY,
        );
        if (
          canvasX > objX &&
          canvasX < objX + obj.width * obj.scaleX &&
          canvasY > objY &&
          canvasY < objY + obj.height * obj.scaleY
        ) {
          console.log(
            '=========cancelFrame====checkObject111111=',
            obj.width,
            obj.scaleX,
            scalX,
            obj.width * obj.scaleX * scalX,
          );
          return {
            obj: obj,
            offsetX: offsetX,
            offsetY: offsetY,
            oriWidth: obj.width * obj.scaleX * scalX,
            oriHeight: obj.height * obj.scaleY * scalY,
          };
        }
      }
      return null;
    };

    for (let i = objects.length - 1; i >= 0; i--) {
      const obj = objects[i];
      const foundObj = checkObject(obj, 0, 0, 1, 1);
      if (foundObj) {
        return foundObj;
      }
    }
    if (isInWorkSpace()) {
      return { isInWorkSpace: true };
    }

    return null;
  };

  const handleDrop = useCallback(
    (action: React.DragEvent<HTMLDivElement>) => {
      console.log('=========handleDrop=====');
      action.stopPropagation(); // 阻止冒泡
      action.preventDefault(); // 阻止默认行为
      if (targetLayerRef.current) {
        event?.emitEvent(EventNameCons.EventGetTargetLayer, targetLayerRef.current);
      }
      const files = action.dataTransfer.files;
      if (files.length > 0) {
        Array.from(files as FileList).forEach((item) => {
          const fileExtension = item.name.split('.').pop()?.toLowerCase(); // 获取文件后缀并转换为小写
          uploadImageForCavas({
            updateStart: () =>
              editorToastShow({
                tips: getTranslation(TranslationsKeys.Loading),
                type: EditorToastType.loading,
              }),
            updateEnd: (ret, error) => {
              editorToastHidden();
            },
            fileExtension: fileExtension as string,
            fileItem: item,
            event: event,
            canvasEditor: canvasEditor,
            uploadFileType: GetUpTokenFileTypeEnum.Edit2dLocal,
          });
          // if (fileExtension === 'svg') {
          //   // SVG 文件的处理逻辑
          //   fileToBase64(item).then((fileRet) => {
          //     setNetLoading(true);
          //     upload2dEditFile(item, GetUpTokenFileTypeEnum.Edit2dLocal).then(async (resp) => {
          //       const ret = await createUserMaterial({ file_name: resp.key_prefix });
          //       setNetLoading(false);
          //       if (!ret?.data) {
          //         throw new Error('上传失败');
          //       }
          //       if (resp && resp.key_prefix) {
          //         event?.emitEvent(EventNameCons.EventUpdateMaterial, ret.data);
          //         canvasEditor?.addSvgFile(fileRet as string);
          //       } else {
          //         throw new Error('上传失败，没有返回 key_prefix');
          //       }
          //     }).catch((error) => {
          //       // 处理上传错误
          //       console.error(error);
          //       setNetLoading(false);
          //     });
          //   })
          // } else if (/\/(?:jpeg|jpg|png)/i.test(item.type)) {
          //   // 图片文件的处理逻辑
          //   setNetLoading(true);
          //   getImgCompress(item, 1000, 0, 1).then((blob) => {
          //     var file: File = new File([blob], item.name, { type: blob.type, lastModified: Date.now() })
          //     upload2dEditFile(file, GetUpTokenFileTypeEnum.Edit2dLocal).then(async (resp) => {
          //       const ret = await createUserMaterial({ file_name: resp.key_prefix });
          //       setNetLoading(false);
          //       if (!ret?.data) {
          //         throw new Error('上传失败');
          //       }
          //       if (resp && resp.key_prefix) {
          //         event?.emitEvent(EventNameCons.EventUpdateMaterial, ret.data);
          //         fileToBase64(file).then((fileRet) => {
          //           canvasEditor?.addImage(fileRet,
          //             {
          //               importSource: ImportSource.Local,
          //               fileType: fileExtension,
          //               key_prefix: resp.key_prefix
          //             });
          //         })
          //       } else {
          //         throw new Error('上传失败，没有返回 key_prefix');
          //       }
          //     }).catch((error) => {
          //       // 处理上传错误
          //       console.error(error);
          //       setNetLoading(false);
          //     });
          //   });
          // }
        });
      } else {
        setNetLoading(false);
      }

      if (highlightedLayer.current) {
        console.log('=========cancelFrame=====');
        // TextureEffect2dManager.getInstance().endDrop((highlightedLayer.current as any).id, canvasEditor?.canvas);
        canvasEditor?.cancelFrame(highlightedLayer);
        highlightedLayer.current = null;
      }
    },
    [canvasEditor],
  );

  // #region layer and zoom;
  const [showLayer, setShowLayer] = useState(false);
  const [showZoom, setShowZoom] = useState(false);
  // #endregion ;

  return (
    <div id="workspace" onDragOver={handleDragOver} onDrop={handleDrop}>
      <div className={classes.canvasBg}>
        <canvas id="canvas_bg"></canvas>
      </div>
      <div className={classes.canvasBox}>
        <canvas id="canvas"></canvas>
      </div>

      <CommonControl />
      <Layer onShowLayer={(e: boolean) => setShowLayer(e)} isShowZoom={showZoom} />
      <Zoom
        onShowZoom={(e: boolean) => setShowZoom(e)}
        isShowLayer={showLayer}
        setShowTextureView={setShowTextureView}
      />
      <Loading loading={isNetLoading} />
    </div>
  );
};

export default MainUiCenter;
// end_ai_generated
