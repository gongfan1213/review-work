import { ACTION_OPENCV, CustomPcAction, PrintSource } from 'src/templates/2dEditor/cons/2dEditorCons';
// @ts-ignore
import OpencvWorker from 'src/templates/2dEditor/core/worker/opencv.worker';
// import cv from "@techstark/opencv-js";
import { createRemoveBGImage, getRemoveBGImage } from 'src/templates/LightPainting/LightService';
import { upload, upload2dEditFile } from "src/hooks/useUpload";
import { PrintLayerFileStr, PrintLayerModel, PrintLayerType, PrintModel, PrintQuality } from '../../MainUi/MainUiRightComponent/PrintLayer/model/PrintLayerModel';
import Tar from 'tar-js';
import { blobToBase64, blobToMd5 } from 'src/common/utils';
import { isPc, schemeUrlPC, sendCommandToPc } from 'src/common/jsbridge';
import { getUserInfo } from 'src/common/storage';
import { OpenCvManager } from 'src/templates/2dEditor/common/logic/OpenCvManager';
import { PrintToPcModel } from '../../MainUi/MainUiRightComponent/PrintLayer/model/PrintToPcModel';
import { sendCommandToPcWithResponse } from 'src/common/jsbridge/util';
import StringUtil from 'src/common/utils/stringUtil';
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';


export class LightMapManager {
    private static instance: LightMapManager;
    private SATURATION_SCALE: number = 1.2; //饱和度参数配置
    private SKETCH_BRIGHTNESS: number = 30; // 线稿图亮度
    private SKETCH_CONTRAST: number = 30; // 线稿图对比度
    private LIGHT_ON_WEIGHT: number = 0.8; // 加权混合权重，默认为0.8
    private BG_LIGHT_ALPHA: number = 0.7; //高亮区域透明度系数，默认为0.7
    private ALL_LIGHT_EFFECT_ALPHA: number = 0.7; //高亮区域的加权融合系数，默认为0.7
    private ALL_LIGHT_EFFECT_BETA: number = 0.3; //非高亮区域的加权融合系数，默认为0.3
    private ALL_LIGHT_EFFECT_WEIGHT: number = 0.8; //前景图像的权重，默认为0.8

    // 需要缓存使用的图片数据，饱和度原图/线稿图/灰度图
    private enhancedImg: any | null = null; // 饱和度原图
    private sketchImage: any | null = null; // 线稿图
    private highlightMask: any | null = null; // 背景图
    private bgEffectMat: any | null = null; // 背景图效果图
    private silhouetteImage: any | null = null; // 剪影图
    private RemoveImage: Blob | null = null; // 去背图
    private cv: any = null; // 添加 cv 属性

    private mDarkAlpha = 0;
    private mThreshold = 0;
    private mIsUseSilhouette: boolean = false;


    private constructor() {
    }

    public static getInstance(): LightMapManager {
        if (!LightMapManager.instance) {
            LightMapManager.instance = new LightMapManager();
        }
        return LightMapManager.instance;
    }

    public async printClick(isRenderSketch: boolean, projectModel: any, uploadUrl: string) {

        const tarball = new Tar(); // 创建一个新的 tar 实例
        var model: PrintLayerModel = { printModel: PrintModel.printModel7, printLayerData: [], imgQuality: PrintQuality.printQuality2 };
        var enhancedUrl = this.matToBase64(this.enhancedImg!);
        var fontUrl = isRenderSketch ? this.matToBase64(this.sketchImage!) : this.matToBase64(this.silhouetteImage!);
        var bgEffectUrl = this.mDarkAlpha > 0 ? this.matToBase64(this.highlightMask!) : null;

        const enhancedWidth = this.enhancedImg!.cols;
        const enhancedHeight = this.enhancedImg!.rows;
        const format_size_w = StringUtil.pixelToMm(enhancedWidth, 200);
        const format_size_h = StringUtil.pixelToMm(enhancedHeight, 200);

        // 创建一个新的空白图像，大小为 enhancedWidth 和 enhancedHeight
        let grayImage = new this.cv.Mat(enhancedHeight, enhancedWidth, this.cv.CV_8UC1, new this.cv.Scalar(255));

        // 将该图像转换为灰度图
        // cv.cvtColor(grayImage, grayImage, cv.COLOR_RGBA2GRAY);
        // 将灰度图转换为 Base64 数据
        var grayImageUrl = this.matToBase64(grayImage);

        if (this.mDarkAlpha > 0) {
            console.log("-----this.mDarkAlpha > 0");

            model.printLayerData = [
                { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: [], dataUrl: fontUrl },
                { printType: PrintLayerType.printLayerType1, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr1, layerNum: 1, printLayerObjIds: [], dataUrl: grayImageUrl },
                { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: [], dataUrl: bgEffectUrl! },
                { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: [], dataUrl: enhancedUrl },
            ];
        } else {
            model.printLayerData = [
                { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: [], dataUrl: fontUrl },
                { printType: PrintLayerType.printLayerType1, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr1, layerNum: 1, printLayerObjIds: [], dataUrl: grayImageUrl },
                { printType: PrintLayerType.printLayerType2, printTypeFileStr: PrintLayerFileStr.printLayerTypeStr2, layerNum: 1, printLayerObjIds: [], dataUrl: enhancedUrl },
            ];
        }

        model.printLayerData.forEach((data, index) => {
            data.printTypeFileStr = data.printTypeFileStr + index;
            let prefix = data.printTypeFileStr;
            for (let index = 0; index < data.layerNum; index++) {
                const filename = `${prefix}.png`;
                const fileData = this.base64ToUint8Array(data.dataUrl!.split(',')[1]); // 假设 data.dataUrl 是一个 Base64 编码的 Data URL
                data.dataUrl = "";
                tarball.append(filename, fileData);
            }
        });
        model.format_size_w = format_size_w;
        model.format_size_h = format_size_h;
        model.format_size_w_non = format_size_w;
        model.format_size_h_non = format_size_h;

        const configData = new TextEncoder().encode(JSON.stringify(model));
        // 将 config.json 文件及其内容添加到 tarball 中
        tarball.append('config.json', configData);

        const blobTar = new Blob([tarball.out], { type: 'application/x-tar' });
        const fileTar = new File([blobTar], "printLayers.tar", { type: 'application/x-tar' });
        const base64Tar = await blobToBase64(blobTar);
        const md5Tar = await blobToMd5(blobTar);

        let project_id = projectModel.project_info.project_id;
        console.log('printClick =上传完成==', projectModel.canvas, model)
        var url = `project_id=${project_id}&source=${PrintSource.print_2d_light_map}&handle_id=${getUserInfo()!.user_id}`;
        if (isPc()) {
            upload(uploadUrl, fileTar);
            let newCanvas = [{
                ...projectModel.canvas,
                thumb_file: {
                    thumbnail: enhancedUrl
                },
                effect_file: {
                    effectImage: enhancedUrl
                },
                print_param: JSON.stringify({
                    format_size_w_non: StringUtil.pixelToMm(enhancedWidth, 200),
                    format_size_h_non: StringUtil.pixelToMm(enhancedHeight, 200),
                    printModel: PrintModel.printModel7,
                })
            }];
            let newProjectModel = {
                ...projectModel,
                canvas: newCanvas
            };
            let model: PrintToPcModel = {
                project_id: project_id,
                project_info: JSON.stringify(newProjectModel?.project_info),
                canvases: JSON.stringify(newProjectModel.canvas),
                sn: "",
                rectIndex: 0,
            }
            model.file_tar = base64Tar;
            model.file_md5 = md5Tar;
            sendCommandToPcWithResponse(CustomPcAction.Command_Have_Printer, (data: any) => {
                if (data) {
                    sendCommandToPc(CustomPcAction.PrintAction, model);
                } else {

                }
            });

        } else {
            // 等待上传tar包
            const uploadResult = await upload(uploadUrl, fileTar);
            schemeUrlPC(url)
        }

    }

    private base64ToUint8Array(base64: string) {
        const binaryString = window.atob(base64);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes;
    }

    /**
     * opencv 初始化
     */
    public init() {
        OpenCvManager.getInstance().initOpenCv().then(async () => {
            console.log('====LightMapManager===000=')
            this.cv = await (window as any).cv;
            console.log('====LightMapManager===1111=')
        });
    }

    /**
     * opencv 退出清理
     */
    public clear(): void {
        if (this.enhancedImg) {
            this.enhancedImg.delete();
            this.enhancedImg = null;
        }
        if (this.sketchImage) {
            this.sketchImage.delete();
            this.sketchImage = null;
        }
        if (this.highlightMask) {
            this.highlightMask.delete();
            this.highlightMask = null;
        }
        if (this.bgEffectMat) {
            this.bgEffectMat.delete();
            this.bgEffectMat = null;
        }
        if (this.silhouetteImage) {
            this.silhouetteImage.delete();
            this.silhouetteImage = null;
        }
        if (this.mDarkAlpha) {
            this.mDarkAlpha = 0;
        }
        if (this.mThreshold) {
            this.mThreshold = 0
        }
    }

    /**
     * 导入项目，直接填充数据
     * @param fontImageBlob 
     * @param darkAlpha 
     * @param threshold 
     * @param isUseSilhouette 
     */
    public async initData(darkAlpha: number, threshold: number, isUseSilhouette: boolean): Promise<void> {
        // this.enhancedImg = await this.blobToMat(imageBlob);
        // if (isUseSilhouette) {
        //     this.silhouetteImage = await this.blobToMat(fontImageBlob, true);
        // } else {
        //     this.sketchImage = await this.blobToMat(fontImageBlob);
        // }
        this.mDarkAlpha = darkAlpha;
        this.mThreshold = threshold;
        this.mIsUseSilhouette = isUseSilhouette;
    }

    /**
     * 获取开灯图
     * @param ImageBlob  原图
     * @param isRenderSketch 是否要重新获取线稿图
     * @returns 
     */
    public async getLightOnImgBlob(imageBlob?: Blob | null, isRenderSketch?: boolean): Promise<Blob> {
        // 得到饱和度原图
        if (imageBlob) {
            await this.adjustColorSaturation(imageBlob);
            if (this.mDarkAlpha > 0) {
                if (this.highlightMask) {
                    this.highlightMask.delete();
                }
                this.highlightMask = await this.detectHighlightAreas(this.mThreshold);
                if (this.bgEffectMat) {
                    this.bgEffectMat.delete();
                }
                this.bgEffectMat = this.highlightBGBlender(this.highlightMask, this.mDarkAlpha);
            }
        }
        // 得到线稿图
        if (isRenderSketch) {
            await this.colorToSketch();
        }
        // 是否有背景图
        if (this.mDarkAlpha != 0) {
            if (!this.highlightMask) {
                this.highlightMask = await this.detectHighlightAreas(this.mThreshold);
                if (this.bgEffectMat) {
                    this.bgEffectMat.delete();
                }
                this.bgEffectMat = this.highlightBGBlender(this.highlightMask, this.mDarkAlpha);
            }
            // 去掉前景图
            // let ret: any = await this.highlightFGBlender(this.mIsUseSilhouette ? this.silhouetteImage! : this.sketchImage!, this.bgEffectMat!);
            // let ret = this.bgEffectMat;
            let resultBlob = await this.matToBlob(this.bgEffectMat);
            // ret.delete();
            return resultBlob;
        } else {
            // let blendedImage: any;
            // if (!this.mIsUseSilhouette) {
            // blendedImage = await this.sketchBlender();
            // } else {
            //     blendedImage = await this.silhouetteBlender();
            // }
            // let resultBlob = await this.matToBlob(blendedImage!);
            // blendedImage.delete();
            let resultBlob = await this.matToBlob(this.enhancedImg!);
            return resultBlob;
        }
    }

    /**
     * @returns 返回线稿图
     */
    public async getSketchImgBlob(): Promise<Blob> {
        let resultBlob: any = null;
        if (this.sketchImage) {
            resultBlob = await this.matToBlob(this.sketchImage!);
        }
        console.log("resultBlob===", resultBlob)
        return resultBlob;
    }


    /**
     * @returns 返回去背图
     */

    public async getRemoveBgImgBlob(blob?: any) {
        // if (!this.silhouetteImage) {
        //     return await this.getRemoveBgImage()
        // } else {
        //     if (blob) {
        //         this.RemoveImage = blob;
        //         return blob;
        //     } else {
        //         return this.RemoveImage;
        //     }
        // }
        if (!this.silhouetteImage) {
            return await this.getRemoveBgImage()
        } else {
            if (blob) {
                this.setSilhouetteImgBlob(blob)
                return blob;
            } else {
                console.log("getRemoveBgImgBlob====", this.silhouetteImage.channels());
                return this.matToBlob(this.silhouetteImage);
            }
        }
    }

    /**
     * @returns 返回是否生成过去背图
     */

    public isRemoveBgImg() {
        if (!this.silhouetteImage) {
            // 没生成过
            return false;
        } else {
            // 生成过
            return true;
        }
    }


    /**
    * 得到修正饱和度图片
    * @param base64Image 
    * @returns 
    */
    public async getEnhancedImgBlob() {
        let resultBlob: any = null;
        if (this.enhancedImg) {
            resultBlob = await this.matToBlob(this.enhancedImg!);
            return resultBlob;
        }
    }

    /**
     * 更新线稿图
     * @param blob 
     */
    public async setSketchImgBlob(blob: Blob) {
        this.mIsUseSilhouette = false;
        this.sketchImage = await this.blobToMat(blob);
    }
    /**
     * 更新剪影图
     * @param blob 
     */
    public async setSilhouetteImgBlob(blob: Blob) {
        this.mIsUseSilhouette = true;
        this.silhouetteImage = await this.blobToMat(blob, true);
        console.log("setSilhouetteImgBlob====", this.silhouetteImage.channels());
    }


    // 获取去背前景图
    public async getRemoveBgImage() {
        try {
            // mat转化为Base64Image
            let Base64Image = await this.matToFile(this.enhancedImg!, "MatUpload.png");
            // 上传图片
            const uploadRes = await upload2dEditFile(Base64Image, 1019);
            // 创建去背任务
            const removeBgRes: any = await createRemoveBGImage({
                src_image: uploadRes.key_prefix
            });
            // 当创建任务成功后，才执行后续查询任务轮循接口
            if (removeBgRes?.code === 0) {
                // 初始化resultImage变量
                let resultImage: any = null;
                // 轮询去背状态接口
                do {
                    resultImage = await getRemoveBGImage({
                        task_id: removeBgRes?.data?.task_id
                    });
                    // 检查状态是否为2（成功），或者为3或4（需要停止轮询）
                    if (resultImage.data?.status === 2 || resultImage.data?.status === 3 || resultImage.data?.status === 4) {
                        break; // 停止轮询
                    }
                    // 延迟2秒后再次轮询
                    await new Promise(resolve => setTimeout(resolve, 2000));
                } while (true);
                // 根据状态返回结果或undefined
                if (resultImage.data?.status === 2) {
                    // console.log("resultImage", resultImage)

                    // this.RemoveImage = resultImage.data?.result_list[0]?.download_url
                    // return resultImage.data?.result_list[0]?.download_url; // 去背成功,返回数据链接
                    StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.creative_lightmap_style);//成功时的埋点

                    // 获取图片链接
                    const downloadUrl = resultImage.data?.result_list[0]?.download_url;
                    // 将图片链接转换为Blob
                    const response = await fetch(downloadUrl);
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    const imageBlob = await response.blob();
                    // 更新剪映图（去背图）
                    this.setSilhouetteImgBlob(imageBlob)
                    // this.RemoveImage = imageBlob;
                    // 返回Blob对象
                    return imageBlob;
                } else {
                    console.error("去背失败或取消", resultImage.data?.status);
                    return undefined;
                }
            } else if (removeBgRes?.code === 220100) {
                console.log("积分不足");
                return '220100';
            } else {
                console.log("创建去背任务失败");
                return null;
            }
        } catch (error) {
            console.log("图片上传失败或创建去背任务出错", error);
            return null;
        }
    }

    /**
     * 得到背景设置效果图
     * @param threshold 背景范围 0-255
     * @param darkAlpha 背景透明度 0-1
     * return 返回背景设置效果图
     */
    public async setBGValue(threshold: number, darkAlpha: number): Promise<Blob | null> {
        if (!this.enhancedImg) return null;
        console.log("threshold", threshold, "darkAlpha", darkAlpha)
        // if (darkAlpha == 0) {
        //     // 透明度为0，清空背景图，返回原图
        //     if (this.highlightMask) {
        //         this.highlightMask.delete();
        //         this.highlightMask = null;
        //     }
        //     let resultBlob = await this.matToBlob(this.enhancedImg!);
        //     getLightOnImgBlob
        //     return resultBlob;
        // }
        console.log('setBGValue====start====', new Date().toISOString());
        this.mDarkAlpha = darkAlpha;
        this.mThreshold = threshold;
        if (this.highlightMask) {
            this.highlightMask.delete();
            this.highlightMask = null; // 确保删除后将其设置为null
        }
        this.highlightMask = await this.detectHighlightAreas(threshold);
        if (this.bgEffectMat) {
            this.bgEffectMat.delete();
            this.bgEffectMat = null; // 确保删除后将其设置为null
        }
        if (darkAlpha != 0) {
            this.bgEffectMat = this.highlightBGBlender(this.highlightMask, darkAlpha);
        }

        // 重新生成开灯图
        let resultBlob = await this.getLightOnImgBlob(null, false);

        // let resultBase64 = await this.matToBase64(this.bgEffectMat);
        // console.log('setBGValue====resultBase64====', resultBase64, new Date().toISOString());
        // console.log('setBGValue====end====', new Date().toISOString());

        // let resultBlob = await this.matToBlob(this.bgEffectMat);
        // result.delete();
        return resultBlob;
    }

    /**
     * 原图修正饱和度，得到新图
     * @param base64Image 
     * @returns 
     */
    private async adjustColorSaturation(imageBlob: Blob): Promise<string> {
        console.log('=======adjustColorSaturation=start =', new Date().toISOString())

        var scale = this.SATURATION_SCALE;

        // base64Image = this.imgStr;
        // 将 base64 字符串转换为 cv.Mat 对象
        let img = await this.blobToMat(imageBlob);
        // 转换为HSV颜色空间
        let hsvImg = new this.cv.Mat();
        this.cv.cvtColor(img, hsvImg, this.cv.COLOR_RGB2HSV);
        // 分离HSV通道
        let hsvChannels = new this.cv.MatVector();
        this.cv.split(hsvImg, hsvChannels);

        // 计算饱和度均值
        let meanSaturation = this.cv.mean(hsvChannels.get(1));

        // 三个档次提升饱和度
        if (meanSaturation[0] < 50) {
            scale += 0.3;
        } else if (meanSaturation[0] > 100) {
            scale -= 0.05;
        }
        // 调整饱和度
        hsvChannels.get(1).convertTo(hsvChannels.get(1), -1, scale, 0);
        // 合并HSV通道
        this.cv.merge(hsvChannels, hsvImg);

        if (this.enhancedImg) {
            this.enhancedImg.delete(); // 释放之前的内存
        }
        // 转换回BGR颜色空间
        this.enhancedImg = new this.cv.Mat();
        this.cv.cvtColor(hsvImg, this.enhancedImg, this.cv.COLOR_HSV2RGB);
        console.log('=======adjustColorSaturation=start4444444 =', new Date().toISOString())

        // 将处理后的图像转换回 base64 字符串
        // let resultBase64 = this.matToBase64(enhancedImg);
        // console.log('=======resultBase64==', resultBase64, new Date().toISOString())
        // 释放内存
        img.delete();
        hsvImg.delete();
        hsvChannels.delete();
        // enhancedImg.delete();

        // await this.colorToSketch();
        // await this.sketchBlender();
        // await this.setBGValue(150, 0.6);
        // // this.highlightFGBlender(this.blendedImage!, this.mDarkAlpha);
        // await this.highlightFGBlender(this.bgEffectMat!);
        return "";
    }

    /**
     * 得到线稿图
     * @param base64Image 
     * @param brightness 
     * @param contrast 
     * @returns 
     */
    private async colorToSketch(): Promise<string> {
        console.log('=======colorToSketch=start =', new Date().toISOString())

        // 将 base64 字符串转换为 cv.Mat 对象
        // let img = await this.base64ToMat(base64Image);
        var brightness = this.SKETCH_BRIGHTNESS;
        var contrast = this.SKETCH_CONTRAST;
        console.log('=======colorToSketch=start =11111111', new Date().toISOString())

        // 转换为灰度图
        let grayImage = new this.cv.Mat();
        this.cv.cvtColor(this.enhancedImg!, grayImage, this.cv.COLOR_RGB2GRAY);

        // 调整灰度图的亮度和对比度
        let adjustedGrayImage = new this.cv.Mat();
        grayImage.convertTo(adjustedGrayImage, -1, contrast / 50.0, brightness);
        console.log('=======colorToSketch=start =222222', new Date().toISOString())

        // 反转灰度图
        let invertedGrayImage = new this.cv.Mat();
        this.cv.bitwise_not(adjustedGrayImage, invertedGrayImage);
        console.log('=======colorToSketch=start =3333333', new Date().toISOString())

        // 对反转的灰度图应用双边滤波
        let blurredImage = new this.cv.Mat();
        // cv.bilateralFilter(invertedGrayImage, blurredImage, 9, 75, 75);

        let smallImage = new this.cv.Mat();
        this.cv.resize(invertedGrayImage, smallImage, new this.cv.Size(invertedGrayImage.cols / 2, invertedGrayImage.rows / 2));
        this.cv.bilateralFilter(smallImage, blurredImage, 9, 75, 75);
        this.cv.resize(blurredImage, blurredImage, new this.cv.Size(invertedGrayImage.cols, invertedGrayImage.rows));
        smallImage.delete();

        console.log('=======colorToSketch=start =444444', new Date().toISOString())

        // 反转灰度图
        let invertedBlurredImage = new this.cv.Mat();
        this.cv.bitwise_not(blurredImage, invertedBlurredImage);
        console.log('=======colorToSketch=start =5555555', new Date().toISOString())

        // 调整对比度并混合
        if (this.sketchImage) {
            this.sketchImage.delete(); // 释放之前的内存
        }
        this.sketchImage = new this.cv.Mat();
        this.cv.divide(adjustedGrayImage, invertedBlurredImage, this.sketchImage!, 255.0);
        console.log('=======colorToSketch=start =66666', new Date().toISOString())

        // 进行进一步的对比度受限自适应直方图均衡化 (CLAHE)
        // this.cv.GaussianBlur(this.sketchImage!, this.sketchImage!, new this.cv.Size(7, 7), 0);
        let clahe = new this.cv.CLAHE(2.0, new this.cv.Size(8, 8));
        clahe.apply(this.sketchImage!, this.sketchImage!);
        console.log('=======colorToSketch=end =', new Date().toISOString())

        // 将处理后的图像转换回 base64 字符串
        // let resultBase64 = this.matToBase64(this.sketchImage);
        // console.log('=======colorToSketch resultBase64==', resultBase64, new Date().toISOString())
        // 释放内存
        // img.delete();
        grayImage.delete();
        adjustedGrayImage.delete();
        invertedGrayImage.delete();
        blurredImage.delete();
        invertedBlurredImage.delete();
        // sketchImage.delete();
        return "";
    }

    /**
     * 得到开灯效果图，彩图处理
     * @returns 
     */
    private async sketchBlender(): Promise<any> {
        console.log('=======sketchBlender=start =', new Date().toISOString())

        var weight = this.LIGHT_ON_WEIGHT;

        let colorImage = this.enhancedImg!;
        let sketchImage = this.sketchImage!;

        // 检查输入
        if (colorImage.channels() != 3 && colorImage.channels() != 4) {
            throw new Error("color_image must be a 3-channel BGR or 4-channel BGRA image.");
        }

        let sketchImage3Ch = new this.cv.Mat();
        let mask = new this.cv.Mat();
        let blurredImage = new this.cv.Mat();
        let mask3Ch = new this.cv.Mat();
        let blendedImage = new this.cv.Mat();
        // 确保素描图像是三通道的
        if (sketchImage.channels() == 1) {
            this.cv.cvtColor(sketchImage, sketchImage3Ch, this.cv.COLOR_GRAY2RGB);
            this.cv.threshold(sketchImage, mask, 200, 255, this.cv.THRESH_BINARY);
            // 将素描图像中的白色部分设为透明
            this.cv.cvtColor(mask, mask3Ch, this.cv.COLOR_GRAY2RGB); // 转换为3通道掩码
        } else if (sketchImage.channels() == 4) {
            this.cv.cvtColor(sketchImage, sketchImage3Ch, this.cv.COLOR_RGBA2RGB);
            // 分离通道，只对第一个通道进行阈值处理
            let channels = new this.cv.MatVector();
            this.cv.split(sketchImage, channels);
            this.cv.threshold(channels.get(0), mask, 200, 255, this.cv.THRESH_BINARY);
            channels.delete();
        } else {
            // 将三通道的 RGB 图像转换为单通道的灰度图像
            let graySketchImage = new this.cv.Mat();
            this.cv.cvtColor(sketchImage, graySketchImage, this.cv.COLOR_RGB2GRAY);
            this.cv.threshold(graySketchImage, mask, 200, 255, this.cv.THRESH_BINARY);
            graySketchImage.delete();
            sketchImage3Ch = sketchImage.clone();
        }
        console.log('=======sketchBlender 1111111111==', sketchImage.channels(), colorImage.channels(), sketchImage.size(), new Date().toISOString())

        // 对原图像应用模糊滤镜
        // if (colorImage.channels() == 4) {
        //     cv.cvtColor(colorImage, blurredImage, cv.COLOR_RGBA2RGB);
        //     cv.GaussianBlur(blurredImage, blurredImage, new cv.Size(25, 25), 0);
        // } else {
        //     cv.GaussianBlur(colorImage, blurredImage, new cv.Size(25, 25), 0);
        // }

        // 缩小图像
        let smallImage = new this.cv.Mat();
        this.cv.resize(colorImage, smallImage, new this.cv.Size(colorImage.cols / 2, colorImage.rows / 2));
        // 对缩小的图像进行高斯模糊
        let smallBlurredImage = new this.cv.Mat();
        // this.cv.GaussianBlur(smallImage, smallBlurredImage, new this.cv.Size(15, 15), 0);
        // 恢复原始分辨率
        this.cv.resize(smallImage, blurredImage, new this.cv.Size(colorImage.cols, colorImage.rows));
        // 释放内存
        smallImage.delete();
        smallBlurredImage.delete();


        console.log('=======sketchBlender 22222222==', new Date().toISOString(), mask.size(), mask3Ch.size())
        // // 将素描图像中的白色部分设为透明
        // cv.cvtColor(mask, mask3Ch, cv.COLOR_RGBA2GRAY); // 转换为3通道掩码

        console.log('=======sketchBlender 33333333==', new Date().toISOString())
        // 使用掩码将模糊图像的对应部分复制到素描图像中
        const invertedMask = new this.cv.Mat();
        this.cv.bitwise_not(mask, invertedMask);
        const tempImage = new this.cv.Mat();
        console.log('=======sketchBlender 33333==', new Date().toISOString())

        this.cv.bitwise_and(blurredImage, blurredImage, tempImage, invertedMask);
        this.cv.bitwise_and(sketchImage3Ch, sketchImage3Ch, sketchImage3Ch, mask);
        this.cv.add(tempImage, sketchImage3Ch, sketchImage3Ch);
        tempImage.delete();
        invertedMask.delete();

        console.log('=======sketchBlender 444444==', new Date().toISOString())
        // 混合图像
        this.cv.addWeighted(blurredImage, weight, sketchImage3Ch, 1 - weight, 0, blendedImage);
        console.log('=======sketchBlender end==', new Date().toISOString())

        // 将处理后的图像转换回 base64 字符串
        // let resultBase64 = this.matToBase64(blendedImage);
        // console.log('=======sketchBlender resultBase64==', resultBase64, new Date().toISOString())

        // 释放内存
        // colorImage.delete();
        // sketchImage.delete();
        sketchImage3Ch.delete();
        mask.delete();
        blurredImage.delete();
        mask3Ch.delete();
        // blendedImage.delete();

        return blendedImage;
    }


    /**
     * 得到开灯效果图，彩图+线稿图+背景图效果
     * @param colorImage 得到彩图+线稿图
     * @param darkAlpha 
     * @returns 
     */
    // private highlightFGBlender(colorImage: cv.Mat, darkAlpha: number): cv.Mat {
    //     console.log('=====highlightFGBlender===start', new Date().toISOString())
    //     let alpha = this.ALL_LIGHT_EFFECT_ALPHA;
    //     let beta = this.ALL_LIGHT_EFFECT_BETA;
    //     // 检查输入
    //     if (colorImage.channels() === 1) {
    //         throw new Error("colorImage must be a 3-channel BGR image.");
    //     }
    //     if (this.highlightMask!.channels() !== 1) {
    //         throw new Error("highlightMask must be a single-channel grayscale image.");
    //     }

    //     // 创建一个彩色的高光区域掩码
    //     let highlightMaskColored = new cv.Mat();
    //     cv.cvtColor(this.highlightMask!, highlightMaskColored, cv.COLOR_GRAY2RGB);

    //     // 将高光区域标记在原始图像上
    //     let highlightedImage = new cv.Mat();
    //     cv.addWeighted(colorImage, alpha, highlightMaskColored, 1 - alpha, beta, highlightedImage);

    //     // 根据highlight_mask控制暗部的亮度
    //     let darkenedImage = new cv.Mat();
    //     cv.addWeighted(highlightedImage, darkAlpha, colorImage, 1 - darkAlpha, beta, darkenedImage);

    //     let resultBase64 = this.matToBase64(darkenedImage);
    //     console.log('=======highlightFGBlender resultBase64==', resultBase64, new Date().toISOString())

    //     // 释放内存
    //     highlightMaskColored.delete();
    //     highlightedImage.delete();
    //     console.log('=====highlightFGBlender===end', new Date().toISOString())
    //     return darkenedImage;
    // }


    /**
     * 得到开灯效果图，彩图+线稿图+背景图效果
     * @param fgImage 线稿图
     * @param bgImage 背景+彩图效果
     * @param weight 
     * @returns 
     */
    private async highlightFGBlender(sketchImage: any, bgImage: any): Promise<any> {
        console.log('=====highlightFGBlender===start', new Date().toISOString(), bgImage)
        let weight: number = this.ALL_LIGHT_EFFECT_WEIGHT;
        let fgImage: any = sketchImage;
        let fgImage3Ch: any;
        let bgImage3Ch: any;

        // fg_image转为3通道
        if (fgImage.channels() === 1) {
            fgImage3Ch = new this.cv.Mat();
            this.cv.cvtColor(fgImage, fgImage3Ch, this.cv.COLOR_GRAY2BGR);
        } else if (fgImage.channels() === 4) {
            fgImage3Ch = new this.cv.Mat();
            this.cv.cvtColor(fgImage, fgImage3Ch, this.cv.COLOR_BGRA2BGR);
        } else {
            fgImage3Ch = fgImage;
        }

        // Convert bgImage to 3 channels
        if (bgImage.channels() === 1) {
            bgImage3Ch = new this.cv.Mat();
            this.cv.cvtColor(bgImage, bgImage3Ch, this.cv.COLOR_GRAY2BGR);
        } else {
            bgImage3Ch = bgImage;
        }

        // Blend the images
        let blenderImage = new this.cv.Mat();
        this.cv.addWeighted(bgImage3Ch, weight, fgImage3Ch, 1 - weight, 0, blenderImage);
        console.log('=====highlightFGBlender===end', new Date().toISOString())

        // let resultBase64 = await this.matToBase64(blenderImage);
        // console.log('highlightFGBlender====resultBase64====', resultBase64, new Date().toISOString());

        // Clean up temporary Mats if they were created
        if (fgImage.channels() === 1 || fgImage.channels() === 4) {
            fgImage3Ch.delete();
        }
        if (bgImage.channels() === 1) {
            bgImage3Ch.delete();
        }

        return blenderImage;
    }

    /**
     * 得到彩图+背景图效果
     * @param highlightMask 背景图
     * @param darkAlpha 默认为0.6, 低档0.7 高档0.5
     * @returns 
     */
    private highlightBGBlender(highlightMask: any, darkAlpha: number): any {
        console.log('highlightBGBlender====start====', new Date().toISOString());
        let lightAlpha = this.BG_LIGHT_ALPHA;
        if (highlightMask.channels() !== 1) {
            throw new Error("highlightMask must be a single-channel grayscale image.");
        }

        // 创建一个彩色的高光区域掩码
        let highlightMaskColored = new this.cv.Mat();
        this.cv.cvtColor(highlightMask, highlightMaskColored, this.cv.COLOR_GRAY2RGB);

        let highlightedImage = new this.cv.Mat();
        this.cv.addWeighted(this.enhancedImg!, lightAlpha, highlightMaskColored, 1 - lightAlpha, 0, highlightedImage);

        // 控制图像暗部区域亮度
        let normalImage = new this.cv.Mat();
        this.cv.addWeighted(this.enhancedImg!, darkAlpha, highlightMaskColored, 1 - darkAlpha, 0, normalImage);

        // 创建一个与高亮掩码相反的掩码
        let inverseHighlightMask = new this.cv.Mat();
        this.cv.bitwise_not(highlightMask, inverseHighlightMask);

        // 将暗部区域提取出来
        let nonHighlightedArea = new this.cv.Mat();
        this.cv.bitwise_and(normalImage, normalImage, nonHighlightedArea, inverseHighlightMask);

        // 将高亮区域提取出来
        let highlightedArea = new this.cv.Mat();
        this.cv.bitwise_and(highlightedImage, highlightedImage, highlightedArea, highlightMask);

        // 将两个区域合并在一起
        let finalImage = new this.cv.Mat();
        this.cv.add(highlightedArea, nonHighlightedArea, finalImage);
        console.log('highlightBGBlender====end====', new Date().toISOString());

        // 释放内存
        highlightMaskColored.delete();
        highlightedImage.delete();
        normalImage.delete();
        inverseHighlightMask.delete();
        nonHighlightedArea.delete();
        highlightedArea.delete();

        return finalImage;
    }

    /**
     * 得到背景图
     * @param threshold 0-255
     * @returns 
     */
    private async detectHighlightAreas(threshold: number): Promise<any> {
        console.log('detectHighlightAreas =====start===', new Date().toISOString())
        // 将图像转换为灰度图像
        let grayImage = new this.cv.Mat();
        this.cv.cvtColor(this.enhancedImg!, grayImage, this.cv.COLOR_RGB2GRAY);

        // 拉伸对比度
        let stretchedGrayImage = this.stretchGray(grayImage);

        // 应用阈值来检测高亮度区域
        let highlightMask = new this.cv.Mat();
        this.cv.threshold(stretchedGrayImage, highlightMask, threshold, 255, this.cv.THRESH_BINARY);

        // 将处理后的图像转换回 base64 字符串
        // let resultBase64 = await this.matToBase64(highlightMask);
        // console.log('detectHighlightAreas =====resultBase64===', resultBase64)
        console.log('detectHighlightAreas =====end===', new Date().toISOString())

        grayImage.delete();
        stretchedGrayImage.delete();

        return highlightMask;
    }

    private stretchGray(grayImage: any): any {
        // 查找灰度图像的最小和最大像素值
        // @ts-ignore 
        var value: any = this.cv.minMaxLoc(grayImage);

        let minValScalar = value.minVal;
        let maxValScalar = value.maxVal;
        let stretchedGrayImage = new this.cv.Mat();
        this.cv.convertScaleAbs(grayImage, stretchedGrayImage, 255.0 / (maxValScalar - minValScalar), -minValScalar * 255.0 / (maxValScalar - minValScalar));
        return stretchedGrayImage;
    }

    /**
     * 彩色图+剪影图像开灯效果
     * @returns 
     */
    private async silhouetteBlender(): Promise<any> {
        let isBlur: boolean = true;

        // Convert silhouette image to RGBA if it is not already
        let silhouetteImageRGBA = new this.cv.Mat();
        if (this.silhouetteImage!.channels() === 3) {
            this.cv.cvtColor(this.silhouetteImage!, silhouetteImageRGBA, this.cv.COLOR_RGB2RGBA);
        } else if (this.silhouetteImage!.channels() === 4) {
            silhouetteImageRGBA = this.silhouetteImage!;
        } else {
            throw new Error("silhouette_image must be RGB or RGBA.");
        }

        console.log("=======silhouetteBlender=====start", new Date().toISOString())
        // 提取剪影图像的RGB通道
        let silhouetteRgb = new this.cv.Mat();
        this.cv.cvtColor(silhouetteImageRGBA, silhouetteRgb, this.cv.COLOR_RGBA2RGB);

        // 提取剪影图像的Alpha通道作为掩码
        let channels = new this.cv.MatVector();
        this.cv.split(silhouetteImageRGBA, channels);
        let silhouetteAlpha = channels.get(3);

        // 如果原图是RGBA格式，先转换为RGB
        var image = this.enhancedImg!;
        let imageRgb = image;
        if (image.channels() === 4) {
            imageRgb = new this.cv.Mat();
            this.cv.cvtColor(image, imageRgb, this.cv.COLOR_RGBA2RGB);
        }

        // 对原图进行高斯模糊
        console.log("=======silhouetteBlender=====1111111", new Date().toISOString(), image.channels(), silhouetteImageRGBA.channels())
        // if (isBlur) {
        //     let ksize = new this.cv.Size(15, 15);
        //     this.cv.GaussianBlur(imageRgb, imageRgb, ksize, 0);
        // }
        // console.log("=======silhouetteBlender=====222222", new Date().toISOString())
        // 将剪影图像与原图进行融合
        let resultImage = imageRgb.clone();
        // for (let y = 0; y < silhouetteAlpha.rows; ++y) {
        //     for (let x = 0; x < silhouetteAlpha.cols; ++x) {
        //         if (silhouetteAlpha.ucharPtr(y, x)[0] >= 40) {
        //             resultImage.ucharPtr(y, x)[0] = silhouetteRgb.ucharPtr(y, x)[0];
        //             resultImage.ucharPtr(y, x)[1] = silhouetteRgb.ucharPtr(y, x)[1];
        //             resultImage.ucharPtr(y, x)[2] = silhouetteRgb.ucharPtr(y, x)[2];
        //         }
        //     }
        // }
        let mask = new this.cv.Mat();
        this.cv.threshold(silhouetteAlpha, mask, 40, 255, this.cv.THRESH_BINARY);
        silhouetteRgb.copyTo(resultImage, mask);
        console.log("=======silhouetteBlender=====333333", new Date().toISOString())

        // Clean up
        silhouetteRgb.delete();
        channels.delete();
        silhouetteAlpha.delete();
        if (image.channels() === 4) {
            imageRgb.delete();
        }
        if (this.silhouetteImage!.channels() === 3) {
            silhouetteImageRGBA.delete();
        }
        return resultImage;
    }

    private async base64ToMat(base64Image: string): Promise<any> {
        return new Promise((resolve, reject) => {
            let img = new Image();
            img.src = `${base64Image}`;
            img.onload = () => {
                try {
                    let canvas = document.createElement('canvas');
                    let ctx = canvas.getContext('2d');
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx!.drawImage(img, 0, 0, img.width, img.height);
                    let imageData = ctx!.getImageData(0, 0, img.width, img.height);
                    let mat = new this.cv.Mat(img.height, img.width, this.cv.CV_8UC4);
                    mat.data.set(imageData.data);
                    this.cv.cvtColor(mat, mat, this.cv.COLOR_RGBA2RGB);
                    resolve(mat);
                } catch (error) {
                    reject(error);
                }
            };
            img.onerror = (err) => {
                reject(new Error(`Failed to load image: ${err}`));
            };
        });
    }

    private matToBase64(mat: any): string {
        // 创建一个 canvas 元素
        let canvas = document.createElement('canvas');
        this.cv.imshow(canvas, mat);
        // 将 canvas 转换为 base64 字符串
        return canvas.toDataURL();
    }

    private async blobToMat(blob: Blob, isChangeRGBA: boolean = false): Promise<any> {
        return new Promise((resolve, reject) => {
            let reader = new FileReader();
            reader.onload = () => {
                let arrayBuffer = reader.result as ArrayBuffer;
                let bytes = new Uint8Array(arrayBuffer);
                let img = new Image();
                img.src = URL.createObjectURL(new Blob([bytes], { type: 'image/webp' }));
                img.onload = () => {
                    try {
                        let canvas = document.createElement('canvas');
                        let ctx = canvas.getContext('2d');
                        canvas.width = img.width;
                        canvas.height = img.height;
                        ctx!.drawImage(img, 0, 0, img.width, img.height);
                        let imageData = ctx!.getImageData(0, 0, img.width, img.height);
                        let mat = new this.cv.Mat(img.height, img.width, this.cv.CV_8UC4);

                        mat.data.set(imageData.data);
                        if (!isChangeRGBA) {
                            this.cv.cvtColor(mat, mat, this.cv.COLOR_RGBA2RGB);
                        }
                        resolve(mat);
                    } catch (error) {
                        reject(error);
                    }
                };
                img.onerror = (err) => {
                    reject(new Error(`Failed to load image: ${err}`));
                };
            };
            reader.onerror = (error) => {
                reject(error);
            };
            reader.readAsArrayBuffer(blob);
        });
    }

    private matToBlob(mat: any): Promise<Blob> {
        return new Promise((resolve, reject) => {
            try {
                // 创建一个 canvas 元素
                let canvas = document.createElement('canvas');
                this.cv.imshow(canvas, mat);
                // 将 canvas 转换为 Blob
                canvas.toBlob((blob) => {
                    if (blob) {
                        resolve(blob);
                    } else {
                        reject(new Error('Canvas to Blob conversion failed.'));
                    }
                }, 'image/webp');
            } catch (error) {
                reject(error);
            }
        });
    }

    private async matToFile(mat: any, fileName: string): Promise<File> {
        return new Promise((resolve, reject) => {
            try {
                // 创建一个 canvas 元素
                let canvas = document.createElement('canvas');
                this.cv.imshow(canvas, mat); // 显示 mat 到 canvas 上
                // 将 canvas 转换为 Blob
                canvas.toBlob((blob) => {
                    if (blob) {
                        // 将 Blob 转换为 File
                        const file = new File([blob], fileName, { type: 'image/jpeg' });
                        resolve(file);
                    } else {
                        reject(new Error('Canvas to Blob conversion failed.'));
                    }
                }, 'image/jpeg');
            } catch (error) {
                reject(error);
            }
        });
    }

    public async blobToBase64(blob: Blob): Promise<string> {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                resolve(reader.result as string);
            };
            reader.onerror = (error) => {
                reject(error);
            };
            reader.readAsDataURL(blob);
        });
    }

    private base64ToBlob(base64: string, contentType: string = '', sliceSize: number = 512): Blob {
        const byteCharacters = atob(base64.split(',')[1]);
        const byteArrays = [];

        for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            const slice = byteCharacters.slice(offset, offset + sliceSize);

            const byteNumbers = new Array(slice.length);
            for (let i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }

            const byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }

        return new Blob(byteArrays, { type: contentType });
    }
}
