import React, { useEffect, useState, useRef } from 'react';
import { useCanvasEditor } from '../../hooks/context';
import './index.scss';
import TemplatesInput from '../TemplatesInput';
import SideTable from '../SideTable';
import TemplatesPopover from '../TemplatesPopover';
import { getWorksList, getJsonUrl } from '../../service/2dEditService';
import useDataCache from '../../utils/DataCache';
import { useEvent } from 'src/templates/2dEditor/hooks/context';
import DataCache from 'src/templates/2dEditor/components/MainUi/MainUiLeft/MainUiLeftUpload/cache';
import { useDispatch } from 'react-redux';
import { openToast } from 'src/state/reducers/toast';
import { useTranslation } from '@volcengine/i18n';
import { get } from 'src/services';
import empty_data_icon from 'src/images/empty_upload.png';
import { appendListToDataA, replaceGraphicData } from 'src/templates/2dEditor/utils/utils';
import VagueLoading from 'src/components/VagueLoading';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';

interface materialTypeI {
  value: string;
  label: string;
  list?: materialItemI[];
}

interface materialItemI {
  value: string;
  label: string;
  tempUrl: string;
  src: string;
}

function ImportTmpl() {
  const [state, setState] = useState(() => ({
    search: '',
    placeholder: '',
    jsonFile: null,
    materialType: [''], // 选中分类
    materialTypelist: [], // 分类列表
    materialist: [], // 列表内容
  }));
  const { getTranslation } = useCustomTranslation();
  const [FilterPopoverState, setFilterPopoverState] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const canvasEditor = useCanvasEditor();
  const [isNetLoading, setNetLoading] = useState(false); //全局加载动画
  const [isLoading, setLoading] = useState(false); //列表加载动画
  const [templates_data, setTemplates_data] = useState<any>(null);
  const [searchValue, SetSearchValue] = useState<any>('');
  const [filterValue, setFilterValue] = useState<any>([]);
  const pageIndex = useRef(2);
  const SeeAllref = useRef(null);
  const PAGE_SIZE = 20;
  const [isSeeAll, setIsSeeAll] = useState<any>('');
  const [hasMore, setHasMore] = useState(false);
  const [seeAllData, setSeeAllData] = useState<any>([]);
  const { getCacheItem, setCacheItem, cacheData, cachePageSize, cacheHasMore } = useDataCache();
  const event = useEvent();
  const refdata = useRef<any>();
  const dispatch = useDispatch();
  const { t } = useTranslation();
  const [AllTypeData, setAllTypeData] = useState<any>([]); //全部的类别
  const [ListLoading, setListLoading] = useState(false); //加载更多模块的loading
  const [ListMore, setListMore] = useState(false);
  const List_PAGE_SIZE = 5;
  const currentIndex = useRef(0);
  const interface_loading = useRef(false);
  const [RefreshLoading, setRefreshLoading] = useState<any>([]);
  const refInput = useRef<any>();
  const [isError, setIsError] = useState(false);
  const refRightState = useRef<Boolean>(false);

  useEffect(() => {
    // 获取素材分类
    // canvasEditor?.getMaterialType('template').then((list: materialTypeI[]) => {
    //   // @ts-ignore
    //   setState(state => ({
    //     ...state,
    //     materialTypelist: [...list],
    //     materialist: list,
    //   }))
    // });
  }, [canvasEditor]);

  useEffect(() => {
    // 插入文件
    canvasEditor?.stopSaveHistory();
    state.jsonFile &&
      canvasEditor?.insertSvgFile(state.jsonFile, () => {
        canvasEditor?.startSaveHistory(true);
      });
  }, [state.jsonFile]);

  useEffect(() => {
    // @ts-ignore
    DataCache.getInstance().updateMaterialtEmitter(event);
    return () => {
      DataCache.getInstance().removeUpdateMaterialtEmitter();
    };
  }, []);

  const SearchValue = (value: any) => {
    // 搜索框数据
    // console.log("searchValue", value)
    SetSearchValue(value);
  };

  const IconClick = () => {
    // 搜索按钮
    console.log('IconClick');
  };

  const editClick = (event: any) => {
    const rect = event.currentTarget.getBoundingClientRect();
    // 打开弹窗
    // @ts-ignore
    setAnchorEl({ left: rect.left + 36, top: rect.bottom + 15 });
    setFilterPopoverState(true);
  };

  // 关闭弹窗，清空列表
  const onClose = () => {
    setFilterPopoverState(false);
  };

  // 清空表格数据
  const CloseState = () => {
    setTemplates_data([]);
    setListMore(false);
    currentIndex.current = 0;
  };

  const filterData = {
    product: [
      { value: 1, label: 'Painting' },
      { value: 2, label: 'Sticker' },
      { value: 3, label: 'Cute' },
    ],
    tags: [
      { value: 1, label: 'Mug' },
      { value: 2, label: 'Oil painting' },
      { value: 3, label: 'Cute' },
      { value: 4, label: 'Dog' },
      { value: 5, label: 'Cat' },
    ],
  };

  // 筛选框确认按钮
  const ConfirmClick = (props: any) => {
    // console.log('StarItClick', props)
    setCacheItem('templatesMenu', {
      ...getCacheItem('templatesMenu'),
      activeForm: props,
    });
    CloseState();
    clearSeeAllState();
    setLoading(true);
    onClose();
    setFilterValue(props);
    if (props?.product?.length === 0 && props?.tags?.length === 0 && searchValue === '') {
      fetchSonClass();
    } else {
      getWorksListData(props, '');
    }
  };

  const ClearnAllClick = (props: any, activeForm: any) => {
    // onClose()
    // CloseState()
    clearSeeAllState();
    setCacheItem('templatesMenu', {
      ...getCacheItem('templatesMenu'),
      activeForm: { product: [], tags: [] },
    });
    setFilterValue([]);
    if (searchValue === '') {
      // fetchSonClass()
    } else {
      setFilterValue([]);
      getWorksListData(activeForm, '');
    }
  };

  const CardClick = (data: any) => {
    console.log('++++++++CardClick+++++++', data);
    //埋点
    StatisticalReportManager.getInstance().addStatisticalEvent(
      CONS_STATISTIC_TYPE.canvas_template_click,
      data.templates_file,
    );
    setNetLoading(true);
    getJsonUrl({ works_id: data?.templates_file }).then(async (res: any) => {
      if (res && res.data && res.data.download_url) {
        await canvasEditor?.addJSON(res.data.download_url, true);
        setNetLoading(false);
      } else if (res && res.download_url) {
        await canvasEditor?.addJSON(res.download_url, true);
        setNetLoading(false);
      } else {
        setNetLoading(false);
        dispatch(
          openToast({
            message: getTranslation(TranslationsKeys.FAILED_JSON),
            severity: 'error',
          }),
        );
      }
    });
  };

  // 数据转化
  function ChuDataChange(AllData: any, datas: any) {
    const result = Object.entries(AllData)?.map(([key, value]: [any, any]) => {
      const matchingClass = datas?.find((item: any) => {
        return item?.class_name === key;
      });

      return {
        label: key,
        id: matchingClass?.id || null,
        total: value?.total,
        list: value?.works_list?.map((item: any) => ({
          image: item?.cover_tiny_link,
          templates_file: item?.works_id,
          isCollect: item?.like_status,
          rules: {
            title: item?.description,
            username: item?.user?.nickname,
            avatar: item?.user?.avatar,
            CategoryList: item?.tags,
            id: item?.works_id,
            like_status: item?.like_status,
          },
        })),
      };
    });
    return result;
  }

  function transformData(data: any, initial: any) {
    const transformedData =
      (Array.isArray(data?.data?.works_list) &&
        data?.data?.works_list?.length &&
        data?.data?.works_list?.map((item: any) => {
          return {
            image: item?.cover_tiny_link,
            templates_file: item?.works_id,
            isCollect: item?.like_status, //1:已收藏 2:未收藏
            rules: {
              title: item?.description,
              username: item?.user?.nickname,
              avatar: item?.user?.avatar,
              CategoryList: item?.tags,
              id: item?.works_id,
              like_status: item?.like_status, //1:已收藏 2:未收藏
            },
          };
        })) ||
      [];

    return [
      {
        label: data?.data?.total === 0 ? '' : initial ? initial : 'All',
        total: data?.data?.total === 0 ? '' : data?.data?.total?.toString(),
        id: 9999,
        list: transformedData,
      },
    ];
  }

  // 筛选数据的获取
  const getWorksListData = async (FilterValue: any, SearchData: any) => {
    setLoading(true);
    setTemplates_data([]);
    setListMore(false);
    const filters: any = {};
    // console.log("FilterValue", FilterValue);
    FilterValue = getCacheItem('templatesMenu')?.['activeForm'] || FilterValue;
    // console.log('activeForm', getCacheItem('templatesMenu')?.['activeForm'])
    if (FilterValue?.product?.length > 0 || filterValue?.product?.length > 0) {
      filters.style_type = {
        $find_in: [FilterValue?.product || filterValue?.product],
      };
    }

    if (FilterValue?.tags?.length > 0 || filterValue?.tags?.length > 0) {
      filters.tag_ids = {
        $find_in: FilterValue?.tags || filterValue?.tags,
      };
    }

    if (SearchData !== 'clear') {
      if (!!searchValue) {
        if (searchValue?.length === 1) {
          // 一个字符的时候，精准搜索
          filters.name = {
            $eq: searchValue,
          };
        } else {
          filters.fulltext = {
            $fuzzy: searchValue,
          };
        }
      }
    }

    const data = await getWorksList({
      filters: Object.keys(filters).length > 0 || !!searchValue ? filters : undefined,
      scene: 201,
      pagination: {
        page: 1,
        page_size: PAGE_SIZE,
      },
    });
    setTemplates_data(transformData(data, ''));
    // setCacheItem('templatesMenu', {
    //   'pageData': transformData(data, ''),
    //   'searchValue': searchValue,
    //   'activeForm': FilterValue || [],
    // },)
    setLoading(false);
  };

  // 初始数据的获取
  const getInitialValue = async (datas: any) => {
    // setLoading(true)
    setLoading(false);
    interface_loading.current = true;
    let ItemId = '';

    const promises = datas?.map((item: any) => {
      ItemId = item?.id;
      return getWorksList({
        // @ts-ignore
        filters: {
          style_type: {
            $find_in: [item?.id],
          },
        },
        scene: 201,
        pagination: {
          page: 1,
          page_size: PAGE_SIZE,
        },
      }).then((result: any) => {
        // console.log("result", result);
        const newData = { [item?.class_name]: result?.data || [] };
        const processedData = ChuDataChange(newData, datas);
        if (Array.isArray(processedData)) {
          // 检查 processedData 是否是数组
          setTemplates_data((prevData: any) => {
            // console.log("--------prevData", prevData);
            // 确保 prevData 是数组
            prevData = Array.isArray(prevData) ? prevData : [];
            // 创建一个新的数组，用于存储更新后的数据
            let newData = [...prevData];

            processedData?.forEach((newItem: any) => {
              // 在旧数据中找到与新数据具有相同 id 的项的索引
              const index = prevData?.findIndex((oldItem: any) => oldItem?.id === newItem?.id);
              // 如果找到了匹配的项，就用新数据替换旧数据
              if (index !== -1) {
                newData[index] = newItem;
              }
            });
            const cacheData = getCacheItem('templatesMenu') || {};
            setCacheItem('templatesMenu', {
              ...cacheData,
              pageData: newData,
            });
            // 返回更新后的数据
            return newData;
          });
        }
        interface_loading.current = false;
      });
    });
    const results = await Promise?.all(promises);
    // console.log("result--=------", newAllData);
    if (datas && datas?.length > 0) {
      currentIndex.current = currentIndex.current + 5;
    }
    // 当前数据大于缓存数据时，且返回的数据大于List_PAGE_SIZE条数时，加载更多
    setListMore(datas?.length >= List_PAGE_SIZE);
    setRefreshLoading((prevIds: any) => prevIds?.filter((id: string) => id !== ItemId));
    interface_loading.current = false;
    setListLoading(false);
  };

  // 加载更多数据获取,点击seeAll时调用，nowItemClass：当前点击的小类，clear：清空数据状态,NewTotal：最新的页码
  const getMoreValue = async (nowItemClass: any, clear: string, NewPage: number) => {
    setLoading(false);
    if (NewPage) {
      pageIndex.current = NewPage;
    }
    // 当前的数据大于等于总数时，就不跑加加载更多的方法
    if (nowItemClass?.list?.length >= nowItemClass?.total) {
      setLoading(false);
      setHasMore(false);
      return;
    }
    if (clear === 'clear') {
      setSeeAllData([]);
      pageIndex.current = 2;
    }
    let ret: any = [];
    const filters: any = {};

    if (filterValue?.product?.length > 0) {
      filters.style_type = {
        $find_in: [filterValue?.product],
      };
    }

    if (filterValue?.tags?.length > 0) {
      filters.tag_ids = {
        $find_in: filterValue?.tags,
      };
    }

    if (!!searchValue) {
      if (searchValue?.length === 1) {
        // 一个字符的时候，精准搜索
        filters.name = {
          $eq: searchValue,
        };
      } else {
        filters.fulltext = {
          $fuzzy: searchValue,
        };
      }
    }

    const data = await getWorksList(
      nowItemClass?.id !== 9999
        ? {
            // @ts-ignore
            filters: {
              style_type: {
                $find_in: [nowItemClass?.id],
              },
            },
            scene: 201,
            pagination: {
              page: pageIndex.current,
              page_size: PAGE_SIZE,
            },
          }
        : {
            // @ts-ignore
            filters: Object.keys(filters).length > 0 || !!searchValue ? filters : undefined,
            scene: 201,
            pagination: {
              page: pageIndex.current,
              page_size: PAGE_SIZE,
            },
          },
    );

    const newItem = transformData(data, 'initial')[0];
    if (newItem && newItem?.list.length > 0) {
      ret = newItem?.list;
      pageIndex.current++;
    }

    setSeeAllData((oldData: any) => {
      // 创建一个新的数组，包含旧的sideData和新的list数据
      const newData = [...oldData];
      // const newItem = transformData(data, 'initial')[0];
      const existingItem = newData.find((data: any) => data.id === newItem.id);

      if (existingItem) {
        // 如果item已经存在于sideData中，那么更新它的list
        existingItem.list = [...existingItem.list, ...newItem.list];
      } else {
        // 如果item不存在于sideData中，那么添加它，需要加入第一页的数据
        newData.push({
          ...nowItemClass,
          list: [...nowItemClass?.list, ...newItem.list],
        });
      }
      // 返回新的sideData
      if (SeeAllref.current) {
        setTemplates_data(newData);
        setCacheItem('templatesMenu', replaceGraphicData(newData, getCacheItem('templatesMenu')));
      }
      return newData;
    });

    setLoading(false);
    setHasMore(ret.length >= PAGE_SIZE);
  };

  // 往右侧滚动加载跟多方法
  const RightMoreData = async (nowItemClass: any) => {
    // console.log("------>");
    if (refRightState.current === true) {
      return;
    }
    let nextPage = 1;
    const filters: any = {};
    // 计算当前页数
    const currentPage = Math.ceil(nowItemClass?.list.length / PAGE_SIZE);
    // 判断是否有下一页
    if (nowItemClass?.list.length >= nowItemClass?.total) {
      // console.log("不需要调用接口，已加载所有数据。");
      return;
    } else {
      // 计算下一次调用接口的页数
      nextPage = currentPage + 1;
      refRightState.current = true;
    }

    if (filterValue?.product?.length > 0) {
      filters.style_type = {
        $find_in: [filterValue?.product],
      };
    }

    if (filterValue?.tags?.length > 0) {
      filters.tag_ids = {
        $find_in: filterValue?.tags,
      };
    }

    if (!!searchValue) {
      if (searchValue?.length === 1) {
        // 一个字符的时候，精准搜索
        filters.name = {
          $eq: searchValue,
        };
      } else {
        filters.fulltext = {
          $fuzzy: searchValue,
        };
      }
    }

    const data = await getWorksList(
      nowItemClass?.id !== 9999
        ? {
            // @ts-ignore
            filters: {
              style_type: {
                $find_in: [nowItemClass?.id],
              },
            },
            scene: 201,
            pagination: {
              page: nextPage,
              page_size: PAGE_SIZE,
            },
          }
        : {
            // @ts-ignore
            filters: Object.keys(filters).length > 0 || !!searchValue ? filters : undefined,
            scene: 201,
            pagination: {
              page: nextPage,
              page_size: PAGE_SIZE,
            },
          },
    );
    const newItem = transformData(data, nowItemClass?.label)[0];
    const newData = appendListToDataA(templates_data, newItem);
    setTemplates_data(newData);
    refRightState.current = false;
    return 'success';
  };

  // 点击seeAll时调用，seeAllState：是否点击了seeAll，item：当前点击的小类，clear：清空数据状态
  const IsSeeAll = (seeAllState: any) => {
    SeeAllref.current = seeAllState;
    setIsSeeAll(seeAllState);
  };

  // 清空seeAll状态
  const clearSeeAllState = () => {
    refdata.current.resetExpandedStates();
  };

  // 获取所有类
  const fetchSonClass = async () => {
    if (typeof window === 'undefined') return;
    setIsError(false);
    setListLoading(true);
    interface_loading.current = true;
    const cacheData = getCacheItem('templatesMenu');
    // 一进入页面时，判断AllTypeData内是否存在数据，如果没有就调接口，如果存在就直接取值
    const hasLabel = cacheData?.TypeData?.some((_: any) => {
      // console.log("youhuancun ")
      if (cacheData?.TypeData.length > 0) {
        const newData = cacheData?.TypeData.slice(currentIndex.current, currentIndex.current + 5);
        setTemplates_data(newData);
        getInitialValue(newData);
        return true;
      }
      return false;
    });

    // 如果AllTypeData内不存在label，那么就调接口获取数据
    if (hasLabel) return;

    // console.log("meihuanc");
    try {
      const json = await get<{ data: any }>('/web/cms-proxy/common/content', {
        // cms接口地址
        content_type: 'make-2d-templates-classes',
        pagination: {
          page: 1,
          pageSize: 10000,
        },
        sort: ['weight:DESC'], // 按weight降序排列
      });
      let data = [] as any;
      console.log('json', json);

      json.data?.data?.map((_: any) => {
        data.push({
          label: _?.attributes?.class_name,
          id: _?.id,
          class_name: _?.attributes?.class_name,
        });
      });

      setAllTypeData((oldData: any) => {
        setCacheItem('templatesMenu', {
          ...(getCacheItem('templatesMenu') || {}),
          TypeData: data,
        });
        return data;
      });

      const newData = data.slice(currentIndex.current, currentIndex.current + 5);
      setTemplates_data(newData);
      getInitialValue(newData);
    } catch (error) {
      console.log('fetchSonClass方法错误');
      setListLoading(false);
      interface_loading.current = false;
      setIsError(true);
      return;
    }
  };

  const item_refresh = (item: any) => {
    // 添加需要loading状态的id项
    setRefreshLoading((oldData: any) => [...oldData, item.id]);
    getInitialValue([{ label: item.label, id: item?.id }]);
  };

  //  首页加载更多数据
  const fetchListMore = () => {
    // 需要处理
    if (interface_loading.current === true) {
      // 延迟一秒再跑一次
      // setTimeout(fetchListMore, 1000);
      return;
    }

    const cachePageData = getCacheItem('templatesMenu') || {};
    // 只有所有数据大于缓存数据时才加载更多
    if (AllTypeData?.length <= cachePageData?.pageData?.length) {
      setListMore(false);
      return;
    }

    if (isSeeAll === true) return;
    // 存放五项数据，超出高度就加载后面五项
    const newData1 = AllTypeData?.slice(currentIndex.current, currentIndex.current + 5);
    // 率先展示小类，然后再调接口填充值
    setTemplates_data((item: any) => {
      getInitialValue(newData1);
      return [...item, ...newData1];
    });
  };

  useEffect(() => {
    // 没有点击seeAll时,不是切换tab,不是刚进入页面时,使用旧的数据
    // 当输入框存在数据时，不设置表格数据，使用旧值
    if (searchValue.length === 0) {
      // 没有点击seeAll时,不是切换tab,不是刚进入页面时,使用旧的数据
      if (!isSeeAll && isSeeAll !== '') {
        setTemplates_data(cacheData('templatesMenu'));
      }
    } else {
      if (!isSeeAll && isSeeAll !== '') {
      }
    }
  }, [isSeeAll]);

  useEffect(() => {
    const cacheFilterValue = getCacheItem('templatesMenu')?.['activeForm'];
    if (cacheFilterValue) {
      setFilterValue(cacheFilterValue);
    }
    refInput.current.resetExpandedStates();
    const cacheData = getCacheItem('templatesMenu') || {};
    setAllTypeData(cacheData.TypeData || []);

    if (cacheData && cacheData?.pageData?.length > 0) {
      setTemplates_data(cacheData?.pageData);
      // 总数据大于当前数据时，加载更多
      if (cacheData.TypeData.length > cacheData?.pageData?.length) {
        currentIndex.current = cacheData?.pageData?.length;
        // console.log("rrr");
        setListMore(true);
      } else {
        // console.log("lll");
        setListMore(false);
        return;
      }
    } else {
      fetchSonClass();
    }
  }, []);

  // 输入值 加上过滤 切换页 叉掉输入值 还有过滤

  return (
    <div className="templates_box">
      <TemplatesPopover
        open={FilterPopoverState}
        onClose={onClose}
        anchorEl={anchorEl}
        data={filterData}
        ConfirmClick={ConfirmClick}
        ClearnAllClick={ClearnAllClick}
      />

      <div className="templates_top">
        <div className="templates_title">{getTranslation(TranslationsKeys.Templates)}</div>
      </div>

      <div
        style={{
          pointerEvents: interface_loading.current ? 'none' : undefined,
        }}
        className="TemplatesInput_box"
      >
        <TemplatesInput
          SearchValue={SearchValue}
          IconClick={IconClick}
          editClick={editClick}
          getSearchData={getWorksListData}
          fetchSonClass={fetchSonClass}
          CloseState={CloseState}
          filterValue={filterValue}
          clearSeeAllState={clearSeeAllState}
          refInput={refInput}
        />
      </div>
      {isError && (
        <div className="error_box">
          <div className="no_data_box">
            <img src={empty_data_icon} className="no_data_icon" />
            <div>{getTranslation(TranslationsKeys.NO_DATA_AVAILABLE)}</div>
          </div>
          <div
            className="item_refresh"
            onClick={() => {
              fetchSonClass();
            }}
          >
            {getTranslation(TranslationsKeys.Refresh)}
          </div>
        </div>
      )}
      <div style={{ height: '87%', overflow: 'auto' }}>
        <SideTable
          data={templates_data}
          CardClick={CardClick}
          type={'Templates'}
          isLoading={isLoading}
          hasMore={hasMore}
          fetchDataMore={getMoreValue}
          IsSeeAll={IsSeeAll}
          refdata={refdata}
          item_refresh={item_refresh}
          RefreshLoading={RefreshLoading}
          fetchListMore={fetchListMore}
          ListLoading={ListLoading}
          ListMore={ListMore}
          RightMoreData={RightMoreData}
          isDetailsIcon={true}
        />
      </div>
      <VagueLoading loading={isNetLoading} />
    </div>
  );
}

export default ImportTmpl;
