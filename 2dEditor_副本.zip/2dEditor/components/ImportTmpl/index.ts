import ImportTmpl from "./ImportTmpl";
import './index.scss';

export default ImportTmpl;