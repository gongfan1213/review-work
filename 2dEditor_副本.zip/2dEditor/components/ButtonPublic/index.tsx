import React from "react";
import { Button } from 'src/components/MakeUI'
import * as classes from './index.module.scss'


function ButtonPublic(props: any) {

  // 思路：基于二次封装的按钮再次封装，在不改变目前项目中使用的按钮基础上，确定了部分样式，移除了部分方法
  // 参数整理：
  // loading:boolean 按钮是否为加载状态
  // disabled:boolean 按钮是否不可点击
  // variant:string 按钮的样式，目前只用outlined(底色透明)，contained(绿底按钮黑色字体），greenWhite（绿底白字）
  // onClick:function 点击事件
  // style:object 按钮的样式

  return (
    <Button
      loading={props?.loading}
      disabled={props?.disabled}
      variant={props?.variant}
      onClick={props?.onClick}
      style={props?.style}
      buttonClassName={classes.buttonClassName}
    >{props?.children}</Button>
  )
}
export default ButtonPublic