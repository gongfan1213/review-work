export enum ProjectSaveState {
  SaveStateSaving = 'SaveStateSaving',
  SaveStateSaved = 'SaveStateSaved',
  SaveStateOffline = 'SaveStateOffline',
}

export enum WorkspaceID {
  WorkspaceCavas = 'workspace', // 画布范围
  WorkspaceBG = 'workspace1', //背景图层
  WorkspaceRange = 'workspace2', // 可见范围
  WorkspaceBGCavas = 'workspace3', // 图片转画布，绘制背景
  WorkspaceFrame = 'workspaceFrame', // hover框
}

export enum DownFileType {
  DownFileTypePNG = 'png',
  DownFileTypeJPG = 'jpeg',
  DownFileTypePDF = 'pdf',
  DownFileTypeSVG = 'svg',
}

export enum DownFileUnit {
  mm = 'mm',
  px = 'px',
  in = 'in',
}

export enum FabricObjectType {
  TextI = 'i-text',
  Text = 'text',
  TextBox = 'textbox',
  Image = 'image',
  SVG = 'svg',
  ///矢量
  Group = 'group',
  Path = 'path',
  Rect = 'rect',
  Polygon = 'polygon',
  Polyline = 'polyline',
  ActiveSelection = 'activeSelection',
  GuideLine = 'GuideLine',
  // pattern;
  Pattern = 'pattern',
}

export enum EventNameCons {
  OpenImageTool = 'OpenImageTool',
  OpenTextTool = 'OpenTextTool',
  EventMaterialSet = 'EventMaterialSet',
  EventUpdateDetailProject = 'EventUpdateDetailProject',
  EventUpdateDetailProjectDataOnly = 'EventUpdateDetailProjectDataOnly',
  EventUpdateProjectThumbnail = 'EventUpdateProjectThumbnail',
  EventUpdateDetailCreate = 'EventUpdateDetailCreate',
  EventProjectChangeState = 'EventProjectChangeState',
  EventUpdateMaterial = 'EventUpdateMaterial',
  Event2dObjectRemove = 'Event2dObjectRemove',
  EventProjectSaveState = 'EventProjectSaveState',
  Event2dProejctSearch = 'Event2dProejctSearch',
  EventPageFrom = 'EventPageFrom',
  EventGotoExplore = 'EventGotoExplore',
  EventHiddenCloseIcon = 'EventHiddenCloseIcon',
  EventHideZoomSelect = 'EventHideZoomSelect',
  EventHideLayerTreeList = 'EventHideLayerTreeList',
  ChangeEditorSaveState = 'ChangeEditorSaveState',
  EventCanvasTextDeSelect = 'EventCanvasTextDeSelect',
  EventCanvasChangeImg = 'EventCanvasChangeImg',
  EventGetTargetLayer = 'EventGetTargetLayer',
  EventToBottom = 'EventToBottom',
  EventToTop = 'EventToTop',
  EventHanlederLock = 'EventHanlederLock',
  EventShowCanvasDialog = 'EventShowCanvasDialog',
  EventCanvasSizeDisable = 'EventCanvasSizeDisable',
  EventUpdateLayer = 'EventUpdateLayer',
  EventOpenDisignDialog = 'EventOpenDisignDialog',
  EventHanlederSliderMax = 'EventHanlederSliderMax',
}

export enum LeftTabValue {
  LeftTabApps = 0,
  LeftCraft = 1,
  LeftTabValueModel = 2,
  LeftTabValueElements = 3,
  LeftTabValueText = 4,
  LeftTabUpload = 5,
  LeftTabProject = 6,
  LeftTabValueImageAdjustment = 7,
  LeftTabValueTextAdjustment = 8,
}

export enum LayerType {
  Vector = 'Vector Layer',
  Text = 'Text Layer',
  Image = 'Image Layer',
  Group = 'Group Layer',
  TextureImage = 'Texture Layer',
  ReliefImage = 'Relief Layer',
}

export enum CustomKey {
  IsLayerFold = '_isLayerFold', // 群组元素是否折叠
  IsView = '_isView', // 可视
  IsLock = '_isLock', // 锁
  LayerName = '_layerName', // 图层名称
  LayerNameCus = '_layerNameCus', // 图层名称
  ImageResolution = '_imageResolution', // 图片分辨率
  ImageRBLoading = '_rbLoading', // 图片去底加载中
  ImageUpscalerLoading = '_upscalerLoading', // 图片放大加载中
  ImageUpscalerProcess = '_imageUpscalerProcess', // 图片放大进度
  RelativeAngle = '_relativeAngle', // 相对画布angle
  ZIndex = '_zIndex', // 层级;
  FontUrl = '_fontUrl', // 字体样式文件url
  CustomType = '_customType', // 自定义类型
  PatternBase64 = '_patternBase64', // 图案base64
  key_prefix = 'key_prefix', // 图案base64
  skip_upload = '_skip_upload',
  ParentId = '_parentId',
  TextureType = 'textureType',
  Grayscale = 'grayscale',
  IsCanvasTexture = 'isCanvasTexture',
  IsTextureGroup = '_isTextureGroup',
  IsPublish = 'isPublish',
  Contrast = 'contrast',
  Thickness = 'thickness',
  Invert = 'invert',
  DisableRightClick = '_disableRightClick', //禁用右键菜单和快捷键
}

export const EDITOR_JSON_KEY = [
  'id',
  'gradientAngle',
  'selectable',
  'selection',
  'hasControls',
  'hasBorder',
  'source',
  'fileType',
  'importSource',
  'layerId',
  'source',
  'fileType',
  'filtersMap',
  CustomKey.key_prefix,
  'importSource',
  'cropX',
  'cropY',
  'cropKey',
  'cropPath',
  'cropSize',
  'transformType',
  'reTransform',
  'path',
  'pathAlign',
  'pathSide',
  'pathStartOffset',
  'evented',
  'imageOriginSize',
  CustomKey.skip_upload,
  CustomKey.IsLock,
  CustomKey.LayerNameCus,
  CustomKey.FontUrl, // 字体样式文件地址,用于网站加载字体样式;
  CustomKey.CustomType,
  CustomKey.PatternBase64,
  CustomKey.TextureType, //纹理类型
  CustomKey.Grayscale, //纹理灰度图
  CustomKey.IsCanvasTexture, //是否是画布级别的纹理
  CustomKey.IsTextureGroup, //是否是纹理组
  'isSVG',
  CustomKey.Contrast, //平滑度
  CustomKey.Thickness, //厚度
  CustomKey.Invert, //反转
  CustomKey.IsPublish, //是否是官方纹理库的素材
  CustomKey.DisableRightClick,
];

// ;
export enum CustomObjectType {
  Image = 'customImage',
  Pattern = 'pattern',
  Group = 'customGroup', // 内含text/image/group/pattern;
  Path = 'customPath', // path/circle/ellipse/rect等都为path;
}

export enum CustomPcAction {
  PrintAction = 'command_print',
  PrintTarGetAction = 'command_get_print_tar',
  GetDeviceInfoAction = 'command_get_device_info',
  TakePhotoAction = 'command_take_photo',
  TakePhotoProgressAction = 'command_take_photo_progress',
  SyncDeviceInfoAction = 'command_sync_device_info',
  PrintNeedLocalData = 'command_print_need_local_data',
  Command_Auto_Measure = 'command_auto_measure',
  Command_Have_Printer = 'command_have_printer',
  Command_Update_Login_Data = 'command_update_login_data',
  command_open_design_dialog = 'command_open_design_dialog',
  command_switchPage = 'command_switchPage',
}

export enum ACTION_MAGICK {
  LOCAL_MAGICK_WASM = 'LOCAL_MAGICK_WASM',
  ACTION_TYPE_DISTORT = 'ACTION_TYPE_DISTORT',
  ACTION_TYPE_DISTORT_CYLINDER = 'ACTION_TYPE_DISTORT_CYLINDER',
  ACTION_TYPE_DISTORT_ARC = 'ACTION_TYPE_DISTORT_ARC',
  ACTION_TYPE_FORMAT = 'ACTION_TYPE_FORMAT',
  ACTION_TYPE_INIT = 'ACTION_TYPE_INIT',
}

export enum ACTION_OPENCV {
  LOCAL_OPENCV = 'LOCAL_OPENCV',
  ACTION_TYPE_OPENCV_INIT = 'ACTION_TYPE_OPENCV_INIT',
}

export enum PROJECT_STANDARD_TYPE {
  PROJECT_STANDARD = 1,
  PROJECT_STANDARD_NON = 2,
}

export enum TextureType {
  CMYK = 'cmyk',
  GLOSS = 'gloss',
  RELIEF = 'relief',
}

export enum CanvasCategory {
  CANVAS_CATEGORY_PHONECASE = 2,
  CANVAS_CATEGORY_CYLINDRICAL = 4, // 旋转体
  CANVAS_CATEGORY_ACCESSORY = 6, // 配件

}

export enum CanvasSubCategory {
  CANVAS_CATEGORY_PHONECASE_NORMAL = 18,
  CANVAS_CATEGORY_CYLINDRICAL_MUG = 5,
  CANVAS_CATEGORY_ACCESSORY_STICKER_S = 12, // 配件
  CANVAS_CATEGORY_ACCESSORY_STICKER_M = 11, // 配件
}

export enum TextureMaxThickness {
  CMYK = 2,
  GLOSS = 2,
  RELIEF = 5,
}

export enum TextureMinThickness {
  CMYK = 0.2,
  GLOSS = 0.2,
  RELIEF = 2,
}

export enum CanvasParams {
  verticalRecommandedBlanklen = 7, // 7mm
  canvas_dpi_def = 100, // 默认dpi
  canvas_handle_height_def = 50,
}

export enum PrintSource {
  print_2d = '2dPrint',
  print_3d = '3dPrint',
  print_2d_light_map = '2dPrint_light_map', //灯光画
  print_2d_brush_strokes = '2dPrint_brush_strokes', //笔触画
  print_2d_stick = '2dPrint_stick', //冰箱贴
  print_2d_poster = '2dPrint_poster', //2.5d海报
}

export enum ReliefType {
  print_relief_type_def = -1, //2d
  print_relief_type_rel = 0, //浮雕
  print_relief_type_texture = 1, //纹理
  print_relief_type_textureRel = 2, //浮雕&纹理
  print_relief_type_brush_strokes = 3, //笔触
  print_relief_type_poster = 4, //海报
  print_relief_type_stick = 5, //冰箱贴
}

