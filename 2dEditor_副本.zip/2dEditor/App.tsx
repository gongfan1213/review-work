import React, { useEffect, useState } from 'react';
import './App.scss';
import {
  FabricContext,
  EventContext,
  CanvasEditorContext,
  AllRight_state,
  CanvasContext,
  ProjectContext,
  ShowUiContainerState,
} from './hooks/context';
import { SelectProvider } from './hooks/select';
import { getProjectDetail } from './service/2dEditService';
import MainUiLeft from './components/MainUi/MainUiLeft/index';
import MainUiHeader from './components/MainUi/MainUiHeader';
import MainUiRightComponent from './components/MainUi/MainUiRightComponent/Index';
import MainUiCenter from './components/MainUi/MainUiCenter/index';
import MainUiTopTool from './components/MainUi/MainUiTopTool/MainUiTopTool';
import RightclickMenu from './components/RightclickMenu';
import SelectDialog from './components/SelectDialog';
import ProjectManager from './utils/ProjectManager';
import allRight_icon from '../../images/2dEditor/allRight_icon.png';
import allLeft_icon from '../../images/2dEditor/allLeft_icon.png';
import { ProjectCreateRequestModel, ProjectModel } from './components/SelectDialog/model/ProjectModel';
import {
  CanvasCategory,
  CanvasParams,
  CanvasSubCategory,
  EventNameCons,
  PROJECT_STANDARD_TYPE,
} from './cons/2dEditorCons';
import { CanvasEventEmitter } from './utils/event/notifier';
import { toast, Toast } from './components/Toast';
import { AIFeedback } from './components/AIFeedback';
import Loading from '../Relief/components/Loading';
import ToastTip from 'src/components/MakeUI/ToastTip/index';
import { isPc } from 'src/common/jsbridge';
import { getLocalStorage, removeLocalStorage, isLogined } from 'src/common/storage';
import { createProjectRequest, handleError } from './utils/utils';
import { fetchAllToolsDataCms } from 'src/templates/Search/services';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from '@volcengine/i18n';
import { titleMapping } from 'src/templates/2dEditor/components/FrontApps/const';
import VagueLoading from 'src/components/VagueLoading';
import { From2dEditorType } from 'src/templates/2dEditor/utils/event/types';
import { BaseMapChangeManager } from './components/BaseMapChange/logic/BaseMapChangeManager';
import eventBus from './core/eventbus';
import { SelectImgToPngData } from './components/BaseMapChange/model/OutLineData';
import { upDateIsShowLogin } from 'src/state/reducers/webLogin';
import TexturePreview from 'src/templates/2dEditor/components/TextureEdit/TexturePreview';
import { selectHome } from 'src/state/reducers/home';
import { StatisticalReportManager } from 'src/common/logic/StatisticalReportManager';
import { CONS_STATISTIC_TYPE } from 'src/common/cons/CommonCons';
import MainUiRightCamera from './components/MainUi/MainUiRightCamera';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

import { CategoryModel } from './components/SelectDialog/model/CategoryModel';
import StringUtil from 'src/common/utils/stringUtil';
function App({ location }: any) {
  const [event, setEvent] = useState<CanvasEventEmitter | null>(null);
  const [canvasEditor, setCanvasEditor] = useState<any>(undefined);
  const [fabric, setFabric] = useState<any>(null);
  const [allRight_state, setAllRight_state] = useState<any>({ state: false });
  const [selectDialogVisible, setSelectDialogVisible] = useState<boolean>(false);
  const [canvas, setCanvas] = useState<any>();

  const [projectModel, setProjectModel] = useState<any>(null);
  const [dialogData, setDialogData] = useState<any>({});
  const [isClose, setIsClose] = useState<boolean>(true);
  const [isOff, setIsOff] = useState<boolean>(false);
  //isPc toDo
  const [dialogState, SetDialogState] = useState(isPc());
  const [active, setActive] = React.useState();
  const [toastTipOpen, setToastTipOpen] = React.useState(false);
  const [isNetLoading, setNetLoading] = useState(true);
  const [showLeftTabPanel, setShowLeftTabPanel] = useState<boolean>(true);
  const [showUiContainer, setShowUiContainer] = useState<boolean>(true);
  const [editUrl, setEditUrl] = useState<boolean>(false);
  const [showTextureView, setShowTextureView] = useState<boolean>(false);
  const dispatch = useDispatch();
  const { t } = useTranslation();
  const { getTranslation } = useCustomTranslation();
  const homeState = useSelector(selectHome);

  useEffect(() => {
    if (!projectModel) return;
    if (!canvasEditor) {
      Promise.all([import('./core'), import('./utils/event/notifier'), import('fabric')]).then(
        ([coreModule, notifierModule, fabricModule]) => {
          const {
            default: Editor,
            AlignGuidLinePlugin,
            CenterAlignPlugin,
            ControlPlugin,
            DownFontPlugin,
            DringPlugin,
            GroupAlignPlugin,
            MaterialPlugin,
            MoveHotKeyPlugin,
            RulerPlugin,
            WorkspacePlugin,
            ImageToolPlugin,
            ImagePlugin,
            TextPlugin,
            ArcTextPlugin,
            BasicFnPlugin,
            InitPlugin,
            PatternPlugin,
            HistoryPlugin,
            OverwritePlugin,
            TemplatePlugin,
          } = coreModule;
          const { CanvasEventEmitter } = notifierModule;
          const { fabric } = fabricModule;
          const _event = new CanvasEventEmitter();
          const _canvasEditor = new Editor();
          setFabric(fabricModule.fabric);
          // 初始化fabric
          const canvas = new fabric.Canvas('canvas', {
            fireRightClick: true, // 启用右键，button的数字为3
            stopContextMenu: true, // 禁止默认右键菜单
            controlsAboveOverlay: true, // 超出clipPath后仍然展示控制条
            preserveObjectStacking: true, // 保持对象的堆叠顺序, 即active某个元素不让其置顶
            selectionBorderColor: '#3ADB67', // 选择边框色;
            selectionColor: 'rgba(112, 216, 116, .1)', // 选择框背景色;
            imageSmoothingEnabled: false, // 禁用图片平滑
            perPixelTargetFind: false, // 点击控制器内透明区域选中;
          });
          const canvas_bg = new fabric.Canvas('canvas_bg', {
            fireRightClick: true, // 启用右键，button的数字为3
            stopContextMenu: true, // 禁止默认右键菜单
            controlsAboveOverlay: true, // 超出clipPath后仍然展示控制条
            preserveObjectStacking: true, // 保持对象的堆叠顺序, 即active某个元素不让其置顶
            selectionBorderColor: '#3ADB67', // 选择边框色;
            selectionColor: 'rgba(112, 216, 116, .1)', // 选择框背景色;
            imageSmoothingEnabled: false, // 禁用图片平滑
            perPixelTargetFind: false, // 点击控制器内透明区域选中;
          });
          setCanvas(canvas);
          const print_param = JSON.parse(projectModel?.canvases[projectModel?.canvasesIndex]?.print_param || '{}');
          // 初始化编辑器
          _canvasEditor.init(canvas, _event, canvas_bg);
          _canvasEditor.use(InitPlugin);
          _canvasEditor.use(DringPlugin);
          _canvasEditor.use(AlignGuidLinePlugin);
          _canvasEditor.use(ControlPlugin);
          _canvasEditor.use(CenterAlignPlugin);
          _canvasEditor.use(MoveHotKeyPlugin);
          _canvasEditor.use(GroupAlignPlugin);
          _canvasEditor.use(DownFontPlugin);
          _canvasEditor.use(RulerPlugin);
          _canvasEditor.use(MaterialPlugin);
          _canvasEditor.use(ImageToolPlugin);
          _canvasEditor.use(ImagePlugin);
          _canvasEditor.use(PatternPlugin);
          _canvasEditor.use(TextPlugin);
          _canvasEditor.use(ArcTextPlugin);
          _canvasEditor.use(BasicFnPlugin);
          _canvasEditor.use(HistoryPlugin);
          _canvasEditor.use(OverwritePlugin);
          _canvasEditor.use(TemplatePlugin);
          _canvasEditor.use(WorkspacePlugin, {
            width: projectModel?.canvases[projectModel?.canvasesIndex]?.base_map_width || 0,
            height: projectModel?.canvases[projectModel?.canvasesIndex]?.base_map_height || 0,
            url: projectModel?.canvases[projectModel?.canvasesIndex]?.base_map || '',
            cavas_map: print_param?.cavas_map || '',
            shape_cavas_map: print_param?.shape_cavas_map || '',
            bg_cavas_map: print_param?.bg_cavas_map || '',
            is_standard_product: projectModel?.project_info?.is_standard_product,
            canvasShape:
              JSON.parse(projectModel?.canvases[projectModel?.canvasesIndex]?.extra || '{}')?.canvasShape || '',
            bleedingLine:
              JSON.parse(projectModel?.canvases[projectModel?.canvasesIndex]?.extra || '{}')?.bleedingLine || null,
            params: print_param,
            category: projectModel?.project_info.category,
            getTranslation: getTranslation,
            canvas_bg: canvas_bg,
          });
          // 开启刻度尺;
          // _canvasEditor.rulerEnable();
          _event.init(canvas);
          setEvent(_event);
          setCanvasEditor(_canvasEditor);
          handleToast(projectModel);
          //埋点
          StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.into_2d_editor);
          _event?.on(EventNameCons.EventUpdateDetailProject, handleCreate);
          _event?.on(EventNameCons.EventUpdateDetailProjectDataOnly, updateProjectDataOnly);
        },
      );
    }
  }, [projectModel]);

  useEffect(() => {
    if (projectModel) return;
    const params = new URLSearchParams(window?.location?.search || location?.location?.search);
    const project_id = params.get('project_id') || '';
    const fromSourceType = params.get('type') || '';
    const AiTitle = params.get('AiTitle') || '';
    console.log('=====URLSearchParams====project_id==', project_id, AiTitle, location?.state?.EditorParmas?.key);
    // 2dStudio 进入，携带了完整project数据
    if (isPc() && (location?.state?.EditorParmas?.key === '2dStudio')) {
      console.log('pc进入-->', location?.state?.EditorParmas?.data);
      const projectId = project_id || location?.state?.EditorParmas?.data?.project_id;
      const type = location?.state?.EditorParmas?.type;
      const aiTitle = location?.state?.EditorParmas?.AiTitle;
      // 关闭选择对话框
      setSelectDialogVisible(false);
      // 设置关闭状态
      setIsClose(false);
      // 设置关闭状态为开启
      setIsOff(true);
      if (type) {
        location.state.EditorParmas.data.canvasesIndex = 0;
        setProjectModel(location.state.EditorParmas.data);
        return;
      }
      // 获取项目详情并更新项目模型
      getProjectDetail({ project_id: projectId }).then((resp) => {
        if (resp?.data) {
          const updatedProjectModel = { ...resp.data, canvasesIndex: 0 };
          console.log('pc进入-data ret====', updatedProjectModel);
          setProjectModel(updatedProjectModel);
        }
      });
      return;
    }

    // web端my-project进入
    if (location?.state?.EditorParmas?.key === 'userPublished') {
      let { project_id } = location?.state?.EditorParmas?.data;
      setSelectDialogVisible(false);
      getProjectDetail({ project_id: project_id }).then((resp) => {
        if (resp && resp.data) {
          let payload = resp.data;
          payload.project_info.project_id = project_id;
          payload.canvasesIndex = 0;
          setProjectModel(payload);
        }
      });
      return;
    }

    const project_modle: any = getLocalStorage('projectData') ? getLocalStorage('projectData') : '';
    if (!fromSourceType) {
      //如果直接从浏览器地址栏输入url进入2d编辑器，打开选择标品弹窗
      if (!isLogined()) {
        dispatch(upDateIsShowLogin(true));
      } else {
        setNetLoading(false);
        setSelectDialogVisible(true);
      }
    } else {
      //从外部2d Porject跳转2d编辑器
      setSelectDialogVisible(false);
      if (project_id) {
        console.log('project_id进入=====', project_id);
        setSelectDialogVisible(false);
        getProjectDetail({ project_id: project_id }).then((resp) => {
          if (resp && resp.data) {
            let payload = resp.data;
            payload.project_info.project_id = project_id;
            payload.canvasesIndex = 0;
            handleCreate(payload);
            if (!isPc()) {
              const params = {
                project_id: payload?.project_info?.project_id,
                type: From2dEditorType.NewProject,
              };
              const queryString = new URLSearchParams(params).toString();
              history.pushState({}, '', `/apps/2dEditor/?${queryString}`);
            }
          }
        });
      }
      if (fromSourceType === From2dEditorType.AiTool && project_modle) {
        project_modle.canvasesIndex = 0;
        setProjectModel(project_modle);
        setIsClose(false);
        setIsOff(true);
      } else if (fromSourceType === From2dEditorType.CreateProjectAuto) {
        ProjectManager.getInstance().fetchSonClass((data: any, mockMaterialData: any[], mockBlankData: []) => {
          var categoryData: any = ProjectManager.getInstance().mockMaterialData?.[0]?.attributes.options[0];
          var category = CanvasCategory.CANVAS_CATEGORY_PHONECASE;
          var subCategory = CanvasSubCategory.CANVAS_CATEGORY_PHONECASE_NORMAL;
          ProjectManager.getInstance().mockMaterialData.forEach((item: any) => {
            if (item.attributes.categoryType.data.attributes.categoryKey == category) {
              item.attributes.options.forEach((option: any) => {
                if (option.categorySubType.data.attributes.categorySubKey == subCategory) {
                  categoryData = option;
                  categoryData.width = Math.round(
                    StringUtil.mmToPixel(option.baseMapWidth, CanvasParams.canvas_dpi_def),
                  );
                  categoryData.height = Math.round(
                    StringUtil.mmToPixel(option.baseMapHeight, CanvasParams.canvas_dpi_def),
                  );
                  categoryData.categoryType = item.attributes.categoryType;
                  return;
                }
              });
            }
          });
          const projectRequest: any = createProjectRequest({ ...categoryData });
          if (projectRequest instanceof Promise) {
            projectRequest.then((newProjectModle: any) => {
              const result: any = handleError(newProjectModle, dispatch, t);
              if (result) {
                handleCreate({ ...result, canvasesIndex: 0 });
                if (!isPc()) {
                  const params = {
                    project_id: result?.project_info?.project_id,
                    type: From2dEditorType.NewProject,
                  };
                  const queryString = new URLSearchParams(params).toString();
                  history.pushState({}, '', `/apps/2dEditor/?${queryString}`);
                }
              }
            });
          }
        });
      } else if (fromSourceType !== From2dEditorType.AiTool) {
        removeLocalStorage('project_modle');
      }
    }
  }, [window?.location?.search, location?.location?.search]);

  useEffect(() => {
    if (!canvasEditor || !event || !projectModel) return;
    ProjectManager.getInstance().init(canvasEditor, event, projectModel);
    ProjectManager.getInstance().start();
    const params = new URLSearchParams(location.search);
    const project_id = params.get('project_id') || '';
    if (project_id) {
      ProjectManager.getInstance().loadProjectFirst(projectModel, () => {
        setNetLoading(false);
      });
    } else {
      setNetLoading(false);
    }
    eventBus?.on(EventNameCons.EventCanvasChangeImg, handleReplaceByChangeImg);
    eventBus?.on(EventNameCons.EventShowCanvasDialog, handleShowCanvasDialog);

    return () => {
      ProjectManager.getInstance().stop();
      eventBus?.off(EventNameCons.EventCanvasChangeImg, handleReplaceByChangeImg);
      eventBus?.off(EventNameCons.EventShowCanvasDialog, handleShowCanvasDialog);

      event?.off(EventNameCons.EventUpdateDetailProject, handleCreate);
      event?.off(EventNameCons.EventUpdateDetailProjectDataOnly, updateProjectDataOnly);
    };
  }, canvasEditor);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    BaseMapChangeManager.getInstance().init();
    // 在用户离开页面前执行的函数
    const handleBeforeUnload = (event: any) => {
      // 阻止默认行为，并设置返回值
      if (!ProjectManager.getInstance().editPageCheckSave()) {
        event.preventDefault();
      }
    };
    // 添加事件监听器
    window.addEventListener('beforeunload', handleBeforeUnload);
    // 返回一个清理函数，在组件卸载时执行
    return () => {
      removeLocalStorage('projectData');
      // 移除事件监听器
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []); // 空依赖数组表示这个 effect 只在组件加载和卸载时运行

  const allRight_click = (value: any) => {
    setAllRight_state({ state: value });
  };
  const handleShowCanvasDialog = () => {
    setEditUrl?.(true);
    ProjectManager?.getInstance()?.atOnceSave();
    setSelectDialogVisible && setSelectDialogVisible(true);
    setIsClose && setIsClose(true);
    setIsOff && setIsOff(true);
  };

  /**
   * 选择标品后回调（创建和切换项目）
   * @param data 源数据
   */
  const handleCreate = (data?: any) => {
    event?.emitEvent(EventNameCons.EventProjectChangeState, true);
    if (data) data.canvasesIndex = 0;
    if (isClose && data) {
      canvasEditor?.clear(true);
      canvasEditor?.updateWorkspace({
        width: data?.canvases[data?.canvasesIndex].base_map_width || 0,
        height: data?.canvases[data?.canvasesIndex].base_map_height || 0,
        url: data?.canvases[data?.canvasesIndex].base_map || '',
        cavas_map: JSON.parse(data?.canvases[data.canvasesIndex].print_param || '{}')?.cavas_map || '',
        is_standard_product: data?.project_info?.is_standard_product,
        canvasShape: JSON.parse(data?.canvases[data.canvasesIndex]?.extra || '{}')?.canvasShape || '',
        bleedingLine: JSON.parse(data?.canvases[data.canvasesIndex]?.extra || '{}')?.bleedingLine || null,
        params: JSON.parse(data?.canvases[data?.canvasesIndex]?.print_param || '{}'),
        category: data?.project_info.category,
      });
      ProjectManager.getInstance().updateProjectData(data);
      event?.emitEvent(EventNameCons.EventUpdateDetailCreate, data);
    }
    if (data) setProjectModel(data);
    setNetLoading(false);
    setSelectDialogVisible(false);
    event?.emitEvent(EventNameCons.EventProjectChangeState, false);
    handleToast(data);
  };

  const handleReplaceByChangeImg = (data: SelectImgToPngData) => {
    console.log('handleReplaceByChangeIm=====start==', data);
    // canvasEditor?.canvas.discardActiveObject();
    handleReplace(data.newProjectModel!, data.newImgBase64, data.newBgImgBase64);
    if (data.atOnceSave !== false) {
      setTimeout(() => {
        ProjectManager.getInstance().atOnceSave();
      }, 100);
    }
  };

  const handleReplace = (data: ProjectModel, shape_cavas_map?: string, bg_cavas_map?: string) => {
    event?.emitEvent(EventNameCons.EventProjectChangeState, true);
    const print_param = JSON.parse(data?.canvases[data.canvasesIndex].print_param || '{}');
    canvasEditor?.updateWorkspace({
      width: data?.canvases[data?.canvasesIndex].base_map_width || 0,
      height: data?.canvases[data?.canvasesIndex].base_map_height || 0,
      url: data?.canvases[data?.canvasesIndex].base_map || '',
      cavas_map: print_param?.cavas_map || '',
      shape_cavas_map: shape_cavas_map || '',
      bg_cavas_map: bg_cavas_map || '',
      is_standard_product: data?.project_info?.is_standard_product,
      canvasShape: JSON.parse(data?.canvases[data?.canvasesIndex]?.extra || '{}')?.canvasShape || '',
      bleedingLine: JSON.parse(data?.canvases[data?.canvasesIndex]?.extra || '{}')?.bleedingLine || null,
      params: print_param,
      category: data?.project_info.category,
    });
    data.canvasesIndex = 0;
    if (!data.project_info.project_id) {
      const params = new URLSearchParams(window?.location?.search || location?.location?.search);
      const project_id = params.get('project_id') || '';
      data.project_info.project_id = project_id;
    }
    //打印参数中的字段用字符串占位，不为空时代表在画布数据里有对应的值
    print_param.shape_cavas_map = shape_cavas_map ? 'base64' : '';
    print_param.bg_cavas_map = bg_cavas_map ? 'base64' : '';
    data.canvases[data.canvasesIndex].print_param = JSON.stringify(print_param);
    setProjectModel(data);
    setSelectDialogVisible(false);
    event?.emitEvent(EventNameCons.EventProjectChangeState, false);
    handleToast(data);
    setTimeout(() => {
      canvasEditor?.clearHistory();
    }, 300)
  };

  const handleToast = (projectModel: any) => {
    if (!projectModel || !projectModel.canvases) return;
    if (ProjectManager.getInstance().isFilterTextureEffect(projectModel)) {
      setToastTipOpen(true);
    } else {
      setToastTipOpen(false);
    }
  };

  /**
   * 更新项目内部数据
   * @param data 源数据
   */
  const updateProjectDataOnly = (data: ProjectModel) => {
    setProjectModel(data);
    ProjectManager.getInstance().updateProjectData(data);
  };

  const closeClick = () => {
    SetDialogState(false);
  };

  const PrintClick = () => {
    SetDialogState(true);
  };

  const activeValue = (_: any) => {
    setActive(_);
  };

  // handle toptool show/hidden;
  const [isToptoolShow, setIsToptoolShow] = useState<boolean>(false);
  const handleToptoolShow = (flag: boolean) => {
    setIsToptoolShow(flag);
  };

  return (
    <FabricContext.Provider value={fabric}>
      <EventContext.Provider value={event}>
        <CanvasEditorContext.Provider value={canvasEditor}>
          <AllRight_state.Provider value={allRight_state}>
            <CanvasContext.Provider value={canvas}>
              <ProjectContext.Provider value={projectModel}>
                <ShowUiContainerState.Provider value={{ showUiContainer, setShowUiContainer }}>
                  <SelectProvider>
                    <div className="layoutContainer">
                      <div className="uiHeader">
                        <MainUiHeader
                          setSelectDialogVisible={setSelectDialogVisible}
                          dialogData={projectModel}
                          setIsClose={setIsClose}
                          PrintClick={PrintClick}
                          setIsOff={setIsOff}
                          setEditUrl={setEditUrl}
                        />
                      </div>
                      {/* 这里通过showUiContainer定义样式，是因为发布项目的时候需要通过页面展示，所以把内容区域隐藏了 */}
                      <div className="uiContainer" style={{ display: showUiContainer ? 'flex' : 'none' }}>
                        <div
                          className="uiLeftTool"
                          style={{
                            width: allRight_state?.state ? '98%' : 'auto',
                          }}
                        >
                          <MainUiLeft
                            activeValue={activeValue}
                            allRight_state={allRight_state}
                            location={location}
                            allRight_click={allRight_click}
                            showLeftTabPanel={showLeftTabPanel}
                            setShowLeftTabPanel={setShowLeftTabPanel}
                          ></MainUiLeft>
                          {
                            //   false bu zhang shi
                            // 侧边栏处于Apps时，不展示展开与收缩按钮
                            active !== 0 &&
                            // 默认是不展开侧边栏完全数据,true为数据已展开，false为收缩（后续收缩样式待调整）
                            active !== 0 &&
                            (active !== 1 ||
                              homeState.ShowPage === 'textureLib' ||
                              homeState.ShowPage === 'reliefMaker') &&
                            (allRight_state?.state ? (
                              <img
                                src={allLeft_icon}
                                className="allLeft_icon"
                                onClick={() => {
                                  allRight_click(false);
                                }}
                              />
                            ) : (
                              showLeftTabPanel && (
                                <img
                                  src={allRight_icon}
                                  className="allRight_icon"
                                  onClick={() => {
                                    allRight_click(true);
                                  }}
                                />
                              )
                            ))
                          }
                        </div>
                        <div className="uiCenterWrap">
                          <MainUiTopTool onShow={(e: boolean) => handleToptoolShow(e)} />
                          <div className="uiCenterWrapMaster">
                            <div className="uiCenterWrapWorkspace">
                              <MainUiCenter setShowTextureView={setShowTextureView} />
                              {/* <div
                                className="uiCenterWrapRightTool"
                                style={{ top: isToptoolShow ? '40px' : 0 }}
                              >
                                <MainUiRightCamera />
                              </div> */}
                            </div>
                          </div>
                        </div>
                        {dialogState && (
                          <div className="uiCenterWrapRightTool" style={{ top: isToptoolShow ? '40px' : 0 }}>
                            <MainUiRightComponent closeClick={() => closeClick()} />
                          </div>
                        )}
                      </div>
                      {showTextureView && (
                        <div className="texturePreviewWrap">
                          <TexturePreview setShowTextureView={setShowTextureView} />
                        </div>
                      )}
                      <SelectDialog
                        open={selectDialogVisible}
                        onClose={() => setSelectDialogVisible(false)}
                        setSelectDialogVisible={setSelectDialogVisible}
                        onCreate={handleCreate}
                        onReplace={handleReplace}
                        // setProjectModel={setProjectModel}
                        isClose={isClose}
                        isOff={isOff}
                        editUrl={editUrl}
                        location={location}
                      />
                      <RightclickMenu />
                      <Toast />
                      <ToastTip
                        open={toastTipOpen}
                        massege={getTranslation(TranslationsKeys.VIEW3D_EFFECTSTIP)}
                        handleClose={() => {
                          setToastTipOpen(false);
                        }}
                      />
                      <AIFeedback />
                      {/* <Loading loading={isNetLoading} /> */}
                      <VagueLoading loading={isNetLoading} />
                    </div>
                  </SelectProvider>
                </ShowUiContainerState.Provider>
              </ProjectContext.Provider>
            </CanvasContext.Provider>
          </AllRight_state.Provider>
        </CanvasEditorContext.Provider>
      </EventContext.Provider>
    </FabricContext.Provider>
  );
}

export default App;
