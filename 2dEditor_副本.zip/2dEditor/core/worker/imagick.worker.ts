import { AlphaOption, ColorSpace, DistortMethod, Gravity, ImageMagick, MagickColor, MagickFormat, PixelInterpolateMethod, VirtualPixelMethod, initializeImageMagick } from "@imagemagick/magick-wasm";
import IndexedDBAk from "src/common/utils/IndexedDBAk";
import { ACTION_MAGICK } from "../../cons/2dEditorCons";
import { blobToBase64 } from "src/common/utils";

async function fetchAndStoreWasm(storage: IndexedDBAk, key: string, url: string): Promise<ArrayBuffer> {
  await storage.open();
  console.log('IndexedDBAk open=======start');
  let arrayBuffer = await storage.get(key);
  if (!arrayBuffer) {
    const response = await fetch(url);
    console.log('IndexedDBAk open=======fetch');
    if (!response.ok) {
      throw new Error('Network response was not ok.');
    }
    arrayBuffer = await response.arrayBuffer();
    await storage.put(key, arrayBuffer);
  }
  console.log('IndexedDBAk open=======get');
  return arrayBuffer;
}

onmessage = async function (e) {
  const { action, data } = e.data;
  // const { dataUrl, params } = e.data;
  const storage = new IndexedDBAk();
  try {
    // 打开数据库
    await storage.open();
    try {
      const arrayBuffer = await fetchAndStoreWasm(storage, ACTION_MAGICK.LOCAL_MAGICK_WASM, '/magick.wasm');
      await initializeImageMagick(arrayBuffer);
      console.log('IndexedDBAk initializeImageMagick=======end');

      if (action === ACTION_MAGICK.ACTION_TYPE_DISTORT) {
        // 处理图像
        const imageResponse = await fetch(data.dataUrl);
        if (!imageResponse.ok) {
          throw new Error('Image response was not ok.');
        }
        const imageArrayBuffer = await imageResponse.arrayBuffer();
        const uint8Array = new Uint8Array(imageArrayBuffer);
        ImageMagick.read(uint8Array, MagickFormat.Png, (image) => {
          image.backgroundColor = new MagickColor(0, 0, 0, 0); // RGBA
          // 应用透视变换
          image.virtualPixelMethod = VirtualPixelMethod.Transparent; // 设置超出边界的像素为透明
          image.distort(DistortMethod.Perspective, data.params);
          // 将图像写入 Uint8Array
          image.write(MagickFormat.Png, (data) => {
            const mimeType = 'image/png';
            // 将 Uint8Array 转换为 Blob
            const blob = new Blob([data], { type: mimeType });
            // 将 Blob 转换为 base64
            const reader = new FileReader();
            reader.onloadend = function () {
              // reader.result 包含转换后的 base64 字符串
              const base64data = reader.result;
              self.postMessage(base64data);
            };
            reader.readAsDataURL(blob);
          });
        });
      } else if (action === ACTION_MAGICK.ACTION_TYPE_DISTORT_ARC) {
        // 处理图像
        const imageResponse = await fetch(data.dataUrl);
        if (!imageResponse.ok) {
          throw new Error('Image response was not ok.');
        }
        const imageArrayBuffer = await imageResponse.arrayBuffer();
        const uint8Array = new Uint8Array(imageArrayBuffer);
        ImageMagick.read(uint8Array, MagickFormat.Png, (image) => {
          image.backgroundColor = new MagickColor(0, 0, 0, 0); // RGBA
          // 应用透视变换
          image.virtualPixelMethod = VirtualPixelMethod.Transparent; // 设置超出边界的像素为透明
          image.distort(DistortMethod.Arc, data.params);
          // 将图像写入 Uint8Array
          image.write(MagickFormat.Png, (data) => {
            const mimeType = 'image/png';
            // 将 Uint8Array 转换为 Blob
            const blob = new Blob([data], { type: mimeType });
            // 将 Blob 转换为 base64
            const reader = new FileReader();
            reader.onloadend = function () {
              // reader.result 包含转换后的 base64 字符串
              const base64data = reader.result;
              self.postMessage(base64data);
            };
            reader.readAsDataURL(blob);
          });
        });
      } else if (action === ACTION_MAGICK.ACTION_TYPE_DISTORT_CYLINDER) {
        // 处理图像
        const imageResponse = await fetch(data.dataUrl);
        if (!imageResponse.ok) {
          throw new Error('Image response was not ok.');
        }
        const imageArrayBuffer = await imageResponse.arrayBuffer();
        const uint8Array = new Uint8Array(imageArrayBuffer);
        ImageMagick.read(uint8Array, MagickFormat.Png, (image) => {
          image.backgroundColor = new MagickColor(0, 0, 0, 0); // RGBA
          // 应用透视变换
          image.virtualPixelMethod = VirtualPixelMethod.Transparent; // 设置超出边界的像素为透明
          console.log('data.params====', data.params);
          try {
            image.distort(DistortMethod.Perspective, data.params);
            image.wave(PixelInterpolateMethod.Undefined, data.amplitude, data.length);
          } catch (error) {
            console.error('Error applying Plane2Cylinder distortion:', error);
          }

          // 将图像写入 Uint8Array
          image.write(MagickFormat.Png, (data) => {
            const mimeType = 'image/png';
            // 将 Uint8Array 转换为 Blob
            const blob = new Blob([data], { type: mimeType });
            // 将 Blob 转换为 base64
            const reader = new FileReader();
            reader.onloadend = function () {
              // reader.result 包含转换后的 base64 字符串
              const base64data = reader.result;
              self.postMessage(base64data);
            };
            reader.readAsDataURL(blob);
          });
        });
      } else if (action === ACTION_MAGICK.ACTION_TYPE_FORMAT) {
        const imageResponse = await fetch(data.dataUrl)
        if (!imageResponse.ok) {
          throw new Error('Image response was not ok.');
        }
        const imageArrayBuffer = await imageResponse.arrayBuffer();
        const uint8Array = new Uint8Array(imageArrayBuffer);
        ImageMagick.read(uint8Array, MagickFormat.Png, (image) => {
          image.colorSpace = ColorSpace.Gray;
          image.alpha(AlphaOption.Off);
          image.depth = 8;
          image.write(MagickFormat.Png, (data) => {
            const mimeType = 'image/png';
            const blob = new Blob([data], { type: mimeType });
            // 将 Blob 转换为 base64
            const reader = new FileReader();
            reader.onloadend = function () {
              // reader.result 包含转换后的 base64 字符串
              const base64data = reader.result;
              self.postMessage(base64data);
            };
            reader.readAsDataURL(blob);
          })
        });
      } else if (action === ACTION_MAGICK.ACTION_TYPE_INIT) {
        self.postMessage('ImageMagick initialized');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  } catch (error) {
    console.error('Error:', error);
  }
};

