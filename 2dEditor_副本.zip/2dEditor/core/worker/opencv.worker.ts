import { ACTION_OPENCV } from "../../cons/2dEditorCons";

onmessage = async function (e) {
  const { action, data } = e.data;
  if (action === ACTION_OPENCV.ACTION_TYPE_OPENCV_INIT) {
    // import('@techstark/opencv-js').then(cv => {
    //   cv["onRuntimeInitialized"] = async () => {
    //     console.log('onRuntimeInitialized start=======');
    //   };
    //   self.postMessage('ACTION_OPENCV initialized');
    // });
  }
}

