import { encode } from 'base64-arraybuffer';
import axios from 'axios';
// import { convertToBase64 } from 'src/common/utils';


onmessage = async (e) => {
    const res = await convertToBase64(e.data?.canvas_image)   
    postMessage(res);
}


const convertToBase64 = async (url: string) => {
  // debugger
  try {
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    const base64 = encode(response.data);
    // 使用正则表达式提取URL路径中的文件名
    const filename = url.match(/\/([^\/?#]+)(\?|#|$)/)?.[1] || '';
    // 根据文件扩展名设置MIME类型
    const mimeType = filename.endsWith('.svg') ? 'data:image/svg+xml' : 'data:image/jpeg';
    return `${mimeType};base64,${base64}`;
    
  } catch (error) {
    return '';
  }
};