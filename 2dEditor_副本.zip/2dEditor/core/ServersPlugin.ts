/*
 * @Description: 内部插件
 */
import { v4 as uuid } from 'uuid';
import { selectFiles, clipboardText, downFontByJSON } from '../utils/utils';
import { fabric } from 'fabric';
import Editor from '.';
import jsPDF from 'jspdf';
import WatermarkLogo from 'src/assets/img/watermark_logo.png';
import { ACTION_MAGICK, CanvasCategory, DownFileType, DownFileUnit, EDITOR_JSON_KEY, WorkspaceID } from '../cons/2dEditorCons';
import { CategoryScenesModel, CategorySubModel, CyRetData } from '../components/SelectDialog/model/CategoryModel';
import { ProjectCutDataModel, ProjectModel, RotaryParams } from '../components/SelectDialog/model/ProjectModel';
import greenlet from 'greenlet';
// @ts-ignore
import IMagickWorker from './worker/imagick.worker'
import { filterTextureElements, getCanvasThumbnail } from '../common/cavasUtil';
import { CanvasSizeModel } from './model/CanvasModel';
import StringUtil from 'src/common/utils/stringUtil';

type IEditor = Editor;

function downFile(fileStr: string, fileType: string) {
  const anchorEl = document.createElement('a');
  anchorEl.href = fileStr;
  anchorEl.download = `${uuid()}.${fileType}`;
  document.body.appendChild(anchorEl); // required for firefox
  anchorEl.click();
  anchorEl.remove();
}

class ServersPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  static pluginName = 'ServersPlugin';
  hasBackGround: boolean = false;
  private perspectiveTaskThread: (data: Uint8ClampedArray, outputData: Uint8ClampedArray, width: number, height: number) => Promise<Uint8ClampedArray>;

  static apis = [
    'insert',
    'insertSvgFile',
    'insertSvgFileTemp',
    'getJson',
    'getJsonCanvas',
    'dragAddItem',
    'clipboard',
    'saveJson',
    'saveSvg',
    'saveImg',
    'clear',
    'preview',
    'preview1',
    'downFile',
    'setBackGroundBool',
    'mergeSceneImages',
    'getThumbnail',
    'hasLayerPrint',
    'getCanvasSize'
  ];
  // public hotkeys: string[] = ['left', 'right', 'down', 'up'];
  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;

    this.perspectiveTaskThread = greenlet(async (data, outputData, width, height) => {
      var radius = width * 2; // 假设圆柱的周长等于图像宽度
      var centerX = width / 2; // 图像中心的x坐标

      for (var y = 0; y < height; y++) {
        for (var x = 0; x < width; x++) {
          var index = (y * width + x) * 4;
          // 计算每个像素点相对于中心的偏移
          var offsetX = x - centerX;
          // 计算像素点在圆柱上的新位置
          var angle = offsetX / radius;
          var newX = centerX + radius * Math.sin(angle);
          var newY = y + radius * (Math.cos(angle) - 1); // 圆柱的曲率导致的y坐标偏移
          // 确保新坐标在图像范围内
          newX = Math.min(Math.max(newX, 0), width - 1);
          newY = Math.min(Math.max(newY, 0), height - 1);
          // 计算新坐标的索引
          var newIndex = (Math.floor(newY) * width + Math.floor(newX)) * 4;
          // 将原像素数据复制到新位置
          outputData[newIndex] = data[index];         // R
          outputData[newIndex + 1] = data[index + 1]; // G
          outputData[newIndex + 2] = data[index + 2]; // B
          outputData[newIndex + 3] = data[index + 3]; // A
        }
      }
      return outputData; // 返回计算结果
    });
  }

  setBackGroundBool(hasBackGround: boolean) {
    this.hasBackGround = hasBackGround;
  }

  insert() {
    selectFiles({ accept: '.json' }).then((files) => {
      const [file] = files;
      const reader = new FileReader();
      reader.readAsText(file, 'UTF-8');
      reader.onload = () => {
        this.insertSvgFile(reader.result);
      };
    });
  }

  insertSvgFile(jsonFile, callBack?: Function) {
    // 加载前钩子
    this.editor.hooksEntity.hookImportBefore.callAsync(jsonFile, () => {
      this.canvas.loadFromJSON(jsonFile, () => {
        this.canvas.renderAll();
        if (callBack) {
          callBack();
        }
        // 加载后钩子
        this.editor.hooksEntity.hookImportAfter.callAsync(jsonFile, () => {
          this.canvas.renderAll();
        });
      });
    });
  }

  insertSvgFileTemp(jsonFile: string, canvas: fabric.Canvas): Promise<void> {
    // 加载前钩子
    return new Promise<void>((resolve, reject) => {
      downFontByJSON(jsonFile).then(() => {
        console.log('insertSvgFile===2222');
        canvas.loadFromJSON(jsonFile, () => {
          console.log('insertSvgFile===33333');
          canvas.renderAll();
          resolve();
        });
      })
    });
  }

  getJson() {
    return this.getJsonCanvas(this.canvas);
  }

  getCanvasSize(): CanvasSizeModel {
    let canvasSize: CanvasSizeModel = {
      width: 0,
      height: 0,
      width_mm: 0,
      height_mm: 0
    }
    const workspaces: fabric.Object | undefined = this.canvas?.getObjects().find((item) => (item as any).id === WorkspaceID.WorkspaceCavas);
    if (workspaces) {
      const width = workspaces.width! * workspaces.scaleX!;
      const height = workspaces.height! * workspaces.scaleY!;
      canvasSize.width = width;
      canvasSize.height = height;
      var retSize = StringUtil.pixelsToMM(width, height, 100,);
      canvasSize.width_mm = retSize.widthMM;
      canvasSize.height_mm = retSize.heightMM;
    }
    return canvasSize;
  }

  getJsonCanvas(canvas: fabric.Canvas) {
    return canvas.toJSON(EDITOR_JSON_KEY);
  }

  hasLayerPrint(canvas: fabric.Canvas): boolean {
    const objects = canvas.getObjects();
    // 过滤掉 id 包含 WorkspaceID.WorkspaceCavas 的对象
    const otherObjects = objects.filter(obj => !(obj as any).id.includes(WorkspaceID.WorkspaceCavas));
    // 如果存在其他对象，则返回 true，否则返回 false
    return otherObjects.length > 0;
  }

  /**
   * @description: 拖拽添加到画布
   * @param {Event} event
   * @param {Object} item
   */
  dragAddItem(event: DragEvent, item: fabric.Object) {
    const { left, top } = this.canvas.getSelectionElement().getBoundingClientRect();
    if (event.x < left || event.y < top || item.width === undefined) return;
    const point = {
      x: event.x - left,
      y: event.y - top,
    };
    const pointerVpt = this.canvas.restorePointerVpt(point);
    item.left = pointerVpt.x - item.width / 2;
    item.top = pointerVpt.y;
    this.canvas.add(item);
    this.canvas.requestRenderAll();
  }

  clipboard() {
    const jsonStr = this.getJson();
    clipboardText(JSON.stringify(jsonStr, null, '\t'));
  }

  saveJson() {
    const dataUrl = this.getJson();
    const fileStr = `data:text/json;charset=utf-8,${encodeURIComponent(
      JSON.stringify(dataUrl, null, '\t')
    )}`;
    downFile(fileStr, 'json');
  }

  saveSvg() {
    this.editor.hooksEntity.hookSaveBefore.callAsync('', () => {
      const option = this._getSaveSvgOption();
      const dataUrl = this.canvas.toSVG(option);
      const fileStr = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(dataUrl)}`;
      this.editor.hooksEntity.hookSaveAfter.callAsync(fileStr, () => {
        downFile(fileStr, 'svg');
      });
    });
  }

  saveImg() {
    this.editor.hooksEntity.hookSaveBefore.callAsync('', () => {
      const option = this._getSaveOption();
      this.editor.setViewportTransform([1, 0, 0, 1, 0, 0]);
      const dataUrl = this.canvas.toDataURL(option);
      this.editor.hooksEntity.hookSaveAfter.callAsync(dataUrl, () => {
        downFile(dataUrl, 'png');
      });
    });
  }

  preview() {
    return new Promise((resolve, reject) => {
      this.editor.hooksEntity.hookSaveBefore.callAsync('', () => {
        const option = this._getSaveOption();
        this.editor.setViewportTransform([1, 0, 0, 1, 0, 0]);
        this.canvas.renderAll();
        const dataUrl = this.canvas.toDataURL(option);
        this.editor.hooksEntity.hookSaveAfter.callAsync(dataUrl, () => {
          resolve(dataUrl);
        });
      });
    });
  }

  downSvg(finalCanvas: fabric.Canvas, baseLayer: fabric.Object, width: number, height: number, filename: string) {
    // 克隆底层图层作为裁剪路径
    baseLayer.clone((clonedBaseLayer: fabric.Object) => {
      // 应用裁剪路径到 finalCanvas 上的每个对象
      // finalCanvas.getObjects().forEach((obj) => {
      //   if (obj !== baseLayer) { // 不要裁剪底层
      //     obj.clipPath = clonedBaseLayer;
      //     obj.dirty = true; // 标记对象需要重新渲染
      //   }
      // });

      // 渲染 finalCanvas 以应用裁剪路径
      finalCanvas.renderAll();

      // 导出最终的 SVG 图片
      const svgData = finalCanvas.toSVG({
        width: width,
        height: height,
        suppressPreamble: true
      });

      const fileStr = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgData)}`;
      this.downloadDataURL(fileStr, `${filename}.svg`);
    });
  }

  downJPG(finalCanvas: fabric.Canvas, width: number, height: number, filename: string) {
    // 创建一个临时的 Canvas 用于绘制最终的图片
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = width;
    tempCanvas.height = height;
    const ctx = tempCanvas.getContext('2d');

    // 设置背景为白色，填充整个 Canvas
    if (!ctx) return;
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, width, height);

    // 将原始 Canvas 绘制到临时 Canvas 上
    ctx.drawImage(finalCanvas.getElement(), 0, 0, width, height);

    // 导出最终的图片
    const dataURL = tempCanvas.toDataURL('image/jpeg');

    // 调用下载 JPEG 图片的函数
    this.downloadDataURL(dataURL, filename);
  }

  downPNG(finalCanvas: fabric.Canvas, width: number, height: number, filename: string) {
    // 导出最终的图片
    const dataURL = finalCanvas.toDataURL({
      format: 'png',
      left: 0,
      top: 0,
      width: width,
      height: height
    });
    this.downloadDataURL(dataURL, filename);
  }

  downPDF(finalCanvas: fabric.Canvas, width: number, height: number, filename: string) {
    // 导出最终的图片为 PNG 数据 URL
    const dataURL = finalCanvas.toDataURL({
      format: 'png',
      left: 0,
      top: 0,
      width: width,
      height: height
    });

    // 创建一个新的 jsPDF 实例
    const pdf = new jsPDF({
      orientation: 'landscape',
      unit: 'px',
      format: 'a4'
    });

    // 将 PNG 图片添加到 PDF
    pdf.addImage(dataURL, 'PNG', 0, 0, pdf.internal.pageSize.getWidth(), pdf.internal.pageSize.getHeight());

    // 保存 PDF 文件
    pdf.save(`${filename}.pdf`);
  }

  toPixels(value: number, unit: DownFileUnit): number {
    // 假设屏幕 DPI 为 96
    const dpi = window.devicePixelRatio * 96; // 96 是 CSS 中的标准 DPI
    switch (unit) {
      case DownFileUnit.mm:
        return (value / 25.4) * dpi; // 1 inch = 25.4 mm
      case DownFileUnit.in:
        return value * dpi;
      case DownFileUnit.px:
      default:
        return value; // 像素不需要转换
    }
  }

  downFile(
    projectModel: ProjectModel,
    fileType: string,
    width: number,
    height: number,
    removeLogo: boolean,
    unit?: string,
    filename: string
  ) {
    const workspace = this.canvas.getObjects().find((item) => item.id === (WorkspaceID.WorkspaceCavas));
    var left = this.getCanvasLeft(projectModel);
    var bgWidth = workspace?.width! + left * 2;
    var bgHeight = workspace?.height;

    this.editor.hooksEntity.hookSaveBefore.callAsync('', async () => {
      const baseLayer = workspace;
      // 创建一个新的临时画布用于合并图层
      const tempCanvas = new fabric.StaticCanvas(null, {
        width: bgWidth,
        height: bgHeight
      });
      // 复制除底层外的所有图层到临时画布

      this.canvas.getObjects().forEach((obj, index) => {
        if (!obj.id?.includes(WorkspaceID.WorkspaceCavas)) { // 跳过底层
          // 克隆对象并添加到临时画布
          obj.clone((clonedObj: fabric.Object) => {
            tempCanvas.add(clonedObj);
          });
        }
      });

      // add watermark;
      if (!removeLogo) {
        // multi mark logo;
        const gap = 100;
        for (let i = 0; i < width / gap; i++) {
          for (let j = 0; j < height / gap; j++) {
            await fabric.Image.fromURL(WatermarkLogo, (markImg) => {
              markImg.set({
                left: i * gap,
                top: j * gap,
                width: 100,
                height: 20,
                opacity: 0.5,
                angle: -30
              });
              tempCanvas.bringToFront(markImg);
              tempCanvas.add(markImg);
            });
          }
        }
        // single marklogo right bottom;
        // await fabric.Image.fromURL(WatermarkLogo, (markImg) => {
        //   markImg.set({
        //     left: width - 140,
        //     top: height - 80,
        //     width: 100,
        //     height: 20,
        //     opacity: 0.5,
        //   });
        //   tempCanvas.bringToFront(markImg);
        //   tempCanvas.add(markImg);
        // });
      }

      const handleAfterRender = () => {
        tempCanvas.off('after:render', handleAfterRender);
        // 创建一个新的临时画布用于最终的合并
        const finalCanvas = new fabric.StaticCanvas(null, {
          width: bgWidth,
          height: bgHeight
        });
        // 复制底层图层到最终画布
        baseLayer.clone((clonedBaseLayer: fabric.Object) => {
          clonedBaseLayer.set({
            left: left,
            top: 0,
            scaleX: 1,
            scaleY: 1
          });
          finalCanvas.add(clonedBaseLayer);
          finalCanvas.renderAll();
          // 等待临时画布渲染完所有图层
          tempCanvas.renderAll();
          // 将临时画布上的图层与底层图层进行source-in合并
          const tempCanvasImage = new Image();
          tempCanvasImage.onload = () => {
            // 创建一个新的图层用于合并
            const mergedLayer = new fabric.Image(tempCanvasImage, {
              left: 0,
              top: 0,
              width: finalCanvas.width,
              height: finalCanvas.height,
              globalCompositeOperation: 'source-in' // 设置合成模式为source-in
            });
            // 清除最终画布上的所有对象
            finalCanvas.clear();

            // 首先添加底层图层
            finalCanvas.add(clonedBaseLayer);

            // 然后添加合并后的图层
            finalCanvas.add(mergedLayer);

            // 渲染最终画布
            finalCanvas.renderAll();

            console.log('fileType;', fileType);
            switch (fileType) {
              case DownFileType.DownFileTypePNG:
                this.downPNG(finalCanvas, width, height, filename);
                break;
              case DownFileType.DownFileTypeJPG:
                this.downJPG(finalCanvas, width, height, filename);
                break;
              case DownFileType.DownFileTypePDF:
                this.downPDF(finalCanvas, width, height, filename);
                break;
              case DownFileType.DownFileTypeSVG:
                this.downSvg(tempCanvas, clonedBaseLayer, width, height, filename);
                break;
            }
          };
          tempCanvasImage.src = tempCanvas.toDataURL({ format: 'png' });
        });
      };

      tempCanvas.on('after:render', handleAfterRender);
    });
  }

  handleAfterRender() {
    this.tempCanvas.off('after:render', this.handleAfterRender);
    // ...其他逻辑
  }

  downloadDataURL(dataURL: string, filename: string) {
    const link = document.createElement('a');
    link.href = dataURL;
    link.download = filename;
    link.click();
  }

  getCanvasLeft(projectModel: ProjectModel) {
    var left = 0;
    if (projectModel) {
      var canvas = projectModel.canvases[projectModel.canvasesIndex];
      var isCylindrical = canvas.category === CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL;
      var rotary_params: RotaryParams = JSON.parse(canvas.print_param!).rotary_params;
      left = isCylindrical ? rotary_params.horizontalProhibited! : 0;
    }
    return left;
  }

  preview1(projectModel: ProjectModel, canvas?: fabric.Canvas, imgQualityDef?: number) {
    console.log('=======preview1=====start=',)
    const currentCanvas = !!canvas ? canvas : this.canvas;
    return new Promise((resolve, reject) => {
      const workspace = currentCanvas.getObjects().find((item) => (item as any).id === (WorkspaceID.WorkspaceCavas));
      var bgWidth = workspace?.width;
      var bgHeight = workspace?.height;
      const print_param = JSON.parse(projectModel.canvases[projectModel.canvasesIndex].print_param)

      var retSize = StringUtil.scaleToWidth(print_param.format_size_w!, print_param.format_size_h!, imgQualityDef ? imgQualityDef : print_param.imgQuality!);
      var scale = retSize.width / bgWidth!;
      var scaledWidth = retSize.width;
      var scaledHeight = retSize.height;

      const baseLayer = workspace;
      const tempCanvas = new fabric.StaticCanvas(null, {
        width: scaledWidth,
        height: scaledHeight
      });
      // 初始化边界值
      let minX = Number.MAX_VALUE;
      let minY = Number.MAX_VALUE;
      let maxX = 0;
      let maxY = 0;
      const coordsOne = currentCanvas.getObjects()[0].getCoords();

      currentCanvas.getObjects().forEach((obj, index) => {
        if ((obj as any).id && !((obj as any).id as string).includes(WorkspaceID.WorkspaceCavas)) {
          const coords = obj.getCoords();
          coords.forEach(({ x, y }, index) => {
            var zoom = this.canvas.getZoom();
            var oneX = coordsOne[0].x / zoom;
            var oneY = coordsOne[0].y / zoom;
            x = x / zoom;
            y = y / zoom;

            if (index == 0 || index == 2) {
              x = x - oneX;
              y = y - oneY;
            } else if (index == 3 || index == 1) {
              x = x - oneX;
              y = y - oneY;
            }
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);

          });
        }
      });

      minX = Math.max(minX, 0);
      minX = Math.min(minX, bgWidth!);
      minY = Math.max(minY, 0);
      minY = Math.min(minY, bgHeight!);

      maxX = Math.max(maxX, 0);
      maxX = Math.min(maxX, bgWidth!);
      maxY = Math.max(maxY, 0);
      maxY = Math.min(maxY, bgHeight!);

      // 计算offscreenCanvas的宽度和高度
      const offscreenCanvasWidth = maxX - minX;
      const offscreenCanvasHeight = maxY - minY;

      async function cloneObjectsSequentially() {
        for (const obj of currentCanvas.getObjects()) {
          if (!(obj as any).id?.includes(WorkspaceID.WorkspaceCavas)) {
            const objProps = obj.toJSON(EDITOR_JSON_KEY);
            await new Promise((resolveClone) => {
              obj.clone((clonedObj: fabric.Object) => {
                if ((objProps as any).clipPath) {
                  delete (objProps as any).clipPath;
                }
                clonedObj.set({
                  ...objProps,
                  left: clonedObj.left! * scale,
                  top: clonedObj.top! * scale,
                  scaleX: clonedObj.scaleX! * scale,
                  scaleY: clonedObj.scaleY! * scale
                });
                tempCanvas.add(clonedObj);
                resolveClone(clonedObj); // 克隆完成后解决 promise
              });
            });
          }
        }
      }

      // 等待所有克隆操作完成
      cloneObjectsSequentially().then(() => {
        filterTextureElements(currentCanvas, tempCanvas);
        const finalCanvas = new fabric.StaticCanvas(null, {
          width: scaledWidth,
          height: scaledHeight
        });

        baseLayer?.clone((clonedBaseLayer: fabric.Object) => {
          clonedBaseLayer.set({
            left: 0,
            top: 0,
            scaleX: scale,
            scaleY: scale
          });
          finalCanvas.add(clonedBaseLayer);
          finalCanvas.renderAll();

          const tempDataURL = tempCanvas.toDataURL({ format: 'png' });

          // 使用 fromURL 方法创建一个 fabric.Image 对象
          fabric.Image.fromURL(tempDataURL, (img) => {
            // 设置图片的宽高
            img.set({
              left: 0,
              top: 0,
              scaleX: 1,
              scaleY: 1,
              globalCompositeOperation: 'source-in'
            });
            finalCanvas.add(img);
            finalCanvas.renderAll();
            const dataURL = finalCanvas.toDataURL({
              format: 'png',
            });
            // console.log('=======preview1=====end=', dataURL)
            resolve({ dataUrl: dataURL, minX: minX, minY: minY, width: offscreenCanvasWidth, height: offscreenCanvasHeight });
          });
        });
      });
    });
  }

  getThumbnail(canvas?: fabric.Canvas) {
    const currentCanvas = !!canvas ? canvas : this.canvas;
    return getCanvasThumbnail(currentCanvas);
    // return new Promise((resolve, reject) => {
    //   const workspace = currentCanvas.getObjects().find((item) => item.id?.includes(WorkspaceID.WorkspaceCavas));
    //   var bgWidth = workspace?.width;
    //   var bgHeight = workspace?.height;

    //   if (!bgWidth || !bgHeight) {
    //     resolve('');
    //     return;
    //   }

    //   // 初始化边界值
    //   let minX = Number.MAX_VALUE;
    //   let minY = Number.MAX_VALUE;
    //   let maxX = 0;
    //   let maxY = 0;

    //   // 遍历所有图层，计算边界
    //   const coordsOne = currentCanvas.getObjects()[0].getCoords();
    //   currentCanvas.getObjects().forEach((obj, index) => {
    //     if (!obj.id?.includes(WorkspaceID.WorkspaceCavas)) { // 跳过底层
    //       const coords = obj.getCoords();
    //       coords.forEach(({ x, y }, index) => {
    //         var zoom = currentCanvas.getZoom();
    //         var oneX = coordsOne[0].x / zoom;
    //         var oneY = coordsOne[0].y / zoom;
    //         x = x / zoom;
    //         y = y / zoom;

    //         if (index == 0 || index == 2) {
    //           x = x - oneX;
    //           y = y - oneY;
    //         } else if (index == 3 || index == 1) {
    //           x = x - oneX;
    //           y = y - oneY;
    //         }
    //         minX = Math.min(minX, x);
    //         minY = Math.min(minY, y);
    //         maxX = Math.max(maxX, x);
    //         maxY = Math.max(maxY, y);

    //       });
    //     }
    //   });

    //   minX = Math.max(minX, 0);
    //   minX = Math.min(minX, bgWidth!);
    //   minY = Math.max(minY, 0);
    //   minY = Math.min(minY, bgHeight!);

    //   maxX = Math.max(maxX, 0);
    //   maxX = Math.min(maxX, bgWidth!);
    //   maxY = Math.max(maxY, 0);
    //   maxY = Math.min(maxY, bgHeight!);

    //   // 计算offscreenCanvas的宽度和高度
    //   const offscreenCanvasWidth = maxX - minX;
    //   const offscreenCanvasHeight = maxY - minY;

    //   // 创建一个离屏Canvas
    //   const offscreenCanvas = document.createElement('canvas');
    //   offscreenCanvas.width = offscreenCanvasWidth;
    //   offscreenCanvas.height = offscreenCanvasHeight;
    //   const offscreenCtx = offscreenCanvas.getContext('2d');
    //   // 确保离屏Canvas的上下文存在
    //   // 手动绘制除底层以外的图层
    //   if (offscreenCtx) {
    //     offscreenCtx.save();
    //     offscreenCtx.translate(-minX, -minY);

    //     currentCanvas.getObjects().forEach((obj, index) => {
    //       if (!obj.id?.includes(WorkspaceID.WorkspaceCavas) && offscreenCtx) { // 跳过底层
    //         obj.render(offscreenCtx!);
    //       }
    //     });
    //     offscreenCtx.restore();
    //     const dataURL = offscreenCanvas.toDataURL('image/png');
    //     // 导出离屏Canvas的图像数据
    //     resolve({ dataUrl: dataURL, minX: minX, minY: minY, width: offscreenCanvasWidth, height: offscreenCanvasHeight });
    //   }
    // });
  }

  mergeSceneImages(scene: CategoryScenesModel, dataUrl: string, projectCutDataModel?: ProjectCutDataModel): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!scene.scenesImg) {
        return;
      }
      fabric.Image.fromURL(scene.scenesImg[scene.scenesImgSelect!], (sceneImg) => {
        const canvas = new fabric.StaticCanvas(null, { width: sceneImg.width, height: sceneImg.height });
        // 设置 scenesImg 图片的位置和大小
        sceneImg.scaleToWidth(sceneImg.width!);
        sceneImg.scaleToHeight(sceneImg.height!);
        sceneImg.set({
          left: 0,
          top: 0,
        });
        var isCutImg = projectCutDataModel && !(projectCutDataModel.cutWidth == 0 && projectCutDataModel.cutHeight == 0);
        var skewData;
        if (scene.skewData && scene.skewData.length > 0) {
          skewData = JSON.parse(scene.skewData!)
        }
        // if (isCutImg && skewData) {
        if (skewData && !skewData.rectPerspective) {
          fabric.Image.fromURL(dataUrl, (dataImgUrl) => {
            // 创建新的图像对象
            const newImg = new fabric.Image(dataImgUrl.getElement(), {
              left: 0,
              top: 0,
              width: (skewData! as CyRetData).cyCutWidth,
              height: (skewData! as CyRetData).cyCutHeight,
              cropX: (skewData! as CyRetData).cyCutLeft, // 设置裁剪区域的起始X坐标
              cropY: (skewData! as CyRetData).cyCutTop, // 设置裁剪区域的起始Y坐标
            });
            let worker = new IMagickWorker();
            ///得到图片数据dataUrl，传入worker里面
            worker.onmessage = function (e) {
              // 使用处理后的图像数据
              const base64 = e.data;
              fabric.Image.fromURL(base64, (dataImg) => {
                var left: number = scene.positionX!;
                var top: number = scene.positionY!;
                console.log('scene.skewData=====:', scene.positionX, " scene.positionY=", scene.positionY, " dataImg.width=", dataImg.width, " dataImg.height=", dataImg.height, " sceneImg.width=", sceneImg.width, " sceneImg.height=", sceneImg.height, " dataImgUrl.h=", dataImgUrl.height);
                // 设置 dataUrl 图片的位置和大小
                dataImg.set({
                  left: left * 100 / 100,
                  top: top * 100 / 100,
                  width: dataImg.width!,
                  height: dataImg.height!,
                  angle: scene.angle,
                });
                // 先添加 scenesImg，然后添加 dataUrl 图片
                canvas.add(sceneImg);
                canvas.add(dataImg);
                // 导出合成后的图片
                const mergedUrl = canvas.toDataURL();
                resolve(mergedUrl);
                // 清理画布
                canvas.dispose();
              }, {
                crossOrigin: 'anonymous',
                onError: (error) => {
                  reject(error);
                }
              });
              worker.terminate();
              worker = null;
            };
            worker.postMessage({
              action: ACTION_MAGICK.ACTION_TYPE_DISTORT_CYLINDER,
              data: {
                dataUrl: newImg.toDataURL(), // 原始图像数据
                params: (skewData! as CyRetData).srcPoints, // 透视变换参数,
                amplitude: (skewData! as CyRetData).amplitude,
                length: (skewData! as CyRetData).length,
              }
            });

            // var left: number = scene.positionX!;
            // var top: number = scene.positionY!;

            // dataImg.cropX = projectCutDataModel!.cutX;
            // dataImg.cropY = projectCutDataModel!.cutY! - 50;
            // dataImg.width = projectCutDataModel!.cutWidth;
            // dataImg.height = projectCutDataModel!.cutHeight! + 100;
            // // 设置 dataUrl 图片的位置和大小
            // dataImg.set({
            //   left: left * 100 / 100,
            //   top: top * 100 / 100,
            //   scaleX: scene.width / dataImg.width!,
            //   scaleY: scene.height / dataImg.height!,
            //   angle: scene.angle,
            // });
            // // 获取裁剪后的图像数据URL
            // var croppedDataURL = dataImg.toDataURL({});

            // var canvasTemp = document.createElement('canvas');
            // var ctx = canvasTemp.getContext('2d');
            // var image = new Image();

            // image.onload = () => {
            //   canvasTemp.width = image.width;
            //   canvasTemp.height = image.height;
            //   ctx!.drawImage(image, 0, 0);

            //   var imageData = ctx!.getImageData(0, 0, image.width, image.height);
            //   var data = imageData.data;
            //   var outputData = new Uint8ClampedArray(data);

            //   this.perspectiveTaskThread(data, outputData, image.width, image.height).then((outputData: Uint8ClampedArray) => {
            //     // 创建新的ImageData对象并绘制到canvas上
            //     var newImageData = new ImageData(outputData, image.width, image.height);
            //     ctx!.putImageData(newImageData, 0, 0);
            //     const curvedDataURL = canvasTemp.toDataURL();

            //     fabric.Image.fromURL(curvedDataURL, (curvedImg) => {
            //       curvedImg.set({
            //         left: left,
            //         top: top,
            //       });

            //       // 先添加场景图像，然后添加弯曲后的图像
            //       canvas.add(sceneImg);
            //       canvas.add(curvedImg);
            //       // 导出合成后的图片
            //       const mergedUrl = canvas.toDataURL();
            //       resolve(mergedUrl);
            //       // 清理画布
            //       canvas.dispose();
            //     }, {
            //       crossOrigin: 'anonymous',
            //       onError: (error) => {
            //         reject(error);
            //       }
            //     });
            //   });
            // };
            // image.src = croppedDataURL;
          }, {
            crossOrigin: 'anonymous',
            onError: (error) => {
              reject(error);
            }
          });
        } else if (skewData && skewData.rectPerspective) {
          let worker = new IMagickWorker();
          worker.onmessage = function (e: { data: any; }) {
            // 使用处理后的图像数据
            const base64 = e.data;
            fabric.Image.fromURL(base64, (dataImg) => {
              var left: number = scene.positionX!;
              var top: number = scene.positionY!;
              // 设置 dataUrl 图片的位置和大小
              dataImg.set({
                left: left * 100 / 100,
                top: top * 100 / 100,
                scaleX: scene.width / dataImg.width!,
                scaleY: scene.height / dataImg.height!,
                angle: scene.angle,
              });
              // 先添加 scenesImg，然后添加 dataUrl 图片
              canvas.add(sceneImg);
              canvas.add(dataImg);
              // 导出合成后的图片
              const mergedUrl = canvas.toDataURL();
              resolve(mergedUrl);
              // 清理画布
              canvas.dispose();
            }, {
              crossOrigin: 'anonymous',
              onError: (error) => {
                reject(error);
              }
            });
            worker.terminate();
            worker = null;
          };
          console.log('worker========postMessage=:');
          worker.postMessage({
            action: ACTION_MAGICK.ACTION_TYPE_DISTORT,
            data: {
              dataUrl: dataUrl, // 原始图像数据
              params: skewData.rectPerspective // 透视变换参数,
            }
          });
        } else {
          fabric.Image.fromURL(dataUrl, (dataImg) => {
            var left: number = scene.positionX!;
            var top: number = scene.positionY!;
            // 设置 dataUrl 图片的位置和大小
            dataImg.set({
              left: left * 100 / 100,
              top: top * 100 / 100,
              scaleX: scene.width / dataImg.width!,
              scaleY: scene.height / dataImg.height!,
              angle: scene.angle,
            });
            // 先添加 scenesImg，然后添加 dataUrl 图片
            canvas.add(sceneImg);
            canvas.add(dataImg);
            // 导出合成后的图片
            const mergedUrl = canvas.toDataURL();
            resolve(mergedUrl);
            // 清理画布
            canvas.dispose();
          }, {
            crossOrigin: 'anonymous',
            onError: (error) => {
              reject(error);
            }
          });
        }
      }, {
        crossOrigin: 'anonymous',
        onError: (error) => {
          reject(error);
        }
      });
    });
  }

  _getSaveSvgOption() {
    const workspace = this.canvas.getObjects().find((item) => !item.id?.includes(WorkspaceID.WorkspaceCavas));
    const { left, top, width, height } = workspace;
    return {
      width,
      height,
      viewBox: {
        x: left,
        y: top,
        width,
        height,
      },
    };
  }

  _getSaveOption() {
    const workspace = this.canvas
      .getObjects()
      .find((item: fabric.Object) => item.id?.includes(WorkspaceID.WorkspaceCavas));
    const { left, top, width, height } = workspace as fabric.Object;
    const option = {
      name: 'New Image',
      format: 'png',
      quality: 1,
      width,
      height,
      left,
      top,
    };
    return option;
  }

  clear(isClearAll?: boolean) {
    this.canvas.getObjects().forEach((obj) => {
      if (!obj.id?.includes(WorkspaceID.WorkspaceCavas)) {
        this.canvas.remove(obj);
      } else if (isClearAll) {
        this.canvas.remove(obj);
      }
    });
    this.canvas.discardActiveObject();
    this.canvas.renderAll();
  }

  destroy() {
    console.log('pluginDestroy');
  }
}
export default ServersPlugin;