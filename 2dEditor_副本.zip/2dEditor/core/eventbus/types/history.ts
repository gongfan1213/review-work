export enum HistoryEvent {
  Save = 'save', // 保存动作;
  Undo = 'undo', // 撤回动作;
  Redo = 'redo', // 回退动作;
  Stop = 'stop', // 停止保存动作;
  Start = 'start', // 开启保存动作;
  Rendering = 'rendering', // 执行撤回回退渲染动作进行;
}
