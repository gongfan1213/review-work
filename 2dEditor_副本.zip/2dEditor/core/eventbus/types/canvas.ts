export enum CanvasEvent {
  ObjectModified = 'object:modified',
}

export enum CanvasStatus {
  DragMode = 'dragMode',
}