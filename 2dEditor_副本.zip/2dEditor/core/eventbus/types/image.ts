export enum ImageStatus {
  Cropping = 'imageCropping', // 裁剪中;
  RemovingBackground = 'imageRemovingBackground', // 去除背景中;
  Upscaling = 'imageUpscaling', // 超分中;
  Loading = 'imageLoading', // 高清图加载中;
  Editing = 'imageEditing', // 纹理图片编辑中;
}