export enum LayerStatus {
  RenderStatus = 'RenderStatus',
}

export enum RenderLayer {
  OFF,
  ON,
}