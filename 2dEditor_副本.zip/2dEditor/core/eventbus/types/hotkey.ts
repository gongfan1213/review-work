export enum HotkeyStatus {
  UDLR = 'UDLR', // 上下左右
}