export enum TextStatus {
  UnderTransform = 'UnderTransform', // 文字变形操作中;
}