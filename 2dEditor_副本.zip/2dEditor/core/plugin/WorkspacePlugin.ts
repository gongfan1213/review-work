/*
 * @Description: 画布区域插件
 */

import { fabric } from 'fabric';
import Editor from '../core';
//@ts-ignore
import { throttle } from 'lodash-es';
import {
  CanvasCategory,
  CanvasParams,
  EventNameCons,
  PROJECT_STANDARD_TYPE,
  WorkspaceID,
} from '../../cons/2dEditorCons';
import eventBus from '../eventbus';
import { ImageStatus } from '../eventbus/types/image';
import { TextStatus } from '../eventbus/types/text';
import { getColors } from '../../common/color/color';
import { v4 as uuid } from 'uuid';
import { Component } from 'react';
import { TranslationsKeys } from '../../utils/TranslationsKeys';
import ic_column_c from 'src/assets/svg/ic_column_c.svg';
import { getCylindricalIcon } from '../../common/cavasUtil';
import { RotaryParams } from '../../components/SelectDialog/model/ProjectModel';
import StringUtil from 'src/common/utils/stringUtil';
import { height } from 'dom7';
import { IPoint } from 'fabric/fabric-impl';

type IEditor = Editor;

interface InitWorkCanvasRet {
  canvas: fabric.Canvas;
  fabricImageBg: fabric.Object;
}

class WorkspacePlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  public pointer: { x: number; y: number } = { x: 0, y: 0 };
  static pluginName = 'WorkspacePlugin';
  static events = ['sizeChange'];
  static apis = [
    'big',
    'small',
    'auto',
    'one',
    'setSize',
    'updateWorkspace',
    'setZoomAuto',
    'initWorkCanvas',
    'addFrame',
    'cancelFrame',
    'zoomToPoint',
    'setViewportTransform',
  ];
  workspaceEl!: HTMLElement;
  workspace?: null | fabric.Rect | fabric.Image;
  option: any;
  getTranslation?: (key: string) => string;
  public canvas_bg?: fabric.Canvas;

  constructor(canvas: fabric.Canvas, editor: IEditor, option: any) {
    this.canvas = canvas;
    this.editor = editor;
    this.option = option;
    this.canvas_bg = option.canvas_bg;
    this.getTranslation = option.getTranslation;

    console.log('====WorkspacePlugin====canvas_bg==', this.canvas_bg);
    this.mouseMove = this.mouseMove.bind(this);
    this.mouseOver = this.mouseOver.bind(this);
    this.cancelFrame = this.cancelFrame.bind(this);
    this.handleWheel = this.handleWheel.bind(this);
    this.handleCropping = this.handleCropping.bind(this);
    this.handleUnderTransform = this.handleUnderTransform.bind(this);
    this.init();
  }

  handleCropping(e: any) {
    this.outCanvasRangeNoDisplay(e.value);
  }

  handleUnderTransform(flag: any) {
    this.outCanvasRangeNoDisplay(flag);
  }

  init() {
    const workspaceEl = document.querySelector('#workspace') as HTMLElement;
    if (!workspaceEl) {
      throw new Error('element #workspace is missing, plz check!');
    }
    this.workspaceEl = workspaceEl;
    this.workspace = null;
    this._initBackground();
    this._initWorkspace();
    this._initResizeObserve();
    this._initMovePointer();
  }

  updateWorkspace(option?: any) {
    if (option) {
      this.option = option;
    }
    this.init();
  }

  // 因为canvas_bg需要同步调整，所以这里新增zoomToPoint方法
  zoomToPoint(point: IPoint, value: number) {
    this.canvas.zoomToPoint(point, value);
    this.canvas_bg?.zoomToPoint(point, value);
  }

  // 因为canvas_bg需要同步调整，所以这里新增setViewportTransform方法
  setViewportTransform(vpt: number[]) {
    this.canvas.setViewportTransform(vpt);
    this.canvas_bg?.setViewportTransform(vpt);
  }

  hookSaveAfter() {
    return new Promise((resolve) => {
      resolve(true);
    });
  }

  // 初始化背景
  _initBackground() {
    this.canvas.setWidth(this.workspaceEl.offsetWidth);
    this.canvas.setHeight(this.workspaceEl.offsetHeight);

    this.canvas_bg?.setWidth(this.workspaceEl.offsetWidth);
    this.canvas_bg?.setHeight(this.workspaceEl.offsetHeight);
  }

  // 初始化画布
  _initWorkspace() {
    this.initWorkCanvas(this.canvas, this.option).then((initWorkCanvasRet) => {
      this.workspace = initWorkCanvasRet.fabricImageBg;
      this._initScale();
      this.outCanvasRangeNoDisplay();
    });
  }

  /**
   * @param canvas 画布
   * @param option 属性
   * 这个方法也用于项目切换，如果没有json数据（未来的及保存），可以获取初始化json
   */
  initWorkCanvas(canvas: fabric.Canvas, option: any): Promise<InitWorkCanvasRet> {
    var baseMap = option.url;
    var cavasMap = option.cavas_map;
    let bgCavasMap = option.bg_cavas_map;
    let shapeCavasMap = option.shape_cavas_map;

    var fabricImageBg: fabric.Object;
    canvas.getObjects().forEach((item) => {
      if ((item as any).id == WorkspaceID.WorkspaceCavas && shapeCavasMap && !this.isBase64(shapeCavasMap)) {
        shapeCavasMap = (item as any).getSrc();
        canvas.remove(item);
      } else if ((item as any).id == WorkspaceID.WorkspaceBGCavas && bgCavasMap && !this.isBase64(bgCavasMap)) {
        bgCavasMap = (item as any).getSrc();
        canvas.remove(item);
      } else if ((item as any).id.includes(WorkspaceID.WorkspaceCavas)) {
        canvas.remove(item);
      }
    });
    this.canvas_bg?.getObjects().forEach((item) => {
      if ((item as any).id.includes(WorkspaceID.WorkspaceCavas)) {
        this.canvas_bg?.remove(item);
      }
    });

    if (option.is_standard_product === PROJECT_STANDARD_TYPE.PROJECT_STANDARD) {
      // 加载并添加 cavasMap 图片
      const cavasImage = new Image();
      cavasImage.crossOrigin = 'anonymous';
      cavasImage.src = cavasMap;

      return new Promise<InitWorkCanvasRet>((resolve, reject) => {
        cavasImage.onload = () => {
          const bgImage = new Image();
          bgImage.crossOrigin = 'anonymous';
          bgImage.src = baseMap;
          bgImage.onload = () => {
            // 检查宽高比并旋转图像
            const optionAspectRatio = option.width / option.height;
            const cavasImageAspectRatio = cavasImage.width / cavasImage.height;
            const rotate = Math.abs(optionAspectRatio - 1 / cavasImageAspectRatio) < 0.01 ? 90 : 0;

            if (rotate > 0) {
              // 旋转 cavasImage 90 度
              const tempCanvas = document.createElement('canvas');
              tempCanvas.width = cavasImage.height;
              tempCanvas.height = cavasImage.width;
              const tempCtx = tempCanvas.getContext('2d');
              if (tempCtx) {
                tempCtx.translate(tempCanvas.width / 2, tempCanvas.height / 2);
                tempCtx.rotate(Math.PI / 2);
                tempCtx.drawImage(cavasImage, -cavasImage.width / 2, -cavasImage.height / 2);
                cavasImage.src = tempCanvas.toDataURL();
              }

              // 旋转 bgImage 90 度
              const tempCanvas1 = document.createElement('canvas');
              tempCanvas1.width = bgImage.height;
              tempCanvas1.height = bgImage.width;
              const tempCtx1 = tempCanvas1.getContext('2d');
              if (tempCtx1) {
                tempCtx1.translate(tempCanvas1.width / 2, tempCanvas1.height / 2);
                tempCtx1.rotate(Math.PI / 2);
                tempCtx1.drawImage(bgImage, -bgImage.width / 2, -bgImage.height / 2);
                bgImage.src = tempCanvas1.toDataURL();
              }
            }

            // 加载并添加 背景 图片
            const fabricBgImage = new fabric.Image(bgImage);
            fabricBgImage.crossOrigin = 'anonymous';
            fabricBgImage.scaleToWidth(option.width);
            fabricBgImage.scaleToHeight(option.height);
            fabricBgImage.set({
              // @ts-ignore
              id: WorkspaceID.WorkspaceBG,
              selectable: false,
              evented: false,
              hasControls: false,
              hasBorders: false,
              hoverCursor: 'default',
            });
            canvas.add(fabricBgImage);
            canvas.renderAll();

            // 添加绘制区域图片
            const fabricCavasImage = new fabric.Image(cavasImage);
            fabricCavasImage.scaleToWidth(option.width);
            fabricCavasImage.scaleToHeight(option.height);
            fabricCavasImage.set({
              // @ts-ignore 设置 cavasMap 图片的属性
              id: WorkspaceID.WorkspaceCavas,
              selectable: false,
              evented: false,
              hasControls: false,
              hasBorders: false,
              hoverCursor: 'default',
              scaleX: 1,
              scaleY: 1,
            });
            // 添加 cavasMap 图片到画布上
            canvas.add(fabricCavasImage);
            canvas.sendToBack(fabricCavasImage);
            canvas.renderAll();

            //把cavasImage和bgImage 合成然后添加到canvas里面
            // 创建一个新的HTMLCanvasElement
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = option.width;
            tempCanvas.height = option.height;
            const tempCtx = tempCanvas.getContext('2d');
            // 确保临时canvas的上下文存在
            if (tempCtx) {
              // 在bgImage上绘制cavasImage
              tempCtx.drawImage(cavasImage, 0, 0, option.width, option.height);
              // 在临时canvas上绘制bgImage
              tempCtx.drawImage(bgImage, 0, 0, option.width, option.height);
              // 将合成后的图像转换为data URL
              const dataURL = tempCanvas.toDataURL();
              // 使用data URL创建一个新的fabric.Image对象
              fabric.Image.fromURL(dataURL, (fabricRangeRange) => {
                fabricRangeRange.set({
                  // @ts-ignore
                  id: WorkspaceID.WorkspaceRange,
                  selectable: false,
                  evented: false,
                  hasControls: false,
                  hasBorders: false,
                  hoverCursor: 'default',
                  visibility: false,
                });
                // 将合成后的fabric.Image对象添加到Fabric.js的canvas中
                canvas.add(fabricRangeRange);
                canvas.sendToBack(fabricRangeRange);
                canvas.renderAll();

                // 更新initWorkCanvasRet对象
                var initWorkCanvasRet: InitWorkCanvasRet = {
                  canvas: canvas,
                  fabricImageBg: fabricRangeRange,
                };
                resolve(initWorkCanvasRet);
              });
            }
          };
        };
      });
    } else {
      //  canvas.clear();
      console.log('=====initWorkCanvas===canvas===', canvas, option);
      let blankImage = null;
      let mask = null;
      let overlay = null;
      if (option?.canvasShape === 'RoundRect') {
        blankImage = new fabric.Rect({
          //创建圆角矩形画布
          // @ts-ignore
          id: WorkspaceID.WorkspaceCavas,
          fill: '#fff',
          width: option.width,
          height: option.height,
          stroke: '#000', // 边框颜色
          strokeWidth: 1, // 边框宽度
          left: 0,
          top: 0,
          selectable: false,
          evented: false,
          hasControls: false,
          hasBorders: false,
          hoverCursor: 'default',
          rx:
            option?.width <= option?.height
              ? (option?.width - (Number(option?.bleedingLine?.left) + Number(option?.bleedingLine?.right))) / 2
              : (option?.height - (Number(option?.bleedingLine?.left) + Number(option?.bleedingLine?.right))) / 2, // x 轴圆角
          ry:
            option?.width <= option?.height
              ? (option?.width - (Number(option?.bleedingLine?.top) + Number(option?.bleedingLine?.bottom))) / 2
              : (option?.height - (Number(option?.bleedingLine?.top) + Number(option?.bleedingLine?.bottom))) / 2, // y 轴圆角
        });
        overlay = option?.bleedingLine
          ? new fabric.Rect({
            //圆角矩形出血线边框
            // @ts-ignore
            id: WorkspaceID.WorkspaceBG,
            left: Number(option?.bleedingLine?.top),
            top: Number(option?.bleedingLine?.left),
            width: option?.width - (Number(option?.bleedingLine?.top) + Number(option?.bleedingLine?.bottom)),
            height: option?.height - (Number(option?.bleedingLine?.left) + Number(option?.bleedingLine?.right)),
            selectable: false,
            fill: 'transparent',
            strokeWidth: 1, // 边框宽度
            strokeDashArray: [10, 10], // 虚线边框
            stroke: 'rgba(0,0,0,0.1)', // 边框颜色
            rx:
              option?.width <= option?.height
                ? (option?.width - (Number(option?.bleedingLine?.left) + Number(option?.bleedingLine?.right))) / 2
                : (option?.height - (Number(option?.bleedingLine?.left) + Number(option?.bleedingLine?.right))) / 2, // x 轴圆角
            ry:
              option?.width <= option?.height
                ? (option?.width - (Number(option?.bleedingLine?.top) + Number(option?.bleedingLine?.bottom))) / 2
                : (option?.height - (Number(option?.bleedingLine?.top) + Number(option?.bleedingLine?.bottom))) / 2, // y 轴圆角
          })
          : null;
      } else if (option?.canvasShape === 'Circle') {
        blankImage = new fabric.Circle({
          //创建圆形画布
          // @ts-ignore
          id: WorkspaceID.WorkspaceCavas,
          fill: '#fff',
          radius: option?.width / 2, // 圆的半径
          left: 0, // 圆的左上角的 x 坐标
          top: 0, // 圆的左上角的 y 坐标
          stroke: '#000', // 边框颜色
          strokeWidth: 1, // 边框宽度
          selectable: false,
          evented: false,
          hasControls: false,
          hasBorders: false,
          hoverCursor: 'default',
        });
        overlay = option?.bleedingLine
          ? new fabric.Circle({
            //圆形出血线边框
            // @ts-ignore
            id: WorkspaceID.WorkspaceBG,
            radius: (option?.width - (Number(option?.bleedingLine?.top) + Number(option?.bleedingLine?.bottom))) / 2, // 圆的半径
            fill: 'transparent',
            left: Number(option?.bleedingLine?.top), // 圆的左上角的 x 坐标
            top: Number(option?.bleedingLine?.left), // 圆的左上角的 y 坐标
            stroke: 'rgba(0,0,0,0.1)', // 边框颜色
            strokeWidth: 1, // 边框宽度
            strokeDashArray: [10, 10], // 虚线边框
            selectable: false,
            evented: false,
            hasControls: false,
            hasBorders: false,
            hoverCursor: 'default',
          })
          : null;
      } else if (option?.canvasShape === 'Ellipse') {
        blankImage = new fabric.Ellipse({
          // 创建椭圆画布
          // @ts-ignore
          id: WorkspaceID.WorkspaceCavas,
          fill: '#fff',
          rx: option.width / 2, // x 轴半径
          ry: option.height / 2, // y 轴半径
          left: 0, // 圆的左上角的 x 坐标
          top: 0, // 圆的左上角的 y 坐标
          stroke: '#000', // 边框颜色
          strokeWidth: 1, // 边框宽度
          selectable: false,
          evented: false,
          hasControls: false,
          hasBorders: false,
          hoverCursor: 'default',
        });
        overlay = option?.bleedingLine
          ? new fabric.Ellipse({
            //椭圆出血线边框
            // @ts-ignore
            id: WorkspaceID.WorkspaceBG,
            fill: 'rgba(0,0,0,0)',
            rx: (option?.width - (Number(option?.bleedingLine?.left) + Number(option?.bleedingLine?.right))) / 2, // x 轴半径
            ry: (option?.height - (Number(option?.bleedingLine?.top) + Number(option?.bleedingLine?.bottom))) / 2, // y 轴半径
            left: Number(option?.bleedingLine?.left), // 圆的左上角的 y 坐标
            top: Number(option?.bleedingLine?.top), // 圆的左上角的 x 坐标
            stroke: 'rgba(0,0,0,0.1)', // 边框颜色
            strokeWidth: 1, // 边框宽度
            strokeDashArray: [10, 10], // 虚线边框
            // globalCompositeOperation: 'destination-out', // 剪去顶层属性
            selectable: false,
            evented: false,
            hasControls: false,
            hasBorders: false,
            hoverCursor: 'default',
          })
          : null;
      } else {
        console.log('====initWorkCanvas======option.is_standard_product===', option, option?.canvasShape);
        return new Promise<InitWorkCanvasRet>((resolve, reject) => {
          if (shapeCavasMap && this.isBase64(shapeCavasMap)) {
            //绘制带背景的底图
            if (bgCavasMap && this.isBase64(bgCavasMap)) {
              fabric.Image.fromURL(
                bgCavasMap,
                (img) => {
                  img.set({
                    // @ts-ignore
                    id: WorkspaceID.WorkspaceBGCavas,
                    selectable: false,
                    evented: false,
                    hasControls: false,
                    hasBorders: false,
                    hoverCursor: 'default',
                    width: this.option.width,
                    height: this.option.height,
                    left: 0,
                    top: 0,
                  });

                  // 添加空白底图到画布上
                  canvas.add(img);
                  canvas.sendToBack(img);
                  canvas.renderAll();
                },
                {
                  crossOrigin: 'anonymous', // 允许跨域加载图片
                },
              );
            }

            // 如果是 Base64 数据，创建一个图片对象
            fabric.Image.fromURL(
              shapeCavasMap,
              (img) => {
                img.set({
                  // @ts-ignore
                  id: WorkspaceID.WorkspaceCavas,
                  selectable: false,
                  evented: false,
                  hasControls: false,
                  hasBorders: false,
                  hoverCursor: 'default',
                  width: this.option.width,
                  height: this.option.height,
                  left: 0,
                  top: 0,
                });

                // 添加空白底图到画布上
                canvas.add(img);
                canvas.sendToBack(img);
                canvas.renderAll();
                fabricImageBg = img;
                var initWorkCanvasRet: InitWorkCanvasRet = {
                  canvas: canvas,
                  fabricImageBg: fabricImageBg!,
                };
                resolve(initWorkCanvasRet);
              },
              {
                crossOrigin: 'anonymous', // 允许跨域加载图片
              },
            );
          } else if (option.category == CanvasCategory.CANVAS_CATEGORY_CYLINDRICAL) {
            console.log('====initWorkCanvas======option.params==', option.params);

            var rotary_params: RotaryParams = option.params.rotary_params;

            var horizontalProhibited = 0; // 水平禁止线
            if (rotary_params.horizontalProhibited && rotary_params.hasHandle) {
              horizontalProhibited = StringUtil.mmToPixel(
                rotary_params.horizontalProhibited!,
                CanvasParams.canvas_dpi_def,
              ); // 水平禁止线
            }

            var verticalRecommandedBlanklen = StringUtil.mmToPixel(
              rotary_params.verticalRecommandedBlanklen!,
              CanvasParams.canvas_dpi_def,
            ); // 垂直推荐空白长度
            verticalRecommandedBlanklen =
              verticalRecommandedBlanklen >= option.height / 4 ? option.height / 10 : verticalRecommandedBlanklen;
            var prohibitedStr = this.getTranslation!(TranslationsKeys.string_canvas_prohibited_area);
            var recommandStr = this.getTranslation!(TranslationsKeys.string_canvas_recommand_area);
            var fontSize = (horizontalProhibited / 3) * 2;
            fontSize =
              prohibitedStr.length * fontSize > this.option.height
                ? this.option.height / prohibitedStr.length
                : fontSize;

            var verticalFontSize = (verticalRecommandedBlanklen / 3) * 2;
            verticalFontSize =
              recommandStr.length * verticalFontSize > this.option.width - 2 * horizontalProhibited
                ? (this.option.width - 2 * horizontalProhibited) / recommandStr.length
                : verticalFontSize;

            var icons = getCylindricalIcon(
              rotary_params.upperD ? rotary_params.upperD : 0,
              rotary_params.bottomD ? rotary_params.bottomD : 0,
              rotary_params.hasHandle ? rotary_params.hasHandle : false,
            );

            // 创建中间白色矩形
            var whiteRect = new fabric.Rect({
              // @ts-ignore
              id: WorkspaceID.WorkspaceCavas,
              fill: '#fff', // 白色
              width: this.option.width - 2 * horizontalProhibited,
              height: this.option.height,
              left: horizontalProhibited,
              top: 0,
              selectable: false,
              evented: false,
              hasControls: false,
              hasBorders: false,
              hoverCursor: 'default',
            });

            // 创建一个数组来存储所有要添加到组中的对象
            let groupObjects: any[] = [whiteRect];

            // 创建禁止打印区域
            if (horizontalProhibited > 0) {
              var leftProhibitedArea = new fabric.Rect({
                // @ts-ignore
                id: WorkspaceID.WorkspaceBG + uuid(),
                fill: '#d3d3d3',
                width: horizontalProhibited,
                height: this.option.height,
                left: 0,
                top: 0,
                selectable: false,
                evented: false,
                hasControls: false,
                hasBorders: false,
                hoverCursor: 'default',
              });

              var rightProhibitedArea = new fabric.Rect({
                // @ts-ignore
                id: WorkspaceID.WorkspaceBG + uuid(),
                fill: '#d3d3d3',
                width: horizontalProhibited,
                height: this.option.height,
                left: this.option.width - horizontalProhibited,
                top: 0,
                selectable: false,
                evented: false,
                hasControls: false,
                hasBorders: false,
                hoverCursor: 'default',
              });

              // 在禁止打印区域添加文字
              var leftText = new fabric.Text(prohibitedStr, {
                // @ts-ignore
                id: WorkspaceID.WorkspaceBG + uuid(),
                left: horizontalProhibited / 2 - fontSize / 2,
                top: this.option.height / 2 + (prohibitedStr.length * fontSize) / 4,
                angle: -90,
                fontSize: fontSize,
                fill: '#00000096',
                selectable: false,
                evented: false,
                hasControls: false,
                hasBorders: false,
                hoverCursor: 'default',
              });

              var rightText = new fabric.Text(prohibitedStr, {
                // @ts-ignore
                id: WorkspaceID.WorkspaceBG + uuid(),
                left: this.option.width - horizontalProhibited / 2 - fontSize / 2,
                top: this.option.height / 2 + (prohibitedStr.length * fontSize) / 4,
                angle: -90,
                fontSize: fontSize,
                fill: '#00000096',
                selectable: false,
                evented: false,
                hasControls: false,
                hasBorders: false,
                hoverCursor: 'default',
              });

              // 将禁止打印区域和文字添加到组对象数组中
              groupObjects.push(leftProhibitedArea, rightProhibitedArea, leftText, rightText);
            }

            // 创建一个新的图层（组）
            let blankImage = new fabric.Group(groupObjects, {
              // @ts-ignore
              id: WorkspaceID.WorkspaceCavas,
              fill: 'rgba(255, 255, 255, 0)',
              width: this.option.width,
              height: this.option.height,
              selectable: false,
              evented: false,
              hasControls: false,
              hasBorders: false,
              hoverCursor: 'default',
            });

            var groupBG = new fabric.Group([], {
              // @ts-ignore
              id: WorkspaceID.WorkspaceBG + uuid(),
              selectable: false,
              evented: false,
              hasControls: false,
              hasBorders: false,
              hoverCursor: 'default',
            });

            console.log('====initWorkCanvas======option.category==start=');
            // 添加推荐打印区域的虚线
            var topLine = new fabric.Line(
              [
                horizontalProhibited,
                verticalRecommandedBlanklen,
                this.option.width - horizontalProhibited,
                verticalRecommandedBlanklen,
              ],
              {
                // @ts-ignore
                id: WorkspaceID.WorkspaceBG + uuid(),
                stroke: '#000',
                strokeDashArray: [5, 5],
                selectable: false,
                evented: false,
                hasControls: false,
                hasBorders: false,
                hoverCursor: 'default',
              },
            );
            var bottomLine = new fabric.Line(
              [
                horizontalProhibited,
                this.option.height - verticalRecommandedBlanklen,
                this.option.width - horizontalProhibited,
                this.option.height - verticalRecommandedBlanklen,
              ],
              {
                // @ts-ignore
                id: WorkspaceID.WorkspaceBG + uuid(),
                stroke: '#000',
                strokeDashArray: [5, 5],
                selectable: false,
                evented: false,
                hasControls: false,
                hasBorders: false,
                hoverCursor: 'default',
              },
            );

            groupBG.addWithUpdate(topLine);
            groupBG.addWithUpdate(bottomLine);

            var lineTo = this.option.height + this.option.height / 8;
            // 添加垂直虚线
            const getLines = () => {
              var quarterLine = new fabric.Line(
                [this.option.width / 4, verticalRecommandedBlanklen, this.option.width / 4, lineTo],
                {
                  // @ts-ignore
                  id: WorkspaceID.WorkspaceBG + uuid(),
                  stroke: '#000',
                  strokeDashArray: [5, 5],
                  selectable: false,
                  evented: false,
                  hasControls: false,
                  hasBorders: false,
                  hoverCursor: 'default',
                },
              );

              var halfLine = new fabric.Line(
                [this.option.width / 2, verticalRecommandedBlanklen, this.option.width / 2, lineTo],
                {
                  // @ts-ignore
                  id: WorkspaceID.WorkspaceBG + uuid(),
                  stroke: '#000',
                  strokeDashArray: [5, 5],
                  selectable: false,
                  evented: false,
                  hasControls: false,
                  hasBorders: false,
                  hoverCursor: 'default',
                },
              );

              var threeQuarterLine = new fabric.Line(
                [(3 * this.option.width) / 4, verticalRecommandedBlanklen, (3 * this.option.width) / 4, lineTo],
                {
                  // @ts-ignore
                  id: WorkspaceID.WorkspaceBG + uuid(),
                  stroke: '#000',
                  strokeDashArray: [5, 5],
                  selectable: false,
                  evented: false,
                  hasControls: false,
                  hasBorders: false,
                  hoverCursor: 'default',
                },
              );
              return [quarterLine, halfLine, threeQuarterLine];
            };
            var lines1 = getLines();

            groupBG.addWithUpdate(lines1[0]);
            groupBG.addWithUpdate(lines1[1]);
            groupBG.addWithUpdate(lines1[2]);

            // 添加推荐打印区域中间的文字
            if (verticalRecommandedBlanklen > 0) {
              var recommandTextTop = new fabric.Text(recommandStr, {
                // @ts-ignore
                id: WorkspaceID.WorkspaceBG + uuid(),
                left: this.option.width / 2 - (recommandStr.length * verticalFontSize) / 4,
                top: verticalRecommandedBlanklen / 2 - verticalFontSize / 2,
                fontSize: verticalFontSize,
                fill: '#00000096',
                selectable: false,
                evented: false,
                hasControls: false,
                hasBorders: false,
                hoverCursor: 'default',
              });
              var recommandTextBottom = new fabric.Text(recommandStr, {
                // @ts-ignore
                id: WorkspaceID.WorkspaceBG + uuid(),
                left: this.option.width / 2 - (recommandStr.length * verticalFontSize) / 4,
                top: this.option.height - verticalRecommandedBlanklen / 2 - verticalFontSize / 2,
                fontSize: verticalFontSize,
                fill: '#00000096',
                selectable: false,
                evented: false,
                hasControls: false,
                hasBorders: false,
                hoverCursor: 'default',
              });

              groupBG.addWithUpdate(recommandTextTop);
              groupBG.addWithUpdate(recommandTextBottom);
            }

            canvas.add(groupBG);
            canvas.sendToBack(groupBG);
            // // 添加空白底图到画布上
            canvas.add(blankImage);
            canvas.sendToBack(blankImage);
            canvas.renderAll();

            var lines2 = getLines();
            this.canvas_bg?.add(lines2[0]);
            this.canvas_bg?.add(lines2[1]);
            this.canvas_bg?.add(lines2[2]);
            // 添加杯子图片
            const loadImage = (url: string, left: number) => {
              return new Promise<void>((resolve) => {
                fabric.Image.fromURL(url, (img) => {
                  let width = this.option.width / 10;
                  img.scaleToWidth(width);
                  img.scaleToHeight(width);
                  img.set({
                    // @ts-ignore
                    id: WorkspaceID.WorkspaceBG + uuid(),
                    left: left,
                    top: lineTo,
                    selectable: false,
                    evented: false,
                    hasControls: false,
                    hasBorders: false,
                    hoverCursor: 'default',
                  });
                  // canvas.add(img);
                  this.canvas_bg?.add(img);
                  resolve();
                });
              });
            };

            const imagePromises = [
              loadImage(icons[0], this.option.width / 4 - this.option.width / 20),
              loadImage(icons[1], this.option.width / 2 - this.option.width / 20),
              loadImage(icons[2], (3 * this.option.width) / 4 - this.option.width / 20),
            ];

            Promise.all(imagePromises).then(() => {
              console.log('======beizi ======end===', this.canvas_bg?.getObjects())
              canvas.renderAll();
              console.log('====initWorkCanvas======option.category==end=');

              fabricImageBg = blankImage;
              var initWorkCanvasRet: InitWorkCanvasRet = {
                canvas: canvas,
                fabricImageBg: fabricImageBg!,
              };
              console.log('=====loadProjectFirst=-=======222222==', new Date().toISOString());
              resolve(initWorkCanvasRet);
              return;
            });
          } else {
            // 如果不是 Base64 数据，创建一个空白矩形
            var blankImage = new fabric.Rect({
              // @ts-ignore
              id: WorkspaceID.WorkspaceCavas,
              fill: '#fff',
              width: this.option.width,
              height: this.option.height,
              selectable: false,
              evented: false,
              hasControls: false,
              hasBorders: false,
              hoverCursor: 'default',
            });
            // 添加空白底图到画布上
            canvas.add(blankImage);
            canvas.sendToBack(blankImage);
            canvas.renderAll();
            fabricImageBg = blankImage;
            var initWorkCanvasRet: InitWorkCanvasRet = {
              canvas: canvas,
              fabricImageBg: fabricImageBg!,
            };
            resolve(initWorkCanvasRet);
          }
        });
      }
      // 添加空白底图到画布上
      if (blankImage) {
        if (overlay) {
          canvas.add(blankImage, overlay);
          canvas.sendToBack(blankImage);
        } else {
          canvas.add(blankImage);
          canvas.sendToBack(blankImage);
        }
      }
      canvas.renderAll();
      fabricImageBg = blankImage;
      var initWorkCanvasRet: InitWorkCanvasRet = {
        canvas: canvas,
        fabricImageBg: fabricImageBg!,
      };
      return Promise.resolve(initWorkCanvasRet);
    }
  }

  isBase64 = (str: string) => {
    const base64Pattern = /^data:image\/(png|jpg|jpeg);base64,/;
    return base64Pattern.test(str);
  };

  _initScale() {
    // const rulerSize = 20;
    const rulerSize = 0;
    const rightbarWidth = 0;
    let scale: number;
    const viewPortWidth = this.workspaceEl.offsetWidth - rightbarWidth;
    const viewPortHeight = this.workspaceEl.offsetHeight;
    // 按照宽度
    if (viewPortWidth / viewPortHeight < this.option.width / this.option.height) {
      scale = viewPortWidth / this.option.width;
    } else {
      scale = viewPortHeight / this.option.height;
    }
    this.setZoomAuto(scale - 0.08);
    const viewportTransform = this.canvas.viewportTransform;
    if (viewportTransform) {
      viewportTransform[4] = viewportTransform[4] - rightbarWidth / 2 + rulerSize / 2;
      this.canvas.setViewportTransform(viewportTransform);
      this.canvas_bg?.setViewportTransform(viewportTransform);
    }
  }

  /**
   * 设置画布中心到指定对象中心点上
   * @param {Object} obj 指定的对象
   */
  setCenterFromObject(obj: fabric.Rect) {
    const { canvas } = this;
    const objCenter = obj.getCenterPoint();
    const viewportTransform = canvas.viewportTransform;
    if (canvas.width === undefined || canvas.height === undefined || !viewportTransform) return;
    viewportTransform[4] = canvas.width / 2 - objCenter.x * viewportTransform[0];
    viewportTransform[5] = canvas.height / 2 - objCenter.y * viewportTransform[3];
    canvas.setViewportTransform(viewportTransform);
    canvas.renderAll();
  }

  // 初始化监听器
  _initResizeObserve() {
    const resizeObserver = new ResizeObserver(
      throttle(() => {
        const { workspaceEl } = this;
        const width = workspaceEl.offsetWidth;
        const height = workspaceEl.offsetHeight;
        this.canvas.renderOnAddRemove = false;
        this.canvas.setWidth(width);
        this.canvas.setHeight(height);
        this.canvas.renderAll();
        this.canvas.renderOnAddRemove = true;

        if (this.canvas_bg) {
          this.canvas_bg!.renderOnAddRemove = false;
        }
        this.canvas_bg?.setWidth(width);
        this.canvas_bg?.setHeight(height);
        this.canvas_bg?.renderAll();
        if (this.canvas_bg) {
          this.canvas_bg!.renderOnAddRemove = true;
        }
      }, 50),
    );
    resizeObserver.observe(this.workspaceEl);
  }

  setZoomAuto(scale: number, cb?: (left?: number, top?: number) => void) {
    const { workspaceEl } = this;
    const width = workspaceEl.offsetWidth;
    const height = workspaceEl.offsetHeight;
    this.canvas.setWidth(width);
    this.canvas.setHeight(height);
    const center = this.canvas.getCenter();
    this.canvas.setViewportTransform(fabric.iMatrix.concat());
    this.canvas.zoomToPoint(new fabric.Point(center.left, center.top), scale);

    this.canvas_bg?.setWidth(width);
    this.canvas_bg?.setHeight(height);
    this.canvas_bg?.setViewportTransform(fabric.iMatrix.concat());
    this.canvas_bg?.zoomToPoint(new fabric.Point(center.left, center.top), scale);

    if (!this.workspace) return;
    // @ts-ignore
    this.setCenterFromObject(this.workspace);
    if (cb) cb(this.workspace.left, this.workspace.top);
  }

  // 超出画布不展示;
  outCanvasRangeNoDisplay(flag?: boolean) {
    !!this.workspace &&
      this.workspace.clone((cloned: fabric.Rect) => {
        // @ts-ignore
        this.canvas.clipPath = !!flag ? null : cloned;
        this.canvas.renderAll();
      });
  }

  _getScale() {
    const viewPortWidth = this.workspaceEl.offsetWidth;
    const viewPortHeight = this.workspaceEl.offsetHeight;
    if (viewPortWidth / viewPortHeight < this.option.width / this.option.height) {
      return viewPortWidth / this.option.width;
    } // 按照宽度缩放
    return viewPortHeight / this.option.height;
  }

  // 放大
  big() {
    let zoomRatio = this.canvas.getZoom();
    zoomRatio += 0.05;
    const center = this.canvas.getCenter();
    this.canvas.zoomToPoint(new fabric.Point(center.left, center.top), zoomRatio);
    this.canvas_bg?.zoomToPoint(new fabric.Point(center.left, center.top), zoomRatio);
  }

  // 缩小
  small() {
    let zoomRatio = this.canvas.getZoom();
    zoomRatio -= 0.05;
    const center = this.canvas.getCenter();
    this.canvas.zoomToPoint(new fabric.Point(center.left, center.top), zoomRatio < 0 ? 0.01 : zoomRatio);
    this.canvas_bg?.zoomToPoint(new fabric.Point(center.left, center.top), zoomRatio < 0 ? 0.01 : zoomRatio);
  }

  // 自动缩放
  auto() {
    // console.log('auto;');
    const scale = this._getScale();
    this.setZoomAuto(scale - 0.08);
  }

  // 1:1 放大
  one() {
    this.setZoomAuto(0.8 - 0.08);
    this.canvas.requestRenderAll();
    this.canvas_bg?.requestRenderAll();
  }

  _initMovePointer() {
    this.canvasUnBindEvent();
    this.canvasBindEvent();
  }

  canvasBindEvent() {
    this.canvas.on('mouse:wheel', this.handleWheel);
    this.canvas.on('mouse:move', this.mouseMove);
    this.canvas.on('mouse:over', this.mouseOver);
    this.canvas.on('mouse:out', this.cancelFrame);
    this.canvas.on('mouse:down', this.cancelFrame);
    eventBus.on(ImageStatus.Cropping, this.handleCropping);
    eventBus.on(TextStatus.UnderTransform, this.handleUnderTransform);
  }

  canvasUnBindEvent() {
    this.canvas.off('mouse:wheel', this.handleWheel);
    this.canvas.off('mouse:move', this.mouseMove);
    this.canvas.off('mouse:over', this.mouseOver);
    this.canvas.off('mouse:out', this.cancelFrame);
    this.canvas.off('mouse:down', this.cancelFrame);
    eventBus.off(ImageStatus.Cropping, this.handleCropping);
    eventBus.off(TextStatus.UnderTransform, this.handleUnderTransform);
  }

  private getTouchDistance(touches: TouchList): number {
    const [touch1, touch2] = [touches[0], touches[1]];
    const dx = touch2.clientX - touch1.clientX;
    const dy = touch2.clientY - touch1.clientY;
    return Math.sqrt(dx * dx + dy * dy);
  }

  // 定义 mouseMove 方法
  mouseMove({ pointer }: any) {
    this.pointer = pointer;
  }

  // 定义 mouseOver 方法
  mouseOver(e: any) {
    if (!this.canvas) return;
    const target = e.target;
    this.addFrame(target);
  }

  getAbsoluteCoords(obj: any) {
    const matrix = obj.calcTransformMatrix();
    const options = { x: obj.left, y: obj.top };
    //@ts-ignore
    const point = new fabric.Point(options.x, options.y);
    //@ts-ignore
    const transformedPoint = fabric.util.transformPoint(point, matrix);
    return {
      x: transformedPoint.x - (obj.width * obj.scaleX) / 2,
      y: transformedPoint.y - (obj.height * obj.scaleY) / 2,
    };
  }

  addFrame(target: any, offsetX: number = 0, offsetY: number = 0, oriWidth: number = 0, oriHeight: number = 0) {
    if (target && this.canvas.getActiveObjects().length == 0) {
      // 暂停保存历史记录
      this.editor.stopSaveHistory();
      //@ts-ignore
      this.editor.event?.emitEvent(EventNameCons.EventProjectChangeState, true);
      const padding = target.padding || 0;
      let left, top, width, height, originX, originY;
      width = oriWidth == 0 ? (target.width + padding * 2) * target.scaleX : oriWidth;
      height = oriHeight == 0 ? (target.height + padding * 2) * target.scaleY : oriHeight;
      if (target.type === 'group' || target.originX === 'center') {
        const center = target.getCenterPoint();
        left = center.x;
        top = center.y;
        originX = 'center';
        originY = 'center';
      } else {
        // const absoluteCoords = this.getAbsoluteCoords(target);
        left = offsetX == 0 ? target.left - padding : offsetX;
        top = offsetY == 0 ? target.top - padding : offsetY;
        // left = offsetX == 0 ? absoluteCoords.x : offsetX;
        // top = offsetY == 0 ? absoluteCoords.y : offsetY;
        originX = 'left';
        originY = 'top';
      }
      const rect = new fabric.Rect({
        // @ts-ignore
        id: WorkspaceID.WorkspaceFrame,
        left: left,
        top: top,
        width: width,
        height: height,
        fill: 'transparent',
        angle: target.angle,
        stroke: getColors().color_primary,
        strokeWidth: 2,
        selectable: false,
        evented: false,
        originX: originX,
        originY: originY,
      });
      this.canvas.add(rect);
      this.canvas.renderAll();
    }
  }

  cancelFrame(e: any) {
    if (!this.canvas) return;
    const objects = this.canvas.getObjects();
    var needRemove = false;
    for (let i = objects.length - 1; i >= 0; i--) {
      if ((objects[i] as any).id === WorkspaceID.WorkspaceFrame) {
        this.canvas.remove(objects[i]);
        needRemove = true;
      }
    }
    if (needRemove) {
      this.editor.startSaveHistory();
      //@ts-ignore
      this.editor.event?.emitEvent(EventNameCons.EventProjectChangeState, false);
    }
  }

  handleWheel(opt: any) {
    if (!this) return;
    const delta = opt.e.deltaY;
    let zoom = this.canvas.getZoom();
    // 检测是否是触摸设备的缩放手势
    if (opt.e.ctrlKey) {
      // 对于触摸缩放，使用更大的缩放速率
      zoom *= Math.pow(0.97, delta);
    } else {
      // 对于鼠标滚轮，使用原有的缩放速率
      zoom *= Math.pow(0.999, delta);
      return;
    }
    if (zoom > 20) zoom = 20;
    if (zoom < 0.01) zoom = 0.01;
    this.canvas.zoomToPoint(this.pointer, zoom);
    this.canvas_bg?.zoomToPoint(this.pointer, zoom);
    opt.e.preventDefault();
    opt.e.stopPropagation();
  }

  destroy() {
    this.canvasUnBindEvent();
    console.log('pluginDestroy');
  }
}

export default WorkspacePlugin;
