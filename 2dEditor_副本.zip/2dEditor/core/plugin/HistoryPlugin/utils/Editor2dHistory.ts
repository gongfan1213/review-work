import { fabric } from 'fabric';
import md5 from "js-md5";
import IndexedDBAk, { DB_NAME_fabricImgStore_ak } from "src/common/utils/IndexedDBAk";


export class Editor2dHistory {
  private capacity: number;
  private data: fabric.Object[];
  private lastIndex: number;
  private currentIndex: number = 0;
  private paused: boolean;
  private db: IndexedDBAk;
  private tempMap: Map<number, fabric.Object> = new Map();

  constructor(capacity: number, initialData: fabric.Object[]) {
    this.capacity = capacity || 10;
    this.data = initialData || [];
    this.lastIndex = this.data.length - 1;
    this.currentIndex = Math.max(this.data.length - 1, 0);
    this.paused = false;

    this.db = new IndexedDBAk(DB_NAME_fabricImgStore_ak);
    this.db.open().then(() => {
      //this.db.clear()
    });
  }

  async back(): Promise<fabric.Object | null> {
    if (!this.paused && this.currentIndex > 0) {
      if (!this.tempMap.has(this.currentIndex - 1)) return null;
      this.lastIndex = this.currentIndex;
      this.currentIndex--;
      console.log('history =====back item===back==:', new Date().toISOString(), this.data.length, this.currentIndex);
      if (this.data.length > 3
        && this.currentIndex < this.data.length - 2
        && this.currentIndex != 0) {
        const retKey = Math.min(...Array.from(this.tempMap.keys())) - 1;
        this.getItem(retKey).then((newItem) => {
          if (newItem) {
            // 删除 tempMap 中键值最大的对象
            if (this.tempMap.size == 3) {
              const maxKey = Math.max(...Array.from(this.tempMap.keys()));
              this.tempMap.delete(maxKey);
            }
            this.tempMap.set(retKey, newItem);
          }
        });
      }
      return null;
    } else {
      return null;
    }
  }

  async forward(): Promise<fabric.Object | null> {
    if (!this.paused && this.currentIndex < this.data.length - 1) {
      if (!this.tempMap.has(this.currentIndex + 1)) return null;
      this.lastIndex = this.currentIndex;
      this.currentIndex++;
      console.log('history =====back item===forward==:', this.data.length, this.currentIndex);
      if (this.data.length > 3
        && this.currentIndex !== this.data.length - 1
        && this.currentIndex > 1) {
        const retKey = Math.max(...Array.from(this.tempMap.keys())) + 1;
        this.getItem(retKey).then((newItem) => {
          if (newItem) {
            if (this.tempMap.size == 3) {
              // 删除 tempMap 中键值最大的对象
              const minKey = Math.min(...Array.from(this.tempMap.keys()));
              this.tempMap.delete(minKey);
            }
            this.tempMap.set(retKey, newItem);
          }
        });
      }
      return null;
    } else {
      return null;
    }
  }

  push(item: fabric.Object): Promise<void> {
    var retJson = JSON.parse(JSON.stringify(item));
    return new Promise((resolve, reject) => {
      if (!this.paused) {
        Promise.all((item as any).objects.map(async (obj: fabric.Object) => {
          await this.processImage(obj);
        })).then(() => {
          if (this.data.length >= this.capacity) {
            this.data.shift();
          }
          if (this.currentIndex < this.data.length - 1) {
            this.data.splice(this.currentIndex + 1);
            // 移除 tempMap 中 key 大于 currentIndex 的数据
            Array.from(this.tempMap.keys())
              .filter(key => key > this.currentIndex)
              .forEach(key => this.tempMap.delete(key));
          }
          
          this.data.push(item);
          this.currentIndex = this.data.length - 1;
          // 更新 tempMap
          this.updateTempMap(this.currentIndex, retJson);
          resolve(); // Resolve the promise after all operations are done
        }).catch((error) => {
          console.error('Error processing images:', error);
          reject(error); // Reject the promise if there's an error
        });
      } else {
        resolve(); // Resolve immediately if paused
      }
    });
  }

  // 新增方法：更新 tempMap
  private updateTempMap(index: number, item: fabric.Object): void {
    // 添加新的步骤到 tempMap
    this.tempMap.set(index, item);
    // 保持 tempMap 大小为 3
    const keys = Array.from(this.tempMap.keys());
    while (this.tempMap.size > 3) {
      const oldestKey = Math.min(...keys);
      this.tempMap.delete(oldestKey);
    }
  }

  async getItem(index: number): Promise<fabric.Object | null> {
    if (this.data.length == 0 || index >= this.data.length) return null;
    var jsonObj = JSON.parse(JSON.stringify(this.data[index]));
    console.log('history =====getItem item===start==:');
    const fabricObj = (jsonObj as any).objects;
    for (const obj of fabricObj) {
      await this.restoreImage(obj);
    }
    console.log('history =====getItem item===end==:', new Date().toISOString());
    return jsonObj;
  }

  private async processImage(item: fabric.Object): Promise<void> {
    if (item.type === 'image' && (item as any).src && !(item as any).src.startsWith('http')) {
      const src = (item as any).src;
      const hash = md5(src);
      const existingData = await this.db.get(hash);
      if (!existingData) {
        await this.db.put(hash, src);
      }
      (item as any).src = hash;
    } else if (item instanceof fabric.Group) {
      const objects = (item as fabric.Group).getObjects();
      for (const obj of objects) {
        await this.processImage(obj);
      }
    }
  }

  private async restoreImage(item: fabric.Object): Promise<void> {
    if (item.type === 'image' && (item as any).src && !(item as any).src.startsWith('http')) {
      const hash = (item as any).src;
      const base64 = await this.db.get(hash);
      if (base64) {
        (item as any).src = base64;
      }
    } else if (item instanceof fabric.Group) {
      const objects = (item as fabric.Group).getObjects();
      for (const obj of objects) {
        await this.restoreImage(obj);
      }
    }
  }

  async getValue(): Promise<fabric.Object | null | undefined> {
    // const ret = await this.getItem(this.currentIndex);
    console.log('history =====push item===getValue==:', this.currentIndex);
    const ret = this.tempMap.get(this.currentIndex);
    return ret;
  }

  pause(): void {
    this.paused = true;
  }

  resume(): void {
    this.paused = false;
  }

  length(): number {
    return this.data.length;
  }

  getCurrentIndex(): number {
    return this.currentIndex;
  }

  clear(): void {
    if (!this.data || this.data.length === 0) return;
    this.data = [];
    this.lastIndex = 0;
    this.currentIndex = 0;
    this.db.clear();
    this.tempMap.clear();
  }
}