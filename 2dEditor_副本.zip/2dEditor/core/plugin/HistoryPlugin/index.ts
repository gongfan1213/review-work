import { fabric } from 'fabric';
import Editor from '../../core';
import { Editor2dHistory } from './utils/Editor2dHistory';
import { CustomKey, FabricObjectType, WorkspaceID } from '../../../cons/2dEditorCons';
import { Image as CustomImage } from 'src/templates/2dEditor/core/plugin/ImagePlugin/Image';
import { ArcText } from 'src/templates/2dEditor/core/plugin/ArcTextPlugin/ArcText';
import { Textbox } from 'src/templates/2dEditor/core/plugin/TextPlugin/Textbox';
import { BezierControlId, CircleControlId, AngleControlId } from '../ArcTextPlugin/types';
import { DisableLayerId } from 'src/templates/2dEditor/components/Layer/types';
import { UnSaveId, AddJsonTempID } from './types'
import { TempPatternID } from 'src/templates/2dEditor/core/plugin/PatternPlugin/types'
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { ImageStatus } from 'src/templates/2dEditor/core/eventbus/types/image';
import { HistoryEvent } from 'src/templates/2dEditor/core/eventbus/types/history';

// 不进行保存的object id;
const disableSaveIds = [
  // WorkspaceID.WorkspaceBG,
  // WorkspaceID.WorkspaceCavas,
  UnSaveId.Id,
  BezierControlId.ControlCircle,
  BezierControlId.ControlLine,
  CircleControlId.ControlCircle,
  AngleControlId.ControlCircle,
  AngleControlId.ControlLine,
  DisableLayerId.ClonedForMoveId,
  TempPatternID.ID,
  AddJsonTempID.ID,
  'imageCropMask', // crop image mask;
];
const workspaceLength = 3;

type IEditor = Editor;
class HistoryPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  static pluginName = 'HistoryPlugin';
  static apis = [
    'undo',
    'redo',
    'stopSaveHistory',
    'startSaveHistory',
    'clearHistory',
    'historySave',
    'doDisabled'
  ];
  public flag: boolean = true;
  public disabled: boolean = false;
  public history: Editor2dHistory = new Editor2dHistory(30, []);
  public hotkeys: string[] = [
    'ctrl+z',
    'ctrl+shift+z',
    'command+z',
    'command+shift+z'
  ];
  private taskQueue: (() => Promise<void>)[] = [];
  // private isProcessing: boolean = false;

  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
    this.historySave = this.historySave.bind(this);
    this.doDisabled = this.doDisabled.bind(this);
    this.init();
  }

  init() {
    // this.history = new Editor2dHistory(30, []);
    this.setupEventListeners();
  }

  setupEventListeners() {
    this.removeEventListeners();
    this.canvas.on({
      'object:added': this.historySave,
      'object:modified': this.historySave,
      'object:removed': this.historySave,
    });
    eventBus.on(ImageStatus.Cropping, this.doDisabled);
    eventBus.on(ImageStatus.RemovingBackground, this.doDisabled);
    eventBus.on(ImageStatus.Upscaling, this.doDisabled);
    eventBus.on(ImageStatus.Editing, this.doDisabled);
  }

  removeEventListeners() {
    this.canvas.off({
      'object:added': this.historySave,
      'object:modified': this.historySave,
      'object:removed': this.historySave,
    });
    eventBus.off(ImageStatus.Cropping, this.doDisabled);
    eventBus.off(ImageStatus.RemovingBackground, this.doDisabled);
    eventBus.off(ImageStatus.Upscaling, this.doDisabled);
    eventBus.off(ImageStatus.Editing, this.doDisabled);
  }

  // @ts-ignore;
  public doDisabled(e) {
    this.disabled = e.value;
  }

  destroy() {
    this.removeEventListeners();
  }

  public async historySave() {   
    const blockFlag = this.disabled || !this.flag;
    if (blockFlag) {
      return;
    }
    
    return new Promise<void>((resolve, reject) => {
      const task = async () => {
        try {
          const saveJson = this.getJSON();
          // 不保存标品工作区元素不小于3个的历史;
          // if (saveJson.objects.filter((item: any) => item.id && !item.id.includes(WorkspaceID.WorkspaceCavas)).length == 0) {
          //   console.log('historySave =====start==11111:');
          //   resolve();
          //   return;
          // }
          // 过滤无需被保存的object;
          if(!saveJson) return
          saveJson.objects = !!saveJson.objects ?
            saveJson.objects.filter((object: any) => !(disableSaveIds.includes(object.id))) : saveJson.objects;
          try {
            const lastHistory = await this.history.getValue();
            if (lastHistory && JSON.stringify(lastHistory) === JSON.stringify(saveJson)) {
              resolve();
              return; // 如果数据相同，则不执行保存操作
            }
            await this.history.push(saveJson);
            
            eventBus.emit(HistoryEvent.Save, this.history);
            resolve();
          } catch (error) {
            console.error('Error after pushing to history:', error);
            reject(error);
          }
        } catch (error) {
          console.error('Error in historySave:', error);
          reject(error);
        }
      };

      console.log('historySave ====task===start==:', this.taskQueue.length);
      if (this.taskQueue.length == 0) {
        this.taskQueue.push(task);
        this.processQueue();
      } else {
        this.taskQueue.push(task);
      }
    });
  }

  private async processQueue() {
    if (this.taskQueue.length === 0) {
      return;
    }
    // this.isProcessing = true;
    const task = this.taskQueue[0];
    if (task) {
      try {
        await task();        
      } catch (error) {
        console.error('Error processing task:', error);
      }
      this.taskQueue.shift();
    }
    this.processQueue();
    // this.isProcessing = false;
  }

  // 往回走;
  public async undo() {
    if (this.disabled || !this.flag) return;
    if (this.history.length() === 0) return;
    if (this.history.getCurrentIndex() === 0) return;

    await this.history.back();
    await this.render();
    // undo history action;
    eventBus?.emit(HistoryEvent.Undo, this.history);
  }

  // 往前走;
  public async redo() {
    if (this.disabled || !this.flag) return;
    if (this.history.length() === 0) return;
    if (this.history.length() - 1 === this.history.getCurrentIndex()) return;

    await this.history.forward();
    await this.render();
    // redo history action;
    eventBus?.emit(HistoryEvent.Redo, this.history);
  }

  async render() {
    var slectObjId = (this.canvas.getActiveObject() as any)?.id;
    this.canvas.discardActiveObject();
    this.stopSaveHistory();
    // render history action;
    eventBus.emit(HistoryEvent.Rendering, {
      value: true,
      history: this.history,
    });
    var lastHistory = await this.history.getValue();
    if (lastHistory) {
      console.log('history======== render:========', new Date().toISOString());
      await this.canvas.loadFromJSON(lastHistory, () => {
        eventBus.emit(HistoryEvent.Rendering, { value: false });
        if (slectObjId) {
          const obj = this.canvas.getObjects().find(o => (o as any).id === slectObjId);
          if (obj) {
            // 设置找到的对象为激活对象
            this.canvas.setActiveObject(obj);
            this.canvas.renderAll();
          }
        }
        console.log('history======== render:===end=====', new Date().toISOString());
        this.startSaveHistory();
      });
    } else {
      this.startSaveHistory();
    }
  };
  public clearHistory() {
    this.history.clear();
    this.taskQueue = [];
    console.log('historySave =====clearHistory==:');
    this.historySave();
  }
  startSaveHistory(endSave?: boolean) {
    console.log('history===startSaveHistory;', endSave);
    this.flag = true;
    this.history.resume();
    if (endSave) {
      console.log('historySave =====startSaveHistory==:');
      this.historySave()
    }
  }
  stopSaveHistory() {
    console.log('history===stopSaveHistory;', new Date().toISOString());
    this.flag = false;
    this.history.pause();
  }
  // get json;
  getJSON() {
    const historyJson = this.editor.getJson();
    historyJson && historyJson.clipPath && delete historyJson.clipPath;
    return historyJson;
  }

  // hot key;
  hotkeyEvent(eventName: string, e: any) {
    if (!this.flag) return;
    if (this.disabled) return;
    if (e.type === 'keydown') {
      switch (eventName) {
        case 'ctrl+z':
        case 'command+z':
          this.undo();
          break;
        case 'ctrl+shift+z':
        case 'command+shift+z':
          this.redo();
          break;
      }
    }
  }
}

export default HistoryPlugin;
