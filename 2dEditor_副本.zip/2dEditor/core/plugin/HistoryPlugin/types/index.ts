export enum UnSaveId {
  Id = 'unSaveId',
}

export enum AddJsonTempID {
  ID = 'tempJsonId'
}

export enum HistoryOperationType {
  Undo,
  Redo
}