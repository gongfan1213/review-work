import { FabricObjectType } from 'src/templates/2dEditor/cons/2dEditorCons';
import { LayerType, CustomKey, CustomObjectType, TextureType } from 'src/templates/2dEditor/cons/2dEditorCons';

export default function initCustomKey(object: any) {
  if (!object) return;
  // for the text transform;
  if (object.id === 'bezierTextCurve') return;
  if (object.id === 'bezierTextControlCircle') return;

  handleLayerDefaultName(object);
  // 群组元素;
  if (object.type === FabricObjectType.Group) {
    object.set(CustomKey.IsLayerFold, true); // 是否折叠;
    // object.set(CustomKey.IsLock, false); // 是否锁住;
  }
  // other;
  else {
    // object.set(CustomKey.IsLock, false); // 是否锁住;
  }
}

// layer name;
// object: fabric.object;
const handleLayerDefaultName = (object: any) => {
  // console.log("handleLayerDefaultName; object", object);
  if (!!object.get(CustomKey.LayerName)) return;
  switch (object.type) {
    case FabricObjectType.Group:
      if (checkGroupHasTextOrImageOrGroup(object)) {
        object.set(CustomKey.LayerName, LayerType.Group);
        object.set(CustomKey.CustomType, CustomObjectType.Group);
      } else {
        object.set(CustomKey.LayerName, LayerType.Vector);
        object.set(CustomKey.CustomType, CustomObjectType.Path);
      }

      if (object._isTextureGroup) {
        if (object._objects[1].textureType == TextureType.RELIEF) {
          object.set(CustomKey.LayerName, LayerType.ReliefImage);
        } else {
          object.set(CustomKey.LayerName, LayerType.TextureImage);
        }
      }
      break;
    case FabricObjectType.Image:
      if (object.textureType === TextureType.CMYK || object.textureType === TextureType.GLOSS) {
        object.set(CustomKey.LayerName, LayerType.TextureImage);
      } else if (object.textureType === TextureType.RELIEF) {
        object.set(CustomKey.LayerName, LayerType.ReliefImage);
      } else {
        object.set(CustomKey.LayerName, LayerType.Image);
      }
      break;
    case FabricObjectType.TextBox:
    case FabricObjectType.Text:
    case FabricObjectType.TextI:
      // object.set(CustomKey.LayerName, LayerType.Text);
      object.set(CustomKey.LayerName, object.text);
      break;
    default:
      object.set(CustomKey.LayerName, LayerType.Vector);
      break;
  }
};

// #region utils;
// check for text or image in group;
const checkGroupHasTextOrImageOrGroup = (object: any) => {
  if (object.type === FabricObjectType.Group) {
    const innerObjects = object.getObjects();
    return innerObjects.some(
      (item: any) =>
        item.type === FabricObjectType.TextI ||
        item.type === FabricObjectType.Text ||
        item.type === FabricObjectType.TextBox ||
        item.type === FabricObjectType.Image ||
        item.type === FabricObjectType.Group,
    );
  }
  return false;
};
