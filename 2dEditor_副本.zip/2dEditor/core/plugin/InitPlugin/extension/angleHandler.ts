import { CustomKey, FabricObjectType, CustomObjectType } from "src/templates/2dEditor/cons/2dEditorCons";

// @ts-ignore;
export default function angleHandler(object) {
  if (
    !object ||
    !object.id
  ) return;
  // @ts-ignore;
  // object SCALE;
  object.on('rotating', (e) => {
    const target = e.transform.target;
    if (!target) return;
    // group need to check son object;
    if (
      target.type === FabricObjectType.Group &&
      target[CustomKey.CustomType] === CustomObjectType.Group
    ) {
      // @ts-ignore;
      target.forEachObject((sonObject) => {
        sonObject.set({
          [CustomKey.RelativeAngle]: sonObject.angle + target.angle
        });
      })
    }
    // ;
    else {
      target.set({
        [CustomKey.RelativeAngle]: target.angle
      });
    }
  });
  // ;
  // @ts-ignore;
  // object SELECTED;
  object.on('selected', (e) => {
    const target = e.target;
    if (!target) return;
    // group need to check son object;
    if (
      target.type === FabricObjectType.Group &&
      target[CustomKey.CustomType] === CustomObjectType.Group
    ) {
      // @ts-ignore;
      target.forEachObject((sonObject) => {
        sonObject.set({
          [CustomKey.RelativeAngle]: sonObject.angle + target.angle
        });
      })
    }
    // // ;
    else {
      target.set({
        [CustomKey.RelativeAngle]: target.angle
      });
    }
  });
}
