import { v4 as uuid } from "uuid";

export default function initId(object: any) {
  if (
    !object ||
    object.id
  ) return;
  object.set({
    id: uuid(),
  });

}
