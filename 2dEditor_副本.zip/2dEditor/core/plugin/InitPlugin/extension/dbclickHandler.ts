import { fabric } from 'fabric';
import {
  CustomKey,
  CustomObjectType,
  EDITOR_JSON_KEY,
  EventNameCons,
  FabricObjectType,
} from 'src/templates/2dEditor/cons/2dEditorCons';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { LayerStatus, RenderLayer } from 'src/templates/2dEditor/core/eventbus/types/layer';
import { Image } from 'src/templates/2dEditor/core/plugin/ImagePlugin/Image';
import { Textbox } from '../../TextPlugin/Textbox';
import { ArcText } from '../../ArcTextPlugin/ArcText';
import { ImageStatus } from 'src/templates/2dEditor/core/eventbus/types/image';
import { is } from 'dom7';

// @ts-ignore;
export default function dbClickHandler(e) {
  // @ts-ignore;
  if (!this) return;
  if (!this.canvas) return;
  if (
    e.target &&
    e.target.type === FabricObjectType.Group &&
    e.target[CustomKey.CustomType] === CustomObjectType.Group
  ) {
    if (e.target._isTextureGroup) {
      //双击时解除编组，并选中纹理图层，调用纹理图层的双击事件，纹理图层取消选中后重新编组
      // const angle = e.target.angle
      // e.target.set({
      //   angle: 0
      // })

      const textureObject = e.target._objects[1];
      eventBus?.emit(ImageStatus.Editing, {
        value: true,
        target: textureObject,
      });
      this.editor?.ungroup();
      textureObject.removeClipPathAndCache();
      return;
    }

    const selectedGroup = e.target;
    const selectedObject = getGroupObject.bind(this)(e);
    if (!selectedObject) return;

    // 操作群组子图层时 关闭图层模块的渲染;
    eventBus.emit(LayerStatus.RenderStatus, RenderLayer.OFF);
    // 让选中group的元素先取消选择状态;
    const activeObject = this.canvas.getActiveObject();
    if (activeObject && activeObject.group) {
      this.canvas.discardActiveObject();
      this.canvas.requestRenderAll(); // 更新画布以反映变化
    }
    this.editor.stopSaveHistory();
    this.editor.event?.emitEvent(EventNameCons.EventProjectChangeState, true);

    // #region 添加子图层的处理方式;
    // @ts-ignore;

    const options = {
      id: selectedObject.id,
      width: selectedObject.width,
      height: selectedObject.height,
      scaleX: selectedObject.calcTransformMatrix()[0],
      scaleY: selectedObject.calcTransformMatrix()[3],
      left: selectedObject.calcTransformMatrix()[4],
      top: selectedObject.calcTransformMatrix()[5],
      angle: selectedObject[CustomKey.RelativeAngle],
      originX: 'center',
      originY: 'center',
    };

    selectedObject.clone(async (cloned) => {
      if (cloned.type === FabricObjectType.Image) {
        const imageCloned = await Image.fromURL(cloned.src, options);
        cloned.set(selectedObject.toJSON(EDITOR_JSON_KEY));
        cloned = imageCloned;
      } else if (cloned.type === FabricObjectType.Text) {
        var pathObj =
          selectedObject.path && selectedObject.path.path
            ? new fabric.Path(selectedObject.path.path, selectedObject.path)
            : null;
        const transformTextObject = new ArcText(selectedObject.text || '', {
          ...selectedObject.toJSON(EDITOR_JSON_KEY),
          ...options,
          path: pathObj,
        });
        cloned = transformTextObject;
      } else if (cloned.type === FabricObjectType.TextBox) {
        //统一创建成ArcText，防止编辑的时候需要重新new一个新的类，会丢失事件监听
        const textboxCloned = new ArcText(selectedObject.text || '', {
          ...selectedObject.toJSON(EDITOR_JSON_KEY),
          ...options,
          path: null,
        });
        cloned = textboxCloned;
      } else {
        // 使用set方法将所有属性应用到克隆对象上
        cloned.set(selectedObject.toJSON(EDITOR_JSON_KEY));
        cloned.set(options);
      }
      selectedObject.set('opacity', 0);
      this.editor.doDisabled({ value: true });
      cloned.set({
        _parentId: selectedGroup.id,
        _cloneId: selectedObject.id,
      });
      this.canvas.add(cloned);
      this.canvas.setActiveObject(cloned);
      // 取消cloned选择状态;
      // @ts-ignore;
      cloned.on('deselected', (e) => {
        //todo, 克隆的对象调整层级后，zindex会保留更新后的，但是原图层的zindex不会更新，需要在调整层级处手动更新
        //克隆对象会重新加入编组，所以编辑完后会在最顶层，需要重新调整层级
        const clonedObject = e.target;
        if (!clonedObject) {
          selectedGroup.removeWithUpdate(selectedObject);
        } else {
          var layerName = getCanvasObjLayerNameParams(clonedObject!, this.editor?.canvas.getObjects());
          (clonedObject as any).set({ [CustomKey.LayerNameCus]: layerName });

          const active = this.canvas.getActiveObject();
          const id = active ? active.id : '';
          if (!clonedObject.selectable || id.indexOf('ControlCircle') !== -1) {
            return;
          }

          selectedGroup?.addWithUpdate(clonedObject);
          clonedObject.set({
            _parentId: '',
            _cloneId: '',
          });

          const itemIndex = selectedGroup.getObjects().indexOf(selectedObject);

          clonedObject.moveTo(itemIndex);
          selectedGroup.removeWithUpdate(selectedObject);

          clonedObject.off('deselected');
          clonedObject.setCoords();

          // updateCanvasObj(clonedObject, this.editor?.canvas.getObjects());
        }

        let padding = 0;
        let width = selectedGroup.width;
        let height = selectedGroup.height;
        selectedGroup.getObjects().forEach((obj) => {
          if (obj.padding) {
            padding = Math.max(obj.padding, padding);
          }
        });
        selectedGroup.set({ width: width + padding * 2, height: height + padding * 2 });
        this.editor.doDisabled({ value: false });
        this.canvas.remove(cloned);
        // 操作群组内子元素结束 开启图层模块的渲染;
        eventBus.emit(LayerStatus.RenderStatus, RenderLayer.ON);
        eventBus.emit(EventNameCons.EventUpdateLayer);
        this.editor.startSaveHistory(true);

        this.editor.event?.emitEvent(EventNameCons.EventProjectChangeState, false);
      });
      this.canvas.renderAll();
    });
    // #endregion ;
  }
}

function getCanvasObjLayerNameParams(targetObj: fabric.Object, objects?: any[]): any {
  if (!objects) return null;
  var id = (targetObj as any).id;
  for (let i = 0; i < objects.length; i++) {
    const object = objects[i];
    if ((object as any).id === id) {
      return object[CustomKey.LayerNameCus];
    } else if ((object as any)._objects || (object as any).objects) {
      const foundObject = getCanvasObjLayerNameParams(targetObj, (object as any)._objects || (object as any).objects);
      if (foundObject) {
        return foundObject;
      }
    }
  }
  return null;
}

// utils;
function getGroupObject(opt: fabric.IEvent<MouseEvent>) {
  const pointer = this.canvas.getPointer(opt.e, true);
  const clickObject = this.canvas._searchPossibleTargets(opt.target?._objects, pointer);
  return clickObject;
}
