import { WorkspaceID } from "src/templates/2dEditor/cons/2dEditorCons";
import { CustomKey } from "src/templates/2dEditor/cons/2dEditorCons";

export default function initZIndex(object: any) {
  if (
    !this ||
    !object ||
    !object.id ||
    !!~object.id.indexOf(WorkspaceID.WorkspaceCavas)
  ) return;
  const allObject = this.canvas.getObjects().filter(item => !~item.id?.indexOf(WorkspaceID.WorkspaceCavas));
  const allObjectLength = allObject.length;
  object.set({
    [CustomKey.ZIndex]: allObjectLength,
  });
}
