import { fabric } from 'fabric';
type IEditor = Editor;
import Editor from 'src/templates/2dEditor/core';
import { FabricObjectType } from "src/templates/2dEditor/cons/2dEditorCons";
import initId from './extension/initId';
import initCustomKey from './extension/initCustomKey';
import initZIndex from './extension/initZIndex';
import dbclickHandler from './extension/dbclickHandler';
import anglehandler from './extension/angleHandler';

/**
 * init fabric object import stuff;
 */
export default class InitPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  static pluginName = 'InitPlugin';
  public isShiftPress: boolean = false;
  boundDbClickHandler = dbclickHandler.bind(this);

  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
    this.handleKeydown = this.handleKeydown.bind(this);
    this.handleKeyup = this.handleKeyup.bind(this);
    this.addHandler = this.addHandler.bind(this);
    this.addNoRecursionHandle = this.addNoRecursionHandle.bind(this);
    this.handleRotate = this.handleRotate.bind(this);
    this.init();
  }

  public init() {
    this.setupEventListeners();
    // document.addEventListener('keydown', this.handleKeydown.bind(this));
    // document.addEventListener('keyup', this.handleKeyup.bind(this));
    // this.canvas.on('object:added', (e) => {
    //   this.addHandler.bind(this)(e);
    //   this.addNoRecursionHandle.bind(this)(e);
    // });
    // this.canvas.on('object:rotating', this.handleRotate.bind(this));
    // this.canvas.on('mouse:dblclick', dbclickHandler.bind(this));
  }

  setupEventListeners() {
    this.removeEventListeners();
    document.addEventListener('keydown', this.handleKeydown);
    document.addEventListener('keyup', this.handleKeyup);
    this.canvas.on('object:added', this.addHandler);
    this.canvas.on('object:added', this.addNoRecursionHandle);
    this.canvas.on('object:rotating', this.handleRotate);
    this.canvas.on('mouse:dblclick', this.boundDbClickHandler);
  }

  removeEventListeners() {
    document.removeEventListener('keydown', this.handleKeydown);
    document.removeEventListener('keyup', this.handleKeyup);
    this.canvas.off('object:added', this.addHandler);
    this.canvas.off('object:added', this.addNoRecursionHandle);
    this.canvas.off('object:rotating', this.handleRotate);
    this.canvas.off('mouse:dblclick', this.boundDbClickHandler);
  }

  destroy() {
    console.log('pluginDestroy');
    this.removeEventListeners();
  }

  // add item in canvas handler; 递归;
  public addHandler(e: any) {
    const object = e.target ? e.target : e;

    if (
      object.type === FabricObjectType.Group
    ) {
      initId(object);
      initCustomKey(object);
      object.forEachObject((group: any) => this.addHandler(group));
    }
    // ;
    else {
      initId(object);
      initCustomKey(object);
    };
    this.canvas.requestRenderAll();
  }
  // add item in canvas handler; 不递归;
  public addNoRecursionHandle(e: any) {
    const object = e.target ? e.target : e;
    anglehandler(object);
    initZIndex.bind(this)(object);

    //初始化给纹理类型元素绑定约束事件
    if(object.textureType){
      object.setMoveLimit()
    }else if(object._isTextureGroup && object._objects[1]){
      object._objects[1].setMoveLimit();
    }
  }

  public handleKeydown(e: any) {
    if (e.key === 'Shift') this.isShiftPress = true;
  }

  public handleKeyup(e: any) {
    if (e.key === 'Shift') this.isShiftPress = false;
  }
  // handle object rotation;
  public handleRotate(e: any) {
    if (!this.isShiftPress) return;
    const object = e.target;
    let angle = object.angle;
    angle = Math.round(angle / 45) * 45;
    object.rotate(angle);
  }
}
