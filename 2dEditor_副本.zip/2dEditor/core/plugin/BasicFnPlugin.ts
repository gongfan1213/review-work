import { fabric } from 'fabric';
import { CustomKey, EDITOR_JSON_KEY, FabricObjectType, WorkspaceID } from '../../cons/2dEditorCons';
import { Textbox } from 'src/templates/2dEditor/core/plugin/TextPlugin/Textbox';
import { ArcText } from 'src/templates/2dEditor/core/plugin/ArcTextPlugin/ArcText';
import { Image } from 'src/templates/2dEditor/core/plugin/ImagePlugin/Image';
import { TextureImage } from 'src/templates/2dEditor/core/plugin/ImagePlugin/TextureImage';
import { randomString } from 'src/common/utils';

import Editor from '../core';
type IEditor = Editor;

class BasicFnPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  static pluginName = 'BasicFnPlugin';
  public gridlines: any;
  static apis = [
    'copy',
    'paste',
    'duplicate',
    'delete',
    'flipHorizontal',
    'flipVertical',
    'toTop',
    'toUp',
    'toBottom',
    'toDown',
    'alignLeft',
    'alignCenter',
    'alignRight',
    'alignTop',
    'alignMiddle',
    'alignBottom',
    'group',
    'ungroup',
    'lock',
    'unlock',
    'workspaceSendToBack',
    'getWorkspaces',
    'selectAllObject',
    'toggleGridLines',
    'cloneTextureGroup',
  ];
  static macosHotkeyName = {
    copy: 'command+c',
    paste: 'command+v',
    duplicate: 'command+d',
    delete: 'backspace',
    delete2: 'Delete',
    toTop: 'command+shift+]',
    toUp: 'command+]',
    toBottom: 'command+shift+[',
    toDown: 'command+[',
    alignLeft: 'command+shift+l',
    alignCenter: 'command+shift+c',
    alignRight: 'command+shift+r',
    alignTop: 'command+shift+t',
    alignMiddle: 'command+shift+m',
    alignBottom: 'command+shift+b',
    group: 'command+g',
    ungroup: 'command+shift+g',
    toggleGridLines: "command+'",
  };
  static windowHotkeyName = {
    copy: 'ctrl+c',
    paste: 'ctrl+v',
    duplicate: 'ctrl+d',
    delete: 'backspace',
    delete2: 'Delete',
    toTop: 'ctrl+shift+]',
    toUp: 'ctrl+]',
    toBottom: 'ctrl+shift+[',
    toDown: 'ctrl+[',
    alignLeft: 'ctrl+shift+l',
    alignCenter: 'ctrl+shift+c',
    alignRight: 'ctrl+shift+r',
    alignTop: 'ctrl+shift+t',
    alignMiddle: 'ctrl+shift+m',
    alignBottom: 'ctrl+shift+b',
    group: 'ctrl+g',
    ungroup: 'ctrl+shift+g',
    toggleGridLines: "ctrl+'",
  };

  public hotkeys: string[] = [
    BasicFnPlugin.macosHotkeyName.copy,
    BasicFnPlugin.macosHotkeyName.paste,
    BasicFnPlugin.macosHotkeyName.duplicate,
    BasicFnPlugin.macosHotkeyName.delete,
    BasicFnPlugin.macosHotkeyName.delete2,
    BasicFnPlugin.macosHotkeyName.toTop,
    BasicFnPlugin.macosHotkeyName.toUp,
    BasicFnPlugin.macosHotkeyName.toBottom,
    BasicFnPlugin.macosHotkeyName.toDown,
    BasicFnPlugin.macosHotkeyName.alignLeft,
    BasicFnPlugin.macosHotkeyName.alignCenter,
    BasicFnPlugin.macosHotkeyName.alignRight,
    BasicFnPlugin.macosHotkeyName.alignTop,
    BasicFnPlugin.macosHotkeyName.alignMiddle,
    BasicFnPlugin.macosHotkeyName.alignBottom,
    BasicFnPlugin.macosHotkeyName.group,
    BasicFnPlugin.macosHotkeyName.ungroup,
    BasicFnPlugin.macosHotkeyName.toggleGridLines,
    BasicFnPlugin.windowHotkeyName.copy,
    BasicFnPlugin.windowHotkeyName.paste,
    BasicFnPlugin.windowHotkeyName.duplicate,
    BasicFnPlugin.windowHotkeyName.delete,
    BasicFnPlugin.windowHotkeyName.delete2,
    BasicFnPlugin.windowHotkeyName.toTop,
    BasicFnPlugin.windowHotkeyName.toUp,
    BasicFnPlugin.windowHotkeyName.toBottom,
    BasicFnPlugin.windowHotkeyName.toDown,
    BasicFnPlugin.windowHotkeyName.alignLeft,
    BasicFnPlugin.windowHotkeyName.alignCenter,
    BasicFnPlugin.windowHotkeyName.alignRight,
    BasicFnPlugin.windowHotkeyName.alignTop,
    BasicFnPlugin.windowHotkeyName.alignMiddle,
    BasicFnPlugin.windowHotkeyName.alignBottom,
    BasicFnPlugin.windowHotkeyName.group,
    BasicFnPlugin.windowHotkeyName.ungroup,
    BasicFnPlugin.windowHotkeyName.toggleGridLines,
  ];
  private copyObject: null | fabric.ActiveSelection | fabric.Object | any;
  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
    this.copyObject = null;
  }

  // 复制元素
  async copy(paramsActiveObeject?: fabric.ActiveSelection | fabric.Object) {
    const activeKlass = paramsActiveObeject || this.canvas.getActiveObjects();
    if (activeKlass.length === 0) return;
    const tempCopyElement: any[] = [];
    this.canvas.getActiveObjects().forEach(async (item: fabric.Object | any) => {
      if (item.textureType) {
        const clonedObj = await this.cloneTexture(item);
        tempCopyElement.push(clonedObj);
      } else if (item.type === FabricObjectType.Group && item._isTextureGroup) {
        const group = await this.cloneTextureGroup(item);
        group.set({
          left: group.left + 10,
          top: group.top + 10,
        });
        tempCopyElement.push(group);
      } else {
        // 使用clone方式;
        item.clone(
          (copyElement: fabric.Object | any) => {
            this.canvas.discardActiveObject();
            copyElement.set({
              left: item.left + 20,
              top: item.top + 20,
              evented: true,
            });
            // 处理复制元素的自定义类型_type;
            !!copyElement && copyElement.setCoords();
            !!copyElement && tempCopyElement.push(copyElement);
          },
          ['key_prefix', 'importSource', 'fileType'],
        );
      }
    });
    this.copyObject = tempCopyElement;
    // #region backups 20240606;
    // const activeObject = paramsActiveObeject || this.canvas.getActiveObject();
    // if (!activeObject) return;
    // activeObject.clone((clonedObj: any) => {
    //   this.canvas.discardActiveObject();
    //   // TODO 需要处理自定义text和自定义image情况;
    //   this.copyObject = clonedObj;
    //   this.copyObject.setCoords();
    // },
    //   [
    //     'key_prefix',
    //     'importSource',
    //     'fileType',
    //   ]
    // )
    // #endregion ;
  }
  // 粘贴元素
  paste() {
    if (!this.copyObject || this.copyObject.length === 0) return;
    this.copyObject.forEach(async (item: fabric.Object) => {
      // image type;
      if (item.type === FabricObjectType.Image) {
        if (item.textureType) {
          this.canvas.add(item);
        } else {
          const imageObject = await Image.fromURL(item.src, {
            left: item.left,
            top: item.top,
            width: item.width,
            height: item.height,
            scaleX: item.scaleX,
            scaleY: item.scaleY,
            clipPath: item.clipPath,
            cropX: item.cropX,
            cropY: item.cropY,
            // ;
            key_prefix: item.key_prefix,
            importSource: item.importSource,
            fileType: item.fileType,
          });
          this.canvas.add(imageObject);
        }
      } else if (item.type === FabricObjectType.Group && item._isTextureGroup) {
        this.canvas.add(item);
      }
      // textbox type;
      else if (item.type === FabricObjectType.TextBox) {
        console.log('paste textbox;', item);
        const textboxObject = new Textbox(this.text, {
          ...item.toJSON(EDITOR_JSON_KEY),
        });
        delete textboxObject.path;
        this.canvas.add(textboxObject);
      }
      // arctext type;
      else if (item.type === FabricObjectType.Text) {
        console.log('paste text;', item);
        const arctextObject = new ArcText(this.text, {
          ...item.toJSON(EDITOR_JSON_KEY),
        });
        this.canvas.add(arctextObject);
      } else {
        this.canvas.add(item);
      }
    });
    this.canvas.renderAll();
    // #region backups 20240606 2;
    // const canvas = this.canvas;
    // const clipboard = this.copyObject
    // console.log('clipboard;', clipboard);
    // if (!clipboard) return;
    // clipboard.set({
    //   left: clipboard.left + 10,
    //   top: clipboard.top + 10,
    // });
    // canvas.discardActiveObject();
    // canvas.add(clipboard);
    // // if (clipboard.type === FabricObjectType.ActiveSelection) {
    // //   clipboard.forEachObject((obj: fabric.Object) => canvas.add(obj));
    // // }
    // // // ;
    // // else {
    // //   canvas.add(clipboard);
    // // }
    // #endregion ;
    // #region backups 20240606 1;
    // const canvas = this.canvas;
    // const clipboard = this.copyObject
    // if (!clipboard) return;
    // const copyposition = {
    //   left: clipboard.left + 10,
    //   top: clipboard.top + 10,
    // }
    // if (!!clipboard) {
    //   clipboard.set({
    //     left: copyposition.left,
    //     top: copyposition.top,
    //   });
    //   canvas.discardActiveObject();
    //   if (clipboard.type === FabricObjectType.ActiveSelection) {
    //     clipboard.forEachObject((obj: fabric.Object) => canvas.add(obj));
    //   }
    //   // ;
    //   else {
    //     canvas.add(clipboard);
    //   }
    // };
    // #endregion ;
  }
  // copy and paste ?
  async duplicate() {
    // #region backups 20240703;
    const activeObject = this.canvas.getActiveObject();
    if (!activeObject) return;

    if (activeObject.textureType) {
      const clonedObj = await this.cloneTexture(activeObject);
      this.canvas.add(clonedObj);
    } else if (activeObject.type === FabricObjectType.Group && activeObject._isTextureGroup) {
      const group = await this.cloneTextureGroup(activeObject);
      group.set({
        left: group.left + 10,
        top: group.top + 10,
      });
      this.canvas.add(group);
    } else {
      activeObject.clone(
        async (clonedObj: any) => {
          this.canvas.discardActiveObject();
          clonedObj.setCoords();
          if (!clonedObj) return;
          clonedObj.set({
            left: clonedObj.left + 10,
            top: clonedObj.top + 10,
          });
          this.canvas.add(clonedObj);
        },
        ['key_prefix', 'importSource', 'fileType'],
      );
    }
    // #endregion ;
  }
  // delete;
  delete() {
    const activeObject = this.canvas.getActiveObjects();
    if (!!activeObject) {
      if (activeObject.length > 1) {
        this.editor.stopSaveHistory();
      }
      activeObject.forEach((item) => {
        // 不允许删除正在去背/超分/裁剪 image;
        if (
          item.type === FabricObjectType.Image &&
          (!!item['rbLoading'] || !!item['upscaling'] || !!item['isCropping'])
        )
          return;
        this.canvas.remove(item);
      });
      if (activeObject.length > 1) {
        this.editor.startSaveHistory(true);
      }
      this.canvas.requestRenderAll();
      this.canvas.discardActiveObject();
    }
  }
  // flip horizontal;
  flipHorizontal() {
    const activeObject = this.canvas.getActiveObject();
    if (activeObject) {
      activeObject.set('flipX', !activeObject['flipX']).setCoords();
      this.canvas.requestRenderAll();
      this.canvas.fire('object:modified');
    }
  }
  // flip vertical;
  flipVertical() {
    const activeObject = this.canvas.getActiveObject();
    if (activeObject) {
      activeObject.set('flipY', !activeObject['flipY']).setCoords();
      this.canvas.requestRenderAll();
      this.canvas.fire('object:modified');
    }
  }
  // get workspace object;
  getWorkspaces(): fabric.Object[] {
    return this.canvas.getObjects().filter((item) => item.id?.includes(WorkspaceID.WorkspaceCavas));
  }
  // 始终置底 workspace;
  workspaceSendToBack() {
    const workspaces = this.getWorkspaces();
    // !!workspace && workspace.sendToBack();
    if (!!workspaces && workspaces.length > 0) {
      workspaces.forEach((item) => {
        item.sendToBack();
        if (item.id === WorkspaceID.WorkspaceBG) {
          item.bringToFront();
        }
      });
    }
  }
  // 层级向上一级;
  toUp() {
    this.editor.stopSaveHistory();
    const actives = this.canvas.getActiveObjects();
    const active = this.canvas.getActiveObject();
    if (actives && actives.length === 1) {
      active && active.bringForward();
    } else if (actives.length > 1) {
      this.group();
      this.toUp();
      this.ungroup();
    }
    this.canvas.renderAll();
    this.workspaceSendToBack();
    this.editor.startSaveHistory(true);
  }
  // 层级最高;
  toTop() {
    this.editor.stopSaveHistory();
    const actives = this.canvas.getActiveObjects();
    const active = this.canvas.getActiveObject();
    if (actives && actives.length === 1) {
      active && active.bringToFront();
    } else if (actives.length > 1) {
      actives.forEach((item) => this.canvas.bringToFront(item));
    }
    this.workspaceSendToBack();
    this.canvas.renderAll();
    this.editor.startSaveHistory(true);
  }
  // 层级向下一级;
  toDown() {
    this.editor.stopSaveHistory();
    const actives = this.canvas.getActiveObjects();
    const active = this.canvas.getActiveObject();
    if (actives && actives.length === 1) {
      active && active.sendBackwards();
    } else if (actives.length > 1) {
      actives.forEach((item) => {
        this.canvas.sendBackwards(item);
      });
    }
    this.canvas.renderAll();
    this.workspaceSendToBack();
    this.editor.startSaveHistory(true);
  }
  // 层级最低;
  toBottom(object?: fabric.Object) {
    this.editor.stopSaveHistory();
    if (!object) {
      const actives = this.canvas.getActiveObjects();
      const active = this.canvas.getActiveObject();
      if (actives && actives.length === 1) {
        active && active.sendToBack();
      } else if (actives.length > 1) {
        actives.forEach((item) => this.canvas.sendToBack(item));
      }
    }
    // ;
    else {
      this.canvas.sendToBack(object);
    }
    this.canvas.renderAll();
    this.workspaceSendToBack();
    this.editor.startSaveHistory(true);
  }
  // align left;
  alignLeft() {
    this.editor.stopSaveHistory();
    const activeKlass = this.canvas.getActiveObject();
    // 多选;
    if (activeKlass && activeKlass.type === FabricObjectType.ActiveSelection) {
      // const activeObjectLeft = -(activeKlass.width / 2);
      const activeObjectLeft = activeKlass.left;
      // const activeObjectTop = activeKlass.top;
      this.canvas.discardActiveObject();
      activeKlass.forEachObject((item: any) => {
        const klassTopLeftPoint = item.aCoords.tl;
        const klassTopRightPoint = item.aCoords.tr;
        const klassBottomLeftPoint = item.aCoords.bl;
        const klassBottomRightPoint = item.aCoords.br;
        const klassFarLeft = Math.min(
          klassTopLeftPoint.x,
          klassTopRightPoint.x,
          klassBottomLeftPoint.x,
          klassBottomRightPoint.x,
        );
        item.set({
          left: activeObjectLeft,
        });
        if (klassFarLeft !== klassTopLeftPoint.x) {
          const farLeftToTopLeft = klassTopLeftPoint.x - klassFarLeft;
          item.set('left', activeObjectLeft + farLeftToTopLeft);
        }
      });
    }
    // 单选;
    else {
      const klassTopLeftPoint = activeKlass.aCoords.tl;
      const klassTopRightPoint = activeKlass.aCoords.tr;
      const klassBottomLeftPoint = activeKlass.aCoords.bl;
      const klassBottomRightPoint = activeKlass.aCoords.br;
      const klassFarLeft = Math.min(
        klassTopLeftPoint.x,
        klassTopRightPoint.x,
        klassBottomLeftPoint.x,
        klassBottomRightPoint.x,
      );
      activeKlass.set('left', 0);
      if (klassFarLeft !== klassTopLeftPoint.x) {
        const farLeftToTopLeft = klassTopLeftPoint.x - klassFarLeft;
        activeKlass.set('left', farLeftToTopLeft);
      }
    }
    this.canvas.renderAll();
    this.editor.startSaveHistory(true);
  }
  // align center;
  alignCenter() {
    this.editor.stopSaveHistory();
    const activeKlass = this.canvas.getActiveObject() as fabric.ActiveSelection;
    // 多选;
    if (activeKlass && activeKlass.type === FabricObjectType.ActiveSelection) {
      const activeKlassTop = activeKlass.top as number;
      const activeKlassHeight = activeKlass.height as number;
      this.canvas.discardActiveObject();
      activeKlass.forEachObject((item: any) => {
        const klassTopLeftPoint = item.aCoords.tl;
        const klassTopRightPoint = item.aCoords.tr;
        const klassBottomLeftPoint = item.aCoords.bl;
        const klassBottomRightPoint = item.aCoords.br;
        const klassFarTop = Math.max(
          klassTopLeftPoint.y,
          klassTopRightPoint.y,
          klassBottomLeftPoint.y,
          klassBottomRightPoint.y,
        );
        const klassFarBottom = Math.min(
          klassTopLeftPoint.y,
          klassTopRightPoint.y,
          klassBottomLeftPoint.y,
          klassBottomRightPoint.y,
        );
        const setTop = activeKlassTop + activeKlassHeight / 2 + (klassFarBottom - klassFarTop) / 2;
        item.set('top', setTop);
      });
    }
    // 单选;
    else {
      activeKlass.viewportCenterH();
    }
    const zoom = this.canvas.getZoom();
    const tempPoint = { x: 0, y: 0 };
    this.editor.zoomToPoint(tempPoint, zoom);
    this.canvas.renderAll();
    this.editor.startSaveHistory(true);
  }
  // align right;
  alignRight() {
    this.editor.stopSaveHistory();
    const activeKlass = this.canvas.getActiveObject();
    const workspaces = this.getWorkspaces();
    const workspace = workspaces[0];
    // 多选;
    if (activeKlass && activeKlass.type === FabricObjectType.ActiveSelection) {
      const activeObjectLeft = activeKlass.left as number;
      this.canvas.discardActiveObject();
      activeKlass.forEachObject((item: any) => {
        const klassTopLeftPoint = item.aCoords.tl;
        const klassTopRightPoint = item.aCoords.tr;
        const klassBottomLeftPoint = item.aCoords.bl;
        const klassBottomRightPoint = item.aCoords.br;
        const klassFarRight = Math.max(
          klassTopLeftPoint.x,
          klassTopRightPoint.x,
          klassBottomLeftPoint.x,
          klassBottomRightPoint.x,
        );
        item.set({
          left: activeObjectLeft + activeKlass.width * activeKlass.scaleX - (klassFarRight - klassTopLeftPoint.x),
        });
      });
    }
    // 单选;
    else {
      const klassTopLeftPoint = activeKlass.aCoords.tl;
      const klassTopRightPoint = activeKlass.aCoords.tr;
      const klassBottomLeftPoint = activeKlass.aCoords.bl;
      const klassBottomRightPoint = activeKlass.aCoords.br;
      const klassFarRight = Math.max(
        klassTopLeftPoint.x,
        klassTopRightPoint.x,
        klassBottomLeftPoint.x,
        klassBottomRightPoint.x,
      );
      activeKlass.set({
        left: workspace.width * (workspace.scaleX || 1) - (klassFarRight - klassTopLeftPoint.x),
      });
    }
    this.canvas.renderAll();
    this.editor.startSaveHistory(true);
  }
  // align top;
  alignTop() {
    console.log('进入方法top');
    this.editor.stopSaveHistory();
    const activeKlass = this.canvas.getActiveObject();
    // 多选;
    if (activeKlass && activeKlass.type === 'activeSelection') {
      // const activeObjectTop = -(activeKlass.height / 2);
      const activeObjectTop = activeKlass.top;
      this.canvas.discardActiveObject();
      (activeKlass as fabric.ActiveSelection).forEachObject((item: any) => {
        const klassTopLeftPoint = item.aCoords.tl;
        const klassTopRightPoint = item.aCoords.tr;
        const klassBottomLeftPoint = item.aCoords.bl;
        const klassBottomRightPoint = item.aCoords.br;
        const klassFarTop = Math.min(
          klassTopLeftPoint.y,
          klassTopRightPoint.y,
          klassBottomLeftPoint.y,
          klassBottomRightPoint.y,
        );
        item.set({
          top: activeObjectTop + (klassTopLeftPoint.y - klassFarTop),
        });
        item.setCoords();
      });
    }
    // 单选;
    else {
      const klassTopLeftPoint = activeKlass.aCoords.tl;
      const klassTopRightPoint = activeKlass.aCoords.tr;
      const klassBottomLeftPoint = activeKlass.aCoords.bl;
      const klassBottomRightPoint = activeKlass.aCoords.br;
      const klassFarTop = Math.min(
        klassTopLeftPoint.y,
        klassTopRightPoint.y,
        klassBottomLeftPoint.y,
        klassBottomRightPoint.y,
      );
      activeKlass.set('top', 0);
      if (klassFarTop !== klassTopLeftPoint.y) {
        activeKlass.set({
          top: klassTopLeftPoint.y - klassFarTop,
        });
      }
    }
    this.canvas.renderAll();
    this.editor.startSaveHistory(true);
  }
  // align middle;
  alignMiddle() {
    this.editor.stopSaveHistory();
    const activeKlass = this.canvas.getActiveObject() as fabric.ActiveSelection;
    // 多选;
    if (activeKlass && activeKlass.type === FabricObjectType.ActiveSelection) {
      const activeKlassLeft = (activeKlass.left * activeKlass.scaleX) as number;
      const activeKlassWidth = (activeKlass.width * activeKlass.scaleX) as number;
      this.canvas.discardActiveObject();
      activeKlass.forEachObject((item: any) => {
        const itemAngle = item.angle;
        const itemWidth = item.width * item.scaleX;
        item.rotate(0);
        item.set({
          left: activeKlassLeft + activeKlassWidth / 2 - itemWidth / 2,
        });
        item.rotate(itemAngle);
      });
    }
    // 单选;
    else {
      activeKlass.viewportCenterV();
    }
    this.canvas.renderAll();
    this.editor.startSaveHistory(true);
  }
  // align bottom;
  alignBottom() {
    this.editor.stopSaveHistory();
    const activeKlass = this.canvas.getActiveObject();
    if (!activeKlass) return; // 如果没有选中的元素，则直接返回
    const workspaces = this.getWorkspaces();
    const workspace = workspaces[0];
    const workspaceHeight = workspace.height * (workspace.scaleY || 1);
    // 多选;
    if (activeKlass && activeKlass.type === FabricObjectType.ActiveSelection) {
      // const activeObjectTop = activeKlass.height / 2;
      const activeObjectHeight = activeKlass.height * activeKlass.scaleY;
      const activeObjectTop = activeKlass.top;
      this.canvas.discardActiveObject();
      activeKlass.forEachObject((item: any) => {
        const klassTopLeftPoint = item.aCoords.tl;
        const klassTopRightPoint = item.aCoords.tr;
        const klassBottomLeftPoint = item.aCoords.bl;
        const klassBottomRightPoint = item.aCoords.br;
        const klassFarBottom = Math.max(
          klassTopLeftPoint.y,
          klassTopRightPoint.y,
          klassBottomLeftPoint.y,
          klassBottomRightPoint.y,
        );
        item.set({
          top: activeObjectTop + activeObjectHeight - (klassFarBottom - klassTopLeftPoint.y),
        });
      });
    }
    // 单选;
    else {
      const klassTopLeftPoint = activeKlass?.aCoords?.tl;
      const klassTopRightPoint = activeKlass?.aCoords?.tr;
      const klassBottomLeftPoint = activeKlass?.aCoords?.bl;
      const klassBottomRightPoint = activeKlass?.aCoords?.br;
      const klassFarBottom = Math?.max(
        klassTopLeftPoint?.y,
        klassTopRightPoint?.y,
        klassBottomLeftPoint?.y,
        klassBottomRightPoint?.y,
      );
      activeKlass.set({
        top: workspaceHeight - (klassFarBottom - klassTopLeftPoint.y),
      });
    }
    this.canvas.renderAll();
    this.editor.startSaveHistory(true);
  }
  // ungroup;
  async ungroup(omitSaveHistory: boolean) {
    this.editor.stopSaveHistory();
    const activeKlass = this.canvas.getActiveObject() as fabric.Group;
    const activeKlasss = this.canvas.getActiveObjects();
    if (!activeKlass) return;
    if (activeKlasss.length > 1) return;
    if (activeKlasss[0].type !== FabricObjectType.Group) return;
    const groupObjects = activeKlass.getObjects();
    const hasGroup = groupObjects.some((item) => item.type === FabricObjectType.Group);
    const hasImage = groupObjects.some((item) => item.type === FabricObjectType.Image);
    const hasText = groupObjects.some(
      (item) =>
        item.type === FabricObjectType.TextI ||
        item.type === FabricObjectType.TextBox ||
        item.type === FabricObjectType.Text,
    );
    if (!hasGroup && !hasImage && !hasText) return;
    activeKlass.toActiveSelection();
    this.canvas.getObjects().forEach(async (item) => {
      item.setCoords();
      if (
        !!item.id &&
        !~item.id.indexOf(WorkspaceID.WorkspaceCavas) &&
        item.type === FabricObjectType.Image &&
        !item[CustomKey.CustomType]
      ) {
        const imageObject = await Image.fromURL(item.src, {
          originX: 'center',
          originY: 'center',
          left: item.calcTransformMatrix()[4],
          top: item.calcTransformMatrix()[5],
          scaleX: item.calcTransformMatrix()[0],
          scaleY: item.calcTransformMatrix()[3],
          width: item.width,
          height: item.height,
          clipPath: item.clipPath,
          cropX: item.cropX,
          cropY: item.cropY,
          // ;
          key_prefix: item.key_prefix,
          importSource: item.importSource,
          fileType: item.fileType,
        });
        this.canvas.remove(item);
        this.canvas.add(imageObject);
      }
    });
    this.canvas.renderAll();
    this.canvas.discardActiveObject();
    if (!omitSaveHistory) {
      this.editor.startSaveHistory(true);
    }
  }
  // group;
  group() {
    this.editor.stopSaveHistory();
    let activeKlass = this.canvas.getActiveObject() as fabric.ActiveSelection;
    const activeKlasss = this.canvas.getActiveObjects();
    if (!activeKlass) return;
    if (!activeKlasss || activeKlasss.length <= 1) return;

    //获取编组内最大的padding
    let padding = 0;
    let height = activeKlass.height;
    let width = activeKlass.width;
    activeKlasss.forEach((obj) => {
      if (obj.padding) {
        padding = Math.max(obj.padding, padding);
      }
    });
    try {
      activeKlass.toGroup();
      activeKlass.setCoords();
      activeKlass = this.canvas.getActiveObject() as fabric.ActiveSelection;
      activeKlass.set({ height: height + padding * 2, width: width + padding * 2 });
      this.canvas.setActiveObject(activeKlass);
      this.canvas.requestRenderAll();
    } catch (error) {
      console.log(error);
    }
    this.editor.startSaveHistory(true);
  }
  // 快捷键;
  hotkeyEvent(eventName: string, e: any) {
    e.preventDefault();
    const macosHotkeyName = BasicFnPlugin.macosHotkeyName;
    const windowHotkeyName = BasicFnPlugin.windowHotkeyName;
    const active = this.canvas.getActiveObject();

    if (e.type !== 'keydown' || (active && active[CustomKey.DisableRightClick])) return;
    // copy;
    if (eventName === macosHotkeyName.copy || eventName === windowHotkeyName.copy) {
      this.copy();
    }
    // paste;
    if (eventName === macosHotkeyName.paste || eventName === windowHotkeyName.paste) {
      this.paste();
    }
    // duplicate;
    if (eventName === macosHotkeyName.duplicate || eventName === windowHotkeyName.duplicate) {
      this.duplicate();
    }
    // console.log(macosHotkeyName, eventName, 'macosHotkeyNamemacosHotkeyNamemacosHotkeyName+++');
    // delete;
    if (
      eventName === macosHotkeyName.delete ||
      eventName === macosHotkeyName.delete2 ||
      eventName === windowHotkeyName.delete ||
      eventName === windowHotkeyName.delete2
    ) {
      this.delete();
    }
    // toTop;
    if (eventName === macosHotkeyName.toTop || eventName === windowHotkeyName.toTop) {
      this.toTop();
    }
    // toUp;
    if (eventName === macosHotkeyName.toUp || eventName === windowHotkeyName.toUp) {
      this.toUp();
    }
    // toBottom;
    if (eventName === macosHotkeyName.toBottom || eventName === windowHotkeyName.toBottom) {
      this.toBottom();
    }
    // toDown;
    if (eventName === macosHotkeyName.toDown || eventName === windowHotkeyName.toDown) {
      this.toDown();
    }
    // alignLeft;
    if (eventName === macosHotkeyName.alignLeft || eventName === windowHotkeyName.alignLeft) {
      this.alignLeft();
    }
    // alignCenter;
    if (eventName === macosHotkeyName.alignCenter || eventName === windowHotkeyName.alignCenter) {
      this.alignCenter();
    }
    // alignRight;
    if (eventName === macosHotkeyName.alignRight || eventName === windowHotkeyName.alignRight) {
      e.preventDefault(); // 禁用浏览器默认行为
      this.alignRight();
    }
    // alignTop;
    if (eventName === macosHotkeyName.alignTop || eventName === windowHotkeyName.alignTop) {
      console.log('ppppppppppppp---p--pp-p-pp--p-=', eventName);
      e.preventDefault(); // 禁用浏览器默认行为
      this.alignTop();
    }
    // alignMiddle;
    if (eventName === macosHotkeyName.alignMiddle || eventName === windowHotkeyName.alignMiddle) {
      e.preventDefault(); // 禁用浏览器默认行为
      this.alignMiddle();
    }
    // alignBottom;
    if (eventName === macosHotkeyName.alignBottom || eventName === windowHotkeyName.alignBottom) {
      e.preventDefault(); // 禁用浏览器默认行为
      this.alignBottom();
    }
    // group;
    if (eventName === macosHotkeyName.group || eventName === windowHotkeyName.group) {
      this.group();
    }
    // ungroup;
    if (eventName === macosHotkeyName.ungroup || eventName === windowHotkeyName.ungroup) {
      this.ungroup();
    }
    // toggleGridLines;
    if (eventName === macosHotkeyName.toggleGridLines || eventName === windowHotkeyName.toggleGridLines) {
      this.toggleGridLines();
    }
  }
  // lock;
  lock() {
    const activeObject = this.canvas.getActiveObjects();
    if (!!activeObject) {
      activeObject.map((item) => {
        item.selection = false;
        item.selectable = false;
        item.evented = false;
        item.hasBorders = false;
        item.hasControls = false;
        item.lockMovementX = true;
        item.lockMovementY = true;
        item.lockRotation = true;
        item.lockScalingX = true;
        item.lockScalingY = true;
        item.lockUnitScaling = true;
        item.lockScalingFlip = true;
        item[CustomKey.IsLock] = true;
      });

      this.canvas.requestRenderAll();
    }
  }
  // unlock;
  unlock() {
    const activeObject = this.canvas.getActiveObjects();
    if (!!activeObject) {
      activeObject.map((item) => {
        item.selection = true;
        item.selectable = true;
        item.evented = true;
        item.hasBorders = true;
        item.hasControls = item.textureType ? false : true;
        item.lockMovementX = false;
        item.lockMovementY = false;
        item.lockRotation = false;
        item.lockScalingX = false;
        item.lockScalingY = false;
        item.lockUnitScaling = false;
        item.lockScalingFlip = false;
        item[CustomKey.IsLock] = false;
      });
      this.canvas.requestRenderAll();
    }
  }
  // select all object;
  selectAllObject() {
    this.canvas.discardActiveObject();
    const allObject = this.canvas.getObjects().filter((object) => !~object.id.indexOf(WorkspaceID.WorkspaceCavas));
    if (!allObject || allObject.length === 0) return;
    if (allObject.length === 1) {
      this.canvas.setActiveObject(allObject[0]);
      this.canvas.renderAll();
    } else {
      const group = new fabric.Group(allObject);
      const selection = new fabric.ActiveSelection(allObject);
      allObject.forEach((item: fabric.Object) => this.canvas.remove(item));
      this.canvas.add(group);
      this.canvas.setActiveObject(selection);
      group.toActiveSelection();
      this.canvas.remove(group);
      this.canvas.remove(selection);
    }
  }

  removeKeyprefix(object: fabric.Object | any): fabric.Object {
    if (!object) return object;
    if (object.type === FabricObjectType.Group) {
      object.getObjects().forEach((item: any) => {
        this.removeKeyprefix(item);
      });
    } else {
      delete object['key_prefix'];
    }
    return object;
  }

  // 切换网格线
  gridSize: number = 10; // 网格大小，可以根据需要调整
  toggleGridLines() {
    console.log('获取当前画布数据', this?.canvas.getObjects());
    // 使用 some() 方法检查是否存在 id 为 'workspaceGridlinesID' 的网格线对象
    const hasGridLines = this?.canvas.getObjects().some((obj: any) => obj.id === 'workspaceGridlinesID');
    // 根据是否存在网格线调用相应的方法
    hasGridLines ? this.removeGridLines() : this.createGridLines();
    this.canvas.renderAll(); // 重新渲染画布以更新显示
  }

  createGridLines() {
    const nowCanvas = this?.canvas.getObjects()[0];
    // console.log("-----------width", nowCanvas);
    const width = nowCanvas?.width || 0;
    const height = nowCanvas?.height || 0;
    const thickLineStroke = 2; // 粗线的线条宽度
    const thinLineStroke = 1; // 细线的线条宽度
    const thickLineColor = '#000'; // 粗线的颜色
    const thinLineColor = '#ccc'; // 细线的颜色

    // 创建垂直线
    const vertical = [];
    for (let i = 0; i <= width; i += this.gridSize) {
      const isThickLine = i % (this.gridSize * 10) === 0; // 每隔两个gridSize绘制一条粗线
      const line = new fabric.Line([i, 0, i, height], {
        stroke: isThickLine ? thickLineColor : thinLineColor,
        strokeWidth: isThickLine ? thickLineStroke : thinLineStroke,
        selectable: false,
        evented: false,
      });
      vertical.push(line);
    }

    // 创建水平线
    const level = [];
    for (let i = 0; i <= height; i += this.gridSize) {
      const isThickLine = i % (this.gridSize * 10) === 0; // 每隔两个gridSize绘制一条粗线
      const line = new fabric.Line([0, i, width, i], {
        stroke: isThickLine ? thickLineColor : thinLineColor,
        strokeWidth: isThickLine ? thickLineStroke : thinLineStroke,
        selectable: false,
        evented: false,
      });
      level.push(line);
    }

    this.gridlines = new fabric.Group([...vertical, ...level], {
      // @ts-ignore
      id: 'workspaceGridlinesID', // 设置含有workspace字符串的id，可以使网格线不出现在历史记录中，当个辅助线使用
      selectable: false, // 确保网格线组不能被选中
      evented: false, // 确保网格线组不能响应事件，如鼠标点击
      lockMovementX: true, // 锁定X轴移动
      lockMovementY: true, // 锁定Y轴移动
      hasControls: false, // 不显示控制点
      hasBorders: false, // 不显示边框
    });
    this.canvas.add(this.gridlines);
    // this.canvas.renderAll(); // 重新渲染画布以更新显示
  }

  removeGridLines() {
    const obj = this.canvas.getObjects().find((item: any) => item.id === 'workspaceGridlinesID');
    if (obj) {
      this.canvas.remove(obj);
    }
    // this.canvas.renderAll(); // 重新渲染画布以更新显示
  }

  async cloneTexture(object: fabric.Object) {
    const option = {
      left: object.left,
      top: object.top,
      width: object.width,
      height: object.height,
      scaleX: object.scaleX,
      scaleY: object.scaleY,
      clipPath: object.clipPath,
      filters: object.filters,
      originX: object.originX,
      originY: object.originY,
    };

    const src = object.getSrc();
    const clonedObj = await TextureImage.fromURL(src, {
      ...object.toJSON(EDITOR_JSON_KEY),
      ...option,
    });

    clonedObj?.set({
      left: clonedObj.left + 10,
      top: clonedObj.top + 10,
      id: randomString(8),
    });

    return clonedObj;
  }

  async cloneTextureGroup(object: fabric.Object, base64?: string) {
    const originalObject = object._objects[0];
    const textureObject = object._objects[1];

    const originalSrc = originalObject.getSrc();

    const originalImage = await Image.fromURL(originalSrc, {
      ...originalObject.toJSON(EDITOR_JSON_KEY),
      left: originalObject.left,
      top: originalObject.top,
      width: originalObject.width,
      height: originalObject.height,
      scaleX: originalObject.scaleX,
      scaleY: originalObject.scaleY,
      clipPath: originalObject.clipPath,
      filters: originalObject.filters,
      originX: originalObject.originX,
      originY: originalObject.originY,
      id: randomString(8),
    });

    const textureSrc = base64 || textureObject.getSrc();

    const textureImage = await TextureImage.fromURL(textureSrc, {
      ...textureObject.toJSON(EDITOR_JSON_KEY),
      left: textureObject.left,
      top: textureObject.top,
      width: textureObject.width,
      height: textureObject.height,
      scaleX: textureObject.scaleX,
      scaleY: textureObject.scaleY,
      clipPath: textureObject.clipPath,
      filters: textureObject.filters,
      originX: textureObject.originX,
      originY: textureObject.originY,
      _original: originalImage,
      id: randomString(8),
    });

    const group = new fabric.Group([originalImage, textureImage], {
      ...object.toJSON(EDITOR_JSON_KEY),
      id: randomString(8),
    });
    return group;
  }
}

export default BasicFnPlugin;
