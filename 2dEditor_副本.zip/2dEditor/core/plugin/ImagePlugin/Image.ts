import { fabric } from "fabric";
import { ImageClipPathType } from './configs/images'
import { addCropImageInteractions, isolateObjectForEdit } from './extension/crop/cropping'
import { get_croppingControlSet, get_flipXCropControls, get_flipXYCropControls, get_flipYCropControls } from './extension/crop/cropControls'
import { createRBImage } from './extension/remover/removeBackground';
import { upscale } from './extension/upscale/upscale';
import { toast, editorToastShow, EditorToastType } from 'src/templates/2dEditor/components/Toast';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { ImageStatus } from 'src/templates/2dEditor/core/eventbus/types/image';
import { CustomKey, CustomObjectType, EventNameCons } from "src/templates/2dEditor/cons/2dEditorCons";
import { FabricObjectType, WorkspaceID } from 'src/templates/2dEditor/cons/2dEditorCons';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';

export class Image extends fabric.Image {
  public isCropping?: false
  public cropKey?: ImageClipPathType
  public cropPath?: string
  public cropSize?: number
  public cropMask?: fabric.Rect | null
  public originWidth?: number
  public originHeight?: number
  // RB;
  public rbLoading?: boolean
  public rbProcess?: number
  // Upscale;
  public upscalerResolution?: number
  public upscalerLoading?: boolean
  public upscalerProcess?: number
  
  constructor(element: any, options?: any) {
    super(element, { filters: [], ...options });
    this.init();
    this.on('mousedblclick', this.doubleClickHandler.bind(this));
    this.on('selected', this.selectHandler.bind(this));
    this.on('deselected', this.deselectedHandler.bind(this));
  }

  public get _isCropping() {
    return this.isCropping
  }
  public set _isCropping(value) {
    this.isCropping = value
    eventBus.emit(ImageStatus.Cropping, {
      value: value,
      target: this,
    });
    // cropping;
    if (this._isCropping) {
      eventBus.emit(EventNameCons.ChangeEditorSaveState, false);
      if (!this.cropMask) {
        // need to stop history saving;
        // draw dark mask;
        this.cropMask = new fabric.Rect({
          id: 'imageCropMask',
          width: 9999999,
          height: 9999999,
          fill: 'rgba(0,0,0,0.3)',
          left: -4999999,
          top: -4999999,
          evented: false,
          selectable: false,
        });
        this.canvas?.add(this.cropMask);
        this.canvas?.sendToBack(this.cropMask);
        const workspaces = this.canvas?.getObjects().filter((item) => item.id?.includes(WorkspaceID.WorkspaceCavas));;
        if (!!workspaces && workspaces.length > 0) workspaces.forEach(item => item.sendToBack());
      }
      // @ts-ignore
      this.set({
        borderOpacityWhenMoving: 1,
        borderColor: '#ffffff',
      });
      this.onMousedbclickEvent();
      this.canvas?.renderAll();
    }
    // crop end;
    else {
      if (!!this.cropMask) {
        this.canvas?.remove(this.cropMask);
        this.cropMask = null;
      };
      console.log('end image crop;', this.cropX, this.cropY);
      // @ts-ignore
      this.set({
        borderOpacityWhenMoving: 0,
        borderColor: '#60ce75',
      });
      this.canvas?.renderAll();
    };
    this.canvas?.fire('object:modified');
  }

  get _cropKey() {
    return this.cropKey
  }
  set _cropKey(key) {
    this.cropSize = Math.min(this.width, this.height)
    this.clipPath = undefined
    this.cropKey = key
    this.setCropCoords(this.cropSize, this.cropSize)
  }

  get _rbLoading() {
    return this.rbLoading;
  }
  set _rbLoading(value) {
    const { getTranslation } = useCustomTranslation();
    if (this.upscalerLoading) {
      editorToastShow({
        tips: getTranslation(TranslationsKeys.OPERATION_IN_PROGRESS),
        type: EditorToastType.warning,
      })
      return;
    }
    // ;
    this.rbLoading = value;
    if (!!value) {
      toast.current?.show();
      toast.current?.type('loading');
      toast.current?.tips(getTranslation(TranslationsKeys.REMOVING_BACKGROUND));
      createRBImage.bind(this)();
    }
    eventBus.emit(ImageStatus.RemovingBackground, {
      value: value,
      target: this,
    });
  }
  get _upscalerLoading() {
    return this.rbLoading;
  }
  set _upscalerLoading(value) {
    const { getTranslation } = useCustomTranslation();
    if (this.rbLoading) {
      editorToastShow({
        tips: getTranslation(TranslationsKeys.OPERATION_IN_PROGRESS),
        type: EditorToastType.warning,
      })
      return;
    }
    // ;
    this.upscalerLoading = value;
    if (!!value) {
      toast.current?.show();
      toast.current?.type('loading');
      toast.current?.tips(getTranslation(TranslationsKeys.IMAGE_UPSCALING));
    }
    eventBus.emit(ImageStatus.Upscaling, {
      value: value,
      target: this,
    });
  }
  get _upscalerResolution() {
    return this.upscalerResolution;
  }
  set _upscalerResolution(value) {
    const { getTranslation } = useCustomTranslation();
    this.upscalerResolution = value;
    if (value !== undefined && value !== null) {
      toast.current?.type('loading');
      toast.current?.tips(getTranslation(TranslationsKeys.IMAGE_UPSCALING_WITH_PERCENT, { percent: value.toString() }));
      upscale.bind(this)();
    }
  }
  get _upscalerProcess() {
    return this.upscalerProcess;
  }
  set _upscalerProcess(value) {
    const { getTranslation } = useCustomTranslation();
    this.upscalerProcess = value;
    if (!!value && this.upscalerLoading) {
      toast.current?.type('loading');
      toast.current?.tips(getTranslation(TranslationsKeys.IMAGE_UPSCALING_WITH_PERCENT, { percent: value.toString() }));
    }
  }
  public doubleClickHandler(e: any) {
    if (
      !this.canvas ||
      !e.target ||
      e.target !== this ||
      (e.target.lockMovementX && e.target.lockMovementY) ||
      e.target.rbLoading ||
      e.target.upscalerLoading
    ) return;
    //@ts-ignore;
    this.set({
      _isCropping: true,
      clipPath: undefined,
    });
    this.canvas.setActiveObject(this)
    this.canvas.requestRenderAll()
  }

  public selectHandler() {
    const { getTranslation } = useCustomTranslation();
    if (this.rbLoading) {
      toast.current?.show();
      toast.current?.type('loading');
      toast.current?.tips(getTranslation(TranslationsKeys.REMOVING_BACKGROUND));
    }
    if (this.upscalerLoading) {
      toast.current?.show();
      toast.current?.type('loading');
      toast.current?.tips(`Image Upscaling... ${this.upscalerProcess ? '(' + this.upscalerProcess + '%)' : ''}`);
    }
    if (!this.rbLoading && !this.upscalerLoading) {
      // toast.current?.hidden();
    }
  }

  public deselectedHandler() {
    if (this.rbLoading || this.upscalerLoading) {
      toast.current?.hidden();
    }
  }

  public onMousedbclickEvent() {
    const fabricCanvas = this.canvas;
    if (!fabricCanvas) return;
    fabricCanvas.defaultCursor = 'move';
    isolateObjectForEdit(this);
    this.lastEventTop = this.top;
    this.lastEventLeft = this.left;
    this.setupDragMatrix();
    this.bindCropModeHandlers();
    this.controls = get_croppingControlSet(this.cropKey as ImageClipPathType);
    if (this.flipX && !this.flipY) {
      this.controls = get_flipXCropControls(this.cropKey as ImageClipPathType);
    }
    if (this.flipY && !this.flipX) {
      this.controls = get_flipYCropControls(this.cropKey as ImageClipPathType);
    }
    if (this.flipX && this.flipY) {
      this.controls = get_flipXYCropControls(this.cropKey as ImageClipPathType);
    }
    if (this.scaleX != this.scaleY) {
      this.setControlsVisibility({ tlS: false, trS: false, blS: false, brS: false });
    }
    else {
      this.setControlsVisibility({ tlS: true, trS: true, blS: true, brS: true });
    }
    this.setCoords();
    fabricCanvas.centeredKey = null;
    fabricCanvas.altActionKey = null;
    fabricCanvas.selection = false;
  }

  // 初始化
  init() {
    // 缓存原字段 用于恢复以及从原图绘制新图
    // @ts-ignore;
    this[CustomKey.CustomType] = CustomObjectType.Image;
    this.originWidth = this.width;
    this.originHeight = this.height;
    // this.originSrc = this.getSrc()
  }

  setCropCoords(width: number, height: number) {
    if (!this.clipPath) {
      const originWidth = this.getOriginalElementWidth();
      const originHeight = this.getOriginalElementHeight();
      this.cropX = 0;
      this.cropY = 0;
      this.imageOriginSize = {
        width: originWidth,
        height: originHeight,
      }
      if (this.cropKey === ImageClipPathType.NineSixteen) {
        this.width = originHeight / 16 * 9
        this.height = originHeight
      } else if (this.cropKey === ImageClipPathType.SixteenNine) {
        this.width = originWidth
        this.height = originWidth / 16 * 9
      }
      // 1:1;
      else if (
        this.cropKey === ImageClipPathType.OneOne ||
        this.cropKey === ImageClipPathType.Heart ||
        this.cropKey === ImageClipPathType.Triangle ||
        this.cropKey === ImageClipPathType.Star
      ) {
        const minSide = Math.min(originWidth, originHeight);
        this.width = minSide
        this.height = minSide
      }
      else {
        this.width = originWidth
        this.height = originHeight
      }
    }
  }

  getOriginalElementWidth() {
    // @ts-ignore
    return this._originalElement ? this._originalElement.naturalWidth || this._originalElement.width : 0;
  }

  getOriginalElementHeight() {
    // @ts-ignore
    return this._originalElement ? this._originalElement.naturalHeight || this._originalElement.height : 0;
  }

  getElementWidth() {
    // @ts-ignore
    return this._element ? this._element.naturalWidth || this._element.width : 0;
  }

  getElementHeight() {
    // @ts-ignore
    return this._element ? this._element.naturalHeight || this._element.height : 0;
  }

  _getOriginalTransformedDimensions(options: any = {}) {
    const dimOptions = {
      scaleX: this.scaleX,
      scaleY: this.scaleY,
      skewX: this.skewX,
      skewY: this.skewY,
      width: this.getOriginalElementWidth(),
      height: this.getOriginalElementHeight(),
      strokeWidth: this.strokeWidth,
      ...options,
    };
    // stroke is applied before/after transformations are applied according to `strokeUniform`
    const strokeWidth = dimOptions.strokeWidth;
    let preScalingStrokeValue = strokeWidth, postScalingStrokeValue = 0;
    if (this.strokeUniform) {
      preScalingStrokeValue = 0;
      postScalingStrokeValue = strokeWidth;
    }
    const dimX = dimOptions.width + preScalingStrokeValue,
      dimY = dimOptions.height + preScalingStrokeValue,
      noSkew = dimOptions.skewX === 0 && dimOptions.skewY === 0;
    let finalDimensions;
    if (noSkew) {
      finalDimensions = new fabric.Point(dimX * dimOptions.scaleX, dimY * dimOptions.scaleY);
    }
    else {
      finalDimensions = fabric.util.sizeAfterTransform(dimX, dimY, dimOptions);
    }
    return finalDimensions.scalarAdd(postScalingStrokeValue);
  }

  _render(ctx: CanvasRenderingContext2D) {
    const width = this.width || 0;
    const height = this.height || 0;
    const elementToDraw = this._element;
    ctx.save();
    
    if (this._isCropping) {

      this._removeShadow(ctx); // main context
      ctx.globalAlpha = 0.2;
      const elWidth = this.getElementWidth();
      const elHeight = this.getElementHeight();
      const imageCopyX = -(this.cropX || 0) - width / 2;
      const imageCopyY = -(this.cropY || 0) - height / 2;
      ctx.drawImage(
        elementToDraw,
        imageCopyX,
        imageCopyY,
        elWidth,
        elHeight,
      );
      ctx.globalAlpha = 1;
      ctx.beginPath();
      ctx.strokeStyle = '#7356c9';
      ctx.lineWidth = 2;
      ctx.rect(imageCopyX, imageCopyY, elWidth, elHeight);
      ctx.stroke();
    }
    super._render(ctx);
    // @ts-ignore;
    this._drawCroppingPath(ctx);
    // @ts-ignore;
    // this._drawDarkLayer(ctx);
    ctx.restore();
  }

  // @ts-ignore;
  drawBorders(ctx: CanvasRenderingContext2D, options: any, styleOverride: any) {
    this._renderCroppingBorders(ctx);
    super.drawBorders(ctx, options, styleOverride);
  }

  _renderCroppingBorders(ctx: CanvasRenderingContext2D) {
    if (this._isCropping) {
      ctx.save();
      const multX = this.canvas?.viewportTransform[0] || 1;
      const multY = this.canvas?.viewportTransform[3] || 1;
      const scaling = this.getObjectScaling();
      if (this.flipX) {
        scaling.x *= -1;
      }
      if (this.flipY) {
        scaling.y *= -1;
      }
      const elWidth = (this.getElementWidth()) * multX * scaling.x;
      const elHeight = (this.getElementHeight()) * multY * scaling.y;
      const { width, height } = this;
      const imageCopyX = (-this.cropX - width / 2) * multX * scaling.x;
      const imageCopyY = (-this.cropY - height / 2) * multY * scaling.y;
      // ctx.strokeStyle = fabric.Object.prototype.borderColor;
      ctx.strokeStyle = '#ffffff';
      ctx.strokeRect(imageCopyX, imageCopyY, elWidth, elHeight);
      ctx.restore();
    }
  }

  static fromURL(url: string, options: any = {}) {
    return new Promise((resolve, reject) => {     
      fabric.util.loadImage(url, (imageItem) => {
        resolve(new this(imageItem, options));
      })
    });
  }
}

const imageDefaultValues = {
  type: FabricObjectType.Image,
  strokeWidth: 0,
  srcFromAttribute: false,
  minimumScaleTrigger: 0.5,
  cropX: 0,
  cropY: 0,
  imageSmoothing: true,
};

Object.assign(Image.prototype, {
  cacheProperties: [fabric.Object.cacheProperties, 'cropX', 'cropY'],
  ...imageDefaultValues,
  ...addCropImageInteractions()
})
