import ic_imgcut_free from 'src/assets/svg/imgcut_free.svg';
import ic_imgcut_11 from 'src/assets/svg/imgcut_11.svg';
import ic_imgcut_169 from 'src/assets/svg/imgcut_169.svg';
import ic_imgcut_916 from 'src/assets/svg/imgcut_916.svg';
import ic_imgcut_circle from 'src/assets/svg/imgcut_circle.svg';
import ic_imgcut_heart from 'src/assets/svg/imgcut_heart.svg';
import ic_imgcut_triangle from 'src/assets/svg/imgcut_triangle.svg';
import ic_imgcut_star from 'src/assets/svg/imgcut_star.svg';

export enum ImageClipPathType {
  Free = "free",
  OneOne = "oneone",
  NineSixteen = "ninesixteen",
  SixteenNine = "sixteenine",
  Ellipse = "ellipse",
  Triangle = "triangle",
  Star = "star",
  Heart = "heart",
}
export enum ImageEqualType {
  Equal,
  NineSixteen,
  SixteenNine,
}
export const ImageClipPaths = [
  {
    id: ImageClipPathType.Free,
    name: 'Free',
    icon: ic_imgcut_free,
    createPath: squarePath
  },
  {
    name: '1:1',
    id: ImageClipPathType.OneOne,
    icon: ic_imgcut_11,
    createPath: squarePath
  },
  {
    name: '9:16',
    id: ImageClipPathType.NineSixteen,
    icon: ic_imgcut_916,
    createPath: squarePath,
  },
  {
    name: '16:9',
    id: ImageClipPathType.SixteenNine,
    icon: ic_imgcut_169,
    createPath: squarePath
  },
  {
    name: 'Ellipse',
    id: ImageClipPathType.Ellipse,
    icon: ic_imgcut_circle,
    createPath: ellipsePath,
  },
  {
    name: 'Triangle',
    id: ImageClipPathType.Triangle,
    icon: ic_imgcut_triangle,
    createPath: trianglePath,
  },
  {
    name: 'Star',
    id: ImageClipPathType.Star,
    icon: ic_imgcut_star,
    createPath: starPath,
  },
  {
    name: 'Heart',
    id: ImageClipPathType.Heart,
    icon: ic_imgcut_heart,
    createPath: heartPath
  },
];

// 绘制矩形;
function squarePath(width: number, height: number) {
  return `M ${-width / 2} ${-height / 2} L ${width / 2} ${-height / 2} L ${width / 2} ${height / 2} L ${width / 2} ${height / 2} L ${-width / 2} ${height / 2} Z`
}

// 绘制星形;
function starPath(width: number, height: number) {
  const scaleNumber = width >= height ? height / 927 : width / 927;
  return `
  M${285 * scaleNumber},${440 * scaleNumber} 
  L${-1 * scaleNumber},${289 * scaleNumber} 
  L${-288 * scaleNumber},${440 * scaleNumber} 
  L${-233 * scaleNumber},${120 * scaleNumber} 
  L${-465 * scaleNumber},${-105 * scaleNumber} 
  L${-144 * scaleNumber},${-152 * scaleNumber} 
  L${-1 * scaleNumber},${-442 * scaleNumber} 
  L${142 * scaleNumber},${-152 * scaleNumber} 
  L${462 * scaleNumber},${-105 * scaleNumber} 
  L${230 * scaleNumber},${120 * scaleNumber} 
  L${285 * scaleNumber},${440 * scaleNumber} 
  Z`;
}

// 绘制心形;
function heartPath(width: number, height: number) {
  // M 0,20 A 20,20 0,0,1 40,20 A 20,20 0,0,1 80,20 Q 80,50 40,80 Q 0,50 0,20 z; 宽高80px的心形;
  /* M 0,2.5 
     A 2.5,2.5 0,0,1 5,2.5 
     A 2.5,2.5 0,0,1 10,2.5 
     Q 10,6.25 5,10 
     Q 0,6.25 0,2.5 
     z; 宽高10px的心形; 
  */
  //  M 0 , 2.5 A 2.5,2.5 0,0,1 5, 2.5 A 2.5,2.5 0,0,1 10,2.5 Q 10,6.25 5,10 Q 0, 6.25 0,2.5 z
  //  M -5,-2.5 A 2.5,2.5 0 0,1 0,-2.5 A 2.5,2.5 0 0,1 5,-2.5 Q 5 ,1.25 0,5  Q -5,1.25 -5,-2.5 z
  const scaleNumber = width / 10;
  const halfWidth = width / 2;
  const mPoint = `M ${0 - halfWidth},${2.5 * scaleNumber - halfWidth}`;
  const aPoint1 = `A ${2.5 * scaleNumber},${2.5 * scaleNumber} 0,0,1 ${5 * scaleNumber - halfWidth},${2.5 * scaleNumber - halfWidth}`;
  const aPoint2 = `A ${2.5 * scaleNumber},${2.5 * scaleNumber} 0,0,1 ${10 * scaleNumber - halfWidth},${2.5 * scaleNumber - halfWidth}`;
  const qPoint1 = `Q ${10 * scaleNumber - halfWidth},${6.25 * scaleNumber - halfWidth} ${5 * scaleNumber - halfWidth},${10 * scaleNumber - halfWidth}`;
  const qPoint2 = `Q ${0 - halfWidth},${6.25 * scaleNumber - halfWidth} ${0 - halfWidth},${2.5 * scaleNumber - halfWidth}`;
  return `${mPoint} ${aPoint1} ${aPoint2} ${qPoint1} ${qPoint2} z`;
}

// 绘制三角形;
function trianglePath(width: number, height: number) {
  return `M 0 ${-height / 2} L ${-width / 2} ${height / 2} L ${width / 2} ${height / 2} Z`
}

// 绘制椭圆;
function ellipsePath(width: number, height: number) {
  const rx = width / 2;
  const ry = height / 2;
  const path = [
    `M 0 ${-ry}`,
    `A ${rx} ${ry} 0 1 0 0 ${ry}`,
    `A ${rx} ${ry} 0 1 0 0 ${-ry}`,
    `Z`
  ].join(' ');
  return path;
}