import React from 'react';
import { Image } from './Image';
import { getImageSize, getAABBSizeAfterRotation } from './utils/image';
import { fabric } from 'fabric';
import Editor from '../../core';
import { ImportSource } from './types/common';
import { CustomKey, WorkspaceID, TextureType } from 'src/templates/2dEditor/cons/2dEditorCons';
import { executeCrop } from './extension/crop/cropping';
import { TextureImage } from './TextureImage';
import eventBus from '../../eventbus';
import { ImageStatus } from 'src/templates/2dEditor/core/eventbus/types/image';
import { EventNameCons } from '../../../cons/2dEditorCons';

type IEditor = Editor;

interface AddImageOptions extends fabric.IImageOptions {
  importSource?: ImportSource;
  fileType?: string;
  key_prefix?: string;
  grayscale?: string;
  textureType?: TextureType;
  [CustomKey.skip_upload]?: boolean;
}

class AddImagePlugin extends React.Component {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  private loadingElements: any[] = [];
  static pluginName = 'AddImagePlugin';
  static apis = [
    'addImage',
    'addSvgFile',
    'addTextureImage',
    'handleTexture',
    'addLoadingElement',
    'removeLoadingElement',
    'getLoadingElements',
  ];
  public hotkeys: string[] = ['enter'];
  constructor(canvas: fabric.Canvas, editor: IEditor) {
    const superOption = {};
    super(superOption);
    this.canvas = canvas;
    this.editor = editor;
  }

  hotkeyEvent(eventName: string, e: any) {
    const activeObject = this.canvas.getActiveObject();
    executeCrop(e, activeObject);
  }

  addImage(url: string, options?: AddImageOptions, callback?: Function) {
    getImageSize(url).then(async ({ width, height }) => {
      let centerPoint = { left: 0, top: 0 };
      const workspace = this.canvas.getObjects().find((item) => item.id?.includes(WorkspaceID.WorkspaceCavas));
      const workspaceWidth = workspace?.width * workspace?.scaleX;
      const workspaceHeight = workspace?.height * workspace?.scaleY;
      const canvasWidth = this.canvas.width as number;
      const canvasHeight = this.canvas.height as number;
      if (!!workspace) {
        //@ts-ignore;
        centerPoint = { left: (workspaceWidth / 2) as number, top: (workspaceHeight / 2) as number };
        //@ts-ignore;
        if (width > workspaceWidth || height > workspaceHeight) {
          //@ts-ignore;
          const scale = Math.min(workspaceWidth / width, workspaceHeight / height);
          width *= scale;
          height *= scale;
        }
      } else {
        centerPoint = { left: (this.canvas.width as number) / 2, top: (this.canvas.height as number) / 2 };
        if (width > canvasWidth || height > canvasHeight) {
          const scale = Math.min(canvasWidth / width, canvasHeight / height);
          width *= scale;
          height *= scale;
        }
      }

      const imageOptions = {
        left: centerPoint.left - width / 2,
        top: centerPoint.top - height / 2,
        _rbLoading: false,
        _upscalerLoading: false,
        _upscalerProcess: 0,
        crossOrigin: 'anonymous',
        ...options,
      };
      const imageElement = (await Image.fromURL(url, imageOptions)) as fabric.Image;
      if (!options || (!options.width && !options.height)) {
        imageElement.scaleToWidth(width);
        imageElement.scaleToHeight(height);
      }
      this.canvas.add(imageElement);
      this.canvas.setActiveObject(imageElement);
      this.canvas.renderAll();
      if (callback) {
        callback(imageElement);
      }
    });
  }

  addTextureImage(url: string, options: AddImageOptions, active?: any, callback?: Function) {
    getImageSize(url).then(async ({ width, height }) => {
      const transform = this.getTransformByWorkspace(width, height, options?.textureType, options?.isPublish);
      const imageOptions = {
        originX: 'center',
        originY: 'center',
        left: transform.left,
        top: transform.top,
        _rbLoading: false,
        _upscalerLoading: false,
        _upscalerProcess: 0,
        borderOpacityWhenMoving: 0,
        crossOrigin: 'anonymous',
        ...options,
        hasControls: false,
      };

      let imageElement = (await TextureImage.fromURL(url, imageOptions)) as TextureImage;

      if (!options || (!options.width && !options.height)) {
        imageElement.scaleToWidth(transform.width);
        imageElement.scaleToHeight(transform.height);
      }

      const activeObject = active || (this.canvas?.getActiveObject() as any);

      //高清图和灰度图加载完前暂停历史保存
      this.editor?.stopSaveHistory();
      eventBus?.emit(ImageStatus.Editing, {
        value: true,
        target: this,
      });

      if (
        activeObject &&
        ((activeObject.type === 'image' &&
          !activeObject.textureType &&
          imageElement.textureType !== TextureType.RELIEF) ||
          activeObject._isTextureGroup)
      ) {
        this.handleTextureGroup(imageElement, activeObject);
      } else {
        this.handleTexture(imageElement);
      }
      this.canvas.renderAll();

      if (callback) {
        callback(imageElement);
      }
    });
  }

  getTransformByWorkspace(width: number, height: number, textureType: string, isPublish: boolean) {
    let centerPoint = { left: 0, top: 0 };
    const workspace = this.canvas.getObjects().find((item) => item.id?.includes(WorkspaceID.WorkspaceCavas));
    //@ts-ignore
    const workspaceWidth = workspace?.width * workspace?.scaleX;
    //@ts-ignore
    const workspaceHeight = workspace?.height * workspace?.scaleY;
    const canvasWidth = this.canvas.width as number;
    const canvasHeight = this.canvas.height as number;
    if (!!workspace) {
      //@ts-ignore;
      centerPoint = { left: (workspaceWidth / 2) as number, top: (workspaceHeight / 2) as number };
      //@ts-ignore;
      const scale =
        isPublish && textureType !== TextureType.RELIEF
          ? Math.max(workspaceWidth / width, workspaceHeight / height)
          : Math.min(workspaceWidth / width, workspaceHeight / height);
      width *= scale;
      height *= scale;
    } else {
      centerPoint = { left: (this.canvas.width as number) / 2, top: (this.canvas.height as number) / 2 };
      if (width > canvasWidth || height > canvasHeight) {
        const scale =
          isPublish && textureType !== TextureType.RELIEF
            ? Math.max(canvasWidth / width, canvasHeight / height)
            : Math.min(canvasWidth / width, canvasHeight / height);
        width *= scale;
        height *= scale;
      }
    }
    return { width, height, left: centerPoint.left, top: centerPoint.top };
  }

  handleTextureGroup(imageElement: any, activeObject: any) {
    let originalImage;
    //给已有的图层分组添加纹理，先解组
    if (activeObject._isTextureGroup) {
      const originalObject = activeObject._objects[0];
      originalObject.set({ opacity: 1 });
      const textureObject = activeObject._objects[1];
      originalImage = originalObject;
      this.editor?.ungroup(true);
      this.canvas.remove(textureObject);
    } else {
      originalImage = activeObject;
    }

    //考虑旋转造成left的取值有问题，先回正
    const angle = originalImage.angle;
    originalImage.rotate(0);

    const originalLeft =
      originalImage.originX === 'left'
        ? originalImage.left + (originalImage.width * originalImage.scaleX) / 2
        : originalImage.left;
    const originalTop =
      originalImage.originY === 'top'
        ? originalImage.top + (originalImage.height * originalImage.scaleY) / 2
        : originalImage.top;

    //todo, 判断originX，调整复制、去背、加载等和originalImage相关的功能
    originalImage.set({
      originX: 'center',
      originY: 'center',
      left: originalLeft,
      top: originalTop,
    });
    originalImage.rotate(angle);

    //考虑旋转后取值有问题，求AABB包围盒的宽
    const { newWidth, newHeight } = getAABBSizeAfterRotation(originalImage);
    const scaleX = newWidth / (imageElement.width * imageElement.scaleX);
    const scaleY = newHeight / (imageElement.height * imageElement.scaleY);
    const scale = Math.max(scaleX, scaleY);
    originalImage.clone((cloned) => {
      //设置纹理图层的属性, 让纹理图和原图显示大小一致，并把原图赋值给clipPath
      imageElement.set({
        left: originalLeft,
        top: originalTop,
        scaleX: imageElement.scaleX * scale,
        scaleY: imageElement.scaleY * scale,
        opacity: imageElement.textureType === TextureType.GLOSS ? 0.5 : 1,
        clipPath: cloned,
      });

      //设置clipPath的属性，调整在纹理图层坐标系中的大小和位置
      const clonedScaleX = imageElement.width / cloned.width;
      const clonedScaleY = imageElement.height / cloned.height;
      const clonedScale = Math.min(clonedScaleX, clonedScaleY);

      //因为旋转原因缩放，对clipPath造成的影响，需要回正
      //TODO，旋转后仍然有问题
      const scaleX = (originalImage.width * originalImage.scaleX) / newWidth;
      //@ts-ignore
      const scaleY = (originalImage.height * originalImage.scaleY) / newHeight;

      cloned.set({
        left: 0,
        top: 0,
        originX: 'center',
        originY: 'center',
        scaleX: clonedScale * scaleX,
        scaleY: clonedScale * scaleY,
      });

      //两个图层编组，编组位置和原图一致
      const group = new fabric.Group([originalImage, imageElement], {
        originX: originalImage.originX,
        originY: originalImage.originY,
        left: originalLeft,
        top: originalTop,
        _isTextureGroup: true,
      });

      originalImage.set({
        opacity: imageElement.textureType === TextureType.GLOSS ? 1 : 0,
      });

      imageElement.set({
        _original: originalImage,
        _disableRightClick: true,
      });

      this.canvas?.remove(originalImage);
      this.canvas?.add(group);
      this.canvas.setActiveObject(group);
    });
    //
    // const {newScaleX, newScaleY} = imageElement.rotateScaleComponents(originalImage.scaleX, originalImage.scaleY, angle)
  }

  handleTexture(imageElement: any) {
    imageElement.set({
      isCanvasTexture: true,
    });
    const objects = this.canvas?.getObjects();

    //移除已有的纹理图层
    if (imageElement.isPublish && imageElement.textureType !== TextureType.RELIEF) {
      objects.forEach((obj: any) => {
        if (
          obj.id !== imageElement.id &&
          obj.isCanvasTexture &&
          obj.textureType !== TextureType.RELIEF &&
          obj.isPublish
        ) {
          this.canvas.remove(obj);
        }
      });
    }

    this.canvas.add(imageElement);
    this.canvas.setActiveObject(imageElement);

    if (imageElement.textureType === TextureType.GLOSS) {
      //光油纹理
      // this.editor?.toTop();
      // eventBus?.emit(EventNameCons.EventToTop, imageElement);
      imageElement.set({
        opacity: 0.5,
      });
      //变成半透明
    } else if (imageElement.textureType === TextureType.CMYK && imageElement.isPublish) {
      //彩色纹理
      this.editor?.toBottom();
      eventBus?.emit(EventNameCons.EventToBottom, imageElement);
    }

    if (imageElement.isPublish && imageElement.textureType !== TextureType.RELIEF) {
      this.editor?.lock();
      eventBus?.emit(EventNameCons.EventHanlederLock, imageElement, true);
    }
  }

  addSvgFile(svgFile: string) {
    if (!svgFile) throw new Error('file is undefined');
    if (!this.editor) return;
    fabric.loadSVGFromURL(svgFile, (objects: fabric.Object[], options: fabric.IToSVGOptions) => {
      const item = fabric.util.groupSVGElements(objects, {
        ...options,
      });
      // 添加自定义属性
      var isSvgValue = true;
      (item as any).set({
        isSVG: isSvgValue,
      });
      item.toObject = (function (toObject) {
        return function (this: fabric.Object) {
          return fabric.util.object.extend(toObject.call(this), {
            isSVG: isSvgValue,
          });
        };
      })(item.toObject);

      let centerPoint = { left: 0, top: 0 };
      const workspace = this.canvas.getObjects().find((item) => item.id?.includes(WorkspaceID.WorkspaceCavas));
      const workspaceWidth = workspace?.width * workspace?.scaleX;
      const workspaceHeight = workspace?.height * workspace?.scaleY;
      const canvasWidth = this.canvas.width as number;
      const canvasHeight = this.canvas.height as number;
      let width = item.width as number;
      let height = item.height as number;

      if (!!workspace) {
        //@ts-ignore;
        centerPoint = { left: (workspaceWidth / 2) as number, top: (workspaceHeight / 2) as number };
        if (width > workspaceWidth || height > workspaceHeight) {
          const scale = Math.min(workspaceWidth / width, workspaceHeight / height);
          width *= scale;
          height *= scale;
        }
      } else {
        centerPoint = { left: (this.canvas.width as number) / 2, top: (this.canvas.height as number) / 2 };
        if (width > canvasWidth || height > canvasHeight) {
          const scale = Math.min(canvasWidth / width, canvasHeight / height);
          width *= scale;
          height *= scale;
        }
      }

      item.set({ left: centerPoint.left - width / 2, top: centerPoint.top - height / 2 });
      item.scaleToWidth(width);
      item.scaleToHeight(height);
      this.canvas.add(item);
      this.canvas.setActiveObject(item);
      this.canvas.renderAll();
    });
  }

  //添加loading元素
  addLoadingElement(element: any) {
    this.loadingElements.push(element);
  }

  //移除loading元素
  removeLoadingElement(element: any) {
    this.loadingElements = this.loadingElements.filter((item) => item.id !== element.id);
  }

  //获取loading元素
  getLoadingElements() {
    return this.loadingElements;
  }
}

export default AddImagePlugin;
