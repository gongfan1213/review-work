import { createRemoveBGImage, getRemoveBGImage, endRemoveBGImage } from "src/templates/2dEditor/service/2dEditService";
import { toast } from "src/templates/2dEditor/components/Toast";
import { Image } from "../../Image";
import { CustomKey, EventNameCons } from "src/templates/2dEditor/cons/2dEditorCons";
import eventBus from "src/templates/2dEditor/core/eventbus";

const maxPostCount = 100;
export async function createRBImage(this: any) {
  if (!this) return;
  let rbCount = 0;
  const image_key_prefix = this.key_prefix;
  const response = await createRemoveBGImage({
    project_id: !!this._projectId ? this._projectId : '',
    canvas_id: !!this._canvas_id ? this._canvas_id : '',
    src_image: image_key_prefix,
  });
  if (response?.data?.task_id) {
    getRBImage.call(this, response.data.task_id, rbCount);
  } else {
    showToast('error', 'Processing Failed.Your Credits Will Not Be Deducted.');
    this.set({ '_rbLoading': false });
  }
}

// get scaler image;
async function getRBImage(this: any, task_id: string, rbCount: number) {
  if (!task_id) return;
  if (rbCount >= maxPostCount) {
    endRBImage.call(this, task_id);
    return;
  }
  const response = await getRemoveBGImage({ task_id });
  if (response?.data) {
    const { status, progress, result_list } = response.data;
    switch (status) {
      case 0:
      case 1:
        if (this['_rbProcess'] !== null && this['_rbProcess'] !== undefined && this['_rbProcess'] <= 80) {
          this.set({ '_rbProcess': this['_rbProcess'] + 20 });
        } else if (progress === 100) {
          this.set({ '_rbProcess': progress });
        }
        setTimeout(() => getRBImage.call(this, task_id, rbCount + 1), 3000); 
        break;
      case 2:
        handleRBImageCompletion.call(this, result_list);
        break;
      default:
        handleRBImageError.call(this);
        break;
    }
  } else {
    handleRBImageError.call(this);
  }
}

// end scaler image;
async function endRBImage(this: any, task_id: string) {
  await endRemoveBGImage({ task_id });
  showToast('error', 'Processing Failed.Your Credits Will Not Be Deducted.');
  this.set({ '_rbLoading': false });
}

// utils;
const getBase64Image = (imgUrl: string) => {
  return fetch(imgUrl)
    .then(response => response.blob())
    .then(blob => new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    }))
    .catch(error => {
      console.error('upacale error;', error);
      throw error;
    });
}

async function handleRBImageCompletion(this: any, result_list: any[]) {
  const { file_name, download_url } = result_list[0];
  const resultBase64 = await getBase64Image(download_url);
  const resultImage = await Image.fromURL(resultBase64, {
    key_prefix: file_name,
    fileType: file_name.split('.')[1] || 'png',
  });
  const originImageWidth = this.width * this.scaleX;
  const originImageHeight = this.height * this.scaleY;
  const resultImageScaleX = originImageWidth / resultImage.width;
  const resultImageScaleY = originImageHeight / resultImage.height;
  resultImage.set({
    left: this.left,
    top: this.top,
    width: this.width,
    height: this.height,
    // scaleX: resultImageScaleX,
    // scaleY: resultImageScaleY,
    scaleX: this.scaleX,
    scaleY: this.scaleY,
    cropX: this.cropX,
    cropY: this.cropY,
    clipPath: this.clipPath,
    [CustomKey.ZIndex]: this[CustomKey.ZIndex],
    [CustomKey.LayerName]: this[CustomKey.LayerName]
  });
  // this.set('id', UnSaveId.Id);
  this.set({ '_rbLoading': false });

  console.log('resultImage;', resultImage);
  eventBus.emit(EventNameCons.ChangeEditorSaveState, false);
  this.canvas.add(resultImage);
  this.canvas.setActiveObject(resultImage);
  this.canvas.remove(this);
  eventBus.emit(EventNameCons.ChangeEditorSaveState, true);
  showToast('success', 'Remove Background Success.');
}

function handleRBImageError(this: any) {
  this.set({ '_rbLoading': false });
  showToast('error', 'Processing Failed.Your Credits Will Not Be Deducted.');
}

function showToast(type: string, message: string) {
  toast.current?.show();
  toast.current?.type(type);
  toast.current?.tips(message);
}
