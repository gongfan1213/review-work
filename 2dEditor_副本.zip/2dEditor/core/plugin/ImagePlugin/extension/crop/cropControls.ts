import { fabric } from 'fabric';
import {
  cropFromTop,
  cropFromTopFlig,
  cropFromLeft,
  cropFromLeftFlig,
  cropFromRight,
  cropFromRightFlig,
  cropFromBottom,
  cropFromBottomFlig,
  cropFromBottomLeft,
  cropFromBottomRight,
  cropFromTopLeft,
  cropFromTopRight,
  imageCornerBL,
  imageCornerBR,
  imageCornerTL,
  imageCornerTR,
  scaleEquallyCropBL,
  scaleEquallyCropBR,
  scaleEquallyCropTL,
  scaleEquallyCropTR,
  scaleEquallyCropTLFlig,
  scaleEquallyCropBRFlig,
  scaleEquallyCropTRFlig,
  scaleEquallyCropBLFlig
} from './cropControlsHandlers';
import {
  renderCropCorner,
  renderWithShadows
} from './cropControlsRenders';

// const { scaleCursorStyleHandler, renderCircleControl } = fabric.controlsUtils;
const { scaleCursorStyleHandler } = fabric.controlsUtils;

const renderCropTL = renderWithShadows(2, 2, renderCropCorner); // top left
const renderCropTR = renderWithShadows(-2, 2, renderCropCorner); // top right
const renderCropBL = renderWithShadows(2, -2, renderCropCorner); // bottom left
const renderCropBR = renderWithShadows(-2, -2, renderCropCorner); // bottom right
const renderCropMT = () => { } // middle, no render
const renderCropMB = () => { } // middle, no render
const renderCropML = () => { } // middle, no render
const renderCropMR = () => { } // middle, no render

// @ts-ignore;
function renderCircleControl(ctx, left, top, styleOverride, fabricObject) {
  styleOverride = styleOverride || {};
  var xSize = this.sizeX || styleOverride.cornerSize || fabricObject.cornerSize,
    ySize = this.sizeY || styleOverride.cornerSize || fabricObject.cornerSize,
    transparentCorners = typeof styleOverride.transparentCorners !== 'undefined' ? styleOverride.transparentCorners : fabricObject.transparentCorners,
    methodName = transparentCorners ? 'stroke' : 'fill',
    stroke = !transparentCorners && (styleOverride.cornerStrokeColor || fabricObject.cornerStrokeColor),
    myLeft = left,
    myTop = top,
    size;
  ctx.save();
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = '#ffffff';
  if (xSize > ySize) {
    size = xSize;
    ctx.scale(1.0, ySize / xSize);
    myTop = top * xSize / ySize;
  } else if (ySize > xSize) {
    size = ySize;
    ctx.scale(xSize / ySize, 1.0);
    myLeft = left * ySize / xSize;
  } else {
    size = xSize;
  }
  // this is still wrong
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = '#ffffff';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
  ctx.shadowBlur = 5;
  ctx.beginPath();
  ctx.arc(myLeft, myTop, size / 1.5, 0, 2 * Math.PI, false);
  ctx[methodName]();
  // if (stroke) ctx.stroke();
  ctx.restore();
}

export const get_croppingControlSet = () => {
  return {
    tlS: new fabric.Control({
      x: -0.5, y: -0.5,
      actionName: 'tlS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerTL,
      actionHandler: scaleEquallyCropTL,
      render: renderCircleControl,
    }),
    trS: new fabric.Control({
      x: 0.5, y: -0.5,
      actionName: 'trS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerTR,
      actionHandler: scaleEquallyCropTR,
      render: renderCircleControl,
    }),
    blS: new fabric.Control({
      x: -0.5, y: 0.5,
      actionName: 'blS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerBL,
      actionHandler: scaleEquallyCropBL,
      render: renderCircleControl,
    }),
    brS: new fabric.Control({
      x: 0.5, y: 0.5,
      actionName: 'brS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerBR,
      actionHandler: scaleEquallyCropBR,
      render: renderCircleControl,
    }),
    cropLeft: new fabric.Control({
      x: -0.5, y: 0,
      actionName: 'cropLeft',
      render: renderCropML,
      // actionHandler: cropFromLeft,
      actionHandler: (eventData, transform, x, y) => cropFromLeft(eventData, transform, x, y),
      angle: 90,
    }),
    cropRight: new fabric.Control({
      x: 0.5, y: 0,
      actionName: 'cropRight',
      render: renderCropMR,
      // actionHandler: cropFromRight,
      actionHandler: (eventData, transform, x, y) => cropFromRight(eventData, transform, x, y),
      angle: 90,
    }),
    cropTop: new fabric.Control({
      x: 0, y: -0.5,
      actionName: 'cropTop',
      render: renderCropMT,
      actionHandler: (eventData, transform, x, y) => cropFromTop(eventData, transform, x, y),
    }),
    cropBottom: new fabric.Control({
      x: 0, y: 0.5,
      actionName: 'cropBottom',
      render: renderCropMB,
      // actionHandler: cropFromBottom,
      actionHandler: (eventData, transform, x, y) => cropFromBottom(eventData, transform, x, y)
    }),
    cropCornerTL: new fabric.Control({
      x: -0.5, y: -0.5,
      actionName: 'cropCornerTL',
      render: renderCropTL,
      actionHandler: cropFromTopLeft,
    }),
    cropCornerBL: new fabric.Control({
      x: -0.5, y: 0.5,
      actionName: 'cropCornerBL',
      render: renderCropBL,
      angle: 270,
      actionHandler: cropFromBottomLeft,
    }),
    cropCornerBR: new fabric.Control({
      x: 0.5, y: 0.5,
      actionName: 'cropCornerBR',
      render: renderCropBR,
      angle: 180,
      actionHandler: cropFromBottomRight,
    }),
    cropCornerTR: new fabric.Control({
      x: 0.5, y: -0.5,
      actionName: 'cropCornerTR',
      render: renderCropTR,
      angle: 90,
      actionHandler: cropFromTopRight,
    }),
  };
}
export const get_flipXCropControls = () => {
  return {
    tlS: new fabric.Control({
      x: -0.5,
      y: -0.5,
      actionName: 'tlS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerTR,
      actionHandler: scaleEquallyCropTR,
      render: renderCircleControl,
    }),
    trS: new fabric.Control({
      x: 0.5,
      y: -0.5,
      actionName: 'trS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerTL,
      actionHandler: scaleEquallyCropTL,
      render: renderCircleControl,
    }),
    blS: new fabric.Control({
      x: -0.5,
      y: 0.5,
      actionName: 'blS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerBR,
      actionHandler: scaleEquallyCropBR,
      render: renderCircleControl,
    }),
    brS: new fabric.Control({
      x: 0.5,
      y: 0.5,
      actionName: 'brS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerBL,
      actionHandler: scaleEquallyCropBL,
      render: renderCircleControl,
    }),
    cropLeft: new fabric.Control({
      x: -0.5, y: 0,
      actionName: 'cropLeft',
      render: renderCropML,
      // actionHandler: cropFromLeftFlig,
      actionHandler: (eventData, transform, x, y) => cropFromLeftFlig(eventData, transform, x, y),
      angle: 90,
    }),
    cropRight: new fabric.Control({
      x: 0.5, y: 0,
      actionName: 'cropRight',
      render: renderCropMR,
      // actionHandler: cropFromRightFlig,
      actionHandler: (eventData, transform, x, y) => cropFromRightFlig(eventData, transform, x, y),
      angle: 90,
    }),
    cropTop: new fabric.Control({
      x: 0, y: -0.5,
      actionName: 'cropTop',
      render: renderCropMT,
      // actionHandler: cropFromTop,
      actionHandler: (eventData, transform, x, y) => cropFromTop(eventData, transform, x, y),
    }),
    cropBottom: new fabric.Control({
      x: 0, y: 0.5,
      actionName: 'cropBottom',
      render: renderCropMB,
      // actionHandler: cropFromBottom,
      actionHandler: (eventData, transform, x, y) => cropFromBottom(eventData, transform, x, y),
    }),
    cropCornerTL: new fabric.Control({
      x: -0.5, y: -0.5,
      actionName: 'cropCornerTL',
      render: renderCropTL,
      actionHandler: cropFromTopLeft,
    }),
    cropCornerBL: new fabric.Control({
      x: -0.5, y: 0.5,
      actionName: 'cropCornerBL',
      render: renderCropBL,
      angle: 270,
      actionHandler: cropFromBottomLeft,
    }),
    cropCornerBR: new fabric.Control({
      x: 0.5, y: 0.5,
      actionName: 'cropCornerBR',
      render: renderCropBR,
      angle: 180,
      actionHandler: cropFromBottomRight,
    }),
    cropCornerTR: new fabric.Control({
      x: 0.5, y: -0.5,
      actionName: 'cropCornerTR',
      render: renderCropTR,
      angle: 90,
      actionHandler: cropFromTopRight,
    }),
  };
}
export const get_flipYCropControls = () => {
  return {
    tlS: new fabric.Control({
      x: -0.5,
      y: -0.5,
      actionName: 'tlS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerBL,
      actionHandler: scaleEquallyCropBL,
      render: renderCircleControl,
    }),
    trS: new fabric.Control({
      x: 0.5,
      y: -0.5,
      actionName: 'trS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerBR,
      actionHandler: scaleEquallyCropBR,
      render: renderCircleControl,
    }),
    blS: new fabric.Control({
      x: -0.5,
      y: 0.5,
      actionName: 'blS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerTL,
      actionHandler: scaleEquallyCropTL,
      render: renderCircleControl,
    }),
    brS: new fabric.Control({
      x: 0.5,
      y: 0.5,
      actionName: 'brS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerTR,
      actionHandler: scaleEquallyCropTR,
      render: renderCircleControl,
    }),
    cropLeft: new fabric.Control({
      x: -0.5, y: 0,
      actionName: 'cropLeft',
      render: renderCropML,
      // actionHandler: cropFromLeft,
      actionHandler: (eventData, transform, x, y) => cropFromLeft(eventData, transform, x, y),
      angle: 90,
    }),
    cropRight: new fabric.Control({
      x: 0.5, y: 0,
      actionName: 'cropRight',
      render: renderCropMR,
      // actionHandler: cropFromRight,
      actionHandler: (eventData, transform, x, y) => cropFromRight(eventData, transform, x, y),
      angle: 90,
    }),
    cropTop: new fabric.Control({
      x: 0, y: -0.5,
      actionName: 'cropTop',
      render: renderCropMT,
      // actionHandler: cropFromTopFlig,
      actionHandler: (eventData, transform, x, y) => cropFromTopFlig(eventData, transform, x, y),
    }),
    cropBottom: new fabric.Control({
      x: 0, y: 0.5,
      actionName: 'cropBottom',
      render: renderCropMB,
      // actionHandler: cropFromBottomFlig,
      actionHandler: (eventData, transform, x, y) => cropFromBottomFlig(eventData, transform, x, y),
    }),
    cropCornerTL: new fabric.Control({
      x: -0.5, y: -0.5,
      actionName: 'cropCornerTL',
      render: renderCropTL,
      actionHandler: cropFromTopLeft,
    }),
    cropCornerBL: new fabric.Control({
      x: -0.5, y: 0.5,
      actionName: 'cropCornerBL',
      render: renderCropBL,
      angle: 270,
      actionHandler: cropFromBottomLeft,
    }),
    cropCornerBR: new fabric.Control({
      x: 0.5, y: 0.5,
      actionName: 'cropCornerBR',
      render: renderCropBR,
      angle: 180,
      actionHandler: cropFromBottomRight,
    }),
    cropCornerTR: new fabric.Control({
      x: 0.5, y: -0.5,
      actionName: 'cropCornerTR',
      render: renderCropTR,
      angle: 90,
      actionHandler: cropFromTopRight,
    }),
  };
}
export const get_flipXYCropControls = () => {
  return {
    tlS: new fabric.Control({
      x: -0.5,
      y: -0.5,
      actionName: 'tlS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerBR,
      actionHandler: scaleEquallyCropTLFlig,
      render: renderCircleControl,
    }),
    trS: new fabric.Control({
      x: 0.5,
      y: -0.5,
      actionName: 'trS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerBL,
      actionHandler: scaleEquallyCropBLFlig,
      render: renderCircleControl,
    }),
    blS: new fabric.Control({
      x: -0.5,
      y: 0.5,
      actionName: 'blS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerTR,
      actionHandler: scaleEquallyCropTRFlig,
      render: renderCircleControl,
    }),
    brS: new fabric.Control({
      x: 0.5,
      y: 0.5,
      actionName: 'brS',
      cursorStyleHandler: scaleCursorStyleHandler,
      positionHandler: imageCornerTL,
      actionHandler: scaleEquallyCropBRFlig,
      render: renderCircleControl,
    }),
    cropLeft: new fabric.Control({
      x: -0.5, y: 0,
      actionName: 'cropLeft',
      render: renderCropML,
      // actionHandler: cropFromLeftFlig,
      actionHandler: (eventData, transform, x, y) => cropFromLeftFlig(eventData, transform, x, y),
      angle: 90,
    }),
    cropRight: new fabric.Control({
      x: 0.5, y: 0,
      actionName: 'cropRight',
      render: renderCropMR,
      // actionHandler: cropFromRightFlig,
      actionHandler: (eventData, transform, x, y) => cropFromRightFlig(eventData, transform, x, y),
      angle: 90,
    }),
    cropTop: new fabric.Control({
      x: 0, y: -0.5,
      actionName: 'cropTop',
      render: renderCropMT,
      // actionHandler: cropFromTopFlig,
      actionHandler: (eventData, transform, x, y) => cropFromTopFlig(eventData, transform, x, y),
    }),
    cropBottom: new fabric.Control({
      x: 0, y: 0.5,
      actionName: 'cropBottom',
      render: renderCropMB,
      // actionHandler: cropFromBottomFlig,
      actionHandler: (eventData, transform, x, y) => cropFromBottomFlig(eventData, transform, x, y),
    }),
    cropCornerTL: new fabric.Control({
      x: -0.5, y: -0.5,
      actionName: 'cropCornerTL',
      render: renderCropTL,
      actionHandler: cropFromTopLeft,
    }),
    cropCornerBL: new fabric.Control({
      x: -0.5, y: 0.5,
      actionName: 'cropCornerBL',
      render: renderCropBL,
      angle: 270,
      actionHandler: cropFromBottomLeft,
    }),
    cropCornerBR: new fabric.Control({
      x: 0.5, y: 0.5,
      actionName: 'cropCornerBR',
      render: renderCropBR,
      angle: 180,
      actionHandler: cropFromBottomRight,
    }),
    cropCornerTR: new fabric.Control({
      x: 0.5, y: -0.5,
      actionName: 'cropCornerTR',
      render: renderCropTR,
      angle: 90,
      actionHandler: cropFromTopRight,
    }),
  };
}
