import { createUpscalerImage, getUpscalerImage, endUpscalerImage } from "src/templates/2dEditor/service/2dEditService";
import { toast } from "src/templates/2dEditor/components/Toast";
import { Image } from "../../Image";
import { getScaleSize } from '../../utils/image';
import useCustomTranslation from 'src/hooks/useCustomTranslation';
import { TranslationsKeys } from 'src/templates/2dEditor/utils/TranslationsKeys';
enum UpscalerType {
  HD = 2,
  UltraHD = 4,
}
let upscaleCount = 0;
const maxUpscale = 100;
const maxHDMultiple = 4;
const maxUltraHDMultiple = 8;
const HD_area = 2560 * 1440; // 3686400; // 2k;
const ultraHD_area = 3860 * 2160; // 8337600; // 4k;
export async function upscale() {
  if (!this) return;
  upscaleCount = 0;
  const image_key_prefix = this.key_prefix;
  let out_scale: number;
  const { getTranslation } = useCustomTranslation();
  // 2k;
  if (this.upscalerResolution === UpscalerType.HD) {
    const translateArea = getScaleSize(this.width, this.height, HD_area);
    // 2k或4倍;
    if (translateArea.width / this.width > maxHDMultiple) {
      out_scale = maxHDMultiple;
    } else {
      out_scale = translateArea.width / this.width;
    }
  }
  // 4k;
  else if (this.upscalerResolution === UpscalerType.UltraHD) {
    const translateArea = getScaleSize(this.width, this.height, ultraHD_area);
    // 4k或8倍;
    if (translateArea.width / this.width > maxUltraHDMultiple) {
      out_scale = maxUltraHDMultiple;
    } else {
      out_scale = translateArea.width / this.width;
    }
  }
  // ?;
  else {
    return;
  }
  if (!out_scale) return;
  const response = await createUpscalerImage({
    src_image: image_key_prefix,
    out_scale,
    project_id: !!this._projectId ? this._projectId : '',
    canvas_id: !!this._canvas_id ? this._canvas_id : '',
  });
  if (!!response && !!response.data && !!response.data.task_id) {
    // upscaling(this, response.data.task_id);
    upscaling.bind(this)(response.data.task_id);
  } else {
    toast.current?.show();
    toast.current?.type('error');
    toast.current?.tips(getTranslation(TranslationsKeys.PROCESSING_FAILED_NO_CREDITS_DEDUCTED));
    this.set({ '_upscalerLoading': false });
  }
}

// get scaler image;
async function upscaling(task_id: string) {
  if (!task_id) return;
  if (upscaleCount >= maxUpscale) {
    endUpscale.bind(this)(task_id);
    return;
  }
  const { getTranslation } = useCustomTranslation();
  const response = await getUpscalerImage({ task_id });
  if (!!response && !!response.data) {
    // 开始处理&处理中;
    if (response.data.status === 0 || response.data.status === 1) {
      // @ts-ignore;
      if (this['_upscalerProcess'] !== null && this['_upscalerProcess'] !== undefined && this['_upscalerProcess'] <= 80) {
        this.set({ '_upscalerProcess': this['_upscalerProcess'] + 20 });
      } else if (response.data.progress === 100) {
        this.set({ ['_upscalerProcess']: response.data.progress });
      }
      upscaleCount++;
      setTimeout(() => upscaling.bind(this)(task_id), 3000); 
    }
    // 已完成;
    else if (response.data.status === 2) {
      const file_name = response.data.result_list[0].file_name;
      const download_url = response.data.result_list[0].download_url;
      getBase64Image(download_url).then(async (resultBase64: any) => {
        const resultImage = await Image.fromURL(resultBase64, {
          key_prefix: file_name,
          fileType: !!file_name.split('.')[1] ? file_name.split('.')[1] : 'png',
        });
        const originImageWidth = this!.width * this!.scaleX;
        const originImageHeight = this!.height * this!.scaleY;
        const resultImageScaleX = originImageWidth / resultImage.width;
        const resultImageScaleY = originImageHeight / resultImage.height;
        

        resultImage.set({
          left: this!.left,
          top: this!.top,
          scaleX: resultImageScaleX,
          scaleY: resultImageScaleY,
          cropX: this!.cropX,
          cropY: this!.cropY,
          cropPath: this!.clipPath,
        });
        this.set({ '_upscalerLoading': false });
        this.canvas.add(resultImage);
        this.canvas.setActiveObject(resultImage);
        this.canvas.remove(this);
        toast.current?.show();
        toast.current?.type('success');
        toast.current?.tips(getTranslation(TranslationsKeys.UPSCALED_RESULT_REPLACED));
      }).catch((error) => {
        console.log(error);
        this.set({ '_upscalerLoading': false });
        toast.current?.show();
        toast.current?.type('error');
        toast.current?.tips(getTranslation(TranslationsKeys.PROCESSING_FAILED_NO_CREDITS_DEDUCTED));
      });
    }
    // 处理失败;
    else if (response.data.status === 3) {
      this.set({ '_upscalerLoading': false });
      toast.current?.show();
      toast.current?.type('error');
      toast.current?.tips(getTranslation(TranslationsKeys.PROCESSING_FAILED_NO_CREDITS_DEDUCTED));
    }
    // 已取消;
    else if (response.data.status === 4) {
      this.set({ '_upscalerLoading': false });
      toast.current?.show();
      toast.current?.type('error');
      toast.current?.tips(getTranslation(TranslationsKeys.PROCESSING_FAILED_NO_CREDITS_DEDUCTED));
    }
  }
  // request failed;
  else {
    this.set({ '_upscalerLoading': false });
    toast.current?.show();
    toast.current?.type('error');
    toast.current?.tips(getTranslation(TranslationsKeys.PROCESSING_FAILED_NO_CREDITS_DEDUCTED));
  }
}

// end scaler image;
async function endUpscale(task_id: string) {
  const response = await endUpscalerImage({ task_id });
  const { getTranslation } = useCustomTranslation();
  this.set({ '_upscalerLoading': false });
  toast.current?.show();
  toast.current?.type('error');
  toast.current?.tips(getTranslation(TranslationsKeys.PROCESSING_FAILED_NO_CREDITS_DEDUCTED));
}

// utils;
const getBase64Image = (imgUrl: string) => {
  return new Promise((resolve, reject) => {
    fetch(imgUrl)
      .then(response => response.blob())
      .then(blob => {
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          resolve(reader.result)
        }
      })
      .catch(error => {
        console.log('upacale error;', error);
        reject();
      });
  })
}