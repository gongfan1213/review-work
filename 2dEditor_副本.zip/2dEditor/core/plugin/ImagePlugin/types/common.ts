import { GetUpTokenFileTypeEnum } from "src/services"

export type ExportTypes = 'image' | 'pdf' | 'psd' | 'json' | 'svg' | ''
export type PoolType = 'editor' | 'template' | 'material' | 'text' | 'image' | 'illustration' | 'layer' | 'code' | 'toolkit' | 'help'
export type SystemFont = {
  label: string
  value: string
}

export interface PathPoint {
  X: number
  Y: number
}

export interface StrokeItem {
  stroke: string
  strokeWidth: number
}

export enum ImportSource {
  Local = GetUpTokenFileTypeEnum.Edit2dLocal,
  Cloud = GetUpTokenFileTypeEnum.Edit2dCloud,
}