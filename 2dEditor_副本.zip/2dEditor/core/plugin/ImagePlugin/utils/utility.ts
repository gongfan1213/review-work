import { fabric } from 'fabric';

export function containsPoint(pointer: { x: number; y: number }, points: Array<{ x: number; y: number }>) {
  let inside = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i, i += 1) {
    const xi = points[i].x;
    const yi = points[i].y;
    const xj = points[j].x;
    const yj = points[j].y;
    const intersect = ((yi > pointer.y) !== (yj > pointer.y)) && (pointer.x < (xj - xi) * (pointer.y - yi) / (yj - yi) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}


export const getActionFromCorner = (alreadySelected: boolean, corner: string, e: any, target: any) => {
  if (!corner || !alreadySelected) return 'drag';
  const control = target.controls[corner];
  return control.getActionName(e, control, target);
};

export function isTransformCentered(transform: any) {
  return transform.originX === 'center' && transform.originY === 'center';
}

export function invertOrigin(origin: any) {
  return -resolveOrigin(origin) + 0.5;
}

export const isLocked = (
  target: any,
  lockingKey:
    | 'lockMovementX'
    | 'lockMovementY'
    | 'lockRotation'
    | 'lockScalingX'
    | 'lockScalingY'
    | 'lockSkewingX'
    | 'lockSkewingY'
    | 'lockScalingFlip'
) => target[lockingKey];


const originOffset = {
  left: -0.5,
  top: -0.5,
  center: 0,
  bottom: 0.5,
  right: 0.5,
};
/**
 * Resolves origin value relative to center
 * @private
 * @param {TOriginX | TOriginY} originValue originX / originY
 * @returns number
 */
const resolveOrigin = (originValue: number): number => typeof originValue === 'string' ? originOffset[originValue] : originValue - 0.5;


export function normalizePoint(target: any, point: any, originX: any, originY: any,): any {
  // const center = target.getRelativeCenterPoint(),
  const center = target.getCenterPoint(),
    p = typeof originX !== 'undefined' && typeof originY !== 'undefined'
      ? target.translateToGivenOrigin(center, 'center', 'center', originX, originY)
      : new fabric.Point(target.left, target.top),
    // p2 = target.angle
    //   ? point.rotate(-fabric.util.degreesToRadians(target.angle), center)
    //   : point;
    p2 = target.angle
      ? fabric.util.rotatePoint(point, center, fabric.util.degreesToRadians(-target.angle))
      : point;
  return p2.subtract(p);
}