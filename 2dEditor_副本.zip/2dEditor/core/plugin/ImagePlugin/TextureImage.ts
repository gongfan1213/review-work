import { Image } from './Image';
import { fabric } from 'fabric';
import { WorkspaceID, CustomKey, TextureType, EDITOR_JSON_KEY } from 'src/templates/2dEditor/cons/2dEditorCons';
import eventBus from '../../eventbus';
import { ImageStatus } from 'src/templates/2dEditor/core/eventbus/types/image';

export class TextureImage extends Image {
  public textureType: TextureType;
  public grayscale: string;
  public thickness: number;
  public contrast: number;
  public invert: boolean;
  public isCanvasTexture?: boolean;
  public isPublish: boolean;
  // public editor?: Editor;
  // public canvas?: fabric.Canvas;
  public id: any;
  public _type: string = 'textureImage';

  private _clipPath?: fabric.Image;
  private _original?: fabric.Image;
  private _isControls: boolean = false;
  private _scaleX?: number;
  private _scaleY?: number;
  private _left?: number;
  private _top?: number;
  private _angle?: number;
  constructor(element: any, options?: any) {
    super(element, options);
    this.textureType = options.textureType;
    this.grayscale = options.grayscale;
    this.thickness = options.thickness || (this.textureType === TextureType.RELIEF ? 5 : 2);
    this.contrast = options.contrast || 1;
    this.invert = options.invert;
    this.isPublish = options.isPublish;
  }

  setMoveLimit() {
    this.on('moving', (e) => {
      if (this.isCanvasTexture) {
        if (!this.isPublish || this.textureType === TextureType.RELIEF) return;
        const workspace = this.canvas?.getObjects().find((item) => item.id?.includes(WorkspaceID.WorkspaceCavas));
        //@ts-ignore;
        const workspaceWidth = workspace?.width * workspace?.scaleX;
        //@ts-ignore;
        const workspaceHeight = workspace?.height * workspace?.scaleY;
        //@ts-ignore;
        if (this.left - (this.width * this.scaleX) / 2 > 0) {
          //@ts-ignore;
          this.left = (this.width * this.scaleX) / 2;
        }
        //@ts-ignore;
        else if (this.left + (this.width * this.scaleX) / 2 < workspaceWidth) {
          //@ts-ignore
          this.left = workspaceWidth - (this.width * this.scaleX) / 2;
        }
        //@ts-ignore;
        if (this.top - (this.height * this.scaleY) / 2 > 0) {
          //@ts-ignore;
          this.top = (this.height * this.scaleY) / 2;
        }
        //@ts-ignore;

        //@ts-ignore;
        else if (this.top + (this.height * this.scaleX) / 2 < workspaceHeight) {
          //@ts-ignore
          this.top = workspaceHeight - (this.height * this.scaleX) / 2;
        }
      } else {
        if (!this._original) return;
        //@ts-ignore;
        const originalWidth = this._original.left + (this._original.width * this._original?.scaleX) / 2;
        //@ts-ignore;
        const originalHeight = this._original.top + (this._original.height * this._original?.scaleY) / 2;
        //@ts-ignore;
        const originalLeft = this._original.left - (this._original.width * this._original?.scaleX) / 2;
        //@ts-ignore;
        const originalTop = this._original.top - (this._original.height * this._original?.scaleY) / 2;

        //@ts-ignore;
        if (this.left - (this.width * this.scaleX) / 2 > originalLeft) {
          //@ts-ignore;
          this.left = originalLeft + (this.width * this.scaleX) / 2;
        }
        //@ts-ignore;
        else if (this.left + (this.width * this.scaleX) / 2 < originalWidth) {
          //@ts-ignore
          this.left = originalWidth - (this.width * this.scaleX) / 2;
        }

        //@ts-ignore;
        if (this.top - (this.height * this.scaleY) / 2 > originalTop) {
          //@ts-ignore;
          this.top = originalTop + (this.height * this.scaleX) / 2;
        }
        //@ts-ignore;
        else if (this.top + (this.height * this.scaleX) / 2 < originalHeight) {
          //@ts-ignore
          this.top = originalHeight - (this.height * this.scaleX) / 2;
        }
      }
    });
  }

  public async hanlderRemoveEffect() {
    const _this = this as any;
    _this.set({ opacity: 1 });
    const base64 = _this.getSrc();

    const options = {
      id: _this.id,
      width: _this.width,
      height: _this.height,
      scaleX: _this.scaleX,
      scaleY: _this.scaleX,
      left: _this.left - (_this.width * _this.scaleX) / 2,
      top: _this.top - (_this.height * _this.scaleY) / 2,
      angle: _this[CustomKey.RelativeAngle],
      originX: 'left',
      originY: 'top',
      crossOrigin: 'anonymous',
    };

    const imageCloned = (await Image.fromURL(base64, options)) as any;
    _this.canvas?.add(imageCloned);
    _this.canvas?.remove(_this);
  }

  public async restoreClipPath() {
    if (this._isControls) {
      const clipPath = this._clipPath;
      //@ts-ignore
      const scaleX = this._scaleX / this.scaleX;
      //@ts-ignore
      const scaleY = this._scaleY / this.scaleY;
      //@ts-ignore
      const left = this._left - this.left;
      //@ts-ignore
      const top = this._top - this.top;

      const clipPathLeft = clipPath.left;
      const clipPathTop = clipPath.top;
      // const textureLeft =  this.left;
      // const texturehTop =  this.top;
      this.set({
        _isControls: false,
        clipPath: clipPath,
      });

      //@ts-ignore
      if (scaleX !== 1) {
        clipPath?.set({
          //@ts-ignore
          left: 0,
          //@ts-ignore
          top: 0,
        });
        //@ts-ignore
        this.set({
          //@ts-ignore
          left: this._original.left,
          //@ts-ignore
          top: this._original.top,
        });
      } else {
        //计算纹理移动的大小，对clippath进行反向移动
        clipPath?.set({
          //@ts-ignore
          // left: clipPathLeft + left * Math.cos(this.angle)/ this.scaleX,
          // top: clipPathTop + top * Math.cos(this.angle) / this.scaleY
          left: clipPathLeft + left / this.scaleX,
          //@ts-ignore
          top: clipPathTop + top / this.scaleY,
        });
      }
      //@ts-ignore
      this._original.set({
        opacity: this.textureType === TextureType.GLOSS ? 1 : 0,
      });

      //计算纹理缩放的大小，对clippath进行反向缩放
      clipPath?.set({
        //@ts-ignore
        scaleX: clipPath.scaleX * scaleX,
        //@ts-ignore
        scaleY: clipPath.scaleY * scaleY,
      });

      //@ts-ignore
      //重新设置纹理的中心点
      this.set({
        opacity: this.textureType === TextureType.GLOSS ? 0.5 : 1,
      });

      const textureImage = (await TextureImage.fromURL(this.getSrc(), {
        ...this.toJSON(EDITOR_JSON_KEY),
        left: this.left,
        top: this.top,
        width: this.width,
        height: this.height,
        scaleX: this.scaleX,
        scaleY: this.scaleY,
        clipPath: this.clipPath,
        filters: this.filters,
        originX: this.originX,
        originY: this.originY,
        _original: this._original,
        id: this.id,
        _disableRightClick: true,
      })) as TextureImage;

      //编组
      //@ts-ignore
      const group = new fabric.Group([this._original, textureImage], {
        originX: 'center',
        originY: 'center',
        left: this.left,
        top: this.top,
        _isTextureGroup: true,
      });

      this.canvas?.add(group);
      this.canvas?.remove(this._original);
      this.canvas.setActiveObject(group);
      this.canvas?.renderAll();

      eventBus?.emit(ImageStatus.Editing, {
        value: false,
        target: this,
      });
      this.canvas?.remove(this);

      return group;
    }
  }

  protected async removeClipPathAndCache() {
    //@ts-ignore
    if (this._original) {
      this._original.set({
        opacity: 1,
      });
    }

    //缓存纹理当前的位置和缩放
    const scaleX = this.scaleX;
    const scaleY = this.scaleY;
    const left = this.left;
    const top = this.top;

    //@ts-ignore;
    //缓存clipPath，设置纹理图层的clipPath为null
    return new Promise((resolve) => {
      this.clipPath?.clone((cloned) => {
        this.set({
          //@ts-ignore
          _isControls: true,
          clipPath: undefined,
          _clipPath: cloned,
          _scaleX: scaleX,
          _scaleY: scaleY,
          _left: left,
          _top: top,
          opacity: 0.5,
        });
        this.canvas?.setActiveObject(this);
        // this.canvas?.add(cloned)
        this.canvas?.renderAll();
        resolve(null);
      });
    });
  }

  doubleClickHandler() {
    this.removeClipPathAndCache();
  }

  deselectedHandler() {
    this.restoreClipPath();
  }
}
