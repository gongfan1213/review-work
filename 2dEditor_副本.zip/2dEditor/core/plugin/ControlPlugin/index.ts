/*
 * 控制器样式;
 */
import Editor from '../../core';
type IEditor = Editor;

import { fabric } from 'fabric';
import { rotationControl } from './extension/rotation';

/**
 * 实际场景: 在进行某个对象缩放的时候，由于fabricjs默认精度使用的是toFixed(2)。
 * 此处为了缩放的精度更准确一些，因此将NUM_FRACTION_DIGITS默认值改为4，即toFixed(4).
 */
fabric.Object.NUM_FRACTION_DIGITS = 4;
const themeColor = "#60ce75";

class ControlPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  static pluginName = 'ControlPlugin';
  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
    this.init();
  }
  init() {
    // 旋转图标;
    rotationControl();
    // 选中样式
    fabric.Object.prototype.set({
      transparentCorners: false,
      borderScaleFactor: 1,
      borderOpacityWhenMoving: 0,
      cornerSize: 8,
      cornerColor: "#ffffff",
      cornerStrokeColor: themeColor,
      borderColor: themeColor,
    });
  }

}

export default ControlPlugin;
