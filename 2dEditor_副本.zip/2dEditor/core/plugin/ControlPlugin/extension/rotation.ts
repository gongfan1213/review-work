import { fabric } from "fabric";
import rotateImg from 'src/assets/svg/bottom_rotateicon.svg';

// bottom 旋转控件;
export function rotationControl() {
  const img = document.createElement('img');
  img.src = rotateImg;
  function renderIconRotate(
    ctx: CanvasRenderingContext2D,
    left: number,
    top: number,
    styleOverride: any,
    fabricObject: fabric.Object
  ) {
    drawImg(ctx, left, top, img, 45, 45, fabricObject.angle);
  }
  // 旋转图标
  fabric.Object.prototype.controls.mtr = new fabric.Control({
    x: 0,
    y: 0.5,
    //@ts-ignore;
    cursorStyleHandler: fabric.controlsUtils.rotationStyleHandler,
    // cursorStyleHandler: 'grab',
    //@ts-ignore;
    actionHandler: fabric.controlsUtils.rotationWithSnapping,
    offsetY: 25, // 旋转图标偏移量
    // withConnecton: false,
    actionName: 'rotate',
    render: renderIconRotate,
  });
  fabric.Textbox.prototype.controls.mtr = new fabric.Control({
    x: 0,
    y: 0.5,
    //@ts-ignore;
    cursorStyleHandler: fabric.controlsUtils.rotationStyleHandler,
    //@ts-ignore;
    actionHandler: fabric.controlsUtils.rotationWithSnapping,
    offsetY: 20, // 旋转图标偏移量
    // withConnecton: false,
    actionName: 'rotate',
    render: renderIconRotate,
  });
}

function drawImg(
  ctx: CanvasRenderingContext2D,
  left: number,
  top: number,
  img: HTMLElement,
  wSize: number,
  hSize: number,
  angle: number | undefined
) {
  if (angle === undefined) return;
  ctx.save();
  ctx.translate(left, top);
  ctx.rotate(fabric.util.degreesToRadians(angle));
  ctx.drawImage(img, -wSize / 2, -hSize / 2, wSize, hSize);
  ctx.restore();
}