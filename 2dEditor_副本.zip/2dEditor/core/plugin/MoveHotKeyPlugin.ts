/*
 * @Description: 移动快捷键
 */

import { fabric } from 'fabric';
import Editor from '../core';
type IEditor = Editor;
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { HotkeyStatus } from 'src/templates/2dEditor/core/eventbus/types/hotkey';

class MoveHotKeyPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  public flag: boolean = true;
  static pluginName = 'MoveHotKeyPlugin';
  public hotkeys: string[] = ['left', 'right', 'down', 'up'];
  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
    this.init();
  }

  init() {
    eventBus.on(HotkeyStatus.UDLR, this.handleFlag.bind(this));
  }

  handleFlag(flag: boolean) {
    this.flag = flag;
  }

  // 快捷键扩展回调
  hotkeyEvent(eventName: string, e: any) {
    if (!this.flag) return;
    if (e.type === 'keydown') {
      const { canvas } = this;
      const activeObject = canvas.getActiveObject();
      if (!activeObject) return;
      switch (eventName) {
        case 'left':
          if (activeObject.left === undefined) return;
          activeObject.set('left', activeObject.left - 1);
          break;
        case 'right':
          if (activeObject.left === undefined) return;
          activeObject.set('left', activeObject.left + 1);
          break;
        case 'down':
          if (activeObject.top === undefined) return;
          activeObject.set('top', activeObject.top + 1);
          break;
        case 'up':
          if (activeObject.top === undefined) return;
          activeObject.set('top', activeObject.top - 1);
          break;
        default:
      }
      canvas.renderAll();
    }
  }

  destroy() {
    console.log('pluginDestroy');
    eventBus.off(HotkeyStatus.UDLR, this.handleFlag);
  }
}

export default MoveHotKeyPlugin;
