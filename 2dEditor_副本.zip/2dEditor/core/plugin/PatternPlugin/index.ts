import { Pattern } from "./Pattern";
import { fabric } from "fabric";
import Editor from '../../core';
import { CustomKey, CustomObjectType, EventNameCons } from "src/templates/2dEditor/cons/2dEditorCons";
import eventBus from "../../eventbus";
type IEditor = Editor;

class PatternPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  static pluginName = 'PatternPlugin';
  static apis = ['addPattern'];
  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
  }

  addPattern(imageBase64: string, options?: any, callBack?: Function) {
    eventBus.emit(EventNameCons.ChangeEditorSaveState, false);
    const patternObject = new Pattern(imageBase64, options);
    const currentPattern = this.canvas.getObjects().find((object) => (object as any)[CustomKey.CustomType] === CustomObjectType.Pattern);
    !!currentPattern && this.canvas.remove(currentPattern); // only one pattern in canvas;
    patternObject.set({
      evented: false,
      selectable: false,
      // @ts-ignore;
      [CustomKey.IsLock]: true, // default LOCK;
    });
    this.canvas.add(patternObject);
    this.editor.toBottom(patternObject); // put pattern to bottom;
    callBack && callBack();
  };
}

export default PatternPlugin;


