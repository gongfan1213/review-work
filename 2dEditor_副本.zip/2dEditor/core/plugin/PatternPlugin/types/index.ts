export enum TempPatternID {
  ID = 'tempPatternID'
}