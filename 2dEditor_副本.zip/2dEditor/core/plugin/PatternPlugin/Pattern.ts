import { fabric } from "fabric";
import { TempPatternID } from './types';
import { CustomKey, CustomObjectType } from "src/templates/2dEditor/cons/2dEditorCons";

export class Pattern extends fabric.Rect {
  public options: any;
  public imageDoument: HTMLElement | null = null;
  constructor(image: string, options?: any) {
    super(options);
    // @ts-ignore;
    this[CustomKey.CustomType] = CustomObjectType.Pattern;
    // @ts-ignore;
    this[CustomKey.PatternBase64] = image;
    this.options = options;
    this.init();
    this.on('scaling', this.handleScaling.bind(this));
    this.on('mouseup', this.handleMouseup.bind(this));
  }

  public init() {
    const imageInstance = new Image();
    // @ts-ignore;
    imageInstance.src = this[CustomKey.PatternBase64];
    imageInstance.onload = () => {
      this.imageDoument = imageInstance;
      const pattern = new fabric.Pattern({
        source: imageInstance,
        repeat: 'repeat'
      });
      // @ts-ignore;
      this.set({
        fill: pattern,
        width: this.options.width,
        height: this.options.height,
        left: this.left,
        top: this.top,
      });
      this.canvas?.renderAll();
    }
  }
  // @ts-ignore;
  public handleScaling(e) {
    const target = e.transform.target;
    // @ts-ignore;
    this.set({
      width: target.width * target.scaleX,
      height: target.height * target.scaleY,
      scaleX: 1,
      scaleY: 1,
      opacity: 0,
    });
    const tempPattern = new fabric.Rect({
      // @ts-ignore;
      id: TempPatternID.ID,
      width: target.width * target.scaleX,
      height: target.height * target.scaleY,
      left: target.left,
      top: target.top,
      fill: new fabric.Pattern({
        // @ts-ignore;
        source: this.imageDoument,
        repeat: 'repeat',
      }),
      angle: target.angle,
      flipX: target.flipX,
      flipY: target.flipY,
    });
    this.canvas?.getObjects().filter(item => !!item.id && item.id === TempPatternID.ID).forEach(item => this.canvas?.remove(item));
    this.canvas?.add(tempPattern);
  }
  // ;
  public handleMouseup() {
    // @ts-ignore;
    this.set('opacity', 1);
    this.canvas?.getObjects().filter(item => !!item.id && item.id === TempPatternID.ID).forEach(item => this.canvas?.remove(item));
    this.canvas?.discardActiveObject();
    this.canvas?.setActiveObject(this);
    this.canvas?.requestRenderAll();
  }
}
