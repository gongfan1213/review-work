/*
 * @Description: 图片工具插件
 */

import { fabric } from 'fabric';
import Editor from '../core';
import { FILTER_IDENTIFIERS } from 'src/templates/2dEditor/components/FrontApps/const'

type IEditor = Editor;

class ImageToolPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  static pluginName = 'ImageToolPlugin';
  static apis = ['getBrightness', 'setBrightness'
    , 'getSaturation', 'setSaturation'
    , 'getContrast', 'setContrast'
    , 'getGamma', 'setGamma'
    , 'setClarify', 'getClarify'
    , 'setShadows', 'getShadows'
    , 'setConvolute', 'setOldPhoto'
    , 'setHighlight', 'removeSpecificFilters'
    , 'setBlur', 'getBlur'
    , 'setHueRotation', 'getHueRotation'
    , 'setPixelate', 'getPixelate'
  ];
  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
  }
  // 定义范围参数
  private inputRange = { min: -1, max: 1 };
  private outputClarifyRange = { min: 0, max: 10 };
  private outputBrightness = { min: -0.8, max: 0.8 };
  private outputContrast = { min: -0.9, max: 1 };
  private outputShadows = { min: -0.9, max: 1 };


  // 获取activeObject的Brightness值
  getBrightness = (activeObject: fabric.Image): number => {
    const brightnessFilter = activeObject?.filters?.slice().reverse().find(
      (filter): filter is fabric.Image.filters.Brightness => filter instanceof fabric.Image.filters.Brightness
    );
    return brightnessFilter
      // 显示时，转化为-1到1的初始范围
      ? this.mapValue(
        brightnessFilter.brightness,
        this.outputBrightness.min,
        this.outputBrightness.max,
        this.inputRange.min,
        this.inputRange.max,
      )
      : 0;
  };

  // 设置动态亮度滤镜
  setBrightness = (activeObject: fabric.Image, value: number): void => {
    if (!activeObject) return;
    // 使用mapValue方法将输入值映射到-0.8到0.8的范围
    const mappedValue = this.mapValue(value, this.inputRange.min, this.inputRange.max, this.outputBrightness.min, this.outputBrightness.max);
    // console.log("mappedValue----=-=-=-==-", mappedValue);
    const brightnessFilter = new fabric.Image.filters.Brightness({ brightness: mappedValue });
    activeObject.filters = activeObject?.filters?.filter(
      (filter) => !(filter instanceof fabric.Image.filters.Brightness)
    ) || [];
    activeObject.filters.push(brightnessFilter);
    activeObject.applyFilters();
    this.canvas?.renderAll();
  };

  getSaturation = (activeObject: fabric.Image): number => {
    const filter = activeObject?.filters?.slice().reverse().find(
      (f): f is fabric.Image.filters.Saturation => f instanceof fabric.Image.filters.Saturation
    );

    return filter ? filter.saturation : 0; // 取值范围通常是-1到1
  };

  // 设置动态饱和度滤镜
  setSaturation = (activeObject: fabric.Image, value: number): void => {
    if (!activeObject) return;
    const filter = new fabric.Image.filters.Saturation({ saturation: value });
    activeObject.filters = activeObject.filters?.filter(
      (f) => !(f instanceof fabric.Image.filters.Saturation)
    ) || [];
    activeObject.filters.push(filter);
    activeObject.applyFilters();
    this.canvas?.renderAll();
  };

  getContrast = (activeObject: fabric.Image): number => {
    const filter = activeObject?.filters?.slice().reverse().find(
      (f): f is fabric.Image.filters.Contrast => f instanceof fabric.Image.filters.Contrast
    );
    // return filter ? filter.contrast : 0; // 取值范围通常是-1到1
    return filter
      ? this.mapValue(
        filter.contrast,
        this.outputContrast.min,
        this.outputContrast.max,
        this.inputRange.min,
        this.inputRange.max
      )
      : 0;
  };

  // 设置动态对比度滤镜
  setContrast = (activeObject: fabric.Image, value: number): void => {
    if (!activeObject) return;
    // 使用mapValue方法将输入值映射到outputContrast的范围内
    const mappedValue = this.mapValue(value, this.inputRange.min, this.inputRange.max, this.outputContrast.min, this.outputContrast.max);
    const contrastFilter = new fabric.Image.filters.Contrast({ contrast: mappedValue });
    // console.log("设置对比度", mappedValue);
    activeObject.filters = activeObject?.filters?.filter(
      (f) => !(f instanceof fabric.Image.filters.Contrast)
    ) || [];
    activeObject.filters.push(contrastFilter);
    activeObject.applyFilters();
    this.canvas?.renderAll();
  };

  getGamma = (activeObject: fabric.Image): number => {
    const filter = activeObject?.filters?.slice().reverse().find(
      (f): f is fabric.Image.filters.Gamma => f instanceof fabric.Image.filters.Gamma
    );
    if (filter && filter.gamma) {
      // 假设RGB的伽马值相同，只取一个通道的值进行映射
      const gammaValue = filter.gamma[0];
      // 将0.2到2.2的范围映射回-1到1的范围
      const value = ((gammaValue - 0.2) / (2.2 - 0.2)) * 2 - 1;
      return value;
    }
    return 0; // 如果没有设置伽马滤镜，则返回0，表示没有变化
  };

  //设置动态伽马滤镜 
  setGamma = (activeObject: fabric.Image, value: number): void => {
    if (!activeObject) return;
    // 将-1到1的范围映射到0.2到2.2的范围
    const gammaValue = ((value + 1) / 2) * (2.2 - 0.2) + 0.2;
    const gammaArray = [gammaValue, gammaValue, gammaValue]; // RGB色值同比例
    console.log("setImageContrast====", JSON.stringify(gammaArray))

    const filter = new fabric.Image.filters.Gamma({ gamma: gammaArray });
    activeObject.filters = activeObject?.filters?.filter(
      (f) => !(f instanceof fabric.Image.filters.Gamma)
    ) || [];
    activeObject.filters.push(filter);
    activeObject.applyFilters();
    this.canvas?.renderAll();
  };

  // 设置锐化滤镜以提高图像清晰度
  setClarify(activeObject: fabric.Image, value: number): void {
    if (!activeObject) return;
    const clarifyValue = this.mapValue(value, this.inputRange.min, this.inputRange.max, this.outputClarifyRange.min, this.outputClarifyRange.max);
    const clarifyFilter = new fabric.Image.filters.Convolute({
      matrix: [
        0, -clarifyValue, 0,
        -clarifyValue, 4 * clarifyValue + 1, -clarifyValue,
        0, -clarifyValue, 0
      ]
    });

    activeObject.filters = activeObject?.filters?.filter(
      (f) => !(f instanceof fabric.Image.filters.Convolute)
    ) || [];
    // console.log("clarifyFilter-----锐化--->", clarifyFilter);

    activeObject.filters.push(clarifyFilter);
    activeObject.applyFilters();
    this.canvas?.renderAll();
  }

  // 获取当前锐化滤镜的值
  getClarify(activeObject: fabric.Image): number {
    const filter = activeObject?.filters?.slice().reverse().find(
      (f): f is fabric.Image.filters.Convolute => f instanceof fabric.Image.filters.Convolute
    );
    if (filter && filter.matrix) {
      const clarifyValue = (filter.matrix[4] - 1) / 4;
      const value = this.mapValue(clarifyValue, this.outputClarifyRange.min, this.outputClarifyRange.max, this.inputRange.min, this.inputRange.max);
      return value;
    }
    return 0;
  }

  // 设置阴影滤镜
  setShadows = (activeObject: fabric.Image, value: number): void => {
    // value 的范围可以是 -1（变暗）到 1（变亮），0 表示没有变化
    if (!activeObject) return;
    const shadowValue = value; // 根据需要调整这个值
    const shadowColor = shadowValue > 0 ? 'white' : 'black';
    const blendMode = shadowValue > 0 ? 'screen' : 'multiply';
    const absoluteValue = value > 0 ? Math.abs(value) : 0.01 * (1 + value);
    // console.log("setImageClarify====", shadowColor + " absoluteValue=" + absoluteValue);

    const shadowsFilter = new fabric.Image.filters.BlendColor({
      color: shadowColor,
      mode: blendMode,
      alpha: absoluteValue
    });

    // 移除已有的阴影滤镜
    activeObject.filters = activeObject?.filters?.filter(
      (filter) => !(filter instanceof fabric.Image.filters.BlendColor)
    );

    // 添加新的阴影滤镜
    activeObject.filters?.push(shadowsFilter);
    activeObject.applyFilters();
    this.canvas.renderAll();
  };

  getShadows = (activeObject: fabric.Image): number => {
    const shadowsFilter = activeObject?.filters?.find(
      (filter) => filter.type === 'BlendColor'
    ) as fabric.Image.filters.BlendColor;

    if (shadowsFilter) {
      // 根据颜色和模式推断阴影值
      const isLighten = shadowsFilter.mode === 'screen';
      const value = isLighten ? shadowsFilter.alpha : -shadowsFilter.alpha;
      return value;
    }
    return 0; // 如果没有设置阴影滤镜，则返回0
  };

  // 设置模糊滤镜
  setBlur = (activeObject: fabric.Image, value: number) => {
    if (!activeObject) return;
    const BlurFilter = new fabric.Image.filters.Blur({ blur: value });
    // console.log("setBlursetBlursetBlur", BlurFilter);
    activeObject.filters = activeObject?.filters?.filter(
      (f) => !(f instanceof fabric.Image.filters.Blur)
    ) || [];
    activeObject.filters.push(BlurFilter);
    activeObject.applyFilters();
    this.canvas?.renderAll();
  }

  getBlur = (activeObject: fabric.Image): number => {
    const brightnessFilter = activeObject?.filters?.slice().reverse().find(
      (filter): filter is fabric.Image.filters.Blur => filter instanceof fabric.Image.filters.Blur
    );
    // console.log("brightnessFilter122222222222", brightnessFilter);
    return brightnessFilter
      // 显示时，转化为-1到1的初始范围
      ? brightnessFilter.blur : 0;
  }

  //  设置色彩旋转滤镜
  setHueRotation = (activeObject: fabric.Image, value: number): void => {
    if (!activeObject) return;
    const HueRotation = new fabric.Image.filters.HueRotation({ rotation: value });
    activeObject.filters = activeObject?.filters?.filter(
      (f) => !(f instanceof fabric.Image.filters.HueRotation)
    ) || [];
    activeObject.filters.push(HueRotation);
    // 应用滤镜
    activeObject.applyFilters();
    // 重新渲染画布
    this.canvas?.renderAll();
  }

  getHueRotation = (activeObject: fabric.Image): number => {
    const brightnessFilter = activeObject?.filters?.slice().reverse().find(
      (filter): filter is fabric.Image.filters.HueRotation => filter instanceof fabric.Image.filters.HueRotation
    );
    // console.log("brightnessFilter122222222222", brightnessFilter);
    return brightnessFilter
      // 显示时，转化为-1到1的初始范围
      ? brightnessFilter.rotation : 0;
  }

  // 设置像素化滤镜
  setPixelate = (activeObject: fabric.Image, value: number): void => {
    if (!activeObject) return;
    let filter = new fabric.Image.filters.Pixelate({
      blocksize: value * 100
    });
    activeObject.filters = activeObject?.filters?.filter(
      (f) => !(f instanceof fabric.Image.filters.Pixelate)
    ) || [];
    // console.log("setPixelate===filterfilter=", filter);

    activeObject.filters.push(filter);
    // 应用滤镜
    activeObject.applyFilters();
    // 重新渲染画布
    this.canvas?.renderAll();
  };

  getPixelate = (activeObject: fabric.Image): number => {
    const brightnessFilter = activeObject?.filters?.slice().reverse().find(
      (filter): filter is fabric.Image.filters.Pixelate => filter instanceof fabric.Image.filters.Pixelate
    );
    return brightnessFilter
      // 显示时，转化为-1到1的初始范围
      ? brightnessFilter.blocksize : 0
  }

  // 设置Convolute滤镜
  setConvolute = (activeObject: fabric.Image, value: any, filterClass: string): void => {
    // 确保每个对象都有一个filtersMap属性
    // @ts-ignore
    if (!activeObject.filtersMap) {
      // @ts-ignore
      activeObject.filtersMap = {};
    }
    // 使用标识符来检查是否已经应用了Convolute滤镜
    if (activeObject.filtersMap[filterClass]) {
      return;
    }
    let filter = new fabric.Image.filters.Convolute({
      matrix: value
    });
    // 如果已经应用了，则先移除旧的Convolute滤镜
    // activeObject.filters = activeObject.filters.filter(
    //   (f) => !(f instanceof fabric.Image.filters.Convolute)
    // );
    // 添加新的滤镜并更新filtersMap
    activeObject.filters.push(filter);
    activeObject.filtersMap[filterClass] = filter;
    // 应用滤镜
    activeObject.applyFilters();
    // 重新渲染画布
    this.canvas?.renderAll();
  };

  // 老照片效果
  setOldPhoto = (activeObject: fabric.Image): void => {
    // 确保每个对象都有一个filtersMap属性
    // @ts-ignore
    if (!activeObject.filtersMap) {
      // @ts-ignore
      activeObject.filtersMap = {};
    }
    // 使用标识符来检查是否已经应用了旧照片滤镜组
    // @ts-ignore
    if (activeObject.filtersMap[FILTER_IDENTIFIERS.OLD_PHOTO]) {
      // 如果已经应用了，则不再重复应用
      return;
    }
    // 创建滤镜
    var filter1 = new fabric.Image.filters.Noise({ noise: 100 }); // 增加噪声
    var filter2 = new fabric.Image.filters.Brightness({ brightness: -0.1 }); // 降低亮度
    var filter3 = new fabric.Image.filters.Contrast({ contrast: 0.1 }); // 增加对比度
    var filter4 = new fabric.Image.filters.Sepia(); // 棕褐色滤镜
    // 移除旧的Sepia滤镜，如果有的话
    activeObject.filters = activeObject?.filters?.filter(
      (f) => !(f instanceof fabric.Image.filters.Sepia)
    );
    // 添加新的滤镜并更新filtersMap
    // @ts-ignore
    activeObject.filters.push(filter1, filter2, filter3, filter4);
    // 将设置过的滤镜对应到filtersMap，后续删除的话方便对应
    // @ts-ignore
    activeObject.filtersMap[FILTER_IDENTIFIERS.OLD_PHOTO] = [filter1, filter2, filter3, filter4];
    // 应用滤镜
    activeObject.applyFilters();
    // 重新渲染画布
    this.canvas?.renderAll();
  };

  // 高光滤镜
  setHighlight = (activeObject: fabric.Image, value: number): void => {
    // 确保每个对象都有一个filtersMap属性
    // @ts-ignore
    if (!activeObject.filtersMap) {
      // @ts-ignore
      activeObject.filtersMap = {};
    }
    // 使用标识符来检查是否已经应用了高光滤镜组
    // @ts-ignore
    if (activeObject.filtersMap[FILTER_IDENTIFIERS.HIGHLIGHT]) {
      // 如果已经应用了，则不再重复应用
      return;
    }
    var filter1 = new fabric.Image.filters.Brightness({
      brightness: 0.1 // 增加亮度
    });
    var filter2 = new fabric.Image.filters.Contrast({
      contrast: 0.1 // 增加对比度
    });

    // 添加新的高光滤镜并更新filtersMap
    // @ts-ignore
    activeObject.filters.push(filter1, filter2);
    // 将设置过的滤镜对应到filtersMap，后续删除的话方便对应
    // @ts-ignore
    activeObject.filtersMap[FILTER_IDENTIFIERS.HIGHLIGHT] = [filter1, filter2];
    // 应用滤镜
    activeObject.applyFilters();
    // 重新渲染画布
    this.canvas.renderAll();
  };
  // 辅助函数：比较两个滤镜对象（忽略type字段） 
  private isEqualFilterIgnoringType = (filterA: any, filterB: any) => {
    const { type: _, ...restA } = filterA;
    const { type: __, ...restB } = filterB;
    return JSON.stringify(restA) === JSON.stringify(restB);
  }

  // 目前还存在些问题，如刷新后再次删除时，匹配不上，会多一些type，opaque类似的键，需要后续排查
  // 删除特定滤镜效果
  removeSpecificFilters = (activeObject: fabric.Image, filterIdentifiers: string[], filtersMapData: {}): void => {
    // 当activeObject?.filtersMap数据为空时，采用filtersMapData的数据
    // console.log("activeObject?.filtersMap", activeObject?.filtersMap, "filtersMapData", filtersMapData);

    const filtersMap = Object.keys(activeObject?.filtersMap || {}).length === 0 ? filtersMapData : activeObject.filtersMap;

    if (!filtersMap) {
      console.log("No filters have been applied to this object.");
      return;
    }
    // console.log("filtersMap", filtersMap);
    filterIdentifiers.forEach(filterIdentifier => {
      if (filtersMap[filterIdentifier]) {
        const filterList = Array.isArray(filtersMap[filterIdentifier])
          ? filtersMap[filterIdentifier]
          : [filtersMap[filterIdentifier]];

        activeObject.filters = activeObject.filters.filter(
          filter => !filterList.some(filterItem => this.isEqualFilterIgnoringType(filter, filterItem))
        );

        delete filtersMap[filterIdentifier];
      }
    });

    activeObject.applyFilters();
    this.canvas?.renderAll();
  };

  // 映射函数，将一个数值从一个范围映射到另一个范围
  // value：要映射的原始数值。
  // inMin和inMax：原始数值的范围的最小值和最大值。
  // outMin和outMax：目标范围的最小值和最大值。
  private mapValue(value: number, inMin: number, inMax: number, outMin: number, outMax: number): number {
    return ((value - inMin) / (inMax - inMin)) * (outMax - outMin) + outMin;
  }

  destroy() {
    console.log('pluginDestroy');
  }
}

export default ImageToolPlugin;
