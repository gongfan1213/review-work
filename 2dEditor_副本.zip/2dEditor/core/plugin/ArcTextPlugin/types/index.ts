export enum TransformType {
  Custom = "custom",
  Circle = "circle",
  Angle = "angle",
  Bezier2 = "bezier2",
  Polygon = "polygon",
  Distort = "distort",
}

export enum BezierControlId {
  ControlCircle = "bezierTextControlCircle",
  ControlLine = "bezierTextControlLine"
}

export enum CircleControlId {
  ControlCircle = "circleTextControlCircle",
}

export enum AngleControlId {
  ControlCircle = "angleTextControlCircle",
  ControlLine = "angleTextControlLine"
}
