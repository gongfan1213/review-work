/**
 * 三次平滑贝塞尔曲线;
 */
import { fabric } from "fabric";
import { BezierControlId } from "../types";
import eventBus from "src/templates/2dEditor/core/eventbus";
import { TextStatus } from 'src/templates/2dEditor/core/eventbus/types/text';
import { height, width } from "dom7";

export function bezierText(target: any) { 
  if (!target) return;
  const canvas = target.canvas;
  if (!canvas) return;
  // @ts-ignore;

 
  const pathAlign = "center";
  const pathSide = "left"
  const circleCursor = "crosshair"; // hover cursor;
  const circleRadius = 6;
  let pathStartOffset = 0;
  let bezierCurve: fabric.Path | null = null;
  let controlCircle_1: fabric.Object | null = null;
  let controlCircle_1_sub: fabric.Object | null = null;
  let controlCircle_1_sub_line: fabric.Object | null = null;
  let controlCircle_1_sub_offset: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_2: fabric.Object | null = null;
  let controlCircle_2_sub_1: fabric.Object | null = null;
  let controlCircle_2_sub_2: fabric.Object | null = null;
  let controlCircle_2_sub_line_1: fabric.Object | null = null;
  let controlCircle_2_sub_line_2: fabric.Object | null = null;
  let controlCircle_2_sub_1_offset: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_2_sub_2_offset: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_3: fabric.Object | null = null;
  let controlCircle_3_sub: fabric.Object | null = null;
  let controlCircle_3_sub_line: fabric.Object | null = null;
  let controlCircle_3_sub_offset: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_1_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_1_sub_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_2_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_2_sub_1_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_2_sub_2_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_3_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_3_sub_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let targetScaleX = target.scaleX;
  let targetScaleY = target.scaleY;

  target.set({
    scaleX: 1,
    scaleY: 1,
    width: target.width * targetScaleX,
    height: target.height * targetScaleY,
    fontSize: target.fontSize * targetScaleX,
    left: target.originX === 'center' ? target.left - target.width / 2 - target.padding : target.left,
    top: target.originX === 'center' ? target.top - target.height / 2 - target.padding : target.top,
    originX: 'left',
    originY: 'top',
  })

  const textWidth = target.__charBounds[0].reduce((pre, current) => pre + current.width, 0);

  // text transform start;;
  let targetEvented = (flag: boolean) => {
    target.set({
      hasBorders: flag,
    });
    target.set({
      cornerSize: flag ? 8 : 0,
    });
    target.setControlsVisibility({
      mtr: flag
    })
  };
  targetEvented(false);
  // clear control circle, finish bezier text;
  let clear = () => {
    target.set({
      _transformTextControlPoint: {
        controlCircle_1,
        controlCircle_1_sub,
        controlCircle_2,
        controlCircle_2_sub_1,
        controlCircle_2_sub_2,
        controlCircle_3,
        controlCircle_3_sub
      }
    });
    !!target.path && target.path.set('opacity', 0);
    targetEvented(true);
    canvas.getObjects()
      .filter((obj: any) => obj.id === BezierControlId.ControlCircle || obj.id === BezierControlId.ControlLine)
      .forEach((obj: fabric.Object) => canvas.remove(obj));
    eventBus.emit(TextStatus.UnderTransform, false);
    canvas.renderAll();
    canvas.off("mouse:down", mouseDownClick);
  }
  canvas.on("mouse:down", mouseDownClick);
  function mouseDownClick(e: fabric.IEvent): void {
    if( e.target ) {
      if(e.target.id.indexOf('ControlCircle') !== -1) return;
      clear();    
      if (e.target.id === target.id) {           
        canvas.setActiveObject(target)       
      } 
    }else{
      clear();
    }  
  }
  
  // #region draw control circle;
  controlCircle_1 =
    target._transformTextControlPoint.controlCircle_1 ||
    new fabric.Circle({
      id: BezierControlId.ControlCircle,
      radius: circleRadius,
      fill: "#ffffff",
      stroke: "#60ce75",
      strokeWidth: 1,
      left: target.originX === 'center' ? target.left - target.width / 2 :  target.left,
      top: target.top - circleRadius,
      hasControls: false,
      hasBorders: false,
      cornerSize: 0,
      hoverCursor: circleCursor,
      moveCursor: circleCursor,
    });

    
  controlCircle_1_sub =
    target._transformTextControlPoint.controlCircle_1_sub ||
    new fabric.Circle({
      id: BezierControlId.ControlCircle,
      radius: circleRadius,
      fill: "#ffffff",
      stroke: "#60ce75",
      strokeWidth: 1,
      left: controlCircle_1.left + textWidth / 5,
      top: controlCircle_1.top - circleRadius - 20,
      hasControls: false,
      hasBorders: false,
      cornerSize: 0,
      hoverCursor: circleCursor,
      moveCursor: circleCursor,
    });
 
  controlCircle_2 =
    target._transformTextControlPoint.controlCircle_2 ||
    new fabric.Circle({
      id: BezierControlId.ControlCircle,
      radius: circleRadius,
      fill: "#ffffff",
      stroke: "#60ce75",
      strokeWidth: 1,
      left: target.originX === 'center' ? target.left - circleRadius / 2 : target.left + target.width / 2 - circleRadius / 2,
      top: target.top - circleRadius,
      hasControls: false,
      hasBorders: false,
      cornerSize: 0,
      hoverCursor: circleCursor,
      moveCursor: circleCursor,
    });

  controlCircle_2_sub_1 =
    target._transformTextControlPoint.controlCircle_2_sub_1 ||
    new fabric.Circle({
      id: BezierControlId.ControlCircle,
      radius: circleRadius,
      fill: "#ffffff",
      stroke: "#60ce75",
      strokeWidth: 1,
      left: controlCircle_2.left - textWidth / 5,
      top: controlCircle_2.top  - 20,
      hasControls: false,
      hasBorders: false,
      cornerSize: 0,
      hoverCursor: circleCursor,
      moveCursor: circleCursor,
    });
  controlCircle_2_sub_2 =
    target._transformTextControlPoint.controlCircle_2_sub_2 ||
    new fabric.Circle({
      id: BezierControlId.ControlCircle,
      radius: circleRadius,
      fill: "#ffffff",
      stroke: "#60ce75",
      strokeWidth: 1,
      left: controlCircle_2.left + textWidth / 5,
      top: controlCircle_2.top + 20,
      hasControls: false,
      hasBorders: false,
      cornerSize: 0,
      hoverCursor: circleCursor,
      moveCursor: circleCursor,
    });
 
  controlCircle_3 =
    target._transformTextControlPoint.controlCircle_3 ||
    new fabric.Circle({
      id: BezierControlId.ControlCircle,
      radius: circleRadius,
      fill: "#ffffff",
      stroke: "#60ce75",
      strokeWidth: 1,
      left: target.originX === 'center' ? target.left + target.width/2 - circleRadius : target.left + target.width - circleRadius,
      top: target.top - circleRadius,
      hasControls: false,
      hasBorders: false,
      cornerSize: 0,
      hoverCursor: circleCursor,
      moveCursor: circleCursor,
    });
  controlCircle_3_sub =
    target._transformTextControlPoint.controlCircle_3_sub ||
    new fabric.Circle({
      id: BezierControlId.ControlCircle,
      radius: circleRadius,
      fill: "#ffffff",
      stroke: "#60ce75",
      strokeWidth: 1,
      left: controlCircle_3.left - textWidth / 5,
      top: target.top - circleRadius + 20,
      hasControls: false,
      hasBorders: false,
      cornerSize: 0,
      hoverCursor: circleCursor,
      moveCursor: circleCursor,
    });

  // control circle hover;
  [controlCircle_1, controlCircle_1_sub, controlCircle_2, controlCircle_2_sub_1, controlCircle_2_sub_2, controlCircle_3, controlCircle_3_sub].forEach(object => {
    object?.on('mouseover', () => {
      object.set({
        fill: '#60ce75',
        shadow: {
          color: 'rgba(0,0,0,0.2)',  // 阴影颜色
          blur: 5,                  // 模糊度
          offsetX: 0,               // X轴偏移
          offsetY: 0                // Y轴偏移
        }
      });
      canvas.renderAll();
    });
    object?.on('mouseout', () => {
      object.set({
        fill: '#ffffff',
        shadow: null
      });
      canvas.renderAll();
    });
  });

  // @ts-ignore;
  setObjectControlsVisibility(false, [controlCircle_1, controlCircle_2, controlCircle_2_sub_1, controlCircle_2_sub_2, controlCircle_3, controlCircle_1_sub, controlCircle_3_sub]);
  controlCircle_1_center_point = controlCircle_1.getCenterPoint();
  controlCircle_1_sub_center_point = controlCircle_1_sub.getCenterPoint();
  controlCircle_2_center_point = controlCircle_2.getCenterPoint();
  controlCircle_2_sub_1_center_point = controlCircle_2_sub_1.getCenterPoint();
  controlCircle_2_sub_2_center_point = controlCircle_2_sub_2.getCenterPoint();
  controlCircle_3_center_point = controlCircle_3.getCenterPoint();
  controlCircle_3_sub_center_point = controlCircle_3_sub.getCenterPoint();
  // 控制点1的辅助线;
  controlCircle_1_sub_line = new fabric.Line([controlCircle_1_center_point.x, controlCircle_1_center_point.y, controlCircle_1_sub_center_point.x, controlCircle_1_sub_center_point.y], {
    id: BezierControlId.ControlLine,
    fill: "#60ce75",
    stroke: "#60ce75",
    strokeWidth: 1,
    hasControls: false,
    hasBorders: false,
    evented: false,
    selectable: false,
    originX: "center",
    originY: "center",
  });
  // 控制点2与控制点2-1的辅助线;
  controlCircle_2_sub_line_1 = new fabric.Line([controlCircle_2_center_point.x, controlCircle_2_center_point.y, controlCircle_2_sub_1_center_point.x, controlCircle_2_sub_1_center_point.y], {
    id: BezierControlId.ControlLine,
    fill: "#60ce75",
    stroke: "#60ce75",
    strokeWidth: 1,
    hasControls: false,
    hasBorders: false,
    evented: false,
    selectable: false,
    originX: "center",
    originY: "center",
  });
  // 控制点2与控制点2-2的辅助线;
  controlCircle_2_sub_line_2 = new fabric.Line([controlCircle_2_center_point.x, controlCircle_2_center_point.y, controlCircle_2_sub_2_center_point.x, controlCircle_2_sub_2_center_point.y], {
    id: BezierControlId.ControlLine,
    fill: "#60ce75",
    stroke: "#60ce75",
    strokeWidth: 1,
    hasControls: false,
    hasBorders: false,
    evented: false,
    selectable: false,
    originX: "center",
    originY: "center",
  });
  // 控制点3的辅助线;
  controlCircle_3_sub_line = new fabric.Line([controlCircle_3_center_point.x, controlCircle_3_center_point.y, controlCircle_3_sub_center_point.x, controlCircle_3_sub_center_point.y], {
    id: BezierControlId.ControlLine,
    fill: "#60ce75",
    stroke: "#60ce75",
    strokeWidth: 1,
    hasControls: false,
    hasBorders: false,
    evented: false,
    selectable: false,
    originX: "center",
    originY: "center",
  });

  canvas.add(controlCircle_1);
  canvas.add(controlCircle_2);
  canvas.add(controlCircle_3);
  canvas.add(controlCircle_1_sub);
  canvas.add(controlCircle_3_sub);
  canvas.add(controlCircle_2_sub_1);
  canvas.add(controlCircle_2_sub_2);
  canvas.add(controlCircle_1_sub_line);
  canvas.add(controlCircle_2_sub_line_1);
  canvas.add(controlCircle_2_sub_line_2);
  canvas.add(controlCircle_3_sub_line);
  
  // set the control circle zIndex upper to line;
  canvas.bringToFront(controlCircle_1).bringToFront(controlCircle_2).bringToFront(controlCircle_3).bringToFront(controlCircle_1_sub).bringToFront(controlCircle_3_sub).bringToFront(controlCircle_2_sub_1).bringToFront(controlCircle_2_sub_2);
  // #endregion ;
  handleControlCircle1Moving();
  // #region calc relative position of control circle 2 sub control circle;
  controlCircle_1_sub_offset = {
    x: controlCircle_1_sub.left - controlCircle_1.left,
    y: controlCircle_1_sub.top - controlCircle_1.top
  };
  controlCircle_2_sub_1_offset = {
    x: controlCircle_2_sub_1.left - controlCircle_2.left,
    y: controlCircle_2_sub_1.top - controlCircle_2.top
  };
  controlCircle_2_sub_2_offset = {
    x: controlCircle_2_sub_2.left - controlCircle_2.left,
    y: controlCircle_2_sub_2.top - controlCircle_2.top
  };
  controlCircle_3_sub_offset = {
    x: controlCircle_3_sub.left - controlCircle_3.left,
    y: controlCircle_3_sub.top - controlCircle_3.top
  };
  // #endregion ;
  // #region handle control circle drag and transform the bezier;
  // control circle 1 Moving;
  controlCircle_1?.on('moving', () => {
    handleControlCircle1Moving();
    resetCanvasZoom();
  });
  controlCircle_1_sub?.on('moving', () => {
    handleControlCircleSub1Moving();
    resetCanvasZoom();
  });
  controlCircle_2?.on('moving', () => {
    handleControlCircle2Moving();
    resetCanvasZoom();
  });
  controlCircle_2_sub_1?.on('moving', () => {
    handleControlCirle2Sub1Moving();
    resetCanvasZoom();
  });
  controlCircle_2_sub_2?.on('moving', () => {
    handleControlCirle2Sub2Moving();
    resetCanvasZoom();
  });
  controlCircle_3?.on('moving', () => {
    handleControlCircle3Moving();
    resetCanvasZoom();
  });
  controlCircle_3_sub?.on('moving', () => {
    handleControlCircle3Sub1Moving();
    resetCanvasZoom();
  });

  // handle control circle 1 moving;
  function handleControlCircle1Moving() {
    controlCircle_1_sub.set({
      left: controlCircle_1.left + controlCircle_1_sub_offset.x,
      top: controlCircle_1.top + controlCircle_1_sub_offset.y
    });
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    controlCircle_1_sub_center_point = controlCircle_1_sub.getCenterPoint();
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    controlCircle_2_sub_1_center_point = controlCircle_2_sub_1.getCenterPoint();
    controlCircle_2_sub_2_center_point = controlCircle_2_sub_2.getCenterPoint();
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    controlCircle_3_sub_center_point = controlCircle_3_sub.getCenterPoint();
    
    bezierCurve = new fabric.Path(`M ${controlCircle_1_center_point.x} ${controlCircle_1_center_point.y} C ${controlCircle_1_sub_center_point.x} ${controlCircle_1_sub_center_point.y}, ${controlCircle_2_sub_1_center_point.x} ${controlCircle_2_sub_1_center_point.y}, ${controlCircle_2_center_point.x} ${controlCircle_2_center_point.y} S ${controlCircle_3_sub_center_point.x} ${controlCircle_3_sub_center_point.y} ${controlCircle_3_center_point.x} ${controlCircle_3_center_point.y}`, {
      id: "bezierTextCurve",
      fill: "transparent",
      stroke: "#60ce75",
      strokeWidth: 1,
      hasBorders: false,
      hasControls: false,
      selectable: false
    });
    controlCircle_1_sub_line.set({
      x1: controlCircle_1_center_point.x,
      y1: controlCircle_1_center_point.y,
      x2: controlCircle_1_sub_center_point.x,
      y2: controlCircle_1_sub_center_point.y,
      originX: "center",
      originY: "center",
    });

    // calc besier length;
    // const bezierLength = cubicBezierLength(controlCircle_1_center_point, controlCircle_1_sub_center_point, controlCircle_3_sub_center_point, controlCircle_3_center_point, numSegments);
    pathStartOffset = Math.abs(Math.abs(controlCircle_3_center_point.x - controlCircle_1_center_point.x) / 2 - textWidth / 2);
    // pathStartOffset = Math.abs(Math.abs(controlCircle_2_center_point.x - controlCircle_1_center_point.x) - textWidth / 2);
    target.set({
      path: bezierCurve,
      pathAlign,
      pathSide,
      pathStartOffset,
      left: bezierCurve.left,    
      top: bezierCurve.top,
    });
    canvas.requestRenderAll();
  }
  // handle control circle sub 1 moving;
  function handleControlCircleSub1Moving() {
    controlCircle_1_sub_offset = {
      x: controlCircle_1_sub.left - controlCircle_1.left,
      y: controlCircle_1_sub.top - controlCircle_1.top
    };
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    controlCircle_1_sub_center_point = controlCircle_1_sub.getCenterPoint();
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    controlCircle_2_sub_1_center_point = controlCircle_2_sub_1.getCenterPoint();
    controlCircle_2_sub_2_center_point = controlCircle_2_sub_2.getCenterPoint();
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    controlCircle_3_sub_center_point = controlCircle_3_sub.getCenterPoint();

    bezierCurve = new fabric.Path(`M ${controlCircle_1_center_point.x} ${controlCircle_1_center_point.y} C ${controlCircle_1_sub_center_point.x} ${controlCircle_1_sub_center_point.y}, ${controlCircle_2_sub_1_center_point.x} ${controlCircle_2_sub_1_center_point.y}, ${controlCircle_2_center_point.x} ${controlCircle_2_center_point.y} S ${controlCircle_3_sub_center_point.x} ${controlCircle_3_sub_center_point.y} ${controlCircle_3_center_point.x} ${controlCircle_3_center_point.y}`, {
      id: "bezierTextCurve",
      fill: "transparent",
      stroke: "#60ce75",
      strokeWidth: 1,
      hasBorders: false,
      hasControls: false,
      selectable: false,
    });
    controlCircle_1_sub_line.set({
      x1: controlCircle_1_center_point.x,
      y1: controlCircle_1_center_point.y,
      x2: controlCircle_1_sub_center_point.x,
      y2: controlCircle_1_sub_center_point.y,
      originX: "center",
      originY: "center",
    });
    target.set({
      path: bezierCurve,
      pathAlign,
      pathSide,
      pathStartOffset,
      left: bezierCurve.left,
      top: bezierCurve.top,
    });
    canvas.requestRenderAll();
  }
  // handle control circle 2 moving;
  function handleControlCircle2Moving() {
    controlCircle_2_sub_1.set({
      left: controlCircle_2.left + controlCircle_2_sub_1_offset.x,
      top: controlCircle_2.top + controlCircle_2_sub_1_offset.y
    });
    controlCircle_2_sub_2.set({
      left: controlCircle_2.left + controlCircle_2_sub_2_offset.x,
      top: controlCircle_2.top + controlCircle_2_sub_2_offset.y
    });
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    controlCircle_1_sub_center_point = controlCircle_1_sub.getCenterPoint();
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    controlCircle_2_sub_1_center_point = controlCircle_2_sub_1.getCenterPoint();
    controlCircle_2_sub_2_center_point = controlCircle_2_sub_2.getCenterPoint();
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    controlCircle_3_sub_center_point = controlCircle_3_sub.getCenterPoint();

    bezierCurve = new fabric.Path(`M ${controlCircle_1_center_point.x} ${controlCircle_1_center_point.y} C ${controlCircle_1_sub_center_point.x} ${controlCircle_1_sub_center_point.y}, ${controlCircle_2_sub_1_center_point.x} ${controlCircle_2_sub_1_center_point.y}, ${controlCircle_2_center_point.x} ${controlCircle_2_center_point.y} S ${controlCircle_3_sub_center_point.x} ${controlCircle_3_sub_center_point.y} ${controlCircle_3_center_point.x} ${controlCircle_3_center_point.y}`, {
      id: "bezierTextCurve",
      fill: "transparent",
      stroke: "#60ce75",
      strokeWidth: 1,
      hasBorders: false,
      hasControls: false,
      selectable: false,
    });
    controlCircle_2_sub_line_1.set({
      x1: controlCircle_2_center_point.x,
      y1: controlCircle_2_center_point.y,
      x2: controlCircle_2_sub_1_center_point.x,
      y2: controlCircle_2_sub_1_center_point.y,
      originX: "center",
      originY: "center",
    });
    controlCircle_2_sub_line_2.set({
      x1: controlCircle_2_center_point.x,
      y1: controlCircle_2_center_point.y,
      x2: controlCircle_2_sub_2_center_point.x,
      y2: controlCircle_2_sub_2_center_point.y,
      originX: "center",
      originY: "center",
    });
    pathStartOffset = Math.abs(Math.abs(controlCircle_3_center_point.x - controlCircle_1_center_point.x) / 2 - textWidth / 2);
    target.set({
      path: bezierCurve,
      pathAlign,
      pathSide,
      pathStartOffset,
      left: bezierCurve.left,
      top: bezierCurve.top,
    });
    canvas.requestRenderAll();
  }
  // handle control circle 2 sub 1 moving;
  function handleControlCirle2Sub1Moving() {
    controlCircle_2_sub_1_offset = {
      x: controlCircle_2_sub_1.left - controlCircle_2.left,
      y: controlCircle_2_sub_1.top - controlCircle_2.top
    };
    controlCircle_2_sub_2.set({
      left: controlCircle_2_sub_1.left - controlCircle_2_sub_1_offset.x * 2,
      top: controlCircle_2_sub_1.top - controlCircle_2_sub_1_offset.y * 2
    });
    controlCircle_2_sub_2_offset = {
      x: controlCircle_2_sub_2.left - controlCircle_2.left,
      y: controlCircle_2_sub_2.top - controlCircle_2.top
    };
    controlCircle_2_sub_1_center_point = controlCircle_2_sub_1.getCenterPoint();
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    controlCircle_2_sub_2_center_point = controlCircle_2_sub_2.getCenterPoint();
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    controlCircle_1_sub_center_point = controlCircle_1_sub.getCenterPoint();
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    controlCircle_3_sub_center_point = controlCircle_3_sub.getCenterPoint();

    bezierCurve = new fabric.Path(`M ${controlCircle_1_center_point.x} ${controlCircle_1_center_point.y} C ${controlCircle_1_sub_center_point.x} ${controlCircle_1_sub_center_point.y}, ${controlCircle_2_sub_1_center_point.x} ${controlCircle_2_sub_1_center_point.y}, ${controlCircle_2_center_point.x} ${controlCircle_2_center_point.y} S ${controlCircle_3_sub_center_point.x} ${controlCircle_3_sub_center_point.y} ${controlCircle_3_center_point.x} ${controlCircle_3_center_point.y}`, {
      id: "bezierTextCurve",
      fill: "transparent",
      stroke: "#60ce75",
      strokeWidth: 1,
      hasBorders: false,
      hasControls: false,
      selectable: false,
    });
    controlCircle_2_sub_line_1.set({
      x1: controlCircle_2_center_point.x,
      y1: controlCircle_2_center_point.y,
      x2: controlCircle_2_sub_1_center_point.x,
      y2: controlCircle_2_sub_1_center_point.y,
      originX: "center",
      originY: "center",
    });
    controlCircle_2_sub_line_2.set({
      x1: controlCircle_2_center_point.x,
      y1: controlCircle_2_center_point.y,
      x2: controlCircle_2_sub_2_center_point.x,
      y2: controlCircle_2_sub_2_center_point.y,
      originX: "center",
      originY: "center",
    });
    pathStartOffset = Math.abs(Math.abs(controlCircle_3_center_point.x - controlCircle_1_center_point.x) / 2 - textWidth / 2);
    // #region handle bezier text;
    target.set({
      path: bezierCurve,
      pathAlign,
      pathSide,
      pathStartOffset,
      left: bezierCurve.left,
      top: bezierCurve.top,
    });
    canvas.requestRenderAll();
  }
  // handle control circle 2 sub 2 moving;
  function handleControlCirle2Sub2Moving() {
    controlCircle_2_sub_2_offset = {
      x: controlCircle_2_sub_2.left - controlCircle_2.left,
      y: controlCircle_2_sub_2.top - controlCircle_2.top
    };
    controlCircle_2_sub_1.set({
      left: controlCircle_2_sub_2.left - controlCircle_2_sub_2_offset.x * 2,
      top: controlCircle_2_sub_2.top - controlCircle_2_sub_2_offset.y * 2
    });
    controlCircle_2_sub_1_offset = {
      x: controlCircle_2_sub_1.left - controlCircle_2.left,
      y: controlCircle_2_sub_1.top - controlCircle_2.top
    };

    controlCircle_2_sub_1_center_point = controlCircle_2_sub_1.getCenterPoint();
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    controlCircle_2_sub_2_center_point = controlCircle_2_sub_2.getCenterPoint();
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    controlCircle_1_sub_center_point = controlCircle_1_sub.getCenterPoint();
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    controlCircle_3_sub_center_point = controlCircle_3_sub.getCenterPoint();

    bezierCurve = new fabric.Path(`M ${controlCircle_1_center_point.x} ${controlCircle_1_center_point.y} C ${controlCircle_1_sub_center_point.x} ${controlCircle_1_sub_center_point.y}, ${controlCircle_2_sub_1_center_point.x} ${controlCircle_2_sub_1_center_point.y}, ${controlCircle_2_center_point.x} ${controlCircle_2_center_point.y} S ${controlCircle_3_sub_center_point.x} ${controlCircle_3_sub_center_point.y} ${controlCircle_3_center_point.x} ${controlCircle_3_center_point.y}`, {
      id: "bezierTextCurve",
      fill: "transparent",
      stroke: "#60ce75",
      strokeWidth: 1,
      hasBorders: false,
      hasControls: false,
      selectable: false,
    });
    controlCircle_2_sub_line_1.set({
      x1: controlCircle_2_center_point.x,
      y1: controlCircle_2_center_point.y,
      x2: controlCircle_2_sub_1_center_point.x,
      y2: controlCircle_2_sub_1_center_point.y,
      originX: "center",
      originY: "center",
    });
    controlCircle_2_sub_line_2.set({
      x1: controlCircle_2_center_point.x,
      y1: controlCircle_2_center_point.y,
      x2: controlCircle_2_sub_2_center_point.x,
      y2: controlCircle_2_sub_2_center_point.y,
      originX: "center",
      originY: "center",
    });
    pathStartOffset = Math.abs(Math.abs(controlCircle_3_center_point.x - controlCircle_1_center_point.x) / 2 - textWidth / 2);
    target.set({
      path: bezierCurve,
      pathAlign,
      pathSide,
      pathStartOffset,
      left: bezierCurve.left,
      top: bezierCurve.top,
    });
    canvas.requestRenderAll();
  }
  // handle control circle 3 moving;
  function handleControlCircle3Moving() {
    controlCircle_3_sub.set({
      left: controlCircle_3.left + controlCircle_3_sub_offset.x,
      top: controlCircle_3.top + controlCircle_3_sub_offset.y
    });
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    controlCircle_1_sub_center_point = controlCircle_1_sub.getCenterPoint();
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    controlCircle_2_sub_1_center_point = controlCircle_2_sub_1.getCenterPoint();
    controlCircle_2_sub_2_center_point = controlCircle_2_sub_2.getCenterPoint();
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    controlCircle_3_sub_center_point = controlCircle_3_sub.getCenterPoint();

    bezierCurve = new fabric.Path(`M ${controlCircle_1_center_point.x} ${controlCircle_1_center_point.y} C ${controlCircle_1_sub_center_point.x} ${controlCircle_1_sub_center_point.y}, ${controlCircle_2_sub_1_center_point.x} ${controlCircle_2_sub_1_center_point.y}, ${controlCircle_2_center_point.x} ${controlCircle_2_center_point.y} S ${controlCircle_3_sub_center_point.x} ${controlCircle_3_sub_center_point.y} ${controlCircle_3_center_point.x} ${controlCircle_3_center_point.y}`, {
      id: "bezierTextCurve",
      fill: "transparent",
      stroke: "#60ce75",
      strokeWidth: 1,
      hasBorders: false,
      hasControls: false,
      selectable: false,
    });
    controlCircle_3_sub_line.set({
      x1: controlCircle_3_center_point.x,
      y1: controlCircle_3_center_point.y,
      x2: controlCircle_3_sub_center_point.x,
      y2: controlCircle_3_sub_center_point.y,
      originX: "center",
      originY: "center",
    });
    pathStartOffset = Math.abs(Math.abs(controlCircle_3_center_point.x - controlCircle_1_center_point.x) / 2 - textWidth / 2);
    // #region handle bezier text;
    target.set({
      path: bezierCurve,
      pathAlign,
      pathSide,
      pathStartOffset,
      left: bezierCurve.left,
      top: bezierCurve.top,
    });
    canvas.requestRenderAll();
  }
  // handle control circle 3 sub 1 moving;
  function handleControlCircle3Sub1Moving() {
    controlCircle_3_sub_offset = {
      x: controlCircle_3_sub.left - controlCircle_3.left,
      y: controlCircle_3_sub.top - controlCircle_3.top
    };
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    controlCircle_1_sub_center_point = controlCircle_1_sub.getCenterPoint();
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    controlCircle_2_sub_1_center_point = controlCircle_2_sub_1.getCenterPoint();
    controlCircle_2_sub_2_center_point = controlCircle_2_sub_2.getCenterPoint();
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    controlCircle_3_sub_center_point = controlCircle_3_sub.getCenterPoint();
    bezierCurve = new fabric.Path(`M ${controlCircle_1_center_point.x} ${controlCircle_1_center_point.y} C ${controlCircle_1_sub_center_point.x} ${controlCircle_1_sub_center_point.y}, ${controlCircle_2_sub_1_center_point.x} ${controlCircle_2_sub_1_center_point.y}, ${controlCircle_2_center_point.x} ${controlCircle_2_center_point.y} S ${controlCircle_3_sub_center_point.x} ${controlCircle_3_sub_center_point.y} ${controlCircle_3_center_point.x} ${controlCircle_3_center_point.y}`, {
      id: "bezierTextCurve",
      fill: "transparent",
      stroke: "#60ce75",
      strokeWidth: 1,
      hasBorders: false,
      hasControls: false,
      selectable: false,
    });
    controlCircle_3_sub_line.set({
      x1: controlCircle_3_center_point.x,
      y1: controlCircle_3_center_point.y,
      x2: controlCircle_3_sub_center_point.x,
      y2: controlCircle_3_sub_center_point.y,
      originX: "center",
      originY: "center",
    });
    // #region handle bezier text;
    target.set({
      path: bezierCurve,
      pathAlign,
      pathSide,
      pathStartOffset,
      left: bezierCurve.left,
      top: bezierCurve.top,
    });
    canvas.requestRenderAll();
  };

  // reset canvas zoom;
  function resetCanvasZoom() {
    const zoom = canvas.getZoom();
    const tempPoint = { x: 0, y: 0 };
    canvas.zoomToPoint(tempPoint, zoom);
  }
}

// utils;
function setObjectControlsVisibility(flag: boolean, objects: fabric.Object[]) {
  objects.forEach((object) => {
    object.setControlsVisibility({
      mtr: flag
    });

  });
}