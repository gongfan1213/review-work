import { fabric } from "fabric";
import { ellipsePath } from "./path";
import { CircleControlId } from "../types";
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { TextStatus } from 'src/templates/2dEditor/core/eventbus/types/text';

export function circleText(target: fabric.Object) {
  if (!target) return;
  const canvas = target.canvas as any; // fabric.Canvas;
  if (!canvas) return;
  // @ts-ignore;
  const textWidth = target.__charBounds[0].reduce((pre, current) => pre + current.width, 0);
  const pathAlign = 'center';
  const pathSide = 'right';
  const circleCursor = "crosshair"; // hover cursor;
  const circleRadius = 6; // control circle radius;
  const controlCircleMinOffet = 10;
  let pathStartOffset = textWidth / 2;
  let circlePath = ellipsePath(Number(target.width));
  let circleObject: fabric.Object | null = null;
  let controlCircle_1: fabric.Object | null = null;
  let controlCircle_2: fabric.Object | null = null;
  let controlCircle_3: fabric.Object | null = null;
  let controlCircle_4: fabric.Object | null = null;
  let controlCircle_1_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_2_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_3_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_4_center_point: { x: number, y: number } = { x: 0, y: 0 };
  const circleObjectCommonAttr = {
    lockRotation: true,
    lockMovementX: true,
    lockMovementY: true,
    strokeWidth: 1,
    stroke: "#60ce75",
    strokeUniform: true,
    fill: "transparent",
    visible: true,
  };
  // ;
  circleObject = new fabric.Path(circlePath, {
    id: CircleControlId.ControlCircle,
    left: target.left,
    top: target.top,
    pathAlign: 'center',
    ...circleObjectCommonAttr,
  });
  // draw finish, clear control circle;
  const clear = () => {
    targetEvented(true);
    // @ts-ignore
    !!target.path && target.path.set('opacity', 0);
    canvas.getObjects()
      .filter((obj: fabric.Object) => (obj as any).id === CircleControlId.ControlCircle)
      .forEach((obj: fabric.Object) => canvas.remove(obj));
    canvas.renderAll();
    eventBus.emit(TextStatus.UnderTransform, false);
    canvas.off("mouse:down", mouseDownClick);
  }

  canvas.on("mouse:down", mouseDownClick);

   //todo: 需要补充originX=right的情况
  let circleObjectCenterPoint
  if(target.originX === 'center'){
    circleObjectCenterPoint = new fabric.Point(target.left, target.top);
  }else{
    circleObjectCenterPoint = circleObject.getCenterPoint(); // 四个control circle跟随其变化;
  }
  
  circleObject.setControlsVisibility({
    mt: false,
    mb: false,
    ml: false,
    mr: false,
    mtr: false,
  });
  // text transform start;
  let targetEvented = (flag: boolean) => {
    target.set({
      hasBorders: flag,
    });
    target.set({
      cornerSize: flag ? 8 : 0,
    });
    target.setControlsVisibility({
      mtr: flag
    });
  };
  targetEvented(false);

  const circleScaleWidth = circleObject.width * target.scaleX;
  const circleScaleHeight = circleObject.height * target.scaleY;

  target.set({
    path: circleObject,
    pathAlign: pathAlign,
    pathSide: pathSide,
    pathStartOffset: pathStartOffset
  });
  target.setCoords();
  // top;
  controlCircle_1 = new fabric.Circle({
    id: CircleControlId.ControlCircle,
    radius: circleRadius,
    fill: "#ffffff",
    stroke: "#60ce75",
    strokeWidth: 1,
    originX: "center",
    originY: "center",
    // left: circleObjectCenterPoint.x,
    // top: circleObjectCenterPoint.y - circleObject.height / 2 - circleRadius / 2,
    left: circleObjectCenterPoint.x,
    top: circleObjectCenterPoint.y - circleScaleHeight / 2- circleRadius / 2,
    hasControls: false,
    hasBorders: false,
    hoverCursor: circleCursor,
    moveCursor: circleCursor,
    lockMovementX: true,
  });
  // right;
  controlCircle_2 = new fabric.Circle({
    id: CircleControlId.ControlCircle,
    radius: circleRadius,
    fill: "#ffffff",
    stroke: "#60ce75",
    strokeWidth: 1,
    originX: "center",
    originY: "center",
    // left: circleObjectCenterPoint.x + circleObject.width / 2 + circleRadius / 2,
    // top: circleObjectCenterPoint.y,
    left: circleObjectCenterPoint.x + circleScaleWidth / 2 + circleRadius / 2,
    top: circleObjectCenterPoint.y,
    hasControls: false,
    hasBorders: false,
    hoverCursor: circleCursor,
    moveCursor: circleCursor,
    lockMovementY: true,
  });
  // bottom;
  controlCircle_3 = new fabric.Circle({
    id: CircleControlId.ControlCircle,
    radius: circleRadius,
    fill: "#ffffff",
    stroke: "#60ce75",
    strokeWidth: 1,
    originX: "center",
    originY: "center",
    // left: circleObjectCenterPoint.x,
    // top: circleObjectCenterPoint.y + circleObject.height / 2 + circleRadius / 2,
    left: circleObjectCenterPoint.x,
    top: circleObjectCenterPoint.y + circleScaleHeight / 2 + circleRadius / 2,
    hasControls: false,
    hasBorders: false,
    hoverCursor: circleCursor,
    moveCursor: circleCursor,
    lockMovementX: true,
  });
  // left;
  controlCircle_4 = new fabric.Circle({
    id: CircleControlId.ControlCircle,
    radius: circleRadius,
    fill: "#ffffff",
    stroke: "#60ce75",
    strokeWidth: 1,
    originX: "center",
    originY: "center",
    // left: circleObjectCenterPoint.x - circleObject.width / 2 - circleRadius / 2,
    // top: circleObjectCenterPoint.y,
    left: circleObjectCenterPoint.x - circleScaleWidth / 2 - circleRadius / 2,
    top: circleObjectCenterPoint.y,
    hasControls: false,
    hasBorders: false,
    hoverCursor: circleCursor,
    moveCursor: circleCursor,
    lockMovementY: true,
  });
  // #region hover;
  controlCircle_1.on('mouseover', () => {
    controlCircle_1.set({
      fill: '#60ce75',
      shadow: {
        color: 'rgba(0,0,0,0.2)',
        blur: 5,
        offsetX: 0,
        offsetY: 0
      }
    });
    canvas.renderAll();
  });
  controlCircle_1.on('mouseout', () => {
    controlCircle_1.set({
      fill: '#ffffff',
      shadow: null
    });
    canvas.renderAll();
  });
  // ;
  controlCircle_2.on('mouseover', () => {
    controlCircle_2.set({
      fill: '#60ce75',
      shadow: {
        color: 'rgba(0,0,0,0.2)',
        blur: 5,
        offsetX: 0,
        offsetY: 0
      }
    });
    canvas.renderAll();
  });
  controlCircle_2.on('mouseout', () => {
    controlCircle_2.set({
      fill: '#ffffff',
      shadow: null
    });
    canvas.renderAll();
  });
  // ;
  controlCircle_3.on('mouseover', () => {
    controlCircle_3.set({
      fill: '#60ce75',
      shadow: {
        color: 'rgba(0,0,0,0.2)',
        blur: 5,
        offsetX: 0,
        offsetY: 0
      }
    });
    canvas.renderAll();
  });
  controlCircle_3.on('mouseout', () => {
    controlCircle_3.set({
      fill: '#ffffff',
      shadow: null
    });
    canvas.renderAll();
  });
  // ;
  controlCircle_4.on('mouseover', () => {
    controlCircle_4.set({
      fill: '#60ce75',
      shadow: {
        color: 'rgba(0,0,0,0.2)',
        blur: 5,
        offsetX: 0,
        offsetY: 0
      }
    });
    canvas.renderAll();
  });
  controlCircle_4.on('mouseout', () => {
    controlCircle_4.set({
      fill: '#ffffff',
      shadow: null
    });
    canvas.renderAll();
  });
  // #endregion ;
  controlCircle_1.setControlVisible("mtr", false);
  controlCircle_2.setControlVisible("mtr", false);
  controlCircle_3.setControlVisible("mtr", false);
  controlCircle_4.setControlVisible("mtr", false);
  controlCircle_1_center_point = controlCircle_1.getCenterPoint();
  controlCircle_2_center_point = controlCircle_2.getCenterPoint();
  controlCircle_3_center_point = controlCircle_3.getCenterPoint();
  controlCircle_4_center_point = controlCircle_4.getCenterPoint();
  canvas?.add(controlCircle_1);
  canvas?.add(controlCircle_2);
  canvas?.add(controlCircle_3);
  canvas?.add(controlCircle_4);
  canvas?.renderAll();
  // top control circle moving event;
  controlCircle_1.on("moving", () => {
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    if (controlCircle_1_center_point.y >= controlCircle_3_center_point.y - controlCircleMinOffet) {
      controlCircle_1.set({
        left: controlCircle_3_center_point.x,
        top: controlCircle_3_center_point.y - controlCircleMinOffet,
      });
      return;
    }
    circlePath = ellipsePath((controlCircle_1_center_point.y - controlCircle_3_center_point.y) / target.scaleX);
    circleObject = new fabric.Path(circlePath, {
      id: CircleControlId.ControlCircle,
      ...circleObjectCommonAttr,
    });
    const circleObjectRadius = circleObject.width;
    controlCircle_2.set({
      left: circleObjectCenterPoint.x + circleObjectRadius / 2 * target.scaleX,
      top: circleObjectCenterPoint.y,
    });
    controlCircle_3.set({
      left: circleObjectCenterPoint.x,
      top: circleObjectCenterPoint.y + circleObjectRadius / 2 * target.scaleY,
    });
    controlCircle_4.set({
      left: circleObjectCenterPoint.x - circleObjectRadius / 2 * target.scaleX,
      top: circleObjectCenterPoint.y,
    });
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    controlCircle_4_center_point = controlCircle_4.getCenterPoint();
    target.set({
      path: circleObject,
      pathAlign: pathAlign,
      pathSide: pathSide,
      pathStartOffset: pathStartOffset,
      left: target.originX === 'center' ? circleObjectCenterPoint.x : controlCircle_4_center_point.x,
      top: target.originY === 'center'? circleObjectCenterPoint.y : controlCircle_1_center_point.y,
    });

    const zoom = canvas.getZoom();
    const tempPoint = { x: 0, y: 0 };
    canvas.zoomToPoint(tempPoint, zoom);
    canvas?.renderAll();
  });
  // right control circle moving event;
  controlCircle_2.on("moving", () => {
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    if (controlCircle_2_center_point.x <= controlCircle_4_center_point.x + controlCircleMinOffet) {
      controlCircle_2.set({
        left: controlCircle_4_center_point.x + controlCircleMinOffet,
        top: controlCircle_4_center_point.y,
      });
      return;
    }
    circlePath = ellipsePath((controlCircle_2_center_point.x - controlCircle_4_center_point.x) / target.scaleX);
    circleObject = new fabric.Path(circlePath, {
      id: CircleControlId.ControlCircle,
      ...circleObjectCommonAttr,
    });
    const circleObjectRadius = circleObject.width;
    controlCircle_1.set({
      left: circleObjectCenterPoint.x,
      top: circleObjectCenterPoint.y - circleObjectRadius / 2 * target.scaleX,
    });
    controlCircle_3.set({
      left: circleObjectCenterPoint.x,
      top: circleObjectCenterPoint.y + circleObjectRadius / 2 * target.scaleX,
    });
    controlCircle_4.set({
      left: circleObjectCenterPoint.x - circleObjectRadius / 2 * target.scaleX,
      top: circleObjectCenterPoint.y,
    });
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    controlCircle_4_center_point = controlCircle_4.getCenterPoint();
    target.set({
      path: circleObject,
      pathAlign: pathAlign,
      pathSide: pathSide,
      pathStartOffset: pathStartOffset,
      left: target.originX === 'center' ? circleObjectCenterPoint.x : controlCircle_4_center_point.x,
      top: target.originY === 'center' ? circleObjectCenterPoint.y : controlCircle_1_center_point.y,
    });
    const zoom = canvas.getZoom();
    const tempPoint = { x: 0, y: 0 };
    canvas.zoomToPoint(tempPoint, zoom);
    canvas?.renderAll();
  });
  // bottom control circle moving event;
  controlCircle_3.on("moving", () => {
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    if (controlCircle_3_center_point.y <= controlCircle_1_center_point.y + controlCircleMinOffet) {
      controlCircle_3.set({
        left: controlCircle_1_center_point.x,
        top: controlCircle_1_center_point.y + controlCircleMinOffet,
      });
      return;
    }
    circlePath = ellipsePath((controlCircle_1_center_point.y - controlCircle_3_center_point.y) / target.scaleX);
    circleObject = new fabric.Path(circlePath, {
      id: CircleControlId.ControlCircle,
      ...circleObjectCommonAttr,
    });
    const circleObjectRadius = circleObject.width;
    controlCircle_1.set({
      left: circleObjectCenterPoint.x,
      top: circleObjectCenterPoint.y - circleObjectRadius / 2 * target.scaleY,
    });
    controlCircle_2.set({
      left: circleObjectCenterPoint.x + circleObjectRadius / 2 * target.scaleX,
      top: circleObjectCenterPoint.y,
    });
    controlCircle_4.set({
      left: circleObjectCenterPoint.x - circleObjectRadius / 2 * target.scaleX,
      top: circleObjectCenterPoint.y,
    });
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    controlCircle_4_center_point = controlCircle_4.getCenterPoint();
    target.set({
      path: circleObject,
      pathAlign: pathAlign,
      pathSide: pathSide,
      pathStartOffset: pathStartOffset,
      left: target.originX === 'center' ? circleObjectCenterPoint.x : controlCircle_4_center_point.x,
      top: target.originY === 'center' ? circleObjectCenterPoint.y : controlCircle_1_center_point.y,
    });
    const zoom = canvas.getZoom();
    const tempPoint = { x: 0, y: 0 };
    canvas.zoomToPoint(tempPoint, zoom);
    canvas?.renderAll();
  });
  // left control circle moving event;
  controlCircle_4.on("moving", () => {
    controlCircle_4_center_point = controlCircle_4.getCenterPoint();
    if (controlCircle_4_center_point.x >= controlCircle_2_center_point.x - controlCircleMinOffet) {
      controlCircle_4.set({
        left: controlCircle_2_center_point.x - controlCircleMinOffet,
        top: controlCircle_2_center_point.y,
      });
      return;
    }
    circlePath = ellipsePath((controlCircle_2_center_point.x - controlCircle_4_center_point.x) / target.scaleX);
    circleObject = new fabric.Path(circlePath, {
      id: CircleControlId.ControlCircle,
      ...circleObjectCommonAttr,
    });
    const circleObjectRadius = circleObject.width;
    controlCircle_1.set({
      left: circleObjectCenterPoint.x,
      top: circleObjectCenterPoint.y - circleObjectRadius / 2 * target.scaleY,
    });
    controlCircle_2.set({
      left: circleObjectCenterPoint.x + circleObjectRadius / 2 * target.scaleX,
      top: circleObjectCenterPoint.y,
    });
    controlCircle_3.set({
      left: circleObjectCenterPoint.x,
      top: circleObjectCenterPoint.y + circleObjectRadius / 2 * target.scaleY,
    });
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();
    controlCircle_3_center_point = controlCircle_3.getCenterPoint();
    target.set({
      path: circleObject,
      pathAlign: pathAlign,
      pathSide: pathSide,
      pathStartOffset: pathStartOffset,
      left: target.originX === 'center' ? circleObjectCenterPoint.x : controlCircle_4_center_point.x,
      top: target.originY === 'center' ? circleObjectCenterPoint.y : controlCircle_1_center_point.y,
    });
    const zoom = canvas.getZoom();
    const tempPoint = { x: 0, y: 0 };
    canvas.zoomToPoint(tempPoint, zoom);
    canvas?.renderAll();
  });

  function mouseDownClick(e: fabric.IEvent): void {
    if( e.target ) {
      if(e.target.id.indexOf('ControlCircle') !== -1) return;
      clear();    
      if (e.target.id === target.id) {           
        canvas.setActiveObject(target)       
      } 
    }else{
      clear();
    }    
  }
}

