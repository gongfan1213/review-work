// 圆弧路径
export function ellipsePath(width: number, height?: number) {
  width = Math.abs(width);
  height = Math.abs(height || width);
  const rx = width / 2;
  const ry = height ? height / 2 : rx;
  const path = [
    `M 0 ${-ry}`,
    `A ${rx} ${ry} 0 1 0 0 ${ry}`,
    `A ${rx} ${ry} 0 1 0 0 ${-ry}`,
    `Z`
  ].join(' ');
  return path;
}