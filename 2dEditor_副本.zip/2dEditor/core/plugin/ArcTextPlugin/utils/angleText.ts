/**
 * 直线;
 */
import { fabric } from "fabric";
import { AngleControlId } from "../types";
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { TextStatus } from 'src/templates/2dEditor/core/eventbus/types/text';

export function angleText(target: any) {
  if (!target) return;
  const canvas = target.canvas;
  if (!canvas) return;
  // @ts-ignore;
  const textWidth = target.__charBounds[0].reduce((pre, current) => pre + current.width, 0);
  const pathAlign = "center";
  const pathSide = "center"
  const circleCursor = "crosshair"; // hover cursor;
  const circleRadius = 6;
  let pathStartOffset = 0;
  let lineObject: fabric.Path | null = null;
  let controlCircle_1: fabric.Object | null = null;
  let controlCircle_2: fabric.Object | null = null;
  let controlCircle_1_center_point: { x: number, y: number } = { x: 0, y: 0 };
  let controlCircle_2_center_point: { x: number, y: number } = { x: 0, y: 0 };
  // text transform start;;
  let targetEvented = (flag: boolean) => {
    target.set({
      hasBorders: flag,
    });
    target.set({
      cornerSize: flag ? 8 : 0,
    });
    target.setControlsVisibility({
      mtr: flag
    })
  };
  targetEvented(false);
  // clear control circle, finish transform the text;
  let clear = () => {
    targetEvented(true);
    !!target.path && target.path.set('opacity', 0);
    const controlCircleAndLines = canvas.getObjects()
      .filter((obj: any) => obj.id === AngleControlId.ControlCircle || obj.id === AngleControlId.ControlLine);
    controlCircleAndLines.forEach((obj: any) => canvas.remove(obj));
    eventBus.emit(TextStatus.UnderTransform, false);
    canvas.renderAll();
    canvas.off("mouse:down", mouseDownClick);
  }
  canvas.on("mouse:down", mouseDownClick);
  function mouseDownClick(e: fabric.IEvent): void {
    if( e.target ) {
      if(e.target.id.indexOf('ControlCircle') !== -1) return;
      clear();    
      if (e.target.id === target.id) {           
        canvas.setActiveObject(target)       
      } 
    }else{
      clear();
    }  
  }
  
  let controlCircle_1_left;
  let controlCircle_2_left;

  if (target.originX === 'center') {
    controlCircle_1_left = target.left - target.width / 2 * target.scaleX;
    controlCircle_2_left = target.left + target.width / 2 * target.scaleX - circleRadius / 2;
  } else {
    controlCircle_1_left = target.left;
    controlCircle_2_left = target.left + target.width * target.scaleX - circleRadius / 2;
  }
 
  // #region draw control circle;
  controlCircle_1 = new fabric.Circle({
    id: AngleControlId.ControlCircle,
    radius: circleRadius,
    fill: "#ffffff",
    stroke: "#60ce75",
    strokeWidth: 1,
    left: controlCircle_1_left,
    top: target.top - circleRadius,
    hasControls: false,
    hasBorders: false,
    cornerSize: 0,
    hoverCursor: circleCursor,
    moveCursor: circleCursor,
  });
  controlCircle_2 = new fabric.Circle({
    id: AngleControlId.ControlCircle,
    radius: circleRadius,
    fill: "#ffffff",
    stroke: "#60ce75",
    strokeWidth: 1,
    left: controlCircle_2_left,
    top: target.top - circleRadius,
    hasControls: false,
    hasBorders: false,
    cornerSize: 0,
    hoverCursor: circleCursor,
    moveCursor: circleCursor,
  });

  // control circle hover;
  [controlCircle_1, controlCircle_2].forEach((object: fabric.Object) => {
    object?.on('mouseover', () => {
      object.set({
        fill: '#60ce75',
        shadow: {
          color: 'rgba(0,0,0,0.2)',  // 阴影颜色
          blur: 5,                  // 模糊度
          offsetX: 0,               // X轴偏移
          offsetY: 0                // Y轴偏移
        }
      });
      canvas.renderAll();
    });
    object?.on('mouseout', () => {
      object.set({
        fill: '#ffffff',
        shadow: null
      });
      canvas.renderAll();
    });
  });

  setObjectControlsVisibility(false, [controlCircle_1, controlCircle_2]);
  // ;
  controlCircle_1_center_point = controlCircle_1.getCenterPoint();
  controlCircle_2_center_point = controlCircle_2.getCenterPoint();
  canvas.add(controlCircle_1);
  canvas.add(controlCircle_2);
  // set the control circle zIndex upper to line;
  canvas.bringToFront(controlCircle_1).bringToFront(controlCircle_2);
  // #endregion ;
  // #region draw line;


  const lineObjectPath = `M 0 0 L ${(controlCircle_2_left - controlCircle_1_left) / target.scaleX} 0`;

  lineObject = new fabric.Path(lineObjectPath, {
    fill: "transparent",
    stroke: "#60ce75",
    strokeWidth: 1,
    hasBorders: false,
    hasControls: false,
    selectable: false,
    // left: controlCircle_1_center_point.x,
    // top: controlCircle_1_center_point.y
  });

  target.set({
    path: lineObject,
    pathAlign,
    pathSide,
    pathStartOffset
  });
  canvas.renderAll();
  // #endregion ;
  // #region handle control circle drag and transform the bezier;
  // control circle 1 Moving;
  controlCircle_1.on('moving', (e) => {
    controlCircle_1_center_point = controlCircle_1.getCenterPoint();

    let lineObjectPath;
    if(target.originX === 'center') {
      lineObjectPath = `M 0 0 L ${(controlCircle_2_center_point.x - controlCircle_1_center_point.x) / target.scaleX} ${(controlCircle_2_center_point.y - controlCircle_1_center_point.y) / target.scaleY}`;
    }else{
      lineObjectPath = `M ${controlCircle_1_center_point.x} ${controlCircle_1_center_point.y} L ${controlCircle_2_center_point.x} ${controlCircle_2_center_point.y} Z`;
    }
  
    lineObject = new fabric.Path(lineObjectPath, {
      fill: "transparent",
      stroke: "#60ce75",
      strokeWidth: 1,
      hasBorders: false,
      hasControls: false,
      selectable: false,
    });

    pathStartOffset = Math.abs(Math.abs(controlCircle_2_center_point.x - controlCircle_1_center_point.x) / 2 / target.scaleX - textWidth / 2);

    let objectLeft = target.originX === 'center' ? controlCircle_1_center_point.x + (controlCircle_2_center_point.x - controlCircle_1_center_point.x)/2 : lineObject.left;
    let objectTop = target.originX === 'center' ? controlCircle_1_center_point.y + (controlCircle_2_center_point.y - controlCircle_1_center_point.y)/2 : lineObject.top;
   
    target.set({
      path: lineObject,
      pathAlign,
      pathSide,
      pathStartOffset,
      left: objectLeft,
      top: objectTop,
    });
    canvas.requestRenderAll();
  });
  // control circle 2 Moving;
  controlCircle_2.on('moving', (e) => {
    controlCircle_2_center_point = controlCircle_2.getCenterPoint();

    let lineObjectPath;
    if(target.originX === 'center') {
      lineObjectPath = `M 0 0 L ${(controlCircle_2_center_point.x - controlCircle_1_center_point.x) / target.scaleX} ${(controlCircle_2_center_point.y - controlCircle_1_center_point.y) / target.scaleY}`;
    }else{
      lineObjectPath = `M ${controlCircle_1_center_point.x} ${controlCircle_1_center_point.y} L ${controlCircle_2_center_point.x} ${controlCircle_2_center_point.y} Z`;
    }

    lineObject = new fabric.Path(lineObjectPath, {
      fill: "transparent",
      stroke: "#60ce75",
      strokeWidth: 1,
      hasBorders: false,
      hasControls: false,
      selectable: false,
    });
    pathStartOffset = Math.abs(Math.abs(controlCircle_2_center_point.x - controlCircle_1_center_point.x) / 2 / target.scaleX - textWidth / 2);
    let objectLeft = target.originX === 'center' ? controlCircle_1_center_point.x + (controlCircle_2_center_point.x - controlCircle_1_center_point.x)/2 : lineObject.left;
    let objectTop = target.originX === 'center' ? controlCircle_1_center_point.y + (controlCircle_2_center_point.y - controlCircle_1_center_point.y)/2 : lineObject.top;

    target.set({
      path: lineObject,
      pathAlign,
      pathSide,
      pathStartOffset,
      left: objectLeft,
      top: objectTop,
    });
    canvas.requestRenderAll();
  });
}

// utils;
function setObjectControlsVisibility(flag: boolean, objects: fabric.Object[]) {
  objects.forEach((object) => {
    object.setControlsVisibility({
      mtr: flag
    });
  });
}