export function cubicBezierLength(P0, P1, P2, P3, numSegments) {
  function lerp(a, b, t) {
      return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
  }

  function bezier(t) {
      const A = lerp(P0, P1, t);
      const B = lerp(P1, P2, t);
      const C = lerp(P2, P3, t);
      const D = lerp(A, B, t);
      const E = lerp(B, C, t);
      return lerp(D, E, t);
  }

  function distance(P, Q) {
      const dx = Q.x - P.x;
      const dy = Q.y - P.y;
      return Math.sqrt(dx * dx + dy * dy);
  }

  let length = 0;
  let prevPoint = P0;
  for (let i = 1; i <= numSegments; i++) {
      const t = i / numSegments;
      const currentPoint = bezier(t);
      length += distance(prevPoint, currentPoint);
      prevPoint = currentPoint;
  }

  return length;
}
