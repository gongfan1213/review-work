import { fabric } from "fabric";
import { TransformType } from "./types";
import { bezierText } from "./utils/bezierText";
import { circleText } from "./utils/circleText";
import { angleText } from "./utils/angleText";
import { bezier2Text } from "./utils/bezier2Text";
import { BezierControlId, CircleControlId, AngleControlId } from "./types";
import { CustomKey, CustomObjectType, FabricObjectType } from "src/templates/2dEditor/cons/2dEditorCons";
import eventBus from "src/templates/2dEditor/core/eventbus";
import { TextStatus } from "src/templates/2dEditor/core/eventbus/types/text";
import { Textbox } from "src/templates/2dEditor/core/plugin/TextPlugin/Textbox";

export class ArcText extends fabric.Text {
  public transformType?: TransformType;
  public reTransform?: boolean;
  constructor(text: string, options?: any) {
    super(text, options);
    this.init(options);
    this.on("mousedblclick", this.doubleClickHandler.bind(this));
  }

  public get _transformType() {
    return this.transformType;
  }
  public set _transformType(value) {
    this.transformType = value;
    'path' in this && delete this.path;
    'pathAlign' in this && delete this.pathAlign;
    'pathSide' in this && delete this.pathSide;
    this.clearTransformControl();
    this.set('padding', this.fontSize / 2 * this.scaleY);
    if(this.height < 5){
      this.height = 5;
    }
    this.canvas?.renderAll();

    if (!!value) {
      eventBus.emit(TextStatus.UnderTransform, true);
      switch (value) {
        case TransformType.Circle:
          circleText(this);
          break;
        case TransformType.Custom:
          bezierText(this);
          break;
        case TransformType.Angle:
          angleText(this);
          break;
        case TransformType.Bezier2:
          bezier2Text(this);
          break;
      }
    }
    // transform text to Textbox;
    // else {     
      // add Textbox and delete transform text;
      // const originTextObject = new Textbox(this.text, {
      //   ...(this.toJSON(CustomKey.FontUrl)),
      //   opacity: 1,
      //   selectable: true,
      //   evented: true,
      // });
      // this.canvas?.add(originTextObject);
      // this.canvas?.remove(this);
      // this.canvas?.renderAll();
    // }
  }

  public init(options: any) {
    this.setControlsVisibility({
      mt: false,
      mb: false,
      ml: false,
      mr: false,
    });
    
    this.set({
      padding: options.fontSize / 2 * options.scaleY,
      type: FabricObjectType.Text,
      // 用于储存transform control circle;
      // @ts-ignore;
      _transformTextControlPoint: {},
    });
  }

  // handle db click;
  public doubleClickHandler(e: any) {
    const textBoxOption = this.toJSON(CustomKey.FontUrl)
    if (!this.canvas || !e.target || e.target !== e.target) return;
    //@ts-ignore;
    this.set({
      opacity: 0,
      selectable: false,
      evented: false,
    });

    //todo: 需要补充originX=right的情况
    const originTextObject = new Textbox(this.text,{
      opacity: 1,
      selectable: true,
      evented: true,
      fontSize: textBoxOption.fontSize,
      hasBorders: true,
      hasControls: true,
      textAlign: "justify-center",
      left: textBoxOption.originX == 'center' ? textBoxOption.left - textBoxOption.width / 2 : textBoxOption.left,
      ineHeight: textBoxOption.ineHeight,
      top: textBoxOption.originY == 'center' ? textBoxOption.top - textBoxOption.height / 2 : textBoxOption.top,
      width: textBoxOption.width
    });

    delete originTextObject.path;
    originTextObject.on("changed", () => {
      //@ts-ignore;
      this.set('text', originTextObject?.text);
    });
    originTextObject.on("editing:exited", () => {
      this.handleEditTextExit(originTextObject);
    });
    originTextObject.on("deselected", () => {
      this.handleEditTextExit(originTextObject);
    });
    originTextObject.set({
      lockMovementX: true,
      lockMovementY: true,
      lockRotation: true,
      lockScalingX: true,
      lockScalingY: true,
    });
    originTextObject.cornerSize = 0;
    originTextObject.setControlsVisibility({
      mtr: false
    });
    
    this.canvas.add(originTextObject);
    this.canvas.setActiveObject(originTextObject)
    this.canvas.renderAll();
  }

  public handleEditTextExit(originTextObject: fabric.Object) {
    if (!this.canvas) return;
    //@ts-ignore;
    this.set({
      opacity: 1,
      selectable: true,
      evented: true,
    });
    !!originTextObject && this.canvas.remove(originTextObject);
    this.canvas.setActiveObject(this);
    this.canvas.renderAll();
  }

  public clearTransformControl() {
    if (!this.canvas) return;
    this.canvas.getObjects()
      .filter((obj: any) => obj.id === BezierControlId.ControlCircle || obj.id === BezierControlId.ControlLine || obj.id === CircleControlId.ControlCircle || obj.id === AngleControlId.ControlCircle || obj.id === AngleControlId.ControlLine)
      .forEach((obj: any) => this.canvas?.remove(obj));
  }
}
