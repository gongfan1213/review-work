import { ArcText } from "./ArcText";
import { fabric } from "fabric";
import { v4 as uuid } from 'uuid';
import Editor from '../../core';
type IEditor = Editor;

class ArcTextPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  static pluginName = 'ArcTextPlugin';
  static apis = ['addArcText'];
  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
  }

  addArcText(textValue = "Your Text Here", options: any = {}) {
    const textObject = new ArcText(textValue, options);
    this.canvas.add(textObject);
    this.canvas.setActiveObject(textObject);
    this.canvas.renderAll();
  };
}
export default ArcTextPlugin;


