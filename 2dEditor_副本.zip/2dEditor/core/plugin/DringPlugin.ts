/*
 * @Description: 拖拽插件
 */

import { CustomKey, WorkspaceID } from '../../cons/2dEditorCons';
import Editor from '../core';
type IEditor = Editor;

declare type ExtCanvas = fabric.Canvas & {
  isDragging: boolean;
  lastPosX: number;
  lastPosY: number;
};

class DringPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  public defautOption = {};
  static pluginName = 'DringPlugin';
  static events = ['startDring', 'endDring'];
  static apis = ['startDring', 'endDring'];
  public hotkeys: string[] = ['space', 'esc'];
  dragMode = false;
  private lastTouch2Positions: { x: number; y: number } | null = null;
  private wheelTimeout: number | null = null;
  private handleWheelDring: boolean = false;

  constructor(canvas: fabric.Canvas, editor: IEditor, option: any) {
    this.canvas = canvas;
    this.editor = editor;
    this.dragMode = false;
    this.handleMouseDown = this.handleMouseDown.bind(this);
    this.handleMouseMove = this.handleMouseMove.bind(this);
    this.handleMouseUp = this.handleMouseUp.bind(this);
    this.init();
  }
  init() {
    this._initDring();
  }

  startDring() {
    this.dragMode = true;
    this.canvas.defaultCursor = 'grab';
    this.editor.emit('startDring');
    this.canvas.discardActiveObject();
    this.canvas.getObjects().forEach((object: fabric.Object) => {
      object.set({
        selectable: false,
        evented: false,
      });
    });
    this.canvas.renderAll();
  }
  endDring() {
    this.dragMode = false;
    this.canvas.defaultCursor = 'default';
    this.canvas.hoverCursor = 'default';
    // @ts-ignore;
    this.canvas.isDragging = false;
    this.editor.emit('endDring');
    this.canvas.discardActiveObject();
    this.canvas
      .getObjects()
      .filter(
        (object: fabric.Object) => !!(object as any).id && !~(object as any).id.indexOf(WorkspaceID.WorkspaceCavas),
      )
      .forEach((object: fabric.Object) => {
        if (!object._isLock) {
          object.set({
            selectable: true,
            evented: true,
          });
        }
      });
    this.canvas.renderAll();
  }

  // 拖拽模式;
  _initDring() {
    this.setupEventListeners();
  }

  handleMouseDown(opt: any) {
    const evt = opt.e;
    // console.log('====handleWheel=handleMouseDown====', this.dragMode, this.handleWheelDring);
    if (this.dragMode && !this.handleWheelDring) {
      this.handleMouseDownAction(opt, this.canvas);
      this.handleMouseDownAction(opt, this.editor.canvas_bg);
    }
  }
  handleMouseDownAction(opt: any, canvas?: fabric.Canvas) {
    if (!canvas) return;
    const evt = opt.e;
    canvas.defaultCursor = 'grabbing';
    canvas.discardActiveObject();
    this._setDring(); // 确保这个方法在类中定义
    canvas.selection = false;
    //@ts-ignore
    canvas.isDragging = true;
    //@ts-ignore
    canvas.lastPosX = evt.clientX;
    //@ts-ignore
    canvas.lastPosY = evt.clientY;
    canvas.requestRenderAll();
  }

  handleMouseMove(opt: any) {
    //@ts-ignore
    // console.log('=======handleMouseMove====', this.canvas.isDragging, this.handleWheelDring);
    if (this.canvas.isDragging && !this.handleWheelDring) {
      this.handleMouseMoveAction(opt.e.clientX, opt.e.clientY, this.canvas);
      this.handleMouseMoveAction(opt.e.clientX, opt.e.clientY, this.editor.canvas_bg);
    }
  }

  handleMouseMoveAction(optX: number, optY: number, canvas?: fabric.Canvas) {
    if (!canvas) return;
    canvas.discardActiveObject();
    canvas.defaultCursor = 'grabbing';
    // const { e } = opt;
    if (!canvas.viewportTransform) return;
    const vpt = canvas.viewportTransform;
    //@ts-ignore
    vpt[4] += optX - canvas.lastPosX;
    //@ts-ignore
    vpt[5] += optY - canvas.lastPosY;
    //@ts-ignore
    canvas.lastPosX = optX;
    //@ts-ignore
    canvas.lastPosY = optY;
    canvas.requestRenderAll();
  }

  handleMouseUp() {
    //  console.log("====handleMouseUp==")
    if (!this.canvas.viewportTransform) return;
    if (!this.dragMode) return;
    this.editor.setViewportTransform(this.canvas.viewportTransform);
    //@ts-ignore
    this.handleMouseUpAction(this.canvas);
    this.handleMouseUpAction(this.editor.canvas_bg);
  }

  handleMouseUpAction(canvas?: fabric.Canvas) {
    if (!canvas) return;
    //@ts-ignore
    canvas.isDragging = false;
    canvas.selection = true;
    canvas.defaultCursor = 'grab';
    canvas.requestRenderAll();
  }

  private handleWheel = (opt: any) => {
    if (!this) return;
    if (!this.dragMode) {
      this.startDring();
      this.handleMouseDown(opt);
      this.lastTouch2Positions = { x: opt.e.clientX, y: opt.e.clientY };
    }
    if (this.canvas.isDragging) {
      var optX = this.lastTouch2Positions!.x - opt.e.deltaX;
      var optY = this.lastTouch2Positions!.y - opt.e.deltaY;
      this.lastTouch2Positions = { x: optX, y: optY };
      // console.log('====handleWheel=opt.e.ctrlKey====', optX, opt.e.deltaX);
      this.handleMouseMoveAction(optX, optY, this.canvas);
      this.handleMouseMoveAction(optX, optY, this.editor.canvas_bg);

      this.handleWheelDring = true;
      // 清除之前的定时器
      if (this.wheelTimeout) {
        clearTimeout(this.wheelTimeout);
      }

      // 设置新的定时器
      this.wheelTimeout = window.setTimeout(() => {
        this.endDring();
        this.handleWheelDring = false;
      }, 200); // 200ms 后检测滑动是否停止
    }
  };

  setupEventListeners() {
    this.removeEventListeners();
    this.canvas.on('mouse:down', this.handleMouseDown);
    this.canvas.on('mouse:move', this.handleMouseMove);
    this.canvas.on('mouse:up', this.handleMouseUp);
    this.canvas.on('mouse:wheel', this.handleWheel);
  }

  removeEventListeners() {
    this.canvas.off('mouse:down', this.handleMouseDown);
    this.canvas.off('mouse:move', this.handleMouseMove);
    this.canvas.off('mouse:up', this.handleMouseUp);
    this.canvas.off('mouse:wheel', this.handleWheel);
  }

  _setDring() {
    this.canvas.selection = false;
    this.canvas.defaultCursor = 'grab';
    this.canvas.requestRenderAll();
  }

  destroy() {
    console.log('pluginDestroy');
    this.removeEventListeners();
  }

  // space hot key;
  hotkeyEvent(eventName: string, e: any) {
    if (e.code === 'Space' && e.type === 'keydown') {
      !this.dragMode && this.startDring();
    }
    if (e.code === 'Space' && e.type === 'keyup') {
      this.endDring();
    }
    if (e.code === 'Escape' && e.type === 'keyup') {
      this.endDring();
    }
  }
}

export default DringPlugin;
