import loadFromJSONPlugin from './extension/loadFromJSON';

export default class OverwritePlugin {
  public canvas: fabric.Canvas;
  static pluginName = 'OverwritePlugin';

  constructor(canvas: fabric.Canvas) {
    this.canvas = canvas;
    this.init();
  }

  public init() {
    loadFromJSONPlugin();
  }
}