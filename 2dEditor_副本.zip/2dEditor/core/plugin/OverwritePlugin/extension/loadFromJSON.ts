import { fabric } from 'fabric';
import { CustomKey, EDITOR_JSON_KEY, FabricObjectType, WorkspaceID } from 'src/templates/2dEditor/cons/2dEditorCons';
import { Image } from 'src/templates/2dEditor/core/plugin/ImagePlugin/Image';
import { TextureImage } from 'src/templates/2dEditor/core/plugin/ImagePlugin/TextureImage';
import { Textbox } from 'src/templates/2dEditor/core/plugin/TextPlugin/Textbox';
import { ArcText } from 'src/templates/2dEditor/core/plugin/ArcTextPlugin/ArcText';
import { Pattern } from 'src/templates/2dEditor/core/plugin/PatternPlugin/Pattern';

export default function loadFromJSON() {
  // #region ;
  // @ts-ignore;
  fabric.Canvas.prototype.loadFromJSON = function (json, callback, reviver) {
    if (!json) return;
    // serialize if it wasn't already
    var serialized = typeof json === 'string' ? JSON.parse(json) : fabric.util.object.clone(json);
    var _this = this;
    // var clipPath = serialized.clipPath;
    var clipPath: any = null; //超出画布不隐藏
    var renderOnAddRemove = this.renderOnAddRemove;
    this.renderOnAddRemove = false;
    delete serialized.clipPath;
    // @ts-ignore;
    this._enlivenObjects(
      serialized.objects,
      function (enlivenedObjects) {
        const quest = enlivenedObjects.map(async (object: fabric.Object) => {
          // console.log('overwrite load json; object:', object);
          // if image;
          //处理纹理分组的情况
          if (object.type === FabricObjectType.Image) {
            const option = {
              left: object.left,
              top: object.top,
              originX: object.originX,
              originY: object.originY,
              width: object.width,
              height: object.height,
              selectable: object.selectable,
              scaleX: object.scaleX,
              scaleY: object.scaleY,
              cropX: object.cropX,
              cropY: object.cropY,
              clipPath: object.clipPath,
              key_prefix: object.key_prefix,
              importSource: object.importSource,
              fileType: object.fileType,
              filters: object.filters,
            };
            if (!!object.id && !!~object.id.indexOf(WorkspaceID.WorkspaceCavas)) {
              return await object;
            } else if (object.textureType) {
              return TextureImage.fromURL(object.src, {
                ...object.toJSON(EDITOR_JSON_KEY),
                ...option,
              });
            } else {
              return Image.fromURL(object.src, {
                ...object.toJSON(EDITOR_JSON_KEY),
                ...option,
              });
            }
          }
          // if origin text;
          else if (object.type === FabricObjectType.TextBox) {
            if ('path' in object) delete object.path;
            return await new Textbox(object.text, {
              ...object.toJSON(EDITOR_JSON_KEY),
            });
          }
          // if arc text;
          else if (object.type === FabricObjectType.Text) {
            if (object.path && object.path.path) {
              var pathObj = new fabric.Path(object.path.path, object.path);
              const transformTextObject = new ArcText(object.text || '', {
                ...object.toJSON(EDITOR_JSON_KEY),
                path: pathObj,
              });
              return await transformTextObject;
            }
            return await object;
          } else if (object.type === FabricObjectType.Group && object._isTextureGroup) {
            const originalObject = object._objects[0];
            const textureObject = object._objects[1];

            const originalImage = await Image.fromURL(originalObject.src, {
              ...originalObject.toJSON(EDITOR_JSON_KEY),
              left: originalObject.left,
              top: originalObject.top,
              originX: originalObject.originX,
              originY: originalObject.originY,
              selectable: object.selectable,
              width: originalObject.width,
              height: originalObject.height,
              scaleX: originalObject.scaleX,
              scaleY: originalObject.scaleY,
              cropX: originalObject.cropX,
              cropY: originalObject.cropY,
              clipPath: originalObject.clipPath,
              key_prefix: originalObject.key_prefix,
              importSource: originalObject.importSource,
              fileType: originalObject.fileType,
              filters: originalObject.filters,
            });

            const textureImage = await TextureImage.fromURL(textureObject.src, {
              ...textureObject.toJSON(EDITOR_JSON_KEY),
              left: textureObject.left,
              top: textureObject.top,
              originX: textureObject.originX,
              originY: textureObject.originY,
              width: textureObject.width,
              height: textureObject.height,
              scaleX: textureObject.scaleX,
              scaleY: textureObject.scaleY,
              selectable: textureObject.selectable,
              cropX: textureObject.cropX,
              cropY: textureObject.cropY,
              clipPath: textureObject.clipPath,
              key_prefix: textureObject.key_prefix,
              importSource: textureObject.importSource,
              fileType: textureObject.fileType,
              filters: textureObject.filters,
              _original: originalImage,
            });
            const group = new fabric.Group([originalImage, textureImage], {
              ...object.toJSON(EDITOR_JSON_KEY),
            });

            return await group;
          }
          // if pattern;
          else if (
            // @ts-ignore;
            object[CustomKey.CustomType] === FabricObjectType.Pattern &&
            !!object[CustomKey.PatternBase64] &&
            !!object.fill
          ) {
            return await new Pattern(object[CustomKey.PatternBase64], {
              ...object.toJSON(EDITOR_JSON_KEY),
            });
          } else {
            return await object;
          }
        });
        Promise.all(quest).then((res) => {
          enlivenedObjects = res;
          _this.clear();
          _this._setBgOverlay(serialized, function () {
            if (clipPath) {
              _this._enlivenObjects([clipPath], function (enlivenedCanvasClip) {
                _this.clipPath = enlivenedCanvasClip[0];
                _this.__setupCanvas.call(_this, serialized, enlivenedObjects, renderOnAddRemove, callback);
              });
            } else {
              _this.__setupCanvas.call(_this, serialized, enlivenedObjects, renderOnAddRemove, callback);
            }
          });
        });
      },
      reviver,
    );
    return this;
  };
}
