import { fabric } from "fabric";
import { ArcText } from "../ArcTextPlugin/ArcText";
import { TransformType } from "../ArcTextPlugin/types";
import { CustomKey, CustomObjectType, EDITOR_JSON_KEY, FabricObjectType } from "src/templates/2dEditor/cons/2dEditorCons";

export class Textbox extends fabric.Textbox {
  public transformType?: TransformType;
  constructor(text: string, options?: any) {
    super(text, options);
    this.init();
    this.on('scaling', this.handleTextScaling.bind(this));
  }

  public get _transformType() {
    return this.transformType;
  }
  public set _transformType(value) {
    this.transformType = value;
    const transformTextObject = new ArcText(this.text || "", {
      ...(this.toJSON(EDITOR_JSON_KEY)), //CustomKey.FontUrl
      type: FabricObjectType.Text
    });
    this.canvas?.add(transformTextObject);
    this.canvas?.setActiveObject(transformTextObject);
    if(this.group){
      this.group.remove(this)
      this.canvas?.renderAll();
    }else{
      this.canvas?.remove(this).renderAll();
    }
    transformTextObject.set("_transformType", value);
  }

  init() {
    this.setControlsVisibility({
      mt: false,
      mb: false,
    });
    this.set('splitByGrapheme', true);
  }

  // handle text scaling; 拉动字体进行缩放改变其字号, 不改变scale;
  public handleTextScaling(e: any) {
    const target = e.transform.target;
    const fontSize = target.fontSize * target.scaleX;
    //@ts-ignore;
    this.set({
      left: target.left,
      top: target.top,
      width: target.width * target.scaleX,
      height: target.height * target.scaleY,
      scaleX: 1,
      scaleY: 1,
      fontSize,
    });
  }

  _renderChar(method: "fillText" | "strokeText", ctx: CanvasRenderingContext2D, lineIndex: number, charIndex: number, _char: string, left: number, top: number): void {
    if (this.strokes) {
      for (let i = 0; i < this.strokes.length; i++) {
        const item = this.strokes[i]
        ctx.save();
        ctx.strokeStyle = item.stroke;
        ctx.lineWidth = item.strokeWidth;
        ctx.strokeText(_char, left, top);
        ctx.restore()
      }
    }
    super._renderChar(method, ctx, lineIndex, charIndex, _char, left, top)
  }
}
