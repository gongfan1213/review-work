import { Textbox } from "./Textbox";
import { fabric } from "fabric";
import Editor from '../../core';
import { WorkspaceID } from "src/templates/2dEditor/cons/2dEditorCons";
type IEditor = Editor;

export default class TextPlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  static pluginName = 'TextPlugin';
  static apis = ['addText'];
  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
  }

  addText(textValue = "Your Text Here", options: any = {}) {
    const workspace = this.canvas.getObjects().find((item) => item.id?.includes(WorkspaceID.WorkspaceCavas));
    const workspaceCenterPoint = workspace?.getCenterPoint();
    const defaultWidth = 160;
    const textObject = new Textbox(textValue, {
      width: defaultWidth,
      hasControls: true,
      hasBorders: true,
      lineHeight: 1,
      left: workspaceCenterPoint.x - defaultWidth / 2,
      top: workspaceCenterPoint.y,
      textAlign: "justify-center",
      ...options
    });
    this.canvas.add(textObject);
    this.canvas.setActiveObject(textObject);
    this.canvas.renderAll();
  };
}

