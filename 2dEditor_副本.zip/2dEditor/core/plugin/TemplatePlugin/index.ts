import { fabric } from 'fabric'
import { CustomKey, EDITOR_JSON_KEY, FabricObjectType, WorkspaceID } from '../../../cons/2dEditorCons';
import axios from 'axios';
import { Image } from "src/templates/2dEditor/core/plugin/ImagePlugin/Image"
import Editor from '../../core';
import JSZip from 'jszip';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { ImageStatus } from 'src/templates/2dEditor/core/eventbus/types/image';
type IEditor = Editor;

class TemplatePlugin {
  public canvas: fabric.Canvas
  public editor: IEditor;
  static pluginName = "TemplatePlugin"
  static apis = ["addJSON"];
  private PROJECT_JSON_NAME: string = 'project.json'
  private hasImageCropping: boolean = false;
  private croppingImage: Image | null = null;
  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
    this.init();
  }

  init() {
    eventBus.on(ImageStatus.Cropping, this.handleImageStatus.bind(this));
  }
  handleImageStatus(e: { value: boolean, target: Image }) {
    this.hasImageCropping = e.value;
    this.croppingImage = e.value ? e.target : null;
  }

  addJSON(jsonUrl: string, clearCanvas: boolean = false): Promise<void> {
    // if has image cropping will ERROR;
    if (this.hasImageCropping) {
      !!this.croppingImage && !!this.croppingImage.onDeselectEvent && this.croppingImage.onDeselectEvent();
    };
    return new Promise((resolve, reject) => {
      if (!jsonUrl) {
        reject(new Error("No JSON URL provided"));
        return;
      }
      const getJson = axios.get(jsonUrl, { responseType: 'arraybuffer' });
      getJson.then(async (res) => {
        // json;
        if (!!~res.headers['content-type'].indexOf('json')) {
          return new Promise((resolve, reject) => {
            const arrayBuffer = res.data;
            const blob = new Blob([arrayBuffer], { type: 'application/json' });
            const reader = new FileReader();
            reader.readAsText(blob);
            reader.onload = (e) => {
              const jsonString = e.target?.result;
              resolve(jsonString);
            }
          })
        }
        // zip;
        else {
          const zip = new JSZip();
          return zip.loadAsync(res.data);
        }
      }).then(zip => {
        if (typeof zip === 'string') {
          return zip;
        }
        // ;
        else {
          if (zip.files[this.PROJECT_JSON_NAME]) {
            return zip.files[this.PROJECT_JSON_NAME].async('string');
          } else {
            return "";
          }
        }
      }).then(async (jsonStr: string) => {
        const jsonObject = JSON.parse(jsonStr);
        if (!!jsonObject.clipPath) {
          delete jsonObject.clipPath;
        }
        // 去除保存json中的标品工作区数据;
        jsonObject.objects = jsonObject.objects.filter((item: any) => !!item.id && !~item.id.indexOf(WorkspaceID.WorkspaceCavas));
        let currentObjects = this.canvas.getObjects().map((item: any) => item.toJSON(EDITOR_JSON_KEY));
        // 如果需要清空画布其他元素;
        // 只保留当前画布工作区图层元素;
        if (clearCanvas) {
          currentObjects = currentObjects.filter(item => !!~item.id.indexOf(WorkspaceID.WorkspaceCavas))
          jsonObject.objects = [...currentObjects, ...jsonObject.objects];
        } else {
          jsonObject.objects.forEach((item: any) => item.id = 'tempTemplateID');
          jsonObject.objects = [...currentObjects, ...jsonObject.objects];
        }
        // 递归函数，用于清除 key_prefix 并过滤工作区元素
        function clearKeyPrefixAndFilterWorkspace(objects: any[]): any[] {
          return objects.map((item) => {
            // 如果有 key_prefix，设置为空字符串
            if (item.key_prefix) {
              item.key_prefix = "";
            }
            // 如果有 objects 属性，递归处理
            if (item.objects) {
              item.objects = clearKeyPrefixAndFilterWorkspace(item.objects);
            }
            return item;
          });
        }
        jsonObject.objects = clearKeyPrefixAndFilterWorkspace(jsonObject.objects);

        const resultJson = JSON.stringify(jsonObject);
        const textFontFamilyUrls = JSON.parse(resultJson).objects.map((item: any) => {
          if (
            item.type === FabricObjectType.Text ||
            item.type === FabricObjectType.TextBox ||
            item.type === FabricObjectType.TextI
          ) {
            if (!!item[CustomKey.FontUrl]) {
              return {
                font_family: item.fontFamily,
                font_url: item[CustomKey.FontUrl],
              };
            }
          }
        }).filter((item: any) => !!item);
        if (
          !!textFontFamilyUrls &&
          textFontFamilyUrls.length > 0
        ) {
          this.loadFont(textFontFamilyUrls).then(() => {
            this.editor?.stopSaveHistory();
            this.loadTemplateJSON(resultJson, clearCanvas).then((resFlag: any) => {
              resFlag && resolve();
              this.editor?.startSaveHistory(true);
            }).catch(error => {
              console.log('加载模板 - error;', error);
              this.editor?.startSaveHistory(true);
              reject();
            });
          }).catch(error => {
            console.log('加载文字样式 - error;', error);
            reject();
          });
        } else {
          this.editor?.stopSaveHistory();
          this.loadTemplateJSON(resultJson, clearCanvas).then((resFlag: any) => {
            resFlag && resolve();
            this.editor?.startSaveHistory(true);
          }).catch(error => {
            console.log('加载模板 - error;', error);
            this.editor?.startSaveHistory(true);
            reject();
          });
        }
      }).catch(error => {
        console.error('Error loading ZIP:', error);
        reject();
      });
    });
  }
  // load font style;
  async loadFont(textFontFamilyUrls: any) {
    await Promise.all(textFontFamilyUrls.map(fontItem => {
      // 创建一个新的FontFace实例
      let fontFace = new FontFace(fontItem.font_family, `url(${fontItem.font_url})`);
      // 将字体添加到文档
      document.fonts.add(fontFace);
      // 返回字体加载的Promise
      return fontFace.load();
    }));
  }
  // load template json;
  loadTemplateJSON(resultJson: string, isClearCanvas?: boolean) {
    return new Promise(async (resolve, reject) => {
      await this.canvas.loadFromJSON(resultJson, () => {
        const workspace = this.canvas.getObjects().find(item => !!item.id && item.id === WorkspaceID.WorkspaceCavas);
        const workspaceCenterPoint = workspace?.getCenterPoint();
        // if need to clear other object in canvas;
        if (isClearCanvas) {
          const allObjects = this.canvas.getObjects().filter(item => !!item.id && !~item.id.indexOf(WorkspaceID.WorkspaceCavas));
          const group = new fabric.Group(allObjects, {
            originX: 'center',
            originY: 'center',
            left: workspaceCenterPoint?.x,
            top: workspaceCenterPoint?.y,
          });
          group.scaleToWidth(workspace.width * workspace.scaleX);
          allObjects.forEach(item => this.canvas.remove(item));
          this.canvas.add(group);
        }
        // ;
        else {
          const allObjects = this.canvas.getObjects().filter(item => !!item.id && item.id === 'tempTemplateID');
          const group = new fabric.Group(allObjects, {
            originX: 'center',
            originY: 'center',
            left: workspaceCenterPoint?.x,
            top: workspaceCenterPoint?.y,
          });
          group.scaleToWidth(workspace.width * workspace.scaleX);
          allObjects.forEach(item => this.canvas.remove(item));
          this.canvas.add(group);
          this.canvas.setActiveObject(group);
        }
        resolve(true);
      });
    })
  }
}

export default TemplatePlugin;
