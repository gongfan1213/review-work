import { fabric } from 'fabric';
import Editor from '../core';
import eventBus from 'src/templates/2dEditor/core/eventbus';
import { TextStatus } from 'src/templates/2dEditor/core/eventbus/types/text';
type IEditor = Editor;

declare interface VerticalLine {
  x: number;
  y1: number;
  y2: number;
}

declare interface HorizontalLine {
  x1: number;
  x2: number;
  y: number;
}

class AlignGuidLinePlugin {
  public canvas: fabric.Canvas;
  public editor: IEditor;
  public show: boolean = true;
  public defautOption = {
    color: 'rgba(97, 188, 101, 1)',
    width: 1.25,
  };
  static pluginName = 'AlignGuidLinePlugin';
  static events = ['', ''];
  static apis = [];
  public hotkeys: string[] = [''];
  dragMode = false;
  viewportTransform: number[] | undefined;
  aligningLineOffset = 5;
  aligningLineMargin = 4;
  This = this;
  zoom = 1;
  verticalLines: VerticalLine[] = [];
  horizontalLines: HorizontalLine[] = [];

  constructor(canvas: fabric.Canvas, editor: IEditor) {
    this.canvas = canvas;
    this.editor = editor;
    this.dragMode = false;
    this.handleStartDring = this.handleStartDring.bind(this);
    this.handleEndDring = this.handleEndDring.bind(this);
    this.handleTextStatusUnderTransform = this.handleTextStatusUnderTransform.bind(this);
    this.handleMouseDown = this.handleMouseDown.bind(this);
    this.handleObjectMoving = this.handleObjectMoving.bind(this);
    this.handleBeforeRender = this.handleBeforeRender.bind(this);
    this.handleAfterRender = this.handleAfterRender.bind(this);
    this.handleMouseUp = this.handleMouseUp.bind(this);
    this.init();
  }

  init() {
    this.setupEventListeners();
  }

  drawVerticalLine(coords: VerticalLine) {
    this.drawLine(
      coords.x + 0.5,
      coords.y1 > coords.y2 ? coords.y2 : coords.y1,
      coords.x + 0.5,
      coords.y2 > coords.y1 ? coords.y2 : coords.y1,
    );
  }

  drawHorizontalLine(coords: HorizontalLine) {
    this.drawLine(
      coords.x1 > coords.x2 ? coords.x2 : coords.x1,
      coords.y + 0.5,
      coords.x2 > coords.x1 ? coords.x2 : coords.x1,
      coords.y + 0.5,
    );
  }

  drawLine(x1: number, y1: number, x2: number, y2: number) {
    if (this.viewportTransform == null) return;
    var ctx = this.canvas.getSelectionContext();
    ctx.save();
    ctx.lineWidth = this.defautOption.width;
    ctx.strokeStyle = this.defautOption.color;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.moveTo(x1 * this.zoom + this.viewportTransform[4], y1 * this.zoom + this.viewportTransform[5]);
    ctx.lineTo(x2 * this.zoom + this.viewportTransform[4], y2 * this.zoom + this.viewportTransform[5]);
    ctx.stroke();
    ctx.restore();
  }

  isInRange(value1: number, value2: number) {
    value1 = Math.round(value1);
    value2 = Math.round(value2);
    for (let i = value1 - this.aligningLineMargin, len = value1 + this.aligningLineMargin; i <= len; i++) {
      if (i === value2) {
        return true;
      }
    }
    return false;
  }

  setupEventListeners() {
    this.removeEventListeners();
    this.editor.on('startDring', this.handleStartDring);
    this.editor.on('endDring', this.handleEndDring);
    eventBus.on(TextStatus.UnderTransform, this.handleTextStatusUnderTransform);
    this.canvas.on('mouse:down', this.handleMouseDown);
    this.canvas.on('object:moving', this.handleObjectMoving);
    this.canvas.on('before:render', this.handleBeforeRender);
    this.canvas.on('after:render', this.handleAfterRender);
    this.canvas.on('mouse:up', this.handleMouseUp);
  }

  removeEventListeners() {
    this.editor.off('startDring', this.handleStartDring);
    this.editor.off('endDring', this.handleEndDring);
    eventBus.off(TextStatus.UnderTransform, this.handleTextStatusUnderTransform);
    this.canvas.off('mouse:down', this.handleMouseDown);
    this.canvas.off('object:moving', this.handleObjectMoving);
    this.canvas.off('before:render', this.handleBeforeRender);
    this.canvas.off('after:render', this.handleAfterRender);
    this.canvas.off('mouse:up', this.handleMouseUp);
  }

  handleStartDring = () => {
    this.show = false;
  };
  handleEndDring = () => {
    this.show = true;
  };

  handleTextStatusUnderTransform(status: boolean) {
    this.show = !status;
  }

  handleMouseDown() {
    if (!this.show) return;
    this.viewportTransform = this.canvas.viewportTransform;
    this.zoom = this.canvas.getZoom();
  }

  handleObjectMoving(e: any) {
    if (!this.show) return;
    if (this.viewportTransform === undefined || e.target === undefined) return;

    const activeObject = e.target;
    const canvasObjects = this.canvas.getObjects();
    const activeObjectCenter = activeObject.getCenterPoint();
    const activeObjectLeft = activeObjectCenter.x;
    const activeObjectTop = activeObjectCenter.y;
    const activeObjectBoundingRect = activeObject.getBoundingRect();
    const activeObjectHeight = activeObjectBoundingRect.height / this.viewportTransform[3];
    const activeObjectWidth = activeObjectBoundingRect.width / this.viewportTransform[0];
    let horizontalInTheRange = false;
    let verticalInTheRange = false;
    //@ts-ignore
    const transform = this.canvas._currentTransform;

    if (!transform) return;

    // It should be trivial to DRY this up by encapsulating (repeating) creation of x1, x2, y1, and y2 into functions,
    // but we're not doing it here for perf. reasons -- as this a function that's invoked on every mouse move

    for (let i = canvasObjects.length; i--; ) {
      // eslint-disable-next-line no-continue
      if (canvasObjects[i] === activeObject) continue;
      // 排除辅助线
      if (activeObject instanceof fabric.GuideLine && canvasObjects[i] instanceof fabric.GuideLine) {
        continue;
      }

      const objectCenter = canvasObjects[i].getCenterPoint();
      const objectLeft = objectCenter.x;
      const objectTop = objectCenter.y;
      const objectBoundingRect = canvasObjects[i].getBoundingRect();
      const objectHeight = objectBoundingRect.height / this.viewportTransform[3];
      const objectWidth = objectBoundingRect.width / this.viewportTransform[0];

      // snap by the horizontal center line
      if (this.isInRange(objectLeft, activeObjectLeft)) {
        verticalInTheRange = true;
        this.verticalLines.push({
          x: objectLeft,
          y1:
            objectTop < activeObjectTop
              ? objectTop - objectHeight / 2 - this.aligningLineOffset
              : objectTop + objectHeight / 2 + this.aligningLineOffset,
          y2:
            activeObjectTop > objectTop
              ? activeObjectTop + activeObjectHeight / 2 + this.aligningLineOffset
              : activeObjectTop - activeObjectHeight / 2 - this.aligningLineOffset,
        });
        activeObject.setPositionByOrigin(new fabric.Point(objectLeft, activeObjectTop), 'center', 'center');
      }

      // snap by the left edge
      if (this.isInRange(objectLeft - objectWidth / 2, activeObjectLeft - activeObjectWidth / 2)) {
        verticalInTheRange = true;
        this.verticalLines.push({
          x: objectLeft - objectWidth / 2,
          y1:
            objectTop < activeObjectTop
              ? objectTop - objectHeight / 2 - this.aligningLineOffset
              : objectTop + objectHeight / 2 + this.aligningLineOffset,
          y2:
            activeObjectTop > objectTop
              ? activeObjectTop + activeObjectHeight / 2 + this.aligningLineOffset
              : activeObjectTop - activeObjectHeight / 2 - this.aligningLineOffset,
        });
        activeObject.setPositionByOrigin(
          new fabric.Point(objectLeft - objectWidth / 2 + activeObjectWidth / 2, activeObjectTop),
          'center',
          'center',
        );
      }

      // snap by the right edge
      if (this.isInRange(objectLeft + objectWidth / 2, activeObjectLeft + activeObjectWidth / 2)) {
        verticalInTheRange = true;
        this.verticalLines.push({
          x: objectLeft + objectWidth / 2,
          y1:
            objectTop < activeObjectTop
              ? objectTop - objectHeight / 2 - this.aligningLineOffset
              : objectTop + objectHeight / 2 + this.aligningLineOffset,
          y2:
            activeObjectTop > objectTop
              ? activeObjectTop + activeObjectHeight / 2 + this.aligningLineOffset
              : activeObjectTop - activeObjectHeight / 2 - this.aligningLineOffset,
        });
        activeObject.setPositionByOrigin(
          new fabric.Point(objectLeft + objectWidth / 2 - activeObjectWidth / 2, activeObjectTop),
          'center',
          'center',
        );
      }

      // snap by the vertical center line
      if (this.isInRange(objectTop, activeObjectTop)) {
        horizontalInTheRange = true;
        this.horizontalLines.push({
          y: objectTop,
          x1:
            objectLeft < activeObjectLeft
              ? objectLeft - objectWidth / 2 - this.aligningLineOffset
              : objectLeft + objectWidth / 2 + this.aligningLineOffset,
          x2:
            activeObjectLeft > objectLeft
              ? activeObjectLeft + activeObjectWidth / 2 + this.aligningLineOffset
              : activeObjectLeft - activeObjectWidth / 2 - this.aligningLineOffset,
        });
        activeObject.setPositionByOrigin(new fabric.Point(activeObjectLeft, objectTop), 'center', 'center');
      }

      // snap by the top edge
      if (this.isInRange(objectTop - objectHeight / 2, activeObjectTop - activeObjectHeight / 2)) {
        horizontalInTheRange = true;
        this.horizontalLines.push({
          y: objectTop - objectHeight / 2,
          x1:
            objectLeft < activeObjectLeft
              ? objectLeft - objectWidth / 2 - this.aligningLineOffset
              : objectLeft + objectWidth / 2 + this.aligningLineOffset,
          x2:
            activeObjectLeft > objectLeft
              ? activeObjectLeft + activeObjectWidth / 2 + this.aligningLineOffset
              : activeObjectLeft - activeObjectWidth / 2 - this.aligningLineOffset,
        });
        activeObject.setPositionByOrigin(
          new fabric.Point(activeObjectLeft, objectTop - objectHeight / 2 + activeObjectHeight / 2),
          'center',
          'center',
        );
      }

      // snap by the bottom edge
      if (this.isInRange(objectTop + objectHeight / 2, activeObjectTop + activeObjectHeight / 2)) {
        horizontalInTheRange = true;
        this.horizontalLines.push({
          y: objectTop + objectHeight / 2,
          x1:
            objectLeft < activeObjectLeft
              ? objectLeft - objectWidth / 2 - this.aligningLineOffset
              : objectLeft + objectWidth / 2 + this.aligningLineOffset,
          x2:
            activeObjectLeft > objectLeft
              ? activeObjectLeft + activeObjectWidth / 2 + this.aligningLineOffset
              : activeObjectLeft - activeObjectWidth / 2 - this.aligningLineOffset,
        });
        activeObject.setPositionByOrigin(
          new fabric.Point(activeObjectLeft, objectTop + objectHeight / 2 - activeObjectHeight / 2),
          'center',
          'center',
        );
      }
    }

    if (!horizontalInTheRange) {
      this.horizontalLines.length = 0;
    }

    if (!verticalInTheRange) {
      this.verticalLines.length = 0;
    }
  }

  handleBeforeRender() {
    // fix 保存图片时报错
    try {
      // @ts-ignore
      this.canvas.clearContext(this.canvas.contextTop);
    } catch (error) {
      console.log(error);
    }
  }

  handleAfterRender() {
    for (let i = this.verticalLines.length; i--; ) {
      this.drawVerticalLine(this.verticalLines[i]);
    }
    for (let j = this.horizontalLines.length; j--; ) {
      this.drawHorizontalLine(this.horizontalLines[j]);
    }
    // noinspection NestedAssignmentJS
    this.verticalLines.length = 0;
    this.horizontalLines.length = 0;
  }

  handleMouseUp() {
    this.verticalLines.length = 0;
    this.horizontalLines.length = 0;
    this.canvas.renderAll();
    console.log(888, 'allObject', this.canvas.getObjects());
  }

  destroy() {
    console.log('Align Line Plugin Destroy;');
    this.removeEventListeners();
  }
}

export default AlignGuidLinePlugin;
