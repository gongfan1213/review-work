/*
 * @Description: 核心入口文件
 */
import Editor from './core';

import DringPlugin from './plugin/DringPlugin';
import AlignGuidLinePlugin from './plugin/AlignGuidLinePlugin';
import CenterAlignPlugin from './plugin/CenterAlignPlugin';
import MoveHotKeyPlugin from './plugin/MoveHotKeyPlugin';
import GroupAlignPlugin from './plugin/GroupAlignPlugin';
import WorkspacePlugin from './plugin/WorkspacePlugin';
import DownFontPlugin from './plugin/DownFontPlugin';
import RulerPlugin from './plugin/RulerPlugin';
import MaterialPlugin from './plugin/MaterialPlugin';
import ImageToolPlugin from './plugin/ImageToolPlugin';
import ImagePlugin from './plugin/ImagePlugin'; // 导入位图;
import TextPlugin from './plugin/TextPlugin'; // 导入文本;
import ArcTextPlugin from './plugin/ArcTextPlugin'; // 导入弧形文本;
import BasicFnPlugin from './plugin/BasicFnPlugin'; // 基础功能(右键菜单);
import InitPlugin from './plugin/InitPlugin'; // 初始化插件;
import ControlPlugin from './plugin/ControlPlugin'; // 控制器插件;
import HistoryPlugin from './plugin/HistoryPlugin'; // 历史记录插件;
import PatternPlugin from './plugin/PatternPlugin'; // 导入可平铺重复图片;
import OverwritePlugin from './plugin/OverwritePlugin'; // 重写补充fabric部分方法;
import TemplatePlugin from './plugin/TemplatePlugin'; // 模板json;

export {
  DringPlugin,
  AlignGuidLinePlugin,
  CenterAlignPlugin,
  MoveHotKeyPlugin,
  GroupAlignPlugin,
  WorkspacePlugin,
  DownFontPlugin,
  HistoryPlugin,
  RulerPlugin,
  MaterialPlugin,
  ImageToolPlugin,
  ImagePlugin,
  PatternPlugin,
  TextPlugin,
  ArcTextPlugin,
  BasicFnPlugin,
  InitPlugin,
  ControlPlugin,
  OverwritePlugin,
  TemplatePlugin
};
export default Editor;
