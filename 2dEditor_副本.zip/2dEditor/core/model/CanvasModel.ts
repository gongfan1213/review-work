export type CanvasSizeModel = {
    width: number;
    height: number;
    width_mm: number;
    height_mm: number;
}
