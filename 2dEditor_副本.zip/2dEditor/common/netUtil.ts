

export type CusResponseModel = {
  code: number;
  msg: string;
  data: any;
}

export type CusPageRequestModel = {
  project_type: number
  pagination: {
    page_size: number
    page: number
  }
}

export const isNetSuccess = (resp: CusResponseModel | null) => {
  return resp?.code === 0
}