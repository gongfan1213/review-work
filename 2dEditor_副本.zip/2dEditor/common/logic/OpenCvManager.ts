import IndexedDBAk from "src/common/utils/IndexedDBAk";
import { ACTION_OPENCV } from "../../cons/2dEditorCons";
import JSZip from 'jszip';

export class OpenCvManager {
    private static instance: OpenCvManager;
    private isIniting: boolean = false;

    public static getInstance(): OpenCvManager {
        if (!OpenCvManager.instance) {
            OpenCvManager.instance = new OpenCvManager();
        }
        return OpenCvManager.instance;
    }

    private async fetchAndStoreWasm(storage: IndexedDBAk, key: string, url: string): Promise<ArrayBuffer> {
        await storage.open();
        let arrayBuffer = await storage.get(key);
        if (!arrayBuffer) {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            arrayBuffer = await response.arrayBuffer();
            await storage.put(key, arrayBuffer);
        }
        return arrayBuffer;
    }

    public async initOpenCv(): Promise<void> {
        //@ts-ignore
        if (window.cv) return window.cv;
        if (this.isIniting) {
            return new Promise((resolve, reject) => {
                const timer = setInterval(() => {
                    //@ts-ignore
                    if (window.cv) {
                        clearInterval(timer);
                        //@ts-ignore
                        resolve(window.cv);
                    }
                }, 1000);
            });
        }
        this.isIniting = true;
        console.log("====initOpenCv=====start", new Date().toISOString())
        const storage = new IndexedDBAk();
        // 打开数据库
        await storage.open();
        const arrayBuffer = await this.fetchAndStoreWasm(storage, ACTION_OPENCV.LOCAL_OPENCV, '/opencv.js.zip');
        console.log("====initOpenCv=====1111111", new Date().toISOString())

        // 解压缩并加载 opencv.js
        const jszip = new JSZip();
        const zip = await jszip.loadAsync(arrayBuffer);
        const opencvJsFile = zip.file('opencv.js'); // 假设 zip 包中包含 opencv.js 文件
        if (!opencvJsFile) {
            throw new Error('opencv.js not found in the zip file');
        }
        console.log("====initOpenCv=====2222222", new Date().toISOString())

        // 解压缩并加载 opencv.js
        const opencvJsContent = await opencvJsFile.async('blob');
        const url = URL.createObjectURL(opencvJsContent);
        const ret = await this.loadScript(url);
        this.isIniting = false;
        return ret;
    }

    private loadScript(url: string): Promise<any> {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = url;
            script.async = true;
            //使用MutationObserver监听dom变化来监听opencv加载完成，兼容safari Promise 状态为pedding下执行卡死问题
            const observer = new MutationObserver(async () => {
                if ((window as any).cv) {
                    console.log("====initOpenCv=====33333333==start=", (window as any).cv);
                    observer.disconnect();
                    if ((window as any).cv instanceof Promise) {
                        try {
                            // 为了兼容safari，需要不能把(window as any).cv进行传递
                            // const cv = await (window as any).cv;
                            console.log("====initOpenCv=====33333333===", (window as any).cv, new Date().toISOString());
                            resolve("");
                        } catch (error) {
                            console.error("Promise rejected with error===:", error);
                            reject(error);
                        }
                    } else {
                        console.log("====initOpenCv=====33333333==onRuntimeInitialized=");
                        (window as any).cv['onRuntimeInitialized'] = () => {
                            console.log("====initOpenCv=====onRuntimeInitialized33333333", (window as any).cv, new Date().toISOString());
                            resolve((window as any).cv);
                        };
                        // 如果已经初始化完成，直接 resolve
                        if ((window as any).cv && (window as any).cv['onRuntimeInitialized'] === undefined) {
                            resolve((window as any).cv);
                        }
                    }
                }
            });

            observer.observe(document, { childList: true, subtree: true });
            // script.onload = () => {
            //     if ((window as any).cv) {
            //         if ((window as any).cv instanceof Promise) {
            //             console.log("====initOpenCv=====33333333==start=", (window as any).cv);
            //             (window as any).cv.then((cv: any) => {
            //                 console.log("====initOpenCv=====33333333===", cv, (window as any).cv, new Date().toISOString());
            //                 resolve(cv);
            //             }).catch(reject);
            //         } else {
            //             (window as any).cv['onRuntimeInitialized'] = () => {
            //                 resolve((window as any).cv);
            //             };
            //         }
            //     } else {
            //         reject(new Error('Failed to load OpenCV'));
            //     }
            // };
            script.onerror = (error) => {
                console.log("====initOpenCv=========error=", error);
                reject(error);
            };
            document.head.appendChild(script);
        });
    }
}