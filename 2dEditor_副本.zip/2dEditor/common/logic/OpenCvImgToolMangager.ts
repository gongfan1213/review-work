import { OpenCvManager } from "src/templates/2dEditor/common/logic/OpenCvManager";

export class OpenCvImgToolMangager {
    private static instance: OpenCvImgToolMangager;
    private cv: any = null; // 添加 cv 属性
    private constructor() {
        OpenCvManager.getInstance().initOpenCv().then(async () => {
            console.log('====OpenCvImgToolMangager===000=')
            this.cv = await (window as any).cv;
            console.log('====OpenCvImgToolMangager===1111=')
        });
    }
    public static getInstance(): OpenCvImgToolMangager {
        if (!OpenCvImgToolMangager.instance) {
            OpenCvImgToolMangager.instance = new OpenCvImgToolMangager();
        }
        return OpenCvImgToolMangager.instance;
    }

    /**
     * 得到灰度图的后处理，把去背图范围之外的色值变为黑色，得到最终灰度图,当前用于冰箱贴灰度图后处理
     * @param removeBgImg 
     * @param grayImg 
     * @returns 
     */
    public async GrayPostProcessing(removeBgImg: string, grayImg: string): Promise<string> {
        console.log('--GrayPostProcessing', grayImg)
        // Convert base64 to mat
        const removeBgMat = await this.base64ToMat(removeBgImg);
        const grayImgMat = await this.base64ToMat(grayImg);

        //Resize
        this.cv.resize(removeBgMat, removeBgMat, new this.cv.Size(grayImgMat.cols, grayImgMat.rows));

        // Create a mask from the alpha channel of the removeBgMat
        let mask = new this.cv.Mat();
        this.cv.cvtColor(removeBgMat, mask, this.cv.COLOR_RGBA2GRAY);
        this.cv.threshold(mask, mask, 1, 255, this.cv.THRESH_BINARY);

        // Invert the mask
        let invertedMask = new this.cv.Mat();
        this.cv.bitwise_not(mask, invertedMask);

        // Apply the mask to the gray image
        let resultMat = new this.cv.Mat();
        grayImgMat.copyTo(resultMat, mask);

        // Apply the inverted mask to set the background to black
        let blackBackground = new this.cv.Mat(grayImgMat.rows, grayImgMat.cols, grayImgMat.type(), new this.cv.Scalar(0, 0, 0, 255));
        blackBackground.copyTo(resultMat, invertedMask);

        // Convert the result mat to base64
        const resultBase64 = this.matToBase64(resultMat);
        // console.log('======GrayPostProcessing====end', resultBase64)

        // Clean up
        removeBgMat.delete();
        grayImgMat.delete();
        mask.delete();
        invertedMask.delete();
        resultMat.delete();
        blackBackground.delete();

        return resultBase64;
    }

    /**
     * 根据原图，获取图片内容最小外界矩形，裁剪得到新图
     * @param sourceImg 原图
     */
    public async getImgExternalRect(sourceImg: string): Promise<string> {
        console.log('=====getImgExternalRect======start', new Date().toISOString())
        // Convert base64 to mat
        const sourceMat = await this.base64ToMat(sourceImg);

        // Convert to grayscale
        let grayMat = new this.cv.Mat();
        this.cv.cvtColor(sourceMat, grayMat, this.cv.COLOR_RGBA2GRAY);

        // Apply binary thresholding
        let binaryMat = new this.cv.Mat();
        this.cv.threshold(grayMat, binaryMat, 1, 255, this.cv.THRESH_BINARY);

        // Find contours
        let contours = new this.cv.MatVector();
        let hierarchy = new this.cv.Mat();
        this.cv.findContours(binaryMat, contours, hierarchy, this.cv.RETR_EXTERNAL, this.cv.CHAIN_APPROX_SIMPLE);

        // Get the bounding rectangle of the largest contour
        let rect = this.cv.boundingRect(contours.get(0));
        for (let i = 1; i < contours.size(); i++) {
            let tempRect = this.cv.boundingRect(contours.get(i));
            rect.x = Math.min(rect.x, tempRect.x);
            rect.y = Math.min(rect.y, tempRect.y);
            rect.width = Math.max(rect.width, tempRect.x + tempRect.width - rect.x);
            rect.height = Math.max(rect.height, tempRect.y + tempRect.height - rect.y);
        }

        // Crop the image
        let croppedMat = sourceMat.roi(rect);

        // Convert the result mat to base64
        const resultBase64 = this.matToBase64(croppedMat);
        // console.log('======getImgExternalRect====end', resultBase64)
        // Clean up
        sourceMat.delete();
        grayMat.delete();
        binaryMat.delete();
        contours.delete();
        hierarchy.delete();
        croppedMat.delete();

        return resultBase64;
    }


    private async base64ToMat(base64: string): Promise<any> {
        return new Promise((resolve, reject) => {
            let img = new Image();
            img.src = base64;
            img.onload = () => {
                try {
                    let canvas = document.createElement('canvas');
                    let ctx = canvas.getContext('2d');
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx!.drawImage(img, 0, 0, img.width, img.height);
                    let imageData = ctx!.getImageData(0, 0, img.width, img.height);
                    console.log('---this', this)
                    console.log('---this.cv', this.cv)
                    console.log('===执行化====', new Date())
                    let mat = new this.cv.Mat(img.height, img.width, this.cv.CV_8UC4);
                    mat.data.set(imageData.data);
                    resolve(mat);
                } catch (error) {
                    reject(error);
                }
            };
            img.onerror = (err) => {
                reject(new Error(`Failed to load image: ${err}`));
            };
        });
    }

    private matToBase64(mat: any): string {
        // 创建一个 canvas 元素
        let canvas = document.createElement('canvas');
        this.cv.imshow(canvas, mat);
        // 将 canvas 转换为 base64 字符串
        return canvas.toDataURL();
    }

    public async blobToMat(blob: Blob, isChangeRGBA: boolean = false): Promise<any> {
        return new Promise((resolve, reject) => {
            let reader = new FileReader();
            reader.onload = () => {
                let arrayBuffer = reader.result as ArrayBuffer;
                let bytes = new Uint8Array(arrayBuffer);
                let img = new Image();
                img.src = URL.createObjectURL(new Blob([bytes], { type: 'image/webp' }));
                img.onload = () => {
                    try {
                        let canvas = document.createElement('canvas');
                        let ctx = canvas.getContext('2d');
                        canvas.width = img.width;
                        canvas.height = img.height;
                        ctx!.drawImage(img, 0, 0, img.width, img.height);
                        let imageData = ctx!.getImageData(0, 0, img.width, img.height);
                        let mat = new this.cv.Mat(img.height, img.width, this.cv.CV_8UC4);

                        mat.data.set(imageData.data);
                        if (!isChangeRGBA) {
                            this.cv.cvtColor(mat, mat, this.cv.COLOR_RGBA2RGB);
                        }
                        resolve(mat);
                    } catch (error) {
                        reject(error);
                    }
                };
                img.onerror = (err) => {
                    reject(new Error(`Failed to load image: ${err}`));
                };
            };
            reader.onerror = (error) => {
                reject(error);
            };
            reader.readAsArrayBuffer(blob);
        });
    }

    public matToBlob(mat: any): Promise<Blob> {
        return new Promise((resolve, reject) => {
            try {
                // 创建一个 canvas 元素
                let canvas = document.createElement('canvas');
                this.cv.imshow(canvas, mat);
                // 将 canvas 转换为 Blob
                canvas.toBlob((blob) => {
                    if (blob) {
                        resolve(blob);
                    } else {
                        reject(new Error('Canvas to Blob conversion failed.'));
                    }
                }, 'image/webp');
            } catch (error) {
                reject(error);
            }
        });
    }

    public async matToFile(mat: any, fileName: string): Promise<File> {
        return new Promise((resolve, reject) => {
            try {
                // 创建一个 canvas 元素
                let canvas = document.createElement('canvas');
                this.cv.imshow(canvas, mat); // 显示 mat 到 canvas 上
                // 将 canvas 转换为 Blob
                canvas.toBlob((blob) => {
                    if (blob) {
                        // 将 Blob 转换为 File
                        const file = new File([blob], fileName, { type: 'image/jpeg' });
                        resolve(file);
                    } else {
                        reject(new Error('Canvas to Blob conversion failed.'));
                    }
                }, 'image/jpeg');
            } catch (error) {
                reject(error);
            }
        });
    }

    public async blobToBase64(blob: Blob): Promise<string> {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                resolve(reader.result as string);
            };
            reader.onerror = (error) => {
                reject(error);
            };
            reader.readAsDataURL(blob);
        });
    }

    public base64ToBlob(base64: string, contentType: string = '', sliceSize: number = 512): Blob {
        const byteCharacters = atob(base64.split(',')[1]);
        const byteArrays = [];

        for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            const slice = byteCharacters.slice(offset, offset + sliceSize);

            const byteNumbers = new Array(slice.length);
            for (let i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }

            const byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }

        return new Blob(byteArrays, { type: contentType });
    }
}