// start_ai_generated 
import React, { useState, FC, useEffect } from 'react';
import * as classes from './DropdownStyle.module.scss';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import ic_down from 'src/assets/svg/ic_down.svg';

interface ValueItem {
  str: string;
  value: number;
}

interface DropdownProps {
  values: ValueItem[];
  typeStr?: string;
  classNames:string;
  defaultSelectValue: number;
  callback: (item: ValueItem) => void;
}

const Dropdown: FC<DropdownProps> = ({ values, typeStr,classNames, defaultSelectValue, callback }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedValue, setSelectedValue] = useState<ValueItem | undefined>();

  useEffect(() => {
    // 设置默认选中的值
    const defaultValue = values.find(item => item.value === defaultSelectValue);
    setSelectedValue(defaultValue);
  }, [defaultSelectValue, values]);

  useEffect(() => {
    document.addEventListener('click', handleScreenClick);
    return (() => {
      document.removeEventListener('click', handleScreenClick);
    })
  }, [])

  const handleScreenClick = () => {
    setIsOpen(false);
  }

  const handleSelect = (item: ValueItem) => {
    setSelectedValue(item);
    setIsOpen(false);
    callback(item);
  };

  return (
    <div className={`${classes.dropdownContainer} ${classNames ? classes.createRelief: '' }`}>
      {typeStr && <div className={`${classes.dropdownType} ${BaseStyles.txt12}`}>{typeStr}</div>}
      {
        typeStr ?
          <div className={`${classes.dropdownSelected}`} onClick={(event) => { event.stopPropagation(); setIsOpen(!isOpen); }}>
            <span className={`${BaseStyles.txt14}`}>{selectedValue?.str}</span>
            <img className={classes.dropdownIcon} src={ic_down} />
          </div> :
          <div className={`${classes.dropdownSelectedFelx}`} onClick={(event) => { event.stopPropagation(); setIsOpen(!isOpen); }}>
            <span className={`${BaseStyles.txt14} ${classes.felx_span}`}>{selectedValue?.str}</span>
            <img className={`${classes.dropdownIcon} ${classes.felx_img}`} src={ic_down} />
          </div>
      }

      {isOpen && (
        <div className={classes.dropdownOptions}>
          {values.map((item, index) => (
            <div key={index} className={`${classes.dropdownOption} ${BaseStyles.txt14}`} onClick={(event) => { event.stopPropagation(); handleSelect(item) }}>
              {item.str}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Dropdown;
// end_ai_generated 