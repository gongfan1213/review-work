import React, { useState, useRef, useEffect, useCallback } from 'react'
import { useInView } from 'react-intersection-observer'
import LoadingAnimation from 'src/images/lottie/loading.json'
import LottiePlayer from 'react-lottie-player'
import * as classes from './ScrollMoreView.module.scss'


type ScrollMoreViewProps = {
  onLoadMore: () => void
  hasMore?: boolean
  empty?: JSX.Element
  loaderView?: JSX.Element
  isLoading: boolean
  children: React.ReactNode;
}

export default function ScrollMoreView(props: ScrollMoreViewProps) {
  const {
    onLoadMore,
    hasMore,
    empty,
    loaderView,
    isLoading,
    children,
  } = props
  const { ref, inView } = useInView({ threshold: 0 })
  const onLoadMoreRef = useRef(onLoadMore)
  onLoadMoreRef.current = onLoadMore
  useEffect(() => {
    if (inView && !isLoading && hasMore) {
      onLoadMoreRef.current?.()
    }
  }, [inView, isLoading])


  useEffect(() => {

    return () => {
    }
  }, [])

  return (
    <div className={classes.layout}>
      {!isLoading && !hasMore && empty}
      {children}
      {(hasMore || isLoading) && (loaderView ? loaderView : (
        <div className={classes.load} ref={ref}>
          <LottiePlayer
            loop
            play
            className={classes.loadingBox}
            animationData={LoadingAnimation}
          />
        </div>
      ))}
    </div>
  )
}
