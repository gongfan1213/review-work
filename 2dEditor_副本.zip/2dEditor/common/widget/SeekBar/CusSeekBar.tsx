// start_ai_generated 
import React, { useEffect, useState } from 'react';
import * as classes from './CusSeekBarStyle.module.scss';
import * as BaseStyles from 'src/templates/2dEditor/common/styles/BaseStyles.module.scss'
import { getColors } from '../../color/color';

interface SeekBarProps {
  min: number;
  max: number;
  defaultValue: number;
  onChange: (value: number) => void;
}

const CusSeekBar: React.FC<SeekBarProps> = ({ min, max, defaultValue, onChange }) => {
  const [value, setValue] = useState(defaultValue);

  useEffect(() => {
    setValue(defaultValue);
  }, [defaultValue]);
  // 根据当前值计算背景色的样式
  const getBackgroundStyle = () => {
    const inactiveColor = getColors().color_bar_normal;
    const activeColor = getColors().color_bar_select;

    const middle = (min + max) / 2;
    const percentage = ((value - min) / (max - min)) * 100;
    const middlePercentage = ((middle - min) / (max - min)) * 100;
    if (value < middle) {
      return `linear-gradient(to right, ${inactiveColor} 0%, ${inactiveColor} ${percentage}%, ${activeColor} ${percentage}%, ${activeColor} ${middlePercentage}%, ${inactiveColor} ${middlePercentage}%, ${inactiveColor} 100%)`;
    } else {
      return `linear-gradient(to right, ${inactiveColor} 0%, ${inactiveColor} ${middlePercentage}%, ${activeColor} ${middlePercentage}%, ${activeColor} ${percentage}%, ${inactiveColor} ${percentage}%, ${inactiveColor} 100%)`;
    }
  };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = Number(event.target.value);
    setValue(newValue);
    onChange(newValue);
  };

  return (
    <div className={classes.seekBarContainer}>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        className={classes.seekBar}
        onChange={handleChange}
        style={{ background: getBackgroundStyle() }} // 应用动态背景色
      />
      <div className={`${classes.seekBarValue} ${BaseStyles.txt14}`}>{value}</div>
    </div>
  );
};

export default CusSeekBar;
// end_ai_generated 