// start_ai_generated 
import React, { useEffect, useState } from 'react';
import * as classes from './TabSwitcherStyle.module.scss';
import useDataCache from '../../../utils/DataCache';

interface Tab {
  tabName: string;
  tabValue: number;
}

interface TabSwitcherProps {
  tabs: Tab[];
  onTabChange: (tab: Tab) => void;
  nowTab?: number;
}
// 传入nowTab参数，可以控制当前选中的tab高亮
const TabSwitcher: React.FC<TabSwitcherProps> = ({ tabs, onTabChange, nowTab }) => {
  const { getCacheItem } = useDataCache();
  const [activeTab, setActiveTab] = useState<Tab>(tabs[0]);
  useEffect(() => {
    const cacheTabKey = getCacheItem('elementMenus')?.['tabKey'];
    if (cacheTabKey) {
      for (let i = 0; i < tabs.length; i++) {
        if (cacheTabKey == tabs[i].tabName) {
          setActiveTab(tabs[i]);
          return
        }
      }
    }
  }, []);

  const handleTabClick = (tab: Tab) => {
    setActiveTab(tab);
    onTabChange(tab);
  };


  return (
    <div className={classes.tabSwitcher}>
      <div className={classes.tabContainer}>
        {tabs.map((tab) => (
          <div
            key={tab?.tabValue}
            className={`${classes.tab} ${tab?.tabValue === (nowTab || activeTab?.tabValue || tabs[0].tabValue) ? classes.active : ''}`}
            onClick={() => handleTabClick(tab)}
          >
            {tab?.tabName}
            {tab?.tabValue === (nowTab || activeTab?.tabValue || tabs[0].tabValue) && <div className={classes.tabIndicator}></div>}
          </div>
        ))}
      </div>
    </div>
  );
};

export default TabSwitcher;
// end_ai_generated 