import { compressorImage1, dataURLtoFile, fileToBase64, getImgCompress } from "src/common/utils";
import { upload, upload2dEditFile } from "src/hooks/useUpload";
import { GetUpTokenFileTypeEnum } from "src/services";
import { CanvasParams, CustomPcAction, EventNameCons, FabricObjectType, PROJECT_STANDARD_TYPE, ReliefType, TextureType, WorkspaceID } from "../cons/2dEditorCons";
import { createUserMaterial, getProjectDetail, updateProjectCavas } from "../service/2dEditService";
import { CanvasesResInfo, ProjectCavasItemUpdateRequestModel, ProjectCavasUpdateRequestModel, RotaryParams } from "../components/SelectDialog/model/ProjectModel";
import { PrintLayerData, PrintLayerFileStr, PrintLayerModel, PrintLayerType, PrintModel } from "../components/MainUi/MainUiRightComponent/PrintLayer/model/PrintLayerModel";
import Tar from "tar-js";
import { ProjectModel } from '../components/SelectDialog/model/ProjectModel';
import ProjectManager from "../utils/ProjectManager";
import { downFontByJSON } from "../utils/utils";
import { blobToBase64, blobToMd5 } from 'src/common/utils';
import Editor from "../core";
import ic_column_c from 'src/assets/png/ic_column_c.png'
import ic_column_r from 'src/assets/png/ic_column_r.png'
import ic_column_l from 'src/assets/png/ic_column_l.png'
import ic_column_r_h from 'src/assets/png/ic_column_r_h.png'
import ic_column_l_h from 'src/assets/png/ic_column_l_h.png'

import ic_cone_c from 'src/assets/png/ic_cone_c.png'
import ic_cone_r from 'src/assets/png/ic_cone_r.png'
import ic_cone_l from 'src/assets/png/ic_cone_l.png'
import ic_cone_r_h from 'src/assets/png/ic_cone_r_h.png'
import ic_cone_l_h from 'src/assets/png/ic_cone_l_h.png'

import ic_trapezoid_c from 'src/assets/png/ic_trapezoid_c.png'
import ic_trapezoid_r from 'src/assets/png/ic_trapezoid_r.png'
import ic_trapezoid_l from 'src/assets/png/ic_trapezoid_l.png'
import ic_trapezoid_r_h from 'src/assets/png/ic_trapezoid_r_h.png'
import ic_trapezoid_l_h from 'src/assets/png/ic_trapezoid_l_h.png'

import StringUtil from "src/common/utils/stringUtil";
import { isPc } from "src/common/jsbridge";
import { sendCommandToPcWithResponse } from "src/common/jsbridge/util";
import PSD from 'psd.js';
import { base64ToFile } from "src/templates/LightPainting/utils";
import IndexedDBAk from "src/common/utils/IndexedDBAk";
import JSZip from "jszip";
import { StatisticalReportManager } from "src/common/logic/StatisticalReportManager";
import { CONS_STATISTIC_TYPE } from "src/common/cons/CommonCons";

export type CavasUpdateOps = {
  updateStart: () => void;
  updateEnd: (ret: boolean, error: number, message?: string) => void;
  fileExtension: string;
  fileItem: File;
  event: any;
  canvasEditor: any;
  uploadFileType: GetUpTokenFileTypeEnum,
  projectId?: string
  canvas_id?: string
  isApps?: boolean
}
export const uploadImageForCavas = (ops: CavasUpdateOps) => {
  if (ops.fileExtension === 'svg') {
    // SVG 文件的处理逻辑
    fileToBase64(ops.fileItem).then((fileRet) => {
      ops.updateStart();
      upload2dEditFile(ops.fileItem, ops.uploadFileType).then(async (resp) => {
        const ret = await createUserMaterial({ file_name: resp.key_prefix });
        if (!ret?.data) {
          ops.updateEnd(false, -1);
          return;
        }
        if (resp && resp.key_prefix) {
          if (!ops?.isApps) {
            ops.event?.emitEvent(EventNameCons.EventUpdateMaterial, ret.data);
            ops.canvasEditor?.addSvgFile(fileRet as string);
            ops.updateEnd(true, 0);
          }
        } else {
          ops.updateEnd(false, -1);
        }
      }).catch((error) => {
        // 处理上传错误
        console.error(error);
        ops.updateEnd(false, -1, error);
      });
    })
  } else if (ops.fileExtension === 'psd') {
    ops.updateStart();
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      const psd = await PSD.fromURL(dataUrl);
      psd.parse();
      const img = psd.image.toPng();
      const newFile = base64ToFile(img.src, ops.fileItem.name + ".webp");
      getImgCompressAndUpload(newFile, ops);
    };
    reader.readAsDataURL(ops.fileItem);
  } else if (ops.fileExtension === 'ai' || ops.fileExtension === 'pdf') {
    ops.updateStart();
    const reader = new FileReader();
    reader.onload = async (e) => {
      const pdfjs = await import('pdfjs-dist');

      // const storage = new IndexedDBAk();
      // // 打开数据库
      // await storage.open();
      // const arrayBufferPDF = await fetchAndStorage(storage, "LOCAL_PDF_WORK", '/pdf.worker.min.mjs.zip');
      // // 解压缩并加载 opencv.js
      // const jszip = new JSZip();
      // const zip = await jszip.loadAsync(arrayBufferPDF);
      // const workerFile = zip.file('pdf.worker.min.mjs');
      // console.log('=====uploadImageForCavas====start==workerFile=', workerFile)
      // const workerBlob = await workerFile!.async('blob');
      // const workerUrl = URL.createObjectURL(workerBlob);
      // pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;

      pdfjs.GlobalWorkerOptions.workerSrc = `/pdf.worker.min.js`;

      const arrayBuffer = reader.result as ArrayBuffer;
      console.log('=====uploadImageForCavas====start=')
      const loadingTask = pdfjs.getDocument(arrayBuffer);
      const pdf = await loadingTask.promise;

      const numPages = 1;
      const canvases = [];
      let totalHeight = 0;
      let maxWidth = 0;
      for (let i = 1; i <= numPages; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 1.5 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const renderContext = {
          canvasContext: context,
          viewport: viewport,
        };

        //@ts-ignore
        await page.render(renderContext).promise;
        canvases.push(canvas);
        totalHeight += canvas.height;
        maxWidth = Math.max(maxWidth, canvas.width);
      }

      // Create a single canvas to combine all pages
      const combinedCanvas = document.createElement('canvas');
      combinedCanvas.width = maxWidth;
      combinedCanvas.height = totalHeight;
      const combinedContext = combinedCanvas.getContext('2d');

      let yOffset = 0;
      for (let i = 0; i < canvases.length; i++) {
        const canvas = canvases[i];
        combinedContext!.drawImage(canvas, 0, yOffset);
        yOffset += canvas.height;
      }
      const combinedImage = combinedCanvas.toDataURL();
      const newFile = base64ToFile(combinedImage, ops.fileItem.name + ".webp");
      getImgCompressAndUpload(newFile, ops);
      // console.log('=====uploadImageForCavas====end=', combinedImage)
    };
    reader.readAsDataURL(ops.fileItem);
  } else if (/\/(?:jpeg|jpg|png|webp)/i.test(ops.fileItem.type)) {
    // 图片文件的处理逻辑
    ops.updateStart();
    getImgCompress(ops.fileItem, 1000, 0, 1).then((blob) => {
      var file: File = new File([blob], ops.fileItem.name, { type: blob.type, lastModified: Date.now() })
      upload2dEditFile(file, ops.uploadFileType, ops.projectId, ops.canvas_id).then(async (resp) => {
        if (resp && resp.key_prefix) {
          ops.uploadFileType === GetUpTokenFileTypeEnum.Edit2dLocal &&
            (async () => {
              const ret = await createUserMaterial({ file_name: resp.key_prefix });
              if (!ret?.data) {
                ops.updateEnd(false, -1);
                return;
              }
              ops.event?.emitEvent(EventNameCons.EventUpdateMaterial, ret.data);
            })();
          fileToBase64(file).then((fileRet) => {
            if (!ops?.isApps) {
              ops.canvasEditor?.addImage(fileRet,
                {
                  importSource: ops.uploadFileType,
                  fileType: ops.fileExtension,
                  key_prefix: resp.key_prefix
                });
            }
          })
          ops.updateEnd(true, 0);
        } else {
          ops.updateEnd(false, -1);
        }
      }).catch((error) => {
        // 处理上传错误
        console.error(error);
        ops.updateEnd(false, -1, error);
      });
    });
  }
}

const getImgCompressAndUpload = (newFile: File, ops: CavasUpdateOps) => {
  compressorImage1(newFile, 1000, 0, 1).then((blob) => {
    var file: File = new File([blob], ops.fileItem.name + ".webp", { type: blob.type, lastModified: Date.now() })
    upload2dEditFile(file, ops.uploadFileType, ops.projectId, ops.canvas_id).then(async (resp) => {
      if (resp && resp.key_prefix) {
        ops.uploadFileType === GetUpTokenFileTypeEnum.Edit2dLocal &&
          (async () => {
            const ret = await createUserMaterial({ file_name: resp.key_prefix });
            if (!ret?.data) {
              ops.updateEnd(false, -1);
              return;
            }
            ops.event?.emitEvent(EventNameCons.EventUpdateMaterial, ret.data);
          })();
        fileToBase64(file).then((fileRet) => {
          if (!ops?.isApps) {
            ops.canvasEditor?.addImage(fileRet,
              {
                importSource: ops.uploadFileType,
                fileType: ops.fileExtension,
                key_prefix: resp.key_prefix
              });
          }
        })
        ops.updateEnd(true, 0);
      } else {
        ops.updateEnd(false, -1);
      }
    }).catch((error) => {
      // 处理上传错误
      console.error(error);
      ops.updateEnd(false, -1, error);
    });
  });
}


export const getCanvasThumbnail = (currentCanvas: fabric.Canvas) => {
  return new Promise((resolve, reject) => {
    const workspace = currentCanvas.getObjects().find((item) => (item as any).id?.includes(WorkspaceID.WorkspaceCavas));
    var bgWidth = workspace?.width;
    var bgHeight = workspace?.height;

    if (!bgWidth || !bgHeight) {
      resolve('');
      return;
    }

    // 初始化边界值
    let minX = Number.MAX_VALUE;
    let minY = Number.MAX_VALUE;
    let maxX = 0;
    let maxY = 0;

    // 遍历所有图层，计算边界
    const coordsOne = currentCanvas.getObjects()[0].getCoords();
    currentCanvas.getObjects().forEach((obj, index) => {
      if (!(obj as any).id?.includes(WorkspaceID.WorkspaceCavas)) { // 跳过底层
        const coords = obj.getCoords();
        coords.forEach(({ x, y }, index) => {
          var zoom = currentCanvas.getZoom();
          var oneX = coordsOne[0].x / zoom;
          var oneY = coordsOne[0].y / zoom;
          x = x / zoom;
          y = y / zoom;

          if (index == 0 || index == 2) {
            x = x - oneX;
            y = y - oneY;
          } else if (index == 3 || index == 1) {
            x = x - oneX;
            y = y - oneY;
          }
          minX = Math.min(minX, x);
          minY = Math.min(minY, y);
          maxX = Math.max(maxX, x);
          maxY = Math.max(maxY, y);

        });
      }
    });

    minX = Math.max(minX, 0);
    minX = Math.min(minX, bgWidth!);
    minY = Math.max(minY, 0);
    minY = Math.min(minY, bgHeight!);

    maxX = Math.max(maxX, 0);
    maxX = Math.min(maxX, bgWidth!);
    maxY = Math.max(maxY, 0);
    maxY = Math.min(maxY, bgHeight!);

    // 计算offscreenCanvas的宽度和高度
    const offscreenCanvasWidth = maxX - minX;
    const offscreenCanvasHeight = maxY - minY;

    // 创建一个离屏Canvas
    const offscreenCanvas = document.createElement('canvas');
    offscreenCanvas.width = offscreenCanvasWidth;
    offscreenCanvas.height = offscreenCanvasHeight;
    const offscreenCtx = offscreenCanvas.getContext('2d');
    // 确保离屏Canvas的上下文存在
    // 手动绘制除底层以外的图层
    if (offscreenCtx) {
      offscreenCtx.save();
      offscreenCtx.translate(-minX, -minY);

      currentCanvas.getObjects().forEach((obj, index) => {
        if (!(obj as any).id?.includes(WorkspaceID.WorkspaceCavas) && offscreenCtx) { // 跳过底层
          obj.render(offscreenCtx!);
        }
      });
      offscreenCtx.restore();
      const dataURL = offscreenCanvas.toDataURL('image/png');
      // 导出离屏Canvas的图像数据
      resolve({ dataUrl: dataURL, minX: minX, minY: minY, width: offscreenCanvasWidth, height: offscreenCanvasHeight });
    }
  });
}

export const getPrintTar = (project_id: string) => {
  return getProjectDetail({ project_id: project_id }).then((resp) => {
    if (resp && resp.data) {
      var projectModel: ProjectModel = resp.data;
      projectModel.canvasesIndex = 0;
      // 返回 initEditorRendering 的 Promise
      return initEditorRendering(projectModel);
    } else {
      // 如果没有响应数据，返回或抛出错误
      return { result: -2, error: 'project id error:' };
    }
  });
};

export const initEditorRendering = (projectModel: ProjectModel) => {
  const promises: Promise<void>[] = [];
  projectModel?.canvases.forEach((canvas, index) => {
    console.log('printClick =download_url==', canvas.print_file.download_url, new Date().toISOString())
    ///未选中的画布，需要先下载json完整文件，并绘制到临时canvas里，然后生成tar包
    var printLayerModelNet: PrintLayerModel = JSON.parse(canvas.print_param!);
    const promise = ProjectManager.getInstance().getProjectJson(projectModel, index).then((json: string | undefined) => {
      if (!json) return;
      // 初始化fabric
      // @ts-ignore
      const tempCanvas = new fabric.Canvas(null, {
        width: canvas.base_map_width,
        height: canvas.base_map_height
      });
      console.log('printClick =开始渲染==', new Date().toISOString())
      return insertSvgFileTemp(json, tempCanvas).then(() => {
        console.log('printClick =渲染完成==', new Date().toISOString())
        return generateTar(projectModel, canvas, tempCanvas, printLayerModelNet, canvas.print_file.upload_url, "");
      });
    });
    promises.push(promise);
  });

  return Promise.all(promises).then(() => {
    console.log('success generating tar:');
    return { result: 1, error: 'null' };
  }).catch((error) => {
    console.error('Error generating tar:', error);
    return { result: -1, error: 'Error generating tar:' };
  });
}

function insertSvgFileTemp(jsonFile: string, canvas: fabric.Canvas): Promise<void> {
  // 加载前钩子
  return new Promise<void>((resolve, reject) => {
    downFontByJSON(jsonFile).then(() => {
      console.log('insertSvgFile===2222');
      canvas.loadFromJSON(jsonFile, () => {
        console.log('insertSvgFile===33333');
        canvas.renderAll();
        resolve();
      });
    })
  });
}

/*
* 生成当前tar包
*/
export async function generateTar(projectModel: ProjectModel, canvasInfo: CanvasesResInfo, canvas: fabric.Canvas, printLayerData: PrintLayerModel, uploadUrl: string, sn: string, editor?: Editor): Promise<void> {
  const printLayerModule = await import('src/templates/2dEditor/components/MainUi/MainUiRightComponent/PrintLayer/manager/PrintLayerManager');
  const printLayerManager = new printLayerModule.PrintLayerManager();

  printLayerManager.initLayoutId(canvas);
  printLayerManager.initLayerList(printLayerData, canvas);

  const promises: Promise<PrintLayerData>[] = [];
  printLayerData.printLayerData.forEach((layerData) => {
    if (layerData.layerNum > 0) {
      let promise: Promise<PrintLayerData>;
      switch (layerData.printType) {
        case PrintLayerType.printLayerType1:
          promise = printLayerManager!.getPrintPicWhiteInk(projectModel, projectModel?.project_info.is_standard_product, layerData, printLayerData, canvas);
          break;
        case PrintLayerType.printLayerType2:
          promise = printLayerManager!.getPrintPicColorInk(projectModel, projectModel?.project_info.is_standard_product, layerData, printLayerData, canvas, editor);
          break;
        case PrintLayerType.printLayerType3:
          promise = printLayerManager!.getPrintPicVarnishInk(projectModel, projectModel?.project_info.is_standard_product, layerData, printLayerData, canvas);
          break;
        default:
          promise = Promise.reject(new Error('Unknown print type'));
      }
      promises.push(promise);
    }
  });
  return Promise.all(promises).then((printLayerDatas) => {
    console.log('printClick =生图完成==', new Date().toISOString())
    return createAndDownloadTar(projectModel, printLayerDatas, printLayerData, uploadUrl, canvasInfo.thumb_file.upload_url, sn);
  });
}

export function base64ToUint8Array(base64: string) {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// 创建tar包并下载
async function createAndDownloadTar(projectModel: ProjectModel, printLayerDatas: PrintLayerData[], printLayerData: PrintLayerModel, uploadUrl: string, effectUploadUrl: string, sn: string): Promise<any> {
  const tarball = new Tar(); // 创建一个新的 tar 实例

  let textureData = {
    grayCmykUrl: "",
    grayGlosskUrl: "",
  }
  printLayerDatas.forEach((data, index) => {
    data.printTypeFileStr = data.printTypeFileStr + index;
    let prefix = data.printTypeFileStr;
    printLayerData.printLayerData.find((item) => item.printType === data.printType)!.printTypeFileStr = prefix;
    // for (let index = 0; index < data.layerNum; index++) {
    const filename = `${prefix}.png`;
    const fileData = base64ToUint8Array(data.dataUrl!.split(',')[1]); // 假设 data.dataUrl 是一个 Base64 编码的 Data URL
    tarball.append(filename, fileData);

    // 添加纹理图
    if (printLayerData.printModel == PrintModel.printModel8) {
      if (data.grayCmykUrl) {
        textureData.grayCmykUrl = data.grayCmykUrl;
        data.grayCmykFileStr = data.grayCmykFileStr! + index;
        const filename = `${data.grayCmykFileStr}.png`;
        const fileData = base64ToUint8Array(data.grayCmykUrl!.split(',')[1]);
        tarball.append(filename, fileData);
        let prefix = data.grayCmykFileStr;
        let cmykData: PrintLayerData = printLayerData.printLayerData.find((item) => item.printType === data.printType)!;
        cmykData.grayCmykFileStr = prefix;
        cmykData.grayCmykUrl = "";
      }
      if (data.grayGlosskUrl) {
        textureData.grayGlosskUrl = data.grayGlosskUrl;
        data.grayGlossFileStr = data.grayGlossFileStr! + index;
        const filename = `${data.grayGlossFileStr}.png`;
        const fileData = base64ToUint8Array(data.grayGlosskUrl.split(',')[1]);
        tarball.append(filename, fileData);

        let prefix = data.grayGlossFileStr;
        let glossData: PrintLayerData = printLayerData.printLayerData.find((item) => item.printType === data.printType)!;
        glossData.grayGlossFileStr = prefix;
        glossData.grayGlosskUrl = "";
      }
    }
    // }
  });

  for (const data of printLayerDatas) {
    //上传效果图
    if (data.printType === PrintLayerType.printLayerType2 && data.dataUrl) {
      const filename = 'mockUp.png'; // 你可以根据需要设置文件名
      const file = dataURLtoFile(data.dataUrl, filename);
      if (file) {
        // 压缩
        compressorImage1(file, 0, 0, 1, 200).then((blob) => {
          var fileRet: File = new File([blob], file.name, { type: blob.type, lastModified: Date.now() });
          if (effectUploadUrl) {
            /// 上传缩略图
            upload(effectUploadUrl, fileRet).then((uploadSuccess) => {
              // 上传成功的处理
            }).catch((error) => {
              console.error('Upload thumbnail error:', error, effectUploadUrl);
            });
          }
        }).catch((error) => {
          console.error('Error compressing image:', error);
        });
      } else {
        console.error('Failed to convert data URL to file');
      }
      break;
    }
  }
  //以前是非标品数据会再次上传，现在改成所有的都会上传;
  let retJson: PrintLayerModel = JSON.parse(JSON.stringify(printLayerData));
  retJson.printLayerData.forEach((data, index) => {
    data.printLayerObjIds = [];
  });
  updatePrintParams(projectModel, printLayerData);
  console.log(" ====createAndDownloadTar=====config.json===", retJson)
  const configData = new TextEncoder().encode(JSON.stringify(retJson));
  // 将 config.json 文件及其内容添加到 tarball 中
  tarball.append('config.json', configData);

  // 将 tar 包转换为 Blob
  const blobTar = new Blob([tarball.out], { type: 'application/x-tar' });
  const fileTar = new File([blobTar], "printLayers.tar", { type: 'application/x-tar' });
  const base64Tar = await blobToBase64(blobTar);
  const md5Tar = await blobToMd5(blobTar);
  // 等待上传tar包(pc的话不用等待，直接生成后跳转)
  var uploadResult: any = null;
  if (isPc()) {
    return new Promise(async (resolve, reject) => {
      try {
        console.log('====sendCommandToPcWithResponse===start==')
        StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.canvas_print_upload, 0);
        sendCommandToPcWithResponse(CustomPcAction.PrintNeedLocalData, async (data: any) => {
          console.log('====sendCommandToPcWithResponse===ret==', data)
          if (data === 1) {
            upload(uploadUrl, fileTar);
          } else {
            await upload(uploadUrl, fileTar);
          }
          StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.canvas_print_upload, 1, { sn: sn, data: data });
          resolve({ uploadResult, base64Tar, md5Tar, projectModel, textureData });
        }, { sn: sn });
      } catch (error) {
        StatisticalReportManager.getInstance().addStatisticalEvent(CONS_STATISTIC_TYPE.canvas_print_upload, -1);
        reject(error);
      }
    })
  } else {
    uploadResult = await upload(uploadUrl, fileTar);
    return { uploadResult, base64Tar, md5Tar, projectModel, textureData };
  }
  console.log('printClick =上传完成==', new Date().toISOString())

}

const updatePrintParams = (projectModel: ProjectModel, printLayerModel: PrintLayerModel) => {
  let printLayerModelTemp: PrintLayerModel = { ...printLayerModel };
  printLayerModelTemp.printLayerData.forEach((data, index) => {
    data.printLayerObjIds = [];
  })
  var itemRequest: ProjectCavasItemUpdateRequestModel = {
    canvas_id: projectModel!.canvases[projectModel!.canvasesIndex].canvas_id,
    print_param: JSON.stringify(printLayerModelTemp),
  }

  var request: ProjectCavasUpdateRequestModel = {
    project_id: projectModel!.project_info.project_id,
    canvases: [itemRequest],
  }

  updateProjectCavas(request);
  projectModel!.canvases[projectModel!.canvasesIndex].print_param = JSON.stringify(printLayerModel);
}
/**
 * 
 * @param upperD 上直径
 * @param bottomD 下直径
 * @param hasHandle 是否带把
 */
/**
 * 
 * @param upperD 上直径
 * @param bottomD 下直径
 * @param hasHandle 是否带把
 */
export const getCylindricalIcon = (upperD: number, bottomD: number, hasHandle: boolean) => {
  let icons = [];

  if (upperD === bottomD) {
    // 圆柱
    if (hasHandle) {
      icons = [ic_column_l_h, ic_column_c, ic_column_r_h];
    } else {
      icons = [ic_column_l, ic_column_c, ic_column_r];
    }
  } else if (upperD > bottomD) {
    // 锥形
    if (hasHandle) {
      icons = [ic_cone_l_h, ic_cone_c, ic_cone_r_h];
    } else {
      icons = [ic_cone_l, ic_cone_c, ic_cone_r];
    }
  } else {
    // 梯形
    if (hasHandle) {
      icons = [ic_trapezoid_l_h, ic_trapezoid_c, ic_trapezoid_r_h];
    } else {
      icons = [ic_trapezoid_l, ic_trapezoid_c, ic_trapezoid_r];
    }
  }

  return icons;
}

/**
 * 
 * @param width px
 * @param height px
 * @returns 
 */
export const getRotaryParams = (width: number, height: number, handHeight?: number): RotaryParams => {
  let upperD = Math.round(StringUtil.pixelToMm(width, CanvasParams.canvas_dpi_def) / Math.PI);
  let bottomD = Math.round(StringUtil.pixelToMm(width, CanvasParams.canvas_dpi_def) / Math.PI)
  let r = upperD > bottomD ? upperD : bottomD;
  let horizontalProhibited = getHorizontalProhibited(r, handHeight ? handHeight : CanvasParams.canvas_handle_height_def);
  let ret: RotaryParams = {
    upperD: upperD,
    bottomD: bottomD,
    horizontalProhibited: horizontalProhibited,
    verticalRecommandedBlanklen: CanvasParams.verticalRecommandedBlanklen,
    cupHeight: Math.round(StringUtil.pixelToMm(height, CanvasParams.canvas_dpi_def)),
    hasHandle: false,
  }
  return ret;
}
/**
 * @param r 半径
 * @param handleHeight mm
 */
export const getHorizontalProhibited = (r: number, handleHeight: number) => {
  // 计算 cos(Θ)
  const cosTheta = r / (r + handleHeight);
  // 计算 Θ (弧度)
  const theta = Math.acos(cosTheta);
  // 计算单侧不可打印长度
  const prohibitedLength = r * theta;
  // 检查是否为整数，如果不是则保留一位小数
  if (Number.isInteger(prohibitedLength)) {
    return prohibitedLength;
  } else {
    return parseFloat(prohibitedLength.toFixed(1));
  }
}

export const fetchAndStorage = async (storage: IndexedDBAk, key: string, url: string): Promise<ArrayBuffer> => {
  await storage.open();
  let arrayBuffer = await storage.get(key);
  if (!arrayBuffer) {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('Network response was not ok.');
    }
    arrayBuffer = await response.arrayBuffer();
    await storage.put(key, arrayBuffer);
  }
  return arrayBuffer;
}

/**
 * 过滤canvas，光油贴图，不参与打印效果图合成
 * @param tempCanvas 
 */
export const filterTextureElements = (sourceCanvas: fabric.Canvas, tempCanvas: fabric.StaticCanvas) => {
  const sourceElements = sourceCanvas.getObjects();
  let filterIds: string[] = [];
  const sourceProcessGroup = (group: fabric.Group) => {
    const childElements = group.getObjects();
    if ((group as any)._isTextureGroup) {
      let hasGlossChild = false;
      // 检查是否有 GLOSS 类型的子元素
      childElements.forEach((textureChild: any) => {
        if ((textureChild as any).textureType === TextureType.GLOSS) {
          hasGlossChild = true;
        }
      });
      if (hasGlossChild) {
        filterIds.push((group as any).id);
      }
    } else {
      childElements.forEach((textureChild: any) => {
        if (textureChild.type === FabricObjectType.Group && !(textureChild as any).isSVG) {
          sourceProcessGroup(textureChild);
        }
      });
    }
  }
  sourceElements.forEach((element: any) => {
    if (element.type === FabricObjectType.Group && !(element as any).isSVG) {
      sourceProcessGroup(element);
    }
  });

  const processGroup = (group: fabric.Group) => {
    const childElements = group.getObjects();
    if ((group as any)._isTextureGroup) {
      if (filterIds.includes((group as any).id)) {
        // childElements.length > 1 && childElements[0].set('opacity', 1);
        childElements.length > 1 && childElements[1].set('opacity', 0);
      }
    } else {
      childElements.forEach((textureChild: any) => {
        if (textureChild.type === FabricObjectType.Group && !(textureChild as any).isSVG) {
          processGroup(textureChild);
        } else if ((textureChild as any).textureType === TextureType.GLOSS) {
          textureChild.set('opacity', 0);
        }
      });
    }
  };

  const elements = tempCanvas.getObjects();
  elements.forEach((element: any) => {
    if (element.type === FabricObjectType.Group && !(element as any).isSVG) {
      processGroup(element);
    } else if ((element as any).textureType === TextureType.GLOSS) {
      // 底图光油纹理
      element.set('opacity', 0);
    }
  });
  tempCanvas.renderAll();
};

