
export enum colorTheme {
  light = 0,
  dark = 1,
}
export const colorsLight = {
  color_primary: '#10D16A',
  color_text_tab_select: '#10D16A',
  color_text_tab_normal: '#939393',
  color_bar_select: '#10D16A',
  color_bar_normal: '#00000016',
  color_line: '#99999966',
  color_txt_12: '#00000096',
  color_txt_14: '#000',
  color_txt_16: '#000',
  color_txt_18: '#999',
  color_txt_20: '#fff',
  color_txt_24: '#000',
  color_trans: '#00000000',
  color_background1: '#FFFFFF96',
  color_background_menu_btn_item: '#F2F2F2',
  color_btn_cus_normal: '#e0e0e0',
  color_btn_cus_active: '#cccccc',
  color_btn_light_normal: '#10D16A',
  color_btn_light_active: '#10D16A80',
  color_img_bg: '#F2F2F2',
  color_border_bg: '#99999966',


};

export const colorsDark = {
  color_primary: '#10D16A',
};

export function getColors() {
  return colorsLight;
};

export function initTheme() {
  applyTheme(colorTheme.light);
}

// 动态设置CSS变量
export function applyTheme(themeName: colorTheme) {
  var theme;
  if (themeName === colorTheme.dark) {
    theme = colorsDark;
  } else {
    theme = colorsLight;
  }
  for (const [key, value] of Object.entries(theme)) {
    document.documentElement.style.setProperty(`--${key}`, value);
  }
}